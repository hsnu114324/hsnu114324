*** Settings ***
Library  OperatingSystem
Library  String

*** Variables ***
#${FILE_PATH}  200.txt
#${TARGET_STRING}  1 
${shift_line_origin}  1
${shift_num_origin}  3 
${folder_file_should_num}  25
${DEST_DIR}    ./Dest/
${ROOT_DIR}    ./../Outbound       

*** Test Cases ***
Copy Specific S3 Files
    # 確保目標資料夾存在
    Create Directory    ${DEST_DIR}               
    
    # 1. 取得根目錄下所有的子資料夾路徑
    ${top_folders}=    List Directories In Directory    ${ROOT_DIR}    absolute=True
    
    FOR    ${folder}    IN    @{top_folders}
        # 2. 組合出目標路徑：子資料夾/FDBK31/S3
        ${target_path}=    Set Variable    ${folder}/FDBK31/S3
        
        # 3. 檢查這個特定的 S3 資料夾是否存在
        ${dir_exists}=    Run Keyword And Return Status    Directory Should Exist    ${target_path}
        
        IF    ${dir_exists}
            # 4. 搜尋符合 *123*.txt 的檔案
            ${files}=    List Files In Directory    ${target_path}    pattern=*100091*.[tT][xX][tT]    absolute=True
            
            # 5. 執行複製
            FOR    ${file}    IN    @{files}
                Log    正在複製: ${file}
                Copy File    ${file}    ${DEST_DIR}
            END
        END
    END


*** Keywords ***

Read_File_To_Cells
    [Arguments]  ${filepath}
    ${lines}=  Read File  ${FILE_PATH}
    FOR  ${line}  IN  @{lines}
        ${cells}=  Split String  ${line}  
    END
    [Return]  ${cells}

Read File
    [Arguments]  ${filepath}
    ${file_content}=  Get File  ${filepath}
    ${lines}=  Split String  ${file_content}  \n
    [Return]  ${lines}

