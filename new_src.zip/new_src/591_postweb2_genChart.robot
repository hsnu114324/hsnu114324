*** Keywords ***
591_postweb2_genChart



    post_postweb2_591FrontEndlogin  https://sale.591.com.tw

    ${591FrontEndContent1_title}=  post_postweb2_Check591FrontEndContent1_title

    Append_To_File  test.txt  ${591FrontEndContent1_title}

    ${current_page}=   Get Page IDs    ACTIVE    ACTIVE    ACTIVE
    ${all_pages}=      Get Page IDs    CURRENT   CURRENT   ALL
    
#    Click    xpath=//*[@id="app"]/div[4]/div[2]/section/div[2]/div[1]/div[3]

    Browser.Click    xpath=//*[@id="app"]/div[4]/div[2]/section/div[2]/div[2]/div[3]

    take_screenshot
#    Set Browser Timeout  20s

    ${current_page}=   Get Page IDs    ACTIVE    ACTIVE    ACTIVE
    ${all_pages}=      Get Page IDs    CURRENT   CURRENT   ALL
    ${previous} =    Switch Page      NEW

    ${current_page}=   Get Page IDs    ACTIVE    ACTIVE    ACTIVE
    ${all_pages}=      Get Page IDs    CURRENT   CURRENT   ALL

    ${str_title1}=  Get_text  xpath=//*[@id="container"]/div[2]/div/div[1]/h1

    ${str_title2}=  Get_text  xpath=//*[@id="container"]/section[2]/div[2]/div[1]/div/div[1]/span[1]

    ${str_title3}=  Get_text  xpath=//*[@id="container"]/section[2]/div[2]/div[1]/div/div[2]/div[1]


    ${str_title4}=  Get_text  xpath=//*[@id="container"]/section[2]/div[2]/div[2]/div[3]/div[1]


    ${str_title5}=  Get_text  xpath=//*[@id="container"]/section[2]/div[2]/div[4]/div[3]/span[2]

#    Click    xpath=//*[@id="container"]/section[2]/div[2]/div[4]/div[3]/span[2]/a

    Browser.Click    xpath=//*[@id="nav-menu-map"]

    ${page_source}=   Get_Page_Source

    log  ${page_source}

#    ${root}=  Parse XML  ${page_source} 


    ${file_split}=    Split String    ${page_source}    lat=

    ${file_split_count}=    Get length    ${file_split}


    FOR  ${i}  IN RANGE  1  ${file_split_count} 
#    FOR  ${i}  IN RANGE  1  10

        Log  ${file_split}[${i}]
        ${sensor_match}=    Get Regexp Matches    ${file_split}[${i}]    &lng=
        IF    ${sensor_match}
            Log   ${file_split}[${i}]
            ${file_split2}=    Split String    ${file_split}[${i}]    &select


#       Log_To_Console   2 ${i}
#        Should Be True    ${sensor_data}[1] > ${inlet_rotor_minimum}
#            Should Be True    ${sensor_data}[1] < ${inlet_rotor_maximum}
        END
    END


    Log  ${file_split2}[0]
    ${file_split3}=    Split String    ${file_split2}[0]    &lng=
    ${file_split3_count}=    Get length    ${file_split3}

    FOR  ${i}  IN RANGE  0  ${file_split3_count}   

        Log  ${file_split3}[${i}]  

    END


#    Set Browser Timeout  60s
#    Click    xpath=//html/body/div[6]/a[1]

#    Set Browser Timeout  20s
#    take_screenshot

#    ${str_title6}=  Get_text  xpath=//*[@id="detail-map-free"] >>> xpath=//*[@id="mapDiv"]/div/div[3]/div[3]/div/div/div/div/div[1]/div[1]



#    Append_To_File  chartjsfile2.txt  ${str_title2}


    ${chartjsfile1_content}=  post_chart_getchartjsfile1
    ${chartjsfile2_content}=  post_chart_getchartjsfile2
    ${chartjsfile3_content}=  post_chart_getchartjsfile3
    ${chartjsfile4_content}=  post_chart_getchartjsfile4
    ${chartjsfile5_content}=  post_chart_getchartjsfile5

    ${chartjsfile2_content}=  Set_Variable  ${chartjsfile2_content}${str_title2}
    Log  ${chartjsfile2_content}


    ${tr_head}=  Set_Variable   <tr>
    ${tr_tail}=  Set_Variable   </tr>
    ${th_head}=  Set_Variable   <th scope="row">
    ${th_tail}=  Set_Variable   </th>
    ${td_head}=  Set_Variable   <td>
    ${td_tail}=  Set_Variable   </td>



    ${chartjsfile4_content}=  Set_Variable  ${chartjsfile4_content} ${tr_head} ${th_head} ${str_title1} ${th_tail} ${td_head} ${file_split3}[0] ${td_tail} ${td_head} ${file_split3}[1] ${td_tail} ${tr_tail}


    Log  ${chartjsfile4_content}

    Create_File  chart.html
    ${content}=  Get_File     chart.html
    Log  ${content}

    Remove_File  chart.html

    post_chart_appendhtml  ${chartjsfile1_content}
    post_chart_appendhtml  ${chartjsfile2_content}
    post_chart_appendhtml  ${chartjsfile3_content}
    post_chart_appendhtml  ${chartjsfile4_content}
    post_chart_appendhtml  ${chartjsfile5_content}


