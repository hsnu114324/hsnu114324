*** Variables ***
${switch_upgrade_version}      80
${switch_downgrade_version}    70
${switch_upgrade_image}        UT20_SW_CPLD_v008_enc.hpm
${switch_downgrade_image}      UT20_SW_CPLD_v007_enc.hpm


*** Keywords ***
cpld_ipmi_update_switch

	wistron_bmcweb_logout
###
  FOR  ${i}  IN RANGE  2

	${CpldVersion}=   wistron_ipmi_GetSwitchCpldVersion
        Log_To_Console  CpldVerion ${CpldVersion}

	${CpldVersion_match}=	Get Regexp Matches	${CpldVersion}		${switch_upgrade_version}
	IF	${CpldVersion_match}
		${CpldVersion_major}	Set Variable	${EMPTY}
		${CpldVersion_major}	Set Variable	${switch_downgrade_version}
		Log_To_Console  CpldVersion_major ${CpldVersion_major}
		Log_To_Console  ${CpldVersion}
		Log_To_Console  ${switch_downgrade_image}
		wistron_ipmi_updatecpld_switch  ${switch_downgrade_image}
	ELSE
		${CpldVersion_major}	Set Variable	${EMPTY}
		${CpldVersion_major}	Set Variable	${switch_upgrade_version}
		Log_To_Console  CpldVersion_major ${CpldVersion_major}
		Log_To_Console  ${CpldVersion}
		Log_To_Console  ${switch_upgrade_image}
		wistron_ipmi_updatecpld_switch  ${switch_upgrade_image}
	END


###

	${target_CpldVersion}=   wistron_ipmi_GetSwitchCpldVersion
    	Should Be Equal    ${target_CpldVersion}    ${CpldVersion_Major}

  END



