*** Variables ***
${SOL_BIOS_OUTPUT}    ubuntu
${IPMI_SOL_LOG_FILE}    IPMI_SOL_LOG_FILE.txt

#${BROWSER}  
#${URL}      https://www.google.com.tw/
${URL}	    https://finmindtrade.com/
#${URL}      https://finmindtrade.com/analysis/#/data/document


${xpath_finmind_processing_image_1}	xpath=/html/body/div/div[1]/div/div[8]
${xpath_finmind_processing_image_2}	xpath=//*[@id="Layer_1"]

#${xpath_finmind_login1_element}		xpath=/html/body/div/header[1]/div/div/div[2]/div[1]/ul/li[1]/a

${xpath_finmind_login0_element}		xpath=/html/body/div/header[1]/div/div/div/div[2]/ul/li[1]/a
${xpath_finmind_login2_element}		xpath=//*[@id="app"]/div/div[1]/div[1]/div[2]/div/div/div/div/div[2]/button
${xpath_finmind_login3_element}  	xpath=//*[@id="app"]/div/div[1]/div[1]/div[2]/div/div/div/div/div[1]/a


${xpath_finmind_select_button_pre0}	xpath=//*[@id="app"]/div/div[2]/div[2]/section/div[1]/div/div[8]/a/span
${xpath_finmind_select_button_0}	xpath=//*[@id="app"]/div/div[2]/div[2]/section/div[1]/div/div[7]/a/span
#${xpath_finmind_select_button_1}	xpath=//*[@id="__BVID__101___BV_tab_button__"] 
#${xpath_finmind_select_button_1}   	//*[contains(., '技術面')]
${xpath_finmind_select_button_1}   	//*[contains(text(), '技術面')]
#${xpath_finmind_select_button_2}	xpath=//*[@id="__BVID__106___BV_tab_button__"] 
${xpath_finmind_select_button_2}   	//*[contains(text(), '股價日成交資訊')]
#${xpath_finmind_select_button_3}	xpath=//*[@id="__BVID__106"]/div/button
#${xpath_finmind_select_button_3}   	//*[contains(text(), '股價日成交資訊')]/div/button
${xpath_finmind_select_button_3} 	xpath=/html/body/div/div/div[3]/div[1]/div/div[2]/div/div/div/div/div/div[2]/div[1]/div/div[2]/div[3]/div/button


${xpath_finmind_select_button_4}	xpath=//*[@id="app"]/div/div[3]/div[1]/div/div[3]/div/div/div[1]/div[1]/button


${xpath_finmind_select_space} 		xpath=/html/body/div/div/div[3]/div[1]/div/div[2]/div/div/div/div/h4

${xpath_finmind_string_date} 		xpath=/html/body/div/div/div[3]/div[1]/div/div[3]/div/div/div[2]/div/div/div[2]/div/table/thead/tr/th[1]/span

#${xpath_finmind_date_input}	xpath=//*[@id="__BVID__106"]/div/div/div/div/div/input

${xpath_finmind_date_input} =  xpath=/html/body/div/div/div[3]/div[1]/div/div[2]/div/div/div/div/div/div[2]/div[1]/div/div[2]/div[3]/div/div/div/div/div/input

${xpath_finmind_full_member_user_input}	xpath=//*[@id="exampleInput1"]
${xpath_finmind_full_member_password_input}	xpath=//*[@id="exampleInput2"]
${xpath_finmind_full_member_button}	xpath=//html/body/div/div/div/div/div/div/div[1]/div/div[2]/div[2]/button

${finmind_full_member_user}	tw.shaohung@gmail.com
${finmind_full_member_password}	jy99jy88

${xpath_full_member_warning}	xpath=//*[@id="app"]/div/div[3]/div[1]/div/div[3]/div/div/h4
${xpath_full_member_warning2}	xpath=//*[@id="app"]/div/div[3]/div[1]/div/div[3]/div/div/h4
${xpath_finmind_string_element}	xpath=//*[@id="inspire"]/div/div/div[1]

${xpath_finmind_timeout_value}	3s

#${finmind_target_date}		2023-03-01 ~ 2023-03-01


${dir_download}		finmind_folder
#${dir_download}     C:/Users/714838/Downloads/new_src/finmind_folder

*** Keywords ***
test_finmind_full_member_login

  [Arguments]  ${start_date}  ${end_date}


#    ${folder}=    set variable    C:/Users/714838/Downloads/new_src/finmind_folder    # 更換成目標資料>夾的路徑
    ${folder}=    set variable    finmind_folder    # 更換成目標資料>夾的路徑


    ${max_file}    Set Variable    none
    ${max_num}    Set Variable    0
    ${files}    OperatingSystem.List_Files_In_Directory    ${folder}    *.csv

    FOR    ${file}    IN    @{files}
        ${file_split}=    Split String    ${file}    .
        Log_To_Console  ${file_split}[0]
        ${file_num}=  Convert_Date  ${file_split}[0]    result_format=%Y%m%d    date_format=%Y-%m-%d
        ${num}    Evaluate    ${file_num}
        IF    ${num} > ${max_num}
            ${max_file}    Set Variable    ${file}
            ${max_num}    Set Variable    ${num}
        END
    END
    Log_To_Console    Max CSV file: ${max_file}
    Log    Max CSV file: ${max_file}
    Log_To_Console    Max num: ${max_num}
    ${int_max_num}=    Convert_To_Integer    ${max_num}
    ${str_max_num}=    Convert_To_String    ${max_num}
    Log_To_Console    int Max num: ${int_max_num}
    Log_To_Console    str Max num: ${str_max_num}


#  ${date_range}=  finmind_GetDateRange  ${start_date}  ${end_date}
  ${date_range}=  finmind_GetDateRange  ${str_max_num}  ${end_date}
 

#    Log_To_Console  ${date_obj_range}
#    Log  ${date_obj_range}

#   finmind_DynamicDateRange
#    ${date}=    Set Variable    20230201

#    Open Browser    ${URL}    ${BROWSER}
#    Open Browser    ${URL}    ${GUI_BROWSER}
#    Maximize Browser Window
    
    log  ${URL}
    post_postweb2_finmindFrontEndlogin  ${URL}
    
    
#    Input Text      name=q    robot framework
#    Press Keys      name=q    RETURN
#    Wait Until Page Contains Element    css=.g
#    Title Should Be  FinMind
    
    ${title}=  Get Title
    IF  '${title}' != 'FinMind'
        Fail
    END	 
	     

#    Launch Browser And Login GUI
#    Wait Until Page Contains    FinMind    timeout=${xpath_finmind_timeout_value}

#    Wait Until Element Is Not Visible    ${xpath_finmind_processing_image_1}    timeout=${xpath_finmind_timeout_value}

    Wait For Elements State     ${xpath_finmind_processing_image_1}    hidden    timeout=60s

#    Wait Until Element Is Visible    ${xpath_finmind_login1_element}    timeout=${xpath_finmind_timeout_value}

    Wait For Elements State     ${xpath_finmind_login0_element}    visible    timeout=10s


    Get Element States  xpath=/html/body/div/header[1]/div/div/div/div[1]/a/img
    Get Element States  xpath=/html/body/div/header[1]/div/div/div/div[2]/ul/li[1]/a

    sleep  1s
#    Click_Element  ${xpath_finmind_login1_element}
#    Browser.Click  xpath=/html/body/div/header[1]/div/div/div/div[2]/ul/li[1]/a
    Browser.Click   ${xpath_finmind_login0_element}



#    Wait_Until_Element_Is_Visible    ${xpath_finmind_login2_element}    timeout=10s
#    ${login2} =    Run_Keyword_And_Return_Status  Wait For Elements State  ${xpath_finmind_login2_element}  visible
#    Log_To_Console  ${login2}
#    IF  '${login2}' == 'True'
#	Log_To_Console	find xpath_finmind_login2_element
#    ELSE
#    	Wait_Until_Element_Is_Visible    ${xpath_finmind_login3_element}    timeout=10s
    	${login3} =    Run_Keyword_And_Return_Status    Wait For Elements State  ${xpath_finmind_login3_element}  visible
	IF  '${login3}' == 'True'
		Log_To_Console  find xpth_finmind_login3_element

    		Browser.Click  ${xpath_finmind_login3_element}
    		Fill Text	${xpath_finmind_full_member_user_input}		${finmind_full_member_user} 
    		Fill Text	${xpath_finmind_full_member_password_input}     ${finmind_full_member_password}
    		sleep  1s
    		Browser.Click	${xpath_finmind_full_member_button}      

		Take Screenshot

	ELSE
    		Log_To_Console  nothing!
	END
#    END

    Take Screenshot
    sleep  10s

#    Click_Element  ${xpath_finmind_login3_element}
#    Input_Text	${xpath_finmind_full_member_user_input}		${finmind_full_member_user} 
#    Input_Text	${xpath_finmind_full_member_password_input}     ${finmind_full_member_password}
#    sleep  1s
#    Click_Element	${xpath_finmind_full_member_button}      











  FOR  ${date}  IN  @{date_range}
    ${finmind_target_date}=    Set Variable    ${date} ~ ${date}
    Log    ${finmind_target_date}

    Wait For Elements State    ${xpath_finmind_select_button_pre0}  visible    timeout=${xpath_finmind_timeout_value}
    Browser.Click  ${xpath_finmind_select_button_pre0}
#         Take Screenshot
    Wait For Elements State    ${xpath_finmind_select_button_0}  visible    timeout=${xpath_finmind_timeout_value}
    Browser.Click  ${xpath_finmind_select_button_0}
#         Take Screenshot
    Wait For Elements State    ${xpath_finmind_select_button_1}  visible    timeout=${xpath_finmind_timeout_value}
    Browser.Click  ${xpath_finmind_select_button_1}
#         Take Screenshot

    Wait For Elements State    ${xpath_finmind_select_button_2}  visible    timeout=${xpath_finmind_timeout_value}
    Browser.Click  ${xpath_finmind_select_button_2}
#        Take Screenshot
    Clear_Text 	${xpath_finmind_date_input}	
    Fill_Text	${xpath_finmind_date_input}	${finmind_target_date}
    Wait For Elements State    ${xpath_finmind_select_button_3}  visible   timeout=${xpath_finmind_timeout_value}
#    sleep  1s
    Browser.Click  ${xpath_finmind_select_space}

#    sleep  1s
    Clear_Text 	${xpath_finmind_date_input}	
    Fill_Text	${xpath_finmind_date_input}	${finmind_target_date}
    Wait For Elements State    ${xpath_finmind_select_button_3}  visible    timeout=${xpath_finmind_timeout_value}
#    sleep  1s
    Browser.Click  ${xpath_finmind_select_space}


#    sleep  10s
#    sleep  1s
    Browser.Click  ${xpath_finmind_select_button_3}
        Take Screenshot

#    sleep  1s
#    Clear_Element_Text 	${xpath_finmind_date_input}	
#    Input_Text	${xpath_finmind_date_input}	${finmind_target_date}
#    Wait Until Element Is Visible    ${xpath_finmind_select_button_3}    timeout=${xpath_finmind_timeout_value}
#    sleep  1s
#    Click_Element  ${xpath_finmind_select_space}
#    sleep  1s
#    Click_Element  ${xpath_finmind_select_button_3}
#        Capture Page Screenshot




    sleep  3s
    Wait For Elements State    ${xpath_finmind_processing_image_2}  hidden    timeout=60s
    sleep  1s
    ${warning} =    Run_Keyword_And_Return_Status    Wait For Elements State   ${xpath_full_member_warning2}  visible  timeout=${xpath_finmind_timeout_value}
    ${warning_element_text}  Get Text  ${xpath_full_member_warning2}
    Log_To_Console  ${warning}
#    IF  '${warning}' == 'True'
    IF  '${warning_element_text}' == '查無資料。'
#	Log_To_Console	should login full member
	Log_To_Console	no data!
	Log	no data!
#        Capture Page Screenshot
	CONTINUE For Loop
    ELSE
    	Log_To_Console  ok!
    END
#    Capture Page Screenshot


    Remove Files  ${dir_download}${/}股價日成交資訊*.csv


    Wait For Elements State    ${xpath_finmind_processing_image_2}  hidden    timeout=60s
#    Click_Element  ${xpath_finmind_select_button_4}
#    sleep  1s
#    Capture Page Screenshot

#    WHILE  True
    	
#    	${string_element_text}  Get Text  ${xpath_finmind_string_element}
#	Log_To_Console	${string_element_text}

#        ${string_element_text_match}=    Get Regexp Matches    ${string_element_text}    股價日成交資訊
#        IF    ${string_element_text_match}
#               Log_To_Console    string_element_text_match ${string_element_text_match}
#               Log_To_Console    string_element_text ${string_element_text}
##                Should Be True    ${sensor_data}[1] > ${inlet_rotor_minimum}
##                Should Be True    ${sensor_data}[1] < ${inlet_rotor_maximum}
#	ELSE
#               Log_To_Console    string_element_text_match ${string_element_text_match}
#               Log_To_Console    string_element_text ${string_element_text}
#		BREAK
#        END

#        sleep  1s
#        Click_Element  ${xpath_finmind_select_button_4}
#        Capture Page Screenshot
#    END


#    Capture Page Screenshot


    WHILE  True


#	    sleep  3s
	    Wait For Elements State    ${xpath_finmind_processing_image_2}  hidden    timeout=60s
	    sleep  1s
	    ${warning} =    Run_Keyword_And_Return_Status    Wait For Elements State   ${xpath_full_member_warning2}  visible  timeout=${xpath_finmind_timeout_value}
	    ${warning_element_text}  Get Text  ${xpath_full_member_warning2}
	    Log_To_Console  ${warning}
	    IF  '${warning_element_text}' == '查無資料。'
		Log_To_Console	no data!
		Log	no data!
#	        Capture Page Screenshot
		BREAK
	    ELSE
	    	Log_To_Console  ok!
	    END
#	    Capture Page Screenshot





    	
    	${string_element_text}  Get Text  ${xpath_finmind_string_element}
	Log_To_Console	${string_element_text}

        ${string_element_text_match}=    Get Regexp Matches    ${string_element_text}    股價日成交資訊
        IF    ${string_element_text_match}
               Log_To_Console    string_element_text_match ${string_element_text_match}
               Log_To_Console    string_element_text ${string_element_text}
#                Should Be True    ${sensor_data}[1] > ${inlet_rotor_minimum}
#                Should Be True    ${sensor_data}[1] < ${inlet_rotor_maximum}


#		sleep  3s
	    	${string_element_date}  Get Text  ${xpath_finmind_string_date}
		Log_To_Console	${string_element_date}
	
	        ${string_element_date_match}=    Get Regexp Matches   ${string_element_date}     日期
	        IF    ${string_element_text_match}
	               Log_To_Console    string_element_date_match ${string_element_date_match}
	               Log_To_Console    string_element_date ${string_element_date}
	#                Should Be True    ${sensor_data}[1] > ${inlet_rotor_minimum}
	#                Should Be True    ${sensor_data}[1] < ${inlet_rotor_maximum}
			BREAK
		ELSE
	               Log_To_Console    string_element_date_match ${string_element_date_match}
	               Log_To_Console    string_element_date ${string_element_date}
			sleep  1s

			    sleep  1s
			    Clear_Element_Text 	${xpath_finmind_date_input}	
			    Input_Text	${xpath_finmind_date_input}	${finmind_target_date}
			    Wait For Elements State    ${xpath_finmind_select_button_3}  visible    timeout=${xpath_finmind_timeout_value}
			    sleep  1s
			    Browser.Click  ${xpath_finmind_select_space}			
	        END

	ELSE
               Log_To_Console    string_element_text_match ${string_element_text_match}
               Log_To_Console    string_element_text ${string_element_text}
        END

        ${string_element_text_match}=    Get Regexp Matches    ${string_element_text}    Loading... Please wait
        IF    ${string_element_text_match}
               Log_To_Console    string_element_text_match ${string_element_text_match}
               Log_To_Console    string_element_text ${string_element_text}
#                Should Be True    ${sensor_data}[1] > ${inlet_rotor_minimum}
#                Should Be True    ${sensor_data}[1] < ${inlet_rotor_maximum}
		sleep  1s
	ELSE
               Log_To_Console    string_element_text_match ${string_element_text_match}
               Log_To_Console    string_element_text ${string_element_text}
        END







        sleep  3s
#        Click_Element  ${xpath_finmind_select_button_4}
#        Capture Page Screenshot
    END



    sleep  1s
    Wait For Elements State    ${xpath_finmind_processing_image_2}  hidden   timeout=60s
    sleep  1s
    ${warning} =    Run_Keyword_And_Return_Status    Wait For Elements State   ${xpath_full_member_warning2}  visible  timeout=${xpath_finmind_timeout_value}
    ${warning_element_text}=  Get Text  ${xpath_full_member_warning2}
    Log_To_Console  ${warning}
    IF  '${warning_element_text}' == '查無資料。'
	Log_To_Console	no data!
	Log	no data!
#        Capture Page Screenshot
	CONTINUE FOR LOOP
    ELSE
    	Log_To_Console  ok!
    END
#    Capture Page Screenshot





    Remove Files  ${dir_download}${/}股價日成交資訊*.csv


#    ${dl_promise}          Promise To Wait For Download    saveAs=C:/Users/714838/Downloads/股價日成交資訊.csv
    ${dl_promise}          Promise To Wait For Download   saveAs=${dir_download}/股價日成交資訊.csv 

    Browser.Click  ${xpath_finmind_select_button_4}
    ${file_obj}=           Browser.Wait For    ${dl_promise}
    File Should Exist      ${file_obj}[saveAs]
#    Should Be True         ${file_obj.suggestedFilename}



    WHILE  True
    	
    	${file_exists}=  Run Keyword And Return Status  OperatingSystem.File_Should_Exist  ${dir_download}/股價日成交資訊.csv
    	#Run Keyword If  ${file_exists}  BREAK
    	IF  ${file_exists}  BREAK
#        sleep  1s
#        Capture Page Screenshot

    END

    


    # 檢查test1.csv是否存在
    #${file_exists}=  Run Keyword And Return Status  OperatingSystem.File_Should_Exist  ${dir_download}/股價日成交資訊.csv
    #Run Keyword If  ${file_exists}  Rename File  ${dir_download}/股價日成交資訊.csv  ${dir_download}/test2.csv
    OperatingSystem.File_Should_Exist  ${dir_download}${/}股價日成交資訊.csv
    Wait Until Created    ${dir_download}${/}股價日成交資訊.csv
    Move File  ${dir_download}${/}股價日成交資訊.csv  ${dir_download}${/}${date}.csv
#    sleep  1s
  END
  Close Browser














