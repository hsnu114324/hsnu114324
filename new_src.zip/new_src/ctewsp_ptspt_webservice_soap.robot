*** Settings ***
#Library  RequestsLibrary
Library  Collections
#Library  SeleniumLibrary
Library  String
Library  SoapLibrary
Library  OperatingSystem
Library  XML


*** Test Cases ***
ctewsp_ptspt_webservice_soap

#    Create Soap Client    https://ctewsp.post.gov.tw/PSTPT.WebService/PSTPT_WebService.asmx?wsdl   ssl_verify=False  
#    Create Soap Client    https://ctewsp.post.gov.tw/PSTPT.WebService/PSTPT_WebService.asmx?wsdl   ssl_verify=True  
#    Create Soap Client    https://172.17.2.58/PSTPT.WebService/PSTPT_WebService.asmx?wsdl     ssl_verify=False         
#    Create Soap Client    http://172.17.2.58/PSTPT.WebService/PSTPT_WebService.asmx?wsdl  



#    Create Soap Client    http://10.201.51.65/PSTPT/PSTPT_WebService.asmx?wsdl      
#    Create Soap Client    http://10.10.131.96/PSTPT/PSTPT_WebService.asmx?wsdl      
#    ${response}=    Call SOAP Method With XML    ${CURDIR}/request.xml  


###  10.201.51.65 中文地址英譯系統(測試機)
    log   10.201.51.65 中文地址英譯系統(測試機)
    Create Soap Client    https://10.201.51.65/PSTPT/PSTPT_WebService.asmx?wsdl     ssl_verify=False 

    ${response}=    Call SOAP Method     TransferForAddress33Object    臺北市  大安區  愛國東路  ${NULL}  ${NULL}  216 

    log  ${response}

    ${response}=    Call SOAP Method     TransferForAddress33String    臺北市士林區長安東路二段225號A棟5樓808室

    log  ${response}

    ${response}=    Call SOAP Method     TransferForCPAddress33Object    臺北市  大安區  愛國東路  ${NULL}  ${NULL}  216 

    log  ${response}

    ${response}=    Call SOAP Method     TransferForCPAddress33String    臺北市士林區長安東路二段225號A棟5樓808室

    log  ${response}


###  10.10.131.96 中文地址英譯系統(對內正式機)
    log  10.10.131.96 中文地址英譯系統(對內正式機)
    Create Soap Client    http://10.10.131.96/PSTPT/PSTPT_WebService.asmx?wsdl   ssl_verify=False 

    ${response}=    Call SOAP Method     TransferForAddress33Object    臺北市  大安區  愛國東路  ${NULL}  ${NULL}  216 

    log  ${response}

    ${response}=    Call SOAP Method     TransferForAddress33String    臺北市士林區長安東路二段225號A棟5樓808室

    log  ${response}
 
    ${response}=    Call SOAP Method     TransferForCPAddress33Object    臺北市  大安區  愛國東路  ${NULL}  ${NULL}  216 

    log  ${response}

    ${response}=    Call SOAP Method     TransferForCPAddress33String    臺北市士林區長安東路二段225號A棟5樓808室

    log  ${response}


###  ctewsp.post.gov.tw 中文地址英譯系統(對正式機)
    log  ctewsp.post.gov.tw 中文地址英譯系統(對外正式機)
    Create Soap Client    https://ctewsp.post.gov.tw/PSTPT.WebService/PSTPT_WebService.asmx?wsdl   ssl_verify=True

    ${response}=    Call SOAP Method     TransferForAddress33Object    臺北市  大安區  愛國東路  ${NULL}  ${NULL}  216 

    log  ${response}

    ${response}=    Call SOAP Method     TransferForAddress33String    臺北市士林區長安東路二段225號A棟5樓808室

    log  ${response}
 
    ${response}=    Call SOAP Method     TransferForCPAddress33Object    臺北市  大安區  愛國東路  ${NULL}  ${NULL}  216 

    log  ${response}

    ${response}=    Call SOAP Method     TransferForCPAddress33String    臺北市士林區長安東路二段225號A棟5樓808室

    log  ${response}






#    ${response}=    Call SOAP Method     TransferForAddress33String  臺北市松山區長安東路二段225號A棟5樓

#    log  ${response} 


#    ${text}    Get Data From XML By Tag    ${response}    tag_name

#    Log    ${text}
#    Save XML To File    ${response}    ${CURDIR}    response_test








