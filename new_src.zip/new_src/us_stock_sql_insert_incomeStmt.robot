*** Keywords ***
us_stock_sql_insert_incomeStmt
#    [Arguments]    ${excel_file_data}
#    [Arguments]  ${start_date}  ${end_date}
    [Documentation]
    [Tags]
#    Connect To Database
#    ...    pymssql
#    ...    dbName=DLIQSERV
#    ...    dbUsername=DLIQTASK
#    ...    dbPassword=DLIQTASK3817
#    ...    dbHost=10.201.52.130
#    ...    dbPort=1433



    


    ${stock_id}=  set variable  nvda

    Connect To Database Using Custom Params  sqlite3  database="./test.db"


#    ${output}=   Execute Sql String     CREATE TABLE ${table_name} ( ${name_1} ${type_1}, ${name_2} ${type_2}, ${name_3} ${type_3}, ${name_4} ${type_4}, ${name_5} ${type_5}, ${name_6} ${type_6}, ${name_7} ${type_7}, ${name_8} ${type_8}, ${name_9} ${type_9}, ${name_10} ${type_10} ) ;
#    Log  ${output}


                ${table_name}=  set variable  incomeStmt
                ${name_1}=      set variable  primary_key
                ${type_1}=      set variable  INT
                ${name_2}=      set variable  date
                ${type_2}=      set variable  DATE
                ${name_3}=      set variable  class
                ${type_3}=      set variable  varchar(100)
                ${name_4}=      set variable  stock_id
                ${type_4}=      set variable  varchar(100)
                ${name_5}=      set variable  stock_name
                ${type_5}=      set variable  varchar(100)
                ${name_6}=      set variable  type
                ${type_6}=      set variable  varchar(100)
                ${name_7}=      set variable  Tax Effect Of Unusual Items
                ${type_7}=      set variable  INT
                ${name_8}=      set variable  Tax Rate For Calcs
                ${type_8}=      set variable  INT
                ${name_9}=      set variable  Normalized EBITDA
                ${type_9}=      set variable  INT
                ${name_10}=      set variable  Total Unusual Items
                ${type_10}=      set variable  INT
                ${name_11}=      set variable  Total Unusual Items Excluding Goodwill
                ${type_11}=      set variable  INT
                ${name_12}=      set variable  Net Income From Continuing Operation Net Minority Interest
                ${type_12}=      set variable  INT
                ${name_13}=      set variable  Reconciled Depreciation
                ${type_13}=      set variable  INT
                ${name_14}=      set variable  Reconciled Cost Of Revenue
                ${type_14}=      set variable  INT
                ${name_15}=      set variable  EBITDA
                ${type_15}=      set variable  INT
                ${name_16}=      set variable  EBIT
                ${type_16}=      set variable  INT
                ${name_17}=      set variable  Net Interest Income
                ${type_17}=      set variable  INT
                ${name_18}=      set variable  Interest Expense
                ${type_18}=      set variable  INT
                ${name_19}=      set variable  Interest Income
                ${type_19}=      set variable  INT
                ${name_20}=      set variable  Normalized Income
                ${type_20}=      set variable  INT
                ${name_21}=      set variable  Net Income From Continuing And Discontinued Operation
                ${type_21}=      set variable  INT
                ${name_22}=      set variable  Total Expenses
                ${type_22}=      set variable  INT
                ${name_23}=      set variable  Total Operating Income As Reported
                ${type_23}=      set variable  INT
                ${name_24}=      set variable  Diluted Average Shares
                ${type_24}=      set variable  INT
                ${name_25}=      set variable  Basic Average Shares
                ${type_25}=      set variable  INT
                ${name_26}=      set variable  Diluted EPS
                ${type_26}=      set variable  INT
                ${name_27}=      set variable  Basic EPS
                ${type_27}=      set variable  INT
                ${name_28}=      set variable  Diluted NI Availto Com Stockholders
                ${type_28}=      set variable  INT
                ${name_29}=      set variable  Net Income Common Stockholders
                ${type_29}=      set variable  INT
                ${name_30}=      set variable  Net Income
                ${type_30}=      set variable  INT
                ${name_31}=      set variable  Minority Interests
                ${type_31}=      set variable  INT
                ${name_32}=      set variable  Net Income Including Noncontrolling Interests
                ${type_32}=      set variable  INT
                ${name_33}=      set variable  Net Income Continuous Operations
                ${type_33}=      set variable  INT
                ${name_34}=      set variable  Tax Provision
                ${type_34}=      set variable  INT
                ${name_35}=      set variable  Pretax Income
                ${type_35}=      set variable  INT
                ${name_36}=      set variable  Other Income Expense
                ${type_36}=      set variable  INT
                ${name_37}=      set variable  Other Non Operating Income Expenses
                ${type_37}=      set variable  INT
                ${name_38}=      set variable  Special Income Charges
                ${type_38}=      set variable  INT
                ${name_39}=      set variable  Write Off
                ${type_39}=      set variable  INT
                ${name_40}=      set variable  Earnings From Equity Interest
                ${type_40}=      set variable  INT
                ${name_41}=      set variable  Gain On Sale Of Security
                ${type_41}=      set variable  INT
                ${name_42}=      set variable  Net Non Operating Interest Income Expense
                ${type_42}=      set variable  INT
                ${name_43}=      set variable  Total Other Finance Cost
                ${type_43}=      set variable  INT
                ${name_44}=      set variable  Interest Expense Non Operating
                ${type_44}=      set variable  INT
                ${name_45}=      set variable  Interest Income Non Operating
                ${type_45}=      set variable  INT
                ${name_46}=      set variable  Operating Income
                ${type_46}=      set variable  INT
                ${name_47}=      set variable  Operating Expense
                ${type_47}=      set variable  INT
                ${name_48}=      set variable  Other Operating Expenses
                ${type_48}=      set variable  INT
                ${name_49}=      set variable  Research And Development
                ${type_49}=      set variable  INT
                ${name_50}=      set variable  Selling General And Administration
                ${type_50}=      set variable  INT
                ${name_51}=      set variable  Selling And Marketing Expense
                ${type_51}=      set variable  INT
                ${name_52}=      set variable  General And Administrative Expense
                ${type_52}=      set variable  INT
                ${name_53}=      set variable  Other Gand A
                ${type_53}=      set variable  INT
                ${name_54}=      set variable  Gross Profit
                ${type_54}=      set variable  INT
                ${name_55}=      set variable  Cost Of Revenue
                ${type_55}=      set variable  INT
                ${name_56}=      set variable  Total Revenue
                ${type_56}=      set variable  INT
                ${name_57}=      set variable  Operating Revenue
                ${type_57}=      set variable  INT
                











#    ${output}=   Execute Sql String     CREATE TABLE ${table_name} ( '${name_1}' ${type_1}, '${name_2}' ${type_2}, '${name_3}' ${type_3}, '${name_4}' ${type_4}, '${name_5}' ${type_5}, '${name_6}' ${type_6}, '${name_7}' ${type_7}, '${name_8}' ${type_8}, '${name_9}' ${type_9}, '${name_10}' ${type_10}, '${name_11}' ${type_11}, '${name_12}' ${type_12}, '${name_13}' ${type_13}, '${name_14}' ${type_14}, '${name_15}' ${type_15}, '${name_16}' ${type_16}, '${name_17}' ${type_17}, '${name_18}' ${type_18}, '${name_19}' ${type_19}, '${name_20}' ${type_20}, '${name_21}' ${type_21}, '${name_22}' ${type_22}, '${name_23}' ${type_23}, '${name_24}' ${type_24}, '${name_25}' ${type_25}, '${name_26}' ${type_26}, '${name_27}' ${type_27}, '${name_28}' ${type_28}, '${name_29}' ${type_29}, '${name_30}' ${type_30}, '${name_31}' ${type_31}, '${name_32}' ${type_32}, '${name_33}' ${type_33}, '${name_34}' ${type_34}, '${name_35}' ${type_35}, '${name_36}' ${type_36}, '${name_37}' ${type_37}, '${name_38}' ${type_38}, '${name_39}' ${type_39}, '${name_40}' ${type_40}, '${name_41}' ${type_41}, '${name_42}' ${type_42}, '${name_43}' ${type_43}, '${name_44}' ${type_44}, '${name_45}' ${type_45}, '${name_46}' ${type_46}, '${name_47}' ${type_47}, '${name_48}' ${type_48}, '${name_49}' ${type_49}, '${name_50}' ${type_50}, '${name_51}' ${type_51}, '${name_52}' ${type_52}, '${name_53}' ${type_53}, '${name_54}' ${type_54}, '${name_55}' ${type_55}, '${name_56}' ${type_56}, '${name_57}' ${type_57} ) ;


#    Log  ${output}







#    ${folder}=    set variable    ../stock_csv    # 更換成目標資料>夾的路徑



#    ${date_range}=  finmind_GetDateRange  ${start_date}  ${end_date}  


#  FOR  ${date}  IN  @{date_range}

#  log_to_console  date: ${date}

#    ${file_exists}=  Run Keyword And Return Status  OperatingSystem.File_Should_Exist   ${folder}/${date}.csv
#    IF  '${file_exists}' == 'False'
#        CONTINUE FOR LOOP 
#    END
    
#    @{list_csv_before_yesterday}=  read_csv_file_to_list  Excel/daily_stock.csv

    @{list_csv_before_yesterday}=  read_csv_file_to_list  ${stock_id}_quarterly_income_stmt.csv
    ${list_csv_by_cnt}=    Get length    ${list_csv_before_yesterday}
    Log  list_csv_by_cnt ${list_csv_by_cnt}


        ${data_header_list}=   create list   2         #date
#        ${data_list}=     create list        ${empty}

#        FOR  ${iii} in range  1  103
#             Append To List  ${data_header_list}  ${NULL}
#             Append To List  ${data_list}         ${NULL}
#        END  

   
#        ${data_list}=     create list        
        ${data_0}=     get from list  ${list_csv_before_yesterday}  0
        ${data_0_length}=  get length  ${data_0}
        ${set_null}=  Set variable  0
        FOR  ${j}  IN RANGE  1  ${data_0_length}  

            FOR  ${k}  IN RANGE  7  58

                log  ${data_0}[${j}]
                log  ${name_${k}}
                IF  '${data_0}[${j}]' == '${name_${k}}'
#                    append_to_list  ${data_list} ${k}
#                    set variable  ${k-7}  ${k} - 7
#                    set list value  ${data_header_list}  ${k}  ${j} 
                    Append To List  ${data_header_list}  ${k}
                    log  ${data_header_list}[${j}]
                    log  ${data_header_list}
#                    Continue For Loop
                    ${set_null}=   Set variable  0
                    BREAK
                END  
            END
            IF  ${set_null} == 1
                    Append To List  ${data_header_list}  ${NULL}
            END
            ${set_null}=   Set variable  1
#            Append To List  ${data_list}  ${NULL}
        END


    FOR  ${i}  IN RANGE  1  ${list_csv_by_cnt}  1

        ${data}=     get from list  ${list_csv_before_yesterday}  ${i}
#        ${data_1}=   set variable  ${data}[0]
#        ${data_2}=   set variable  ${data}[1]
#        ${data_3}=   set variable  ${data}[2]
#        ${data_4}=   set variable  ${data}[3]
#        ${data_5}=   set variable  ${data}[4]
#        ${data_6}=   set variable  ${data}[5]
#        ${data_7}=   set variable  ${data}[6]
#        ${data_8}=   set variable  ${data}[7]
#        ${data_9}=   set variable  ${data}[8]
#        ${data_10}=  set variable  ${data}[9]
#
#        ${output}=    Execute Sql String    INSERT INTO ${table_name} VALUES ( '${data_1}', '${data_2}', ${data_3}, ${data_4}, ${data_5}, ${data_6}, ${data_7}, ${data_8}, ${data_9}, ${data_10} )


        
        log  ${data_header_list}

        ${data_list}=  Create list
        log  ${data_list}
        FOR  ${iii}  IN RANGE  0  58
            Append To List  ${data_list}  NULL    
        END

        log  ${data_list}
#        Append To List  ${data_list}
        

        FOR  ${ii}  IN RANGE  0  ${data_0_length}
              log  ${ii}
              log  ${data_header_list}[${ii}]
              log  ${data_header_list}
              log  ${data}[${ii}]
              IF  '${data_header_list}[${ii}]' == 'None'
                  Continue For Loop
              END
#              log  ${data}[${data_header_list}[${ii}]]
#              Append To List  ${data_list}  ${data}[${data_header_list}[${ii}]]

              
              IF  '${data}[${ii}]' == '${empty}'
                  ${data}[${ii}]=  set variable  NULL
              END
              Set List Value  ${data_list}  ${data_header_list}[${ii}]  ${data}[${ii}]    #equal to  ${data_list}[${data_header_list[${ii}]}]=  set variable  ${data}[${ii}]

              log  ${data_list}
        END

        log  ${data_list}

        ${output}=    Execute Sql String    INSERT INTO ${table_name} VALUES ( 0, '${data_list}[2]', 'us_stock', '${stock_id}', 'stock_name', 'quarterly', ${data_list}[7], ${data_list}[8], ${data_list}[9], ${data_list}[10], ${data_list}[11], ${data_list}[12], ${data_list}[13], ${data_list}[14], ${data_list}[15], ${data_list}[16], ${data_list}[17], ${data_list}[18], ${data_list}[19], ${data_list}[20], ${data_list}[21], ${data_list}[22], ${data_list}[23], ${data_list}[24], ${data_list}[25], ${data_list}[26], ${data_list}[27], ${data_list}[28], ${data_list}[29], ${data_list}[30], ${data_list}[31], ${data_list}[32], ${data_list}[33], ${data_list}[34], ${data_list}[35], ${data_list}[36], ${data_list}[37], ${data_list}[38], ${data_list}[39], ${data_list}[40], ${data_list}[41], ${data_list}[42], ${data_list}[43], ${data_list}[44], ${data_list}[45], ${data_list}[46], ${data_list}[47], ${data_list}[48], ${data_list}[49], ${data_list}[50], ${data_list}[51], ${data_list}[52], ${data_list}[53], ${data_list}[54], ${data_list}[55], ${data_list}[56], ${data_list}[57] )


        Log  ${output}


    END

#  END

