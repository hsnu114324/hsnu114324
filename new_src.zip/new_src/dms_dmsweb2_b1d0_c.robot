*** Keywords ***
dms_dmsweb2_b1d0_c
    [Arguments]  ${excel_file_data}
  
#  ${MON_PAY}
	[Documentation]
	[Tags]
#***

    Log  ${excel_file_data}

#***
	dms_dmsweb2_pnsFrontEndloginChrome  http://localhost:3000/
#	post_postweb2_pnsFrontEndloginFirefox  https://pnstest.post.gov.tw/LI.Web/LI0010.aspx


#    Debug

    dms_dmsweb2_ClickDmsFrontEnduserID_DM_login

    dms_dmsweb2_ClickDmsFrontEndMenuInput  b1d0

    dms_dmsweb2_ClickDmsFrontEnd_b1d0ACC_DATE  ${excel_file_data}[1] 
    
    dms_dmsweb2_ClickDmsFrontEnd_b1d0CNTR_NO  ${excel_file_data}[2] 

    dms_dmsweb2_ClickDmsFrontEnd_b1d0SEGC_NO  ${excel_file_data}[3] 

    dms_dmsweb2_ClickDmsFrontEnd_b1d0FetchButton

    Sleep  1s

    Keyboard Key    press    Enter

    dms_dmsweb2_ClickDmsFrontEnd_b1d0NewButton

    dms_dmsweb2_ClickDmsFrontEnd_b1d0MAIL_NO     ${excel_file_data}[5] 

    dms_dmsweb2_ClickDmsFrontEnd_b1d0MAIL_TYPE   ${excel_file_data}[4] 

    dms_dmsweb2_ClickDmsFrontEnd_b1d0_RCV_NAME   ${excel_file_data}[6]

    dms_dmsweb2_ClickDmsFrontEnd_b1d0_RCV_ADDR_CITY   ${excel_file_data}[8]

    dms_dmsweb2_ClickDmsFrontEnd_b1d0_RCV_ADDR_CITY   ${excel_file_data}[8]

    dms_dmsweb2_ClickDmsFrontEnd_b1d0_RCV_ADDR_TWP    ${excel_file_data}[9]

    dms_dmsweb2_ClickDmsFrontEnd_b1d0_RCV_ADDR_RD     ${excel_file_data}[10]

    dms_dmsweb2_ClickDmsFrontEnd_b1d0_RCV_ADDR_NO     ${excel_file_data}[13]

    dms_dmsweb2_ClickDmsFrontEnd_b1d0SendButton

    Sleep  1s

    Keyboard Key    press    Escape

    Sleep  1s

#***



#    ${Q_ACC_MONTH_SER}=    dms_dmsweb2_DmsFrontEnd_b1d0_stage1_1    ${excel_file_data}    

    ${Q_ACC_MONTH_SER}=    dms_dmsweb2_DmsFrontEnd_b1d0_stage1_1    

    Log  ${Q_ACC_MONTH_SER}


#***    

    dms_dmsweb2_ClickDmsFrontEnduserID_logout

    Sleep  3s

	RETURN   ${Q_ACC_MONTH_SER}
