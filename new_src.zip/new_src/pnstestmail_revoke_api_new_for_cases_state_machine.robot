*** Keywords ***
pnstestmail_revoke_api_new_for_cases_state_machine



#    [Arguments]     ${excel_file_data}    
    [Arguments]     ${excel_file_data}  ${q_sid}
    [Documentation]
    [Tags]



    ${base_url}=  set variable   https://ndmstest.post.gov.tw

    ${channel_url}=  set variable  /Quest/QuestGetSID/GetSID

    create session  deleteemail    ${base_url}     

    #Create a dynamic messageId
    ${rand_MessageID}=  generate random string  5  [NUMBERS]

    #Set a request variable
    ${SOAP_XML}=   set variable  {"QUEST_SID":[{"Q_SID":"${q_sid}"}]}

#    ${SOAP_XML}=   set variable  {"QUEST_SID":[{"Q_SID":"2sSZqDBsRmO"},{"Q_SID":"08FMWPmJXkk"}]}

#    ${SOAP_XML}=   set variable  {"QUEST_SID":[{"Q_SID":"2sSZqCyLGe2"},{"Q_SID":"2sSZqCyLGe3"},{"Q_SID":"2sSZqDBsRmO"},{"Q_SID":"08FMWPmJXkk"}]}

#    ${SOAP_XML}=   set variable  {"QUEST_SID":[{"Q_SID":"${q_sid}"},{"Q_SID":"2sSZqCyLGe2"},{"Q_SID":"2sSZqCyLGe3"},{"Q_SID":"2sSZqDBsRmO"},{"Q_SID":"08FMWPmJXkk"}]}


    log  ${SOAP_XML}

    ${SOAP_XML_UTF8}=  evaluate   '${SOAP_XML}'.encode("utf-8")

    log  ${SOAP_XML_UTF8}

    #Create Request Headers
    ${request_header}=    create dictionary    Content-Type=application/json; charset=utf-8  x-api-key=c4f6e1d2-3b4a-5c6d-7e8f-901a2b3c4d5e 


    #Send the XML request body
    ${SAVE_Response}=    Post Request    deleteemail    ${channel_url}    headers=${request_header}    data=${SOAP_XML_UTF8}

    #Log Response and Status Code Details
    log to console    ${SAVE_Response.status_code}
    log    ${SAVE_Response.headers}
    log    ${SAVE_Response.content}
#    log    ${SAVE_Response.content.Q_ACC_MONTH_SER}
                ${list_of_dicts}=  evaluate  json.loads('[${SAVE_Response.content}]') 
                log  ${list_of_dicts}

                ${data_value}=  Get Dictionary Items  ${list_of_dicts[0]}
                log  ${data_value}
                log  ${data_value}[0]
                log  ${data_value}[1]
                log  ${data_value}[1][0]
                log  ${data_value}[2]
                log  ${data_value}[3]
#                log  ${data_value}[3][0]
                log  ${data_value}[4]
                log  ${data_value}[5]


                ${1_data_value}=  Get Dictionary Items  ${data_value}[3]
                log  ${1_data_value}
                log  ${1_data_value}[0]
                log  ${1_data_value}[3]
                log  ${1_data_value}[3][0]
                log  ${1_data_value}[4]
                log  ${1_data_value}[4][0]
                log  ${1_data_value}[5]
#                log  ${1_data_value}[5][0]
                log  ${1_data_value}[6]
                log  ${1_data_value}[6][0]


                ${2_data_value}=  Get Dictionary Items  ${1_data_value}[3][0]
                log  ${2_data_value}
                log  ${2_data_value}[0]
                log  ${2_data_value}[1]
                log  ${2_data_value}[2]
                log  ${2_data_value}[3]
                log  ${2_data_value}[4]
                log  ${2_data_value}[5]
                log  ${2_data_value}[6]
                log  ${2_data_value}[7]
                log  ${2_data_value}[8]
                log  ${2_data_value}[9]
                log  ${2_data_value}[10]
                log  ${2_data_value}[11]
                log  ${2_data_value}[12]
                log  ${2_data_value}[13]
                log  ${2_data_value}[14]
                log  ${2_data_value}[15]
                log  ${2_data_value}[16]
                log  ${2_data_value}[17]
                log  ${2_data_value}[18]
                log  ${2_data_value}[19]
                log  ${2_data_value}[20]
                log  ${2_data_value}[21]
                log  ${2_data_value}[22]
                log  ${2_data_value}[23]
                log  ${2_data_value}[24]
                log  ${2_data_value}[25]


#***    
                log  RESPONDENT: ${2_data_value}[25]
                log  RESPONDENT_REVOKED: ${1_data_value}[5]

#***    
     RETURN   RESPONDENT: ${2_data_value}[25] , RESPONDENT_REVOKED: ${1_data_value}[5]


