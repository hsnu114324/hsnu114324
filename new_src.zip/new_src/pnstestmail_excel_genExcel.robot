*** Keywords ***
pnstestmail_excel_genExcel



    [Arguments] 	${old_path_excel}  ${old_sheet_name}  ${new_path_excel}  ${new_sheet_name}  ${is_today}  ${is_WebLoginId}  ${is_mailstate}  ${is_comment}  ${is_sameunit}
    Log   ${old_path_excel}
    Log   ${old_sheet_name}
    Log   ${new_path_excel}
    Log   ${new_sheet_name}
    Log   ${is_today}
    Log   ${is_WebLoginId}
    Log   ${is_mailstate}
    Log   ${is_comment}
    Log   ${is_sameunit}


    ${sensor_check_list}=  post_excel_getdata_for_ezpost    ${old_path_excel}  ${old_sheet_name} 

    ${list_count} =    Get length    ${sensor_check_list}
    Log_To_Console   list_count ${list_count}
	  Log_To_Console   ${sensor_check_list}

    FOR  ${sensor_name}  IN  @{sensor_check_list}

		Log   sensor_name: ${sensor_name}
		Log   ${sensor_name}[0]

    END



    ${line_num}=  Set Variable  1

    FOR  ${sensor_name}  IN  @{sensor_check_list}

        Log  ${is_today}
        Log  ${sensor_name}[3]
#        ${is_today1}=  Replace String Using Regexp  ${is_today}    '    \     count=1
        IF  '${is_today}' == '${sensor_name}[3]'
    	    Log_To_Console	${sensor_name}[3]
    	    Log	 ${sensor_name}[3]
            IF  '${is_today}' == 'today'
                ${temp_date}=  Get Current Date  result_format=%Y-%m-%d
                ${temp2_date}=  Subtract Time From Date  ${temp_date}  697978d  
                ${temp3_date}=  Subtract Time From Date  ${temp_date}  697977d
                ${para2_date}=  Convert Date  ${temp2_date}  result_format=%Y/%m/%d
                Should Match Regexp  ${para2_date}  ^0\\d{3}/\\d{2}/\\d{2}$
                ${para3_date}=  Convert Date  ${temp3_date}  result_format=%Y/%m/%d
                Should Match Regexp  ${para3_date}  ^0\\d{3}/\\d{2}/\\d{2}$
                ${para2}=  Replace String Using Regexp  ${para2_date}    ^0    \     count=1
                ${para3}=  Replace String Using Regexp  ${para3_date}    ^0    \     count=1
            ELSE
                ${para2}=  set variable  113/01/01
                ${para3}=  set variable  113/01/02 
            END
        ELSE
#            CONTINUE For Loop
            Sleep  1ms
        END



        Log  ${is_mailstate}       # 是否退件
        IF  '${is_mailstate}' == '${sensor_name}[6]'
            IF  '${is_mailstate}' == 'D'
                ${para5}=  set variable  D
            ELSE IF  '${is_mailstate}' == 'C'
                ${para5}=  set variable  C
            ELSE
#                CONTINUE For Loop
                Sleep  1ms
            END
        ELSE
#            CONTINUE For Loop
            Sleep  1ms
        END

        Log  ${is_comment}
        Log  ${sensor_name}[5]
        IF  '${is_comment}' == 'True'

            Log  ${sensor_name}[5]
            IF  '${sensor_name}[5]' != 'None'
                ${para6}=  set variable  ${sensor_name}[5]
            ELSE
                ${para6}=  set variable  None
            END
        ELSE
            Log  ${sensor_name}[5]
            IF  '${sensor_name}[5]' == 'None'
                ${para6}=  set variable  None
            ELSE
#                CONTINUE For Loop
                Sleep  1ms
            END
        END


        Log  ${is_WebLoginId}
        Log  ${sensor_name}[3]
        Log  ${is_sameunit}
        Log  ${sensor_name}[6]
        IF  '${is_WebLoginId}' == '${sensor_name}[2]'      # 網頁登入工號 == 送件人工號
            IF  '${is_sameunit}' == 'True'    # 為了LI7012，將送件人id設為'空值'
                ${para4}=  set variable  ${sensor_name}[2]     # para4 是送件人工號
            ELSE IF  '${is_sameunit}' == 'False'
                ${para4}=  set variable  ${sensor_name}[2]     # para4 是送件人工號
            ELSE
                FAIL
            END            
        ELSE
            IF  '${is_sameunit}' == 'True'    # 為了LI7012，將送件人id設為'空值'
                ${para4}=  set variable  ${sensor_name}[2]
                IF  '${sensor_name}[2]' == '698374'    #張稚維
                    ${para4}=  set variable  ${sensor_name}[2]    #張稚維
                ELSE 
#                    CONTINUE For Loop
                    Sleep  1ms
                END
            ELSE IF  '${is_sameunit}' == 'False'      
#                CONTINUE For Loop
                Sleep  1ms
            ELSE
                FAIL
            END 
        END





#        ${line_num}=  Set Variable  ${line_num} + 1
        ${line_num}=  evaluate  ${line_num} + 1
        ${para0}=  Set Variable  ${sensor_name}[1]
        ${para1}=  Set Variable  ${sensor_name}[4]

        Log  ${para0}
        Log  ${para1}
        Log  ${para2}
        Log  ${para3}
        Log  ${para4}
        Log  ${para5}
        Log  ${para6}


        post_excel_write 	    ${new_path_excel}  ${new_sheet_name}  ${line_num}  ${para0}  ${para1}  ${para2}  ${para3}  ${para4}  ${para5}  ${para6}

    END

#	[Return]  ${CR_no}
