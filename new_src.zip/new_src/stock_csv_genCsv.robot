*** Keywords ***
stock_csv_genCsv

#    [Arguments]     ${ii}      ${path_csv}   
#    Log   ${ii}
#    Log_To_Console  path_csv : ${path_csv}






#    ${max_file}    Set Variable    none
#    ${max_num}    Set Variable    0
#    ${files}    OperatingSystem.List_Files_In_Directory    ${folder}    *.csv
    ${files}    OperatingSystem.List_Files_In_Directory    stock_csv_daily    *.csv


    FOR    ${file}    IN    @{files}
        ${file_split}=    Split String    ${file}    .
        Log_To_Console  ${file_split}[0]
#        ${file_num}=  Convert_Date  ${file_split}[0]    result_format=%Y%m%d    date_format=%Y-%m-%d
#        ${num}    Evaluate    ${file_num}
#        IF    ${num} > ${max_num}
#            ${max_file}    Set Variable    ${file}
#            ${max_num}    Set Variable    ${num}
#        END

        ${old_csv_content}=    Get File    stock_csv_daily/${file_split}[0].csv    encoding=UTF-8-SIG    encoding_errors=strict
#        @{list_i}=  Read Csv String To List  ${old_csv_content}

        @{list_csv_before_yesterday}=  Read Csv String To List  ${old_csv_content}
        ${list_csv_by_cnt}=    Get length    ${list_csv_before_yesterday}
            
        FOR  ${old_j}  IN RANGE  0  ${list_csv_by_cnt}  1

            ${s1_by_array}=  get_from_list  ${list_csv_before_yesterday}  ${old_j}

#            Log  s1_by_array ${s1_by_array}
#            Log  ${s1_by_array}[0]
#            Log  ${s1_by_array}[1]
#            Log  ${s1_by_array}[2]
#            Log  ${s1_by_array}[3]
#            Log  ${s1_by_array}[4]
#            Log  ${s1_by_array}[5]
#            Log  ${s1_by_array}[6]
#            Log  ${s1_by_array}[7]
#            Log  ${s1_by_array}[8]
#            Log  ${s1_by_array}[9]

                ${file_exists}=  Run Keyword And Return Status  OperatingSystem.File_Should_Exist   stock_csv_new/${s1_by_array}[1]_${s1_by_array}[0][0:4].csv
 
                IF  '${file_exists}' == 'False'
                    Copy File  lvr_landcsv/a_lvr_land_a_header.csv  stock_csv_new/${s1_by_array}[1]_${s1_by_array}[0][0:4].csv
                END

            

            ${csv_string}=  set variable  ${empty}
            ${str_s1_by_array}=   Evaluate  ",".join(${s1_by_array})   

            ${csv_string}=  set variable  ${str_s1_by_array}\n
#            log  ${csv_string}

            Append To File   stock_csv_new/${s1_by_array}[1]_${s1_by_array}[0][0:4].csv  ${csv_string}

        END

    END







