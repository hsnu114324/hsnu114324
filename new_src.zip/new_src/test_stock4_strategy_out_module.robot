*** Keywords ***
#*** Test Cases ***
test_stock4_strategy_out_module
    [Arguments]     ${excel_file_data}  ${query_start_date}  ${query_end_date}  ${query_stock_id}  ${query_database}

    [Documentation]    Load sensor list file and prepare list
    Log    ${excel_file_data}

    ${query_start_date}=  set variable  ${excel_file_data}[1]
    Log   ${query_start_date}
    ${query_end_date}=  set variable  ${excel_file_data}[2]
    Log   ${query_end_date}
    ${query_stock_id}=  set variable  ${excel_file_data}[3]
    Log   ${query_stock_id}
    ${query_database}=  set variable  ${excel_file_data}[4]
    Log   ${query_database}


    Connect To Database Using Custom Params  sqlite3  database="./${query_database}"


    ${query_primary_key}=  Query  select primary_key from primary_key limit 1 ;
    IF  ${query_primary_key}== []
        ${primay_key}=  set variable  1
    ELSE
        ${primary_key}=  set variable  ${query_primary_key}[0][0]
    END 

    ${query_old_kd_value}=  Query  select old_kd_value from old_kd_value limit 1 ;
    IF  ${query_old_kd_value}== []
        Fail
        ${old_kd_value}=  set variable  0
    ELSE
        ${old_kd_value}=  set variable  ${query_old_kd_value}[0][0]
    END 




    ${output}=    query_output_from_database  '${query_start_date}'  '${query_end_date}'  '${query_stock_id}'
    Log  ${output}

    ${output_k}=    query_output_k_from_database  '${query_start_date}'  '${query_end_date}'  '${query_stock_id}'
    Log  ${output_k}

    ${output_d}=    query_output_d_from_database  '${query_start_date}'  '${query_end_date}'  '${query_stock_id}'
    Log  ${output_d}











  ${date_length}=  get length  ${output_k}

  FOR  ${i}  IN RANGE  ${date_length}

        log  ${output_k}[${i}]
        log  ${output_d}[${i}]

        log  ${output_k}[${i}][0]
        log  ${output_d}[${i}][0]

    ${date}=  set variable  ${output}[${i}][0]
    ${stock_id}=  set variable  ${output}[${i}][1]
    ${close}=  set variable  ${output}[${i}][7]     
  

        IF  ${output_k}[${i}][0] < ${output_d}[${i}][0]
            IF  ${old_kd_value} >= 0
                ${old_kd_value}=  set variable  -1     
                ${output}=  Execute sql string  update old_kd_value set old_kd_value=${old_kd_value}; 
                ${flag_sned_sellout_signal}=  set variable  1   
#                Debug
		    OperatingSystem.Run  echo "${date} | ${output_k}[${i}][0] < ${output_d}[${i}][0]" >> kd.txt
            ELSE
	        Continue For Loop
            END

	ELSE

            Continue For Loop
        END


#	     ${estimate_child_id}=  set variable  1 



    ${list_i}=    Query    SELECT primary_key,date,strategy_id,buyin_signal,class,stock_id,assets_in_or_out,unit_price,number_of_share,share_amount_price, evaluate_in_strategy_ror, estimate_in_stock_ror, estimate_in_parent_id, strategy_out_children_id FROM assets_in WHERE stock_id=${query_stock_id} AND strategy_id=1 AND buyin_signal=1 AND DATE between '1994-01-01' and '${query_end_date}' order by DATE ;
#    ${list_i}=    Query    SELECT primary_key,date,strategy_id,buyin_signal,class,stock_id,assets_in_or_out,unit_price,number_of_share,share_amount_price, evaluate_in_strategy_ror, estimate_in_stock_ror, estimate_in_parent_id, strategy_out_children_id FROM assets_in WHERE stock_id=${query_stock_id} AND strategy_id=1 AND DATE between '1994-01-01' and '${query_end_date}' order by DATE ;
    Log  ${list_i}
#    Fail

        IF  ${list_i} == []
	
	    Continue For Loop

        END

     ${i}=  set variable  0


     ${old_output_buyin}=  set variable  1
        IF  ${old_output_buyin} == 1
           ${flag_sned_sellout_signal}=  set variable  1   
  
         ${assets_in_parent_id}=       set variable  ${list_i}[${i}][0]  
   #      ${date}=                        set variable  ${list_i}[${i}][1]   
         ${strategy_id}=                 set variable  ${list_i}[${i}][2]      
         ${separate_sellout_signal}=                set variable  ${list_i}[${i}][3]  
         ${class}=                       set variable  ${list_i}[${i}][4]       
         ${stock_id}=                    set variable  ${list_i}[${i}][5]      
         ${strategy_in_or_out}=          set variable  ${list_i}[${i}][6]  
         ${close}=                       set variable  ${list_i}[${i}][7]  
  
	ELSE	
           ${flag_sned_sellout_signal}=  set variable  1 

         ${assets_in_parent_id}=         set variable  0  
   #      ${date}=                        set variable  0   
         ${strategy_id}=                 set variable  1      
         ${separate_sellout_signal}=                set variable  0  
         ${class}=                       set variable  0       
         ${stock_id}=                    set variable  0    
         ${strategy_in_or_out}=          set variable  0  
         ${close}=                       set variable  0  
	
        END

        IF  ${flag_sned_sellout_signal} == 1
                ${flag_send_sellout_signal}=  set variable  0
		
		${date}=  set variable  ${query_end_date}
		
                ${buyin_signal}=  set variable  1
                ${number_of_share}=  set variable  1000
                ${share_amount_price}=  evaluate  ${buyin_signal} * ${close} * ${number_of_share} 
		
	        ${evaluate_out_strategy_ror}=             set variable  0   
                ${estimate_out_stock_ror}=                set variable  0   
                ${evaluate_out_priority_sellout_signal}=    set variable  0 
                ${estimate_out_sellout_signal}=             set variable  0 
		
		${evaluate_out_children_id}=             set variable  0 
        END



        ${table_name}=  set variable  strategy_out
                ${primary_key}=  evaluate  ${primary_key} + 1

            ${output}=  Execute sql string  update assets set strategy_out_children_id=${primary_key} where primary_key=${assets_in_parent_id};
            ${output}=  Execute sql string  update assets_in set strategy_out_children_id=${primary_key} where primary_key=${assets_in_parent_id};


        insert_strategy_data_to_database  ${table_name}  ${primary_key}  ${date}  ${strategy_id}  ${separate_sellout_signal}  ${class}  ${stock_id}  ${strategy_in_or_out}  ${close}  ${number_of_share}  ${share_amount_price}  ${evaluate_out_strategy_ror}  ${estimate_out_stock_ror}  ${evaluate_out_priority_sellout_signal}  ${estimate_out_sellout_signal}  ${assets_in_parent_id}  ${evaluate_out_children_id}  









                ${output}=  Execute sql string  update primary_key set primary_key=${primary_key};     
            








#                ${csv_header_string}=  set variable  日期,策略代號,買入訊號,股票代碼,收盤價,成交量,成交金額,evaluate_strategy_ror,strategy_parent_id,estimate_child_id\n


#                ${csv_string}=  set variable  ${today_date}, ${strategy_id}, ${buyin_signal}, ${today_stock_id}, ${today_close}, ${buyin_signal_volume}, ${buyin_among_NTD},${strategy_parent_id},${estimate_child_id},${evaluate_strategy_ror},${strategy_parent_id},${estimate_child_id}\n
#                log  ${csv_string}

#                post_csv_setdata  stock_csv_new_macd_dif/${strategy_id}_evaluate_in_${today_date}[0:4].csv  ${csv_header_string}  ${csv_string}  





  END

    Disconnect From Database

    OperatingSystem.Run  echo "primary_key|date|strategy_id|buyin_signal|class|stock_id|strategy_in_or_out|close|number_of_share|share_amount_price|evaluate_out_strategy_ror|estimate_out_stock_ror|evaluate_out_sellout_signal|estimate_out_sellout_signal|assets_in_parent_id|evaluate_out_children_id" > strategy_out.txt                                     

    OperatingSystem.Run  sqlite3 test.db "select primary_key,date,strategy_id,buyin_signal,class,stock_id,strategy_in_or_out,close,number_of_share,share_amount_price,evaluate_out_strategy_ror,estimate_out_stock_ror,evaluate_out_sellout_signal,estimate_out_sellout_signal,assets_in_parent_id,evaluate_out_children_id from strategy_out;" >> strategy_out.txt






















