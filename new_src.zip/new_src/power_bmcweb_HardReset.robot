*** Keywords ***

power_bmcweb_HardReset
	[Documentation]
	[Tags]
#***
	wistron_bmcweb_login
	wistron_bmcweb_ExpectPowerOn
	wistron_bmcweb_logout

#***
	wistron_bmcweb_login
#***
	wistron_bmcweb_GoToPage  ${url_power_control}
#***
    	${power_status_before}=    wistron_ipmi_CheckChassisPowerStatus
	wistron_bmcweb_ClickPowerButtonHardReset
#***
	${power_status_after}=    wistron_ipmi_CheckChassisPowerStatus
	Should Be Equal    ${power_status_before}    ${power_status_before} 
	wistron_ipmi_WaitPowerOn
#***
	wistron_ssh_WaitPowerOn
#***
	wistron_bmcweb_GoToPage  ${url_event_log_ipmi}
#***
	wistron_bmcweb_ExpectOemEventLog  
#***
	wistron_bmcweb_logout



