*** Keywords ***
dms_dmsweb2_2000_MList_transfer
    [Arguments]  ${excel_file_data}
 
#  ${MON_PAY}
	[Documentation]
	[Tags]
#***

    Log  ${excel_file_data}

#***
	dms_postweb2_pnsFrontEndloginChrome  http://localhost:3000/
#	post_postweb2_pnsFrontEndloginFirefox  https://pnstest.post.gov.tw/LI.Web/LI0010.aspx


#    Debug

    dms_dmsweb2_ClickDmsFrontEnduserID_login

	dms_dmsweb2_ClickDmsFrontEndMenuButton
#***
	dms_dmsweb2_ClickDmsFrontEndMenu_ListOP1
#***
	dms_dmsweb2_ClickDmsFrontEndMenu_ListOP1_2000
#***
	dms_dmsweb2_ClickDmsFrontEnd_2000ACC_DATE  ${excel_file_data}[1]
#***
	dms_dmsweb2_ClickDmsFrontEnd_2000TOUR_NO  ${excel_file_data}[2]
#***
    dms_dmsweb2_ClickDmsFrontEnd_2000STAFF_NO
#	${MLIST_NO}  ${MLIST_STATE}=  dms_dmsweb2_ClickDmsFrontEnd_2000FetchButton
#    Log  ${MLIST_NO} ${MLIST_STATE}


	dms_dmsweb2_ClickDmsFrontEnd_2000FetchButton  













    ${match1}  ${match2}=    dms_dmsweb2_DmsFrontEnd_2000_stage1_1  ${excel_file_data}    transfer    2000

    Log  ${match1}
    Log  ${match2}







    ${match2}  ${match3}=    dms_dmsweb2_DmsFrontEnd_2000_stage1_i  ${match2}  ${excel_file_data}    transfer  2900

    Log  ${match2}
    Log  ${match3}




    dms_dmsweb2_DmsFrontEnd_2000_stage2_transfer_fetch  ${excel_file_data}  2000

    ${match1}  ${match2}=    dms_dmsweb2_DmsFrontEnd_2000_stage2_1  ${excel_file_data}    2000

    Log  ${match1}
    Log  ${match2}

    ${match2}  ${match3}=    dms_dmsweb2_DmsFrontEnd_2000_stage2_i  ${match2}  ${excel_file_data}    2000

    Log  ${match2}
    Log  ${match3}






#    Debug

#	Sleep  1s
	


#	Sleep  1s
	

 

    dms_dmsweb2_ClickDmsFrontEnduserID_logout 

    Sleep  3s


#	Return  ${CR_no}
