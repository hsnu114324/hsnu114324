#*** Settings ***
#Library    ImageHorizonLibrary   reference_folder=${CURDIR}   

#*** Test cases ***
*** Keywords ***

test_click_image

    imagehorizonlibrary.set reference folder   ${CURDIR}
    ${point_2}=  Locate  2.png
    Log_To_Console  ${point_2}
    Move to  ${point_2}
    Double Click     left


    Click Image     1.png
#    Click Image     2.png
    ${point_2}=  Locate  2.png
    Log_To_Console  ${point_2}
    Move to  ${point_2}
    Double Click     left
