*** Settings ***
Library  OperatingSystem
Library  ExcelLibrary
Library  String
Library  Collections
Library  CSVLibrary
Library  DateTime
Library  DatabaseLibrary
Library   Browser
Resource  Common/common_stock.robot
Resource  Common/common_finmind.robot


*** Test Cases ***
Create Lists Using For Loop

#    ${list_top}=  create list
#    ${list_middle}=  create list
#    ${list_bottom}=  create list
#
#
#    FOR  ${i}  IN RANGE  1  4  1
#    append_to_list  ${list_top}  ${list_middle}
#    END
#    log  ${list_top}
#
#
#    FOR  ${i}  IN RANGE  1  4  1
#    append to list  ${list_middle}  ${list_bottom}
#    END
#    log  ${list_middle}
#
#
#    FOR  ${i}  IN RANGE  1  4  1
#    append to list  ${list_bottom}  1
#    END
#    log  ${list_bottom}
#
#
#    log  ${list_top}
#    log  ${list_middle}
#    log  ${list_bottom}



#Example Test
    FOR    ${i}    IN RANGE    3
        ${list_${i}}=  Create List   ${i}  ${i}  ${i}
        log  ${list_${i}} 
    END



Example Test
    New Page    https://playwright.dev
    Get Text    h1    contains    Playwright
