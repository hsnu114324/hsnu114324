*** Keywords ***
test_stock_genChart

#    [Arguments] ${data_1} ${data_2} ${data_3} ${data_4} ${data_5} ${data_6} ${data_7} ${data_8} ${data_9}  
   

  ${YAML}=  Get File  ${CURDIR}${/}chart2.yaml
  ${LOADED}=  yaml.Safe Load  ${YAML}
#  Set To Dictionary  ${LOADED}[chartjs]\[options][scales][yAxes][1][ticks][max]  value=200
  Set To Dictionary  ${LOADED["chartjs"][1]["options"]["scales"]["yAxes"][1]["ticks"]}  min=200

  ${list_value}=  Create List
  Append To List  ${list_value}  300  400  500

  Set To Dictionary  ${LOADED["chartjs"][1]["options"]["scales"]["yAxes"][1]["ticks"]}  max=${list_value}
  ${OUTPUT}=  yaml.Dump  ${LOADED}
  Create File  newchart2.yaml  ${OUTPUT}

#  ${data_value}=  Get Dictionary Items  ${LOADED["chartjs"][0]["datasets"]["data"]}
#  @{data_value}=  Get From Dictionary  ${LOADED["chartjs"][0]["datasets"]}  data
#  @{data_value}=  Get From List  ${LOADED["chartjs"][0]["datasets"]["data"]}  0  
  ${data_value}=  Get slice From List  ${LOADED}[chartjs][0][datasets][0][data] 
#  ${data_value}=  Get variable value  ${LOADED}   

#  ${data_value}  Get Dictionary values  ${LOADED}[chartjs][0][datasets][0][data] 
#  ${data_value}=  Get variable value  ${LOADED["chartjs"][0]["datasets"]}  

  log   ${data_value}
  log list   ${data_value}
#  log list  ${data_value}


#if ...  ${LOADED}[chartjs][0][datasets]...

#${content_data1}=  set variabl  ${LOADED}[chartjs][0][datasets]...

#${cotent1}=  get_file  chartjsfil1.txt

#${content1}= set variable ?

#    append_to_file  chart3.html  ${content1}


    ${chartjs3file1_content}=  Get_file  chartjs3file1.txt 

#    ${chartjs3file2_variable}=  get_variables  ${LOADED}
    ${chartjs3file2pre_content}=  Get_file  chartjs3file2pre.txt 
    ${chartjs3file2_variable}=  Get From Dictionary  ${LOADED}[chartjs][0]  canvas_id 
    log  ${chartjs3file2_variable}
#    ${data_value}=  Get slice From List  ${LOADED}[chartjs][0][datasets][0][data] 
#    log   ${data_value}
    ${chartjs3file2middle_content}=  Get_file  chartjs3file2middle.txt 
    ${chartjs3file2post_content}=  Get_file  chartjs3file2post.txt 
#    ${chartjs3file3_variable}=  Get slice From List  ${LOADED}[chartjs][0][levels] 
    ${chartjs3file3_list}=  Get slice From List   ${LOADED}[chartjs][0][labels] 
    log  ${chartjs3file3_list}

    ${file3_variable_length}=  get length  ${chartjs3file3_list}

#    FOR  ${i}  IN RANGE  0  ${file3_variable_length}  1

#        ${chartjs3file3_variable}=  Evaluate  ",".join(${chartjs3file3_list})

#    END

#    log  ${chartjs3file3_variable}

#    ${chartjs3file3_content}=  Get_file  chartjs3file3.txt 


#    ${item}=   Get Length  ${LOADED}[chartjs]
#    log  ${item}






#    ${chartjs_item_list}=  Get slice From List   ${LOADED}[chartjs] 
#    log  ${chartjs_item_list}

#    ${chartjs_item_length}=  get length  ${chartjs_item_list}


#    FOR  ${i}  IN RANGE  0  ${chartjs_item_length}  1

#        ${chartjs3file19_variable}=  Evaluate  ",".join(${chartjs3file19_list})

#    END


#    ${data_13}=  Set_Variable  100


#    ${chart2yamlfile1_content}=  Set_Variable  \n-\n${SPACE}${SPACE}canvas_id:${SPACE}





#    ${chart2yamlfile1_content}=  Set_Variable  ${chart2yamlfile1_content}${data_1}
#    Log  ${chart2yamlfile1_content}









#    FOR  ${i}  IN RANGE  0  ${file19_variable_length}  1

#        ${chartjs3file19_variable}=  Evaluate  ",".join(${chartjs3file19_list})

#    END

#    log  ${chartjs3file19_variable}



    Remove_File  chart3.html

    append_to_file  chart3.html  ${chartjs3file1_content}
    append_to_file  chart3.html  ${chartjs3file2pre_content}
    append_to_file  chart3.html  ${chartjs3file2_variable}
    append_to_file  chart3.html  ${chartjs3file2middle_content}
    append_to_file  chart3.html  ${chartjs3file2_variable}
    append_to_file  chart3.html  ${chartjs3file2post_content}
    append_to_file  chart3.html  ${chartjs3file3_variable}
    append_to_file  chart3.html  ${chartjs3file3_content}
    append_to_file  chart3.html  ${chartjs3file19_variable}
    append_to_file  chart3.html  ${chartjs3file19_content}
    append_to_file  chart3.html  ${chartjs3file20_content}



