*** Settings ***
Library  OperatingSystem
Library  ExcelLibrary
Library  String
Library  Collections
Library  CSVLibrary
Library  DateTime
Library  DatabaseLibrary
Resource  Common/common_stock.robot
Resource  Common/common_finmind.robot


*** Variables ***
@{stock_list}    @{EMPTY}


#*** Keywords ***
*** Test Cases ***
test_stock_kd_kdj
#    [Arguments]     ${excel_file_name}  ${sheet_name}
    [Documentation]    Load sensor list file and prepare list
#    Log_To_Console   excel_file_name : ${excel_file_name}
#    Log_To_Console   sheet_name : ${sheet_name}



    Connect To Database Using Custom Params  sqlite3  database="./test.db"

    ${rsv_length}=      set_variable   9    
    ${rsv_length-1}=    evaluate       ${rsv_length} - 1    
    log   ${rsv_length-1}

    ${str_start_date}=  set_variable   2024-01-01
    ${str_end_date}=    set_variable   2024-04-01



    ${output}=    Query    SELECT DATE,stock_id,Trading_Volume,Trading_money,open,max,min,close,spread,Trading_turnover FROM daily_stock WHERE stock_id = '2454' AND DATE between '${str_start_date}' and '${str_end_date}' order by DATE ;
    Log  ${output}


    ${output_rsv}=    Query    SELECT DATE,stock_id,rsv FROM daily_stock_rsv WHERE stock_id = '2454' AND DATE between '${str_start_date}' and '${str_end_date}' order by DATE ;
    Log  ${output_rsv}










            ${open}=      set variable  4
            ${high}=      set variable  5
            ${low}=       set variable  6    
            ${close}=     set variable  7
            ${spread}=    set variable  8
            ${pointer}=   set variable  0
            ${high_data}=  Create List  
            ${low_data}=  Create List  
	    
            ${today_k}=   set variable  0
            ${today_d}=   set variable  0
            ${yesterday_k}=   set variable  0
            ${yesterday_d}=   set variable  0


	    
            ${date_length}=  get length  ${output}

            FOR  ${i}  IN RANGE  ${date_length}

    ${today_date}=  set variable  ${output}[${i}][0]     
    ${today_stock_id}=  set variable  ${output}[${i}][1]     
    ${today_trading_volume}=  set variable  ${output}[${i}][2]     
    ${today_trading_money}=  set variable  ${output}[${i}][3]     
    ${today_open}=  set variable  ${output}[${i}][4]     
    ${today_high}=  set variable  ${output}[${i}][5]     
    ${today_low}=  set variable  ${output}[${i}][6]     
    ${today_close}=  set variable  ${output}[${i}][7]     
    ${today_spread}=  set variable  ${output}[${i}][8]     
    ${today_trading_turnover}=  set variable  ${output}[${i}][9]  
    
    ${today_rsv}=  set variable  ${output_rsv}[${i}][2]  


                IF  ${today_rsv} == 0

                

#                    Append To List  ${high_data}  ${today_high}
#                    Append To List  ${low_data}   ${today_low}
#                    
#		    ${highest_order}=  set variable  0
#		    ${lowest_order}=   set variable  0
#		    ${highest_value}=  set variable  0
#		    ${lowest_value}=   set variable  0



#                    CONTINUE FOR LOOP
                    ${today_k}=  set variable  0
                    ${today_d}=  set variable  0
                    ${today_3d-2k}=  set variable  0
                    ${today_3k-2d}=  set variable  0

#                ELSE IF  ${rsv_length} == ${i}
#                     Sleep  1ms

                ELSE

#                    log  ${high_data}
#                    log  ${low_data}

                     IF  ${yesterday_k} == 0
                         ${yesterday_k}=   set variable  50
		     END

		     IF  ${yesterday_d} == 0
                         ${yesterday_d}=   set variable  50
		     END

                     ${today_k}=  evaluate  (2/3)*${yesterday_k} + (1/3)*${today_rsv}
                     ${today_d}=  evaluate  (2/3)*${yesterday_d} + (1/3)*${today_k}
                     ${today_3d-2k}=  evaluate      3*${today_d} - 2*${today_k}
                     ${today_3k-2d}=  evaluate      3*${today_k} - 2*${today_d}




#                    ${old_i}=  evaluate  ${i} - ${rsv_length}
#                    ${old_rsv_high_i_data}=  set variable  ${high_data}[${pointer}]
#                    ${old_rsv_low_i_data}=   set variable  ${low_data}[${pointer}]
#                    ${high_data}[${pointer}]=  set variable  ${output}[${i}][${high}]
#                    ${low_data}[${pointer}]=   set variable  ${output}[${i}][${low}]
#
#
#                    IF  ${high_data}[${pointer}] >= ${highest_value}
#                        ${highest_order}=  set variable  ${pointer}
#                        ${highest_value}=  set variable  ${high_data}[${highest_order}]
#                    ELSE
#                        IF  ${highest_order} == ${pointer}  
#                            ${highest_order}=  set variable  -1
#                            ${highest_value}=  set variable   0
#                            FOR  ${j}  IN RANGE  0  ${rsv_length}  1
#                                 IF  ${high_data}[${j}] > ${highest_value}
#                                     ${highest_order}=  set variable  ${j}
#                                     ${highest_value}=  set variable  ${high_data}[${highest_order}]
#                                 END
#                            END     
#                        ELSE
#                            log  ${highest_order}
#                            log  ${highest_value}
#                        END
#                    END
#
#
#
#
#
#
#                    IF  ${low_data}[${pointer}] <= ${lowest_value}
#                        ${lowest_order}=  set variable  ${pointer}
#                        ${lowest_value}=  set variable  ${low_data}[${lowest_order}]
#                    ELSE
#                        IF  ${lowest_order} == ${pointer}  
#                            ${lowest_order}=  set variable   0
#                            ${lowest_value}=  set variable   ${low_data}[${lowest_order}]
#                            FOR  ${j}  IN RANGE  0  ${rsv_length}  1
#                                 IF  ${low_data}[${j}] < ${lowest_value}
#                                     ${lowest_order}=  set variable  ${j}
#                                     ${lowest_value}=  set variable  ${low_data}[${lowest_order}]
#                                 END
#                            END     
#                        ELSE
#                            log  ${lowest_order}
#                            log  ${lowest_value}
#                        END
#                    END
#









#                    log  ${pointer}
#                    IF  ${pointer} >= ${rsv_length-1}
#                        ${pointer}=  set variable  0
#                    ELSE
#                        ${pointer}=  evaluate  ${pointer}+1
#                    END
#
#                    ${rsv}=  evaluate  ( (${today_close}-${lowest_value}) / (${highest_value}-${lowest_value}) )*100
#


                END


   

   

                    
		    
		    











                ${file_exists}=  Run Keyword And Return Status  OperatingSystem.File_Should_Exist   stock_csv_new_kd_rsv/${today_stock_id}_kdj_${today_date}[0:4].csv

                IF  '${file_exists}' == 'False'
                    Copy File  lvr_landcsv/a_lvr_land_a_header.csv  stock_csv_new_kd_rsv/${today_stock_id}_kdj_${today_date}[0:4].csv
                    Append To File   stock_csv_new_kd_rsv/${today_stock_id}_kdj_${today_date}[0:4].csv   日期,股票代碼,成交量,成交金額,開盤價,最高價,最低價,收盤價,漲跌幅,交易筆數,today_rsv,today_k,today_d,today_3d-2k,today_3k-2d\n
                END




#                ${high_low_value}=   set variable  ${today_date},${today_stock_id},${today},${list_i_j-1_3},${list_i_j-1_4},${list_i_j-1_5},${list_i_j-1_6},${list_i_j-1_7},${list_i_j-1_8},${list_i_j-1_9},${highest9}[${j}],${lowest9}[${j}],${rsv9}[${j}],${today_k},${today_d}
                ${high_low_value}=   set variable  ${today_date},${today_stock_id},${today_trading_volume},${today_trading_money},${today_open},${today_high},${today_low},${today_close},${today_spread},${today_trading_turnover},${today_rsv},${today_k},${today_d},${today_3d-2k},${today_3k-2d}
                log  ${high_low_value}

                ${high_low_by_array}=  set variable  ${high_low_value}

                log  ${high_low_by_array}


                ${csv_string}=  set variable  ${high_low_by_array}\n
                log  ${csv_string}

                Append To File   stock_csv_new_kd_rsv/${today_stock_id}_kdj_${today_date}[0:4].csv   ${csv_string}




                ${table_name}=  set variable  daily_stock_kdj
                ${name_1}=      set variable  date
                ${type_1}=      set variable  DATE
                ${name_2}=      set variable  stock_id
                ${type_2}=      set variable  varchar(100)

                ${name_3}=      set variable  today_rsv
                ${type_3}=      set variable  FLOAT

                ${name_4}=      set variable  today_k
                ${type_4}=      set variable  FLOAT
                ${name_5}=      set variable  today_d
                ${type_5}=      set variable  FLOAT
                ${name_6}=      set variable  today_3d-2k
                ${type_6}=      set variable  FLOAT
                ${name_7}=      set variable  today_3k-2d
                ${type_7}=      set variable  FLOAT




                ${output_sql}=    Execute Sql String    INSERT INTO ${table_name} VALUES ( '${today_date}', '${today_stock_id}', ${today_rsv}, ${today_k}, ${today_d}, ${today_3d-2k}, ${today_3k-2d} )

                log  ${output_sql}

                ${yesterday_k}=  set variable  ${today_k}
                ${yesterday_d}=  set variable  ${today_d}


  END



















