*** Keywords ***

power_bmcweb_off
	[Documentation]
	[Tags]
#***
	wistron_bmcweb_login
	wistron_bmcweb_ExpectPowerOn
	wistron_bmcweb_logout

#***
	wistron_bmcweb_login
#***
	wistron_bmcweb_GoToPage  ${url_power_control}
#***
	wistron_bmcweb_ClickPowerButtonOff
#***
	wistron_ipmi_WaitPowerOff
#***
#	
#***
	wistron_bmcweb_GoToPage  ${url_event_log_ipmi}
#***
	wistron_bmcweb_ExpectOemEventLog  
#***
	wistron_bmcweb_logout



