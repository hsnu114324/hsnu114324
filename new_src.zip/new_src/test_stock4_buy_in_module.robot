*** Keywords ***
#*** Test Cases ***
test_stock4_buy_in_module
    [Arguments]     ${excel_file_data}  ${query_start_date}  ${query_end_date}  ${query_stock_id}  ${query_database}

    [Documentation]    Load sensor list file and prepare list
    Log    ${excel_file_data}

    ${query_start_date}=  set variable  ${excel_file_data}[1]
    Log   ${query_start_date}
    ${query_end_date}=  set variable  ${excel_file_data}[2]
    Log   ${query_end_date}
    ${query_stock_id}=  set variable  ${excel_file_data}[3]
    Log   ${query_stock_id}
    ${query_database}=  set variable  ${excel_file_data}[4]
    Log   ${query_database}


    Connect To Database Using Custom Params  sqlite3  database="./${query_database}"


    ${query_primary_key}=  Query  select primary_key from primary_key limit 1 ;
    IF  ${query_primary_key}== []
        ${primay_key}=  set variable  1
    ELSE
        ${primary_key}=  set variable  ${query_primary_key}[0][0]
    END 




#    ${output}=    query_output_from_database  '${query_start_date}'  '${query_end_date}'  '${query_stock_id}'
#    Log  ${output}










#  ${estimate_child_id}=  set variable  1 



    ${list_i}=    Query    SELECT primary_key,date,strategy_id,separate_buyin_signal,class,stock_id,estimate_in_or_out,close,number_of_share,share_amount_price, evaluate_in_strategy_ror, estimate_in_stock_ror, evaluate_in_priority_buyin_signal, estimate_in_buyin_signal, evaluate_in_parent_id, assets_children_id, equity_children_id FROM estimate_in WHERE stock_id=${query_stock_id} AND DATE between '${query_start_date}' and '${query_end_date}' order by DATE ;

    Log  ${list_i}

#            ${list_i}=    post_csv_get_strategy_data    stock_csv_new_macd_dif/1_strategy_2024.csv
            ${length}=  Get length  ${list_i}
            ${length+1}=  evaluate  ${length} + 1


  FOR  ${i}  IN RANGE  ${length}


#     ${primary_key}=                 set variable  ${list_i}[${i}][0]  
     ${estimate_in_parent_id}=       set variable  ${list_i}[${i}][0]  
     ${date}=                        set variable  ${list_i}[${i}][1]   
     ${strategy_id}=                 set variable  ${list_i}[${i}][2]      
     ${buyin_signal}=                set variable  ${list_i}[${i}][3]  
     ${class}=                       set variable  ${list_i}[${i}][4]       
     ${stock_id}=                    set variable  ${list_i}[${i}][5]    
#     ${estimate_in_or_out}=          set variable  ${list_i}[${i}][6]  
     ${assets_in_or_out}=          set variable  ${list_i}[${i}][6]  
#     ${close}=                       set variable  ${list_i}[${i}][7]  
     ${unit_price}=                       set variable  ${list_i}[${i}][7]  
     ${currency}=                       set variable  ${list_i}[${i}][7]  
     ${currency_amount_NTD}=                       set variable  ${list_i}[${i}][7]  
     ${number_of_share}=             set variable  ${list_i}[${i}][8]  
     ${share_amount_price}=          set variable  ${list_i}[${i}][9]  
     ${evaluate_in_strategy_ror}=             set variable  ${list_i}[${i}][10]   
     ${estimate_in_stock_ror}=       set variable  ${list_i}[${i}][11]   
     ${evaluate_in_priority_buyin_signal}=       set variable  0 
     ${estimate_in_buyin_signal}=       set variable  0  
#     ${evaluate_in_strategy_id}=     set variable  ${list_i}[${i}][12]   



    IF  ${share_amount_price} > ${currency}
        sleep  1ms
    ELSE
        sleep  1ms
#       IF  ${strategy_priority} > ${stock_priority}  
#            ${table_name}=  strategy_out
#            insert_strategy_data_to_database  ${table_name}  ${primary_key}  ${date}  ${strategy_id}  ${buyin_signal}  ${class}  ${stock_id}  ${assets_in_or_out}  ${unit_price}  ${number_of_share}  ${share_amount_price}  ${evaluate_in_strategy_ror}  ${estimate_in_stock_ror}  ${estimate_in_parent_id}  ${strategy_out_children_id}  
#            Continue For Loop
#        END
    END

####################################################
#
#    ${past_close}=  set variable  0
#
#    ${today_close}=  set variable  1
#
#    ${period_spread}=  set variable  ${today_close} - ${past_close}
#
##    ${evaluate_in_strategy_ror}=  evaluate  ${period_spread} / ${today_close}
#
#    ${estimate_in_stock_ror}=  evaluate  ${period_spread} / ${today_close}
#
##    ${strategy_parent_id}=  set variable  ${list_i}[1][1]
##    log  ${strategy_parent_id}
#
#    ${strategy_out_children_id}=  set variable  0
#
##    set_strategy_table_childrend_id  ${i}  ${children_id}
##     post_csv_append_cell_data  stock_csv_new_macd_dif/${strategy_id}_strategy_${today_date}[0:4].csv  test_cell 
#
####################################################

#     IF  ${flag_disable_old_evaluate_buyin_signal} == 1
#           ${flag_disable_old_evaluate_buyin_signal}=  set variable  0
#          update_strategy_in_data_old_buyin_signal=0
#           ${output}=  Execute Sql String  Update
#      END



        ${table_name}=  set variable  assets

        ${strategy_out_children_id}=  set variable  0

                ${primary_key}=  evaluate  ${primary_key} + 1

            ${output}=  Execute sql string  update estimate_in set assets_children_id=${primary_key} where primary_key=${estimate_in_parent_id};
	    
        insert_assets_data_to_database  ${table_name}  ${primary_key}  ${date}  ${strategy_id}  ${buyin_signal}  ${class}  ${stock_id}  ${assets_in_or_out}  ${unit_price}  ${number_of_share}  ${share_amount_price}  ${evaluate_in_strategy_ror}  ${estimate_in_stock_ror}  ${evaluate_in_priority_buyin_signal}  ${estimate_in_buyin_signal}  ${estimate_in_parent_id}  ${strategy_out_children_id}  



        ${table_name}=  set variable  assets_in

        insert_assets_data_to_database  ${table_name}  ${primary_key}  ${date}  ${strategy_id}  ${buyin_signal}  ${class}  ${stock_id}  ${assets_in_or_out}  ${unit_price}  ${number_of_share}  ${share_amount_price}  ${evaluate_in_strategy_ror}  ${estimate_in_stock_ror}  ${evaluate_in_priority_buyin_signal}  ${estimate_in_buyin_signal}  ${estimate_in_parent_id}  ${strategy_out_children_id}  


        ${table_name}=  set variable  equity
        ${equity_in_or_out}=          set variable  out
        ${exchange_rate}=             set variable  1

        insert_equity_data_to_database  ${table_name}  ${primary_key}  ${date}  ${strategy_id}  ${buyin_signal}  ${class}  ${stock_id}  ${equity_in_or_out}  ${currency}  ${exchange_rate}  ${currency_amount_NTD}  ${evaluate_in_strategy_ror}  ${estimate_in_stock_ror}  ${evaluate_in_priority_buyin_signal}  ${estimate_in_buyin_signal}  ${estimate_in_parent_id}  ${strategy_out_children_id}  


                ${output}=  Execute sql string  update primary_key set primary_key=${primary_key};     
            















#                ${csv_header_string}=  set variable  日期,策略代號,買入訊號,股票代碼,收盤價,成交量,成交金額,evaluate_strategy_ror,strategy_parent_id,estimate_child_id\n


#                ${csv_string}=  set variable  ${today_date}, ${strategy_id}, ${buyin_signal}, ${today_stock_id}, ${today_close}, ${buyin_signal_volume}, ${buyin_among_NTD},${strategy_parent_id},${estimate_child_id},${evaluate_strategy_ror},${strategy_parent_id},${estimate_child_id}\n
#                log  ${csv_string}

#                post_csv_setdata  stock_csv_new_macd_dif/${strategy_id}_evaluate_in_${today_date}[0:4].csv  ${csv_header_string}  ${csv_string}  





  END

    Disconnect From Database

    OperatingSystem.Run  echo "primary_key|date|strategy_id|buyin_signal|class|stock_id|assets_in_or_out|unit_price|number_of_share|share_amount_price|evaluate_in_strategy_ror|estimate_in_stock_ror|evaluate_in_buyin_signal|estimate_in_buyin_signal|estimate_in_parent_id|strategy_out_children_id" > assets_in.txt                                     

    OperatingSystem.Run  sqlite3 test.db "select primary_key,date,strategy_id,buyin_signal,class,stock_id,assets_in_or_out,unit_price,number_of_share,share_amount_price,evaluate_in_strategy_ror,estimate_in_stock_ror,evaluate_in_buyin_signal,estimate_in_buyin_signal,estimate_in_parent_id,strategy_out_children_id from assets_in;" >> assets_in.txt
























