*** Settings ***
Library  OperatingSystem
Library  ExcelLibrary
Library  String
Library  Collections
Library  CSVLibrary
Library  DateTime
Resource  Common/common_stock.robot
Resource  Common/common_finmind.robot


*** Variables ***
@{stock_list}    @{EMPTY}


#*** Keywords ***
*** Test Cases ***
test_stock_kd_rsv_prepare
#    [Arguments]     ${excel_file_name}  ${sheet_name}
    [Documentation]    Load sensor list file and prepare list
#    Log_To_Console   excel_file_name : ${excel_file_name}
#    Log_To_Console   sheet_name : ${sheet_name}

 
#    stock_kd_k  a  k.csv
   
    ${old_csv_content}=    Get File    stock_csv_daily/1970-01-01.csv    encoding=UTF-8-SIG    encoding_errors=strict
    @{list_pre_1}=  Read Csv String To List  ${old_csv_content}

    ${old_csv_content}=    Get File    stock_csv_daily/1970-01-02.csv    encoding=UTF-8-SIG    encoding_errors=strict
    @{list_pre_2}=  Read Csv String To List  ${old_csv_content}

    ${old_csv_content}=    Get File    stock_csv_daily/1970-01-03.csv    encoding=UTF-8-SIG    encoding_errors=strict
    @{list_pre_3}=  Read Csv String To List  ${old_csv_content}


    ${old_csv_content}=    Get File    stock_csv_daily/1970-01-04.csv    encoding=UTF-8-SIG    encoding_errors=strict
    @{list_pre_4}=  Read Csv String To List  ${old_csv_content}


    ${old_csv_content}=    Get File    stock_csv_daily/1970-01-05.csv    encoding=UTF-8-SIG    encoding_errors=strict
    @{list_pre_5}=  Read Csv String To List  ${old_csv_content}


    ${old_csv_content}=    Get File    stock_csv_daily/1970-01-06.csv    encoding=UTF-8-SIG    encoding_errors=strict
    @{list_pre_6}=  Read Csv String To List  ${old_csv_content}


    ${old_csv_content}=    Get File    stock_csv_daily/1970-01-07.csv    encoding=UTF-8-SIG    encoding_errors=strict
    @{list_pre_7}=  Read Csv String To List  ${old_csv_content}


    ${old_csv_content}=    Get File    stock_csv_daily/1970-01-08.csv    encoding=UTF-8-SIG    encoding_errors=strict
    @{list_pre_8}=  Read Csv String To List  ${old_csv_content}


    ${old_csv_content}=    Get File    stock_csv_daily/1970-01-09.csv    encoding=UTF-8-SIG    encoding_errors=strict
    @{list_pre_9}=  Read Csv String To List  ${old_csv_content}


#    ${folder}=    set variable    /home/parallels/Downloads    # 更換成目標資料>夾的路徑


   Append To List  ${stock_list}  ${list_pre_1}   ${list_pre_2}  ${list_pre_3}  ${list_pre_4}  ${list_pre_5}  ${list_pre_6}  ${list_pre_7}  ${list_pre_8}  ${list_pre_9}
   Log list    ${stock_list}
   Log list    ${stock_list}[0]
   ${list_0}=  set variable  ${stock_list}[0]
   ${list_1}=  set variable  ${stock_list}[1]
   ${list_2}=  set variable  ${stock_list}[2]
   ${list_3}=  set variable  ${stock_list}[3]
   ${list_4}=  set variable  ${stock_list}[4]
   ${list_5}=  set variable  ${stock_list}[5]
   ${list_6}=  set variable  ${stock_list}[6]
   ${list_7}=  set variable  ${stock_list}[7]
   ${list_8}=  set variable  ${stock_list}[8]
#   ${list_9}=  set variable  ${stock_list}[9]
   ${list_0_0}=  set variable  ${list_0}[0]
#   ${list_0_1}=  set variable  ${list_0}[1]
   ${list_1_0}=  set variable  ${list_1}[0]
#   ${list_1_1}=  set variable  ${list_1}[1]
#   ${list_2_1}=  set variable  ${list_2}[1]
#   ${list_3_1}=  set variable  ${list_3}[1]
#   ${list_4_1}=  set variable  ${list_4}[1]
#   ${list_5_1}=  set variable  ${list_5}[1]
#   ${list_6_1}=  set variable  ${list_6}[1]
#   ${list_7_1}=  set variable  ${list_7}[1]
#   ${list_8_1}=  set variable  ${list_8}[1]
#   ${list_9_1}=  set variable  ${list_9}[1]


    ${max_file}    Set Variable    none
    ${max_num}    Set Variable    0
#    ${files}    OperatingSystem.List_Files_In_Directory    ${folder}    *.csv
    ${files}    OperatingSystem.List_Files_In_Directory    stock_csv_daily    *.csv

    FOR    ${file}    IN    @{files}
        ${file_split}=    Split String    ${file}    .
        Log_To_Console  ${file_split}[0]
        ${file_num}=  Convert_Date  ${file_split}[0]    result_format=%Y%m%d    date_format=%Y-%m-%d
        ${num}    Evaluate    ${file_num}
        IF    ${num} > ${max_num}
            ${max_file}    Set Variable    ${file}
            ${max_num}    Set Variable    ${num}
        END

        ${old_csv_content}=    Get File    stock_csv_daily/${file_split}[0].csv    encoding=UTF-8-SIG    encoding_errors=strict
        @{list_i}=  Read Csv String To List  ${old_csv_content}
        
        Append To List  ${stock_list}  ${list_i}
#        Log list    ${stock_list}
#        Log list    ${stock_list}[0]
        ${list_count}=  Get length  ${stock_list}
        log  ${list_count}
#        ${list_0}=  set variable  ${stock_list}[0]
#        ${list_1}=  set variable  ${stock_list}[1]
#        ${list_2}=  set variable  ${stock_list}[2]

#        FOR  ${i}  IN RANGE  ${list_count}-8  ${list_count} 0

	    ${list_post_1}=  evaluate  ${list_count}-9
            ${list_post_2}=  evaluate  ${list_count}-8
            ${list_post_3}=  evaluate  ${list_count}-7
            ${list_post_4}=  evaluate  ${list_count}-6
            ${list_post_5}=  evaluate  ${list_count}-5
            ${list_post_6}=  evaluate  ${list_count}-4
            ${list_post_7}=  evaluate  ${list_count}-3
            ${list_post_8}=  evaluate  ${list_count}-2
            ${list_post_9}=  evaluate  ${list_count}-1

            ${list_1}=  set variable  ${stock_list}[${list_post_1}]
            ${list_2}=  set variable  ${stock_list}[${list_post_2}]
            ${list_3}=  set variable  ${stock_list}[${list_post_3}]
            ${list_4}=  set variable  ${stock_list}[${list_post_4}]
            ${list_5}=  set variable  ${stock_list}[${list_post_5}]
            ${list_6}=  set variable  ${stock_list}[${list_post_6}]
            ${list_7}=  set variable  ${stock_list}[${list_post_7}]
            ${list_8}=  set variable  ${stock_list}[${list_post_8}]
            ${list_9}=  set variable  ${stock_list}[${list_post_9}]


            ${csv_string}=  set variable  ${empty}
            ${high_low_by_array}=  set variable  ${empty}

            ${length}=  Get length  ${list_1}

            ${highest9}=  Create List  ${EMPTY}
            ${lowest9}=  Create List  ${EMPTY}
            FOR  ${j}  IN RANGE  1  ${length}  1 
                log list  ${highest9}
                ${length_highest9}=  Get length  ${highest9}
                IF  ${length_highest9} == 0
                    Append To List  ${highest9}  0 
                END
                Append To List  ${highest9}  0 

                ${list_1_j}=  set variable  ${list_1}[${j}]
                ${temp_high_1}=  set variable  ${list_1_j}[5]
                ${temp_low_1}=  set variable  ${list_1_j}[6]
                IF  ${temp_high_1} >= ${highest9}[${j}]
                    ${highest9}[${j}]=  set variable  ${temp_high_1}
                END

                ${list_2_j}=  set variable  ${list_2}[${j}]
                ${temp_high_2}=  set variable  ${list_2_j}[5]
                ${temp_low_2}=  set variable  ${list_2_j}[6]
                IF  ${temp_high_2} >= ${highest9}[${j}]
                    ${highest9}[${j}]=  set variable  ${temp_high_2}
                END

                ${list_3_j}=  set variable  ${list_3}[${j}]
                ${temp_high_3}=  set variable  ${list_3_j}[5]
                ${temp_low_3}=  set variable  ${list_3_j}[6]
                IF  ${temp_high_3} >= ${highest9}[${j}]
                    ${highest9}[${j}]=  set variable  ${temp_high_3}
                END

                ${list_4_j}=  set variable  ${list_4}[${j}]
                ${temp_high_4}=  set variable  ${list_4_j}[5]
                ${temp_low_4}=  set variable  ${list_4_j}[6]
                IF  ${temp_high_4} >= ${highest9}[${j}]
                    ${highest9}[${j}]=  set variable  ${temp_high_4}
                END

                ${list_5_j}=  set variable  ${list_5}[${j}]
                ${temp_high_5}=  set variable  ${list_5_j}[5]
                ${temp_low_5}=  set variable  ${list_5_j}[6]
                IF  ${temp_high_5} >= ${highest9}[${j}]
                    ${highest9}[${j}]=  set variable  ${temp_high_5}
                END

                ${list_6_j}=  set variable  ${list_6}[${j}]
                ${temp_high_6}=  set variable  ${list_6_j}[5]
                ${temp_low_6}=  set variable  ${list_6_j}[6]
                IF  ${temp_high_6} >= ${highest9}[${j}]
                    ${highest9}[${j}]=  set variable  ${temp_high_6}
                END

                ${list_7_j}=  set variable  ${list_7}[${j}]
                ${temp_high_7}=  set variable  ${list_7_j}[5]
                ${temp_low_7}=  set variable  ${list_7_j}[6]
                IF  ${temp_high_7} >= ${highest9}[${j}]
                    ${highest9}[${j}]=  set variable  ${temp_high_7}
                END

                ${list_8_j}=  set variable  ${list_8}[${j}]
                ${temp_high_8}=  set variable  ${list_8_j}[5]
                ${temp_low_8}=  set variable  ${list_8_j}[6]
                IF  ${temp_high_8} >= ${highest9}[${j}]
                    ${highest9}[${j}]=  set variable  ${temp_high_8}
                END

                ${list_9_j}=  set variable  ${list_9}[${j}]
                ${temp_high_9}=  set variable  ${list_9_j}[5]
                ${temp_low_9}=  set variable  ${list_9_j}[6]
                IF  ${temp_high_9} >= ${highest9}[${j}]
                    ${highest9}[${j}]=  set variable  ${temp_high_9}
                END






                log list  ${lowest9}
                ${length_lowest9}=  Get length  ${lowest9}
                IF  ${length_lowest9} == 0
                    Append To List  ${lowest9}  999999999 
                END
                Append To List  ${lowest9}  999999999

                ${list_1_j}=  set variable  ${list_1}[${j}]
                ${temp_low_1}=  set variable  ${list_1_j}[6]
                IF  ${temp_low_1} <= ${lowest9}[${j}]
                    ${lowest9}[${j}]=  set variable  ${temp_low_1}
                END

                ${list_2_j}=  set variable  ${list_2}[${j}]
                ${temp_low_2}=  set variable  ${list_2_j}[6]
                IF  ${temp_low_2} <= ${lowest9}[${j}]
                    ${lowest9}[${j}]=  set variable  ${temp_low_2}
                END

                ${list_3_j}=  set variable  ${list_3}[${j}]
                ${temp_low_3}=  set variable  ${list_3_j}[6]
                IF  ${temp_low_3} <= ${lowest9}[${j}]
                    ${lowest9}[${j}]=  set variable  ${temp_low_3}
                END

                ${list_4_j}=  set variable  ${list_4}[${j}]
                ${temp_low_4}=  set variable  ${list_4_j}[6]
                IF  ${temp_low_4} <= ${lowest9}[${j}]
                    ${lowest9}[${j}]=  set variable  ${temp_low_4}
                END

                ${list_5_j}=  set variable  ${list_5}[${j}]
                ${temp_low_5}=  set variable  ${list_5_j}[6]
                IF  ${temp_low_5} <= ${lowest9}[${j}]
                    ${lowest9}[${j}]=  set variable  ${temp_low_5}
                END

                ${list_6_j}=  set variable  ${list_6}[${j}]
                ${temp_low_6}=  set variable  ${list_6_j}[6]
                IF  ${temp_low_6} <= ${lowest9}[${j}]
                    ${lowest9}[${j}]=  set variable  ${temp_low_6}
                END

                ${list_7_j}=  set variable  ${list_7}[${j}]
                ${temp_low_7}=  set variable  ${list_7_j}[6]
                IF  ${temp_low_7} <= ${lowest9}[${j}]
                    ${lowest9}[${j}]=  set variable  ${temp_low_7}
                END

                ${list_8_j}=  set variable  ${list_8}[${j}]
                ${temp_low_8}=  set variable  ${list_8_j}[6]
                IF  ${temp_low_8} <= ${lowest9}[${j}]
                    ${lowest9}[${j}]=  set variable  ${temp_low_8}
                END

                ${list_9_j}=  set variable  ${list_9}[${j}]
                ${temp_low_9}=  set variable  ${list_9_j}[6]
                IF  ${temp_low_9} <= ${lowest9}[${j}]
                    ${lowest9}[${j}]=  set variable  ${temp_low_9}
                END











                ${file_exists}=  Run Keyword And Return Status  OperatingSystem.File_Should_Exist   stock_csv/high_low_${file_split}[0].csv 

                IF  '${file_exists}' == 'False'
                    Copy File  lvr_landcsv/a_lvr_land_a_header.csv  stock_csv/high_low_${file_split}[0].csv 
                END




                ${high_low_value}=   set variable  ${file_split}[0],${list_9_j}[1],${highest9}[${j}],${lowest9}[${j}] 
                log  ${high_low_value}

                ${high_low_by_array}=  set variable  ${high_low_value}  

                log  ${high_low_by_array}

 
                ${csv_string}=  set variable  ${high_low_by_array}\n
                log  ${csv_string}
    
                Append To File   stock_csv/high_low_${file_split}[0].csv   ${csv_string}






            END










#        END

    END

    Log_To_Console    Max CSV file: ${max_file}
    Log    Max CSV file: ${max_file}
    Log_To_Console    Max num: ${max_num}
    ${int_max_num}=    Convert_To_Integer    ${max_num}
    ${str_max_num}=    Convert_To_String    ${max_num}
    Log_To_Console    int Max num: ${int_max_num}
    Log_To_Console    str Max num: ${str_max_num}























