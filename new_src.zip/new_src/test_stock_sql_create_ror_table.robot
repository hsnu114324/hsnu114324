*** Keywords ***
test_stock_sql_create_ror_table
#    [Arguments]  ${start_date}  ${end_date}
    [Documentation]
    [Tags]


    Connect To Database Using Custom Params  sqlite3  database="./test.db"


                ${table_name}=  set variable  RoR
                ${name_1}=      set variable  primary_key
                ${type_1}=      set variable  INT
                ${name_2}=      set variable  strategy_id
                ${type_2}=      set variable  INT
                ${name_3}=      set variable  today_date
                ${type_3}=      set variable  DATE
                ${name_4}=      set variable  amount_NTD
                ${type_4}=      set variable  FLOAT




    ${output}=   Execute Sql String     CREATE TABLE ${table_name} ( ${name_1} ${type_1}, ${name_2} ${type_2}, ${name_3} ${type_3}, ${name_4} ${type_4} ) ;
    Log  ${output}









