*** Keywords ***
test_stock_genYamlStart

#    [Arguments]  ${data_1}  ${data_2}  ${data_3}  ${data_4}  ${data_5}  ${data_6}  ${data_7}  ${data_8}  ${data_9}  
    
#    Log  ${data_1}
#    Log  ${data_2}
#    Log  ${data_3}
#    Log  ${data_4}
#    Log  ${data_5}
#    Log  ${data_6}
#    Log  ${data_7}
#    Log  ${data_8}
#    Log  ${data_9}



#args: 
#
#
#    copy or print chartjs
#for
#    copy canvas
#    append 1       # data_1 => 1 
#    copy labels
#  for
#    copy labels
#    append         # data_2 => Jan,Feb,Mar @list
#  end  
#    copy datasets
#  for  
#    copy type
#    append label           # data_3 => line
#    copy tabel
#    append excel           # data_4 => Exceptional?  
#    copy border
#    append '#e8c3b9'       # data_5 => '#e8c3b9'
#    cppy backgroundColor
#    append null            # data_6 => null
#    for
#      copy data
#      append i_data        # data_7 => 1,2,3 @list 
#    end
#  end
#    copy options-1-2
#    if
#      copy ticks
#      copy min
#      append min_value     # data_8 => 0
#      copy max
#      append max_value     # data_9 => 100
#    end
#    copy options-end
#end    



















#
#    ${chartjs2file1_content}=  post_chart_getchartjs2file1
#    ${chartjs2file2_content}=  post_chart_getchartjs2file2
#    ${chartjs2file3_content}=  post_chart_getchartjs2file3
#    ${chartjs2file4_content}=  post_chart_getchartjs2file4
#    ${chartjs2file5_content}=  post_chart_getchartjs2file5
#    ${chartjs2file6_content}=  post_chart_getchartjs2file6
#    ${chartjs2file7_content}=  post_chart_getchartjs2file7
#    ${chartjs2file8_content}=  post_chart_getchartjs2file8
#    ${chartjs2file9_content}=  post_chart_getchartjs2file9
#    ${chartjs2file10_content}=  post_chart_getchartjs2file10
#    ${chartjs2file11_content}=  post_chart_getchartjs2file11
#
#    ${chartjs2file2_content}=  Set_Variable  ${chartjs2file2_content}${chart_title2}
#    Log  ${chartjs2file2_content}
#
#
##    ${day_ii}=  set variable  1120101 
#
#    FOR  ${old_j}  IN RANGE  0  ${list_csv_by_cnt}  1
#
#        ${s1_by_array}=  get_from_list  ${list_csv_before_yesterday}  ${old_j}
#
#        Log  s1_by_array ${s1_by_array}
#        Log  ${s1_by_array}[7]
#        Log  ${s1_by_array}[7][0:5]
#
#
#        ${csv_string}=  set variable  ${empty}
#        FOR  ${day_ii}  IN RANGE  1121101  1121131  1 
#	    log  ${day_ii}
#            IF  ${s1_by_array}[7] > ${day_ii}
#    	        ${csv_string}=  set variable  ${csv_string},null
#                log  ${csv_string}
#                CONTINUE For Loop  
#    	    ELSE
#                IF  ${s1_by_array}[7] == ${day_ii}
#    	             ${csv_string}=  set variable  ${csv_string},${s1_by_array}[36]
#                     log  ${csv_string}
#                     Exit For Loop
#    	        ELSE
#    	            Fail
#    	        END
#    	    END
#        END
#
#
#    END
#
#    ${csv_string}=  set variable  ${csv_string}\n


#    ${tr_head}=  Set_Variable   <tr>
#    ${tr_tail}=  Set_Variable   </tr>
#    ${th_head}=  Set_Variable   <th scope="row">
#    ${th_tail}=  Set_Variable   </th>
#    ${td_head}=  Set_Variable   <td>
#    ${td_tail}=  Set_Variable   </td>



#    ${chartjs2file4_content}=  Set_Variable  ${chartjs2file4_content},${csv_string} 


#    Log  ${chartjs2file4_content}

#    Create_File  chart.html
#    ${content}=  Get_File     chart.html
#    Log  ${content}

    Remove_File  chart2.yaml

    append_to_file  chart2.yaml  chartjs:
#    post_chart_appendhtml2  ${chartjs2file2_content}
#    post_chart_appendhtml2  ${chartjs2file3_content}
#    post_chart_appendhtml2  ${chartjs2file4_content}
#    post_chart_appendhtml2  ${chartjs2file5_content}
#    post_chart_appendhtml2  ${chartjs2file6_content}
#    post_chart_appendhtml2  ${chartjs2file7_content}
#    post_chart_appendhtml2  ${chartjs2file8_content}
#    post_chart_appendhtml2  ${chartjs2file9_content}
#    post_chart_appendhtml2  ${chartjs2file10_content}
#    post_chart_appendhtml2  ${chartjs2file11_content}
