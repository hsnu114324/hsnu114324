*** Keywords ***
dms_sql_q_sid_fetch


  
    [Arguments] 	${excel_file_data}  ${Q_ACC_MONTH_SER} 
	[Documentation]
	[Tags]
#***




        Log     ${excel_file_data} 
        Log     ${excel_file_data}[29]  
        Log     ${excel_file_data}[30]  
        Log     ${excel_file_data}[5]
        Log     ${Q_ACC_MONTH_SER}

        Connect_To_dmstest_Databases

#        ${q_sid}=  query_data_from_dmstest_database  ${excel_file_data}[29]  ${excel_file_data}[30]  ${excel_file_data}[5]
#        ${q_sid}=  query_data_from_dmstest_database  ${excel_file_data}[1]  ${excel_file_data}[5]
        ${q_sid}=  query_data_from_dmstest_database  ${excel_file_data}[1]  ${Q_ACC_MONTH_SER}
        Log  ${q_sid}
        ${q_sid}=  query_data_from_dmstest_database  ${excel_file_data}[1]  ${Q_ACC_MONTH_SER}



#  END

	[Return]  ${q_sid}
