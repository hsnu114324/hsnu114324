*** Settings ***
Library  OperatingSystem
Library  ExcelLibrary
Library  String
Library  Collections
Library  CSVLibrary
Library  DateTime
Library  DatabaseLibrary
Library  yaml
Resource  Common/common_stock.robot
Resource  Common/common_finmind.robot
Resource  Common/common_chart.robot


*** Variables ***
@{stock_list}    @{EMPTY}


#*** Keywords ***
*** Test Cases ***
test_stock2_RoR_compare
#    [Arguments]     ${excel_file_name}  ${sheet_name}
    [Documentation]    Load sensor list file and prepare list
#    Log_To_Console   excel_file_name : ${excel_file_name}
#    Log_To_Console   sheet_name : ${sheet_name}











     Connect To Database Using Custom Params  sqlite3  database="./test.db"

    ${query_start_date}=  set variable  '2024-01-01'
    ${query_end_date}=    set variable  '2024-04-01'


    ${output_DATE}=    Query  SELECT DISTINCT DATE FROM daily_stock WHERE stock_id = '2330' AND DATE between ${query_start_date} and ${query_end_date} order by DATE ;
    Log  ${output_DATE}

    ${output_open}=    Query  SELECT DISTINCT open,DATE FROM daily_stock WHERE stock_id = '2330' AND DATE between ${query_start_date} and ${query_end_date} order by DATE ;
    Log  ${output_open}


    ${output_high}=    Query  SELECT DISTINCT max,DATE FROM daily_stock WHERE stock_id = '2330' AND DATE between ${query_start_date} and ${query_end_date} order by DATE ;
    Log  ${output_high}


    ${output_low}=    Query  SELECT DISTINCT min,DATE FROM daily_stock WHERE stock_id = '2330' AND DATE between ${query_start_date} and ${query_end_date} order by DATE ;
    Log  ${output_low}


    ${output_close}=    Query  SELECT DISTINCT close,DATE FROM daily_stock WHERE stock_id = '2330' AND DATE between ${query_start_date} and ${query_end_date} order by DATE ;
    Log  ${output_close}

    ${output_Trading_turnover}=    Query  SELECT DISTINCT Trading_turnover,DATE FROM daily_stock WHERE stock_id = '2330' AND DATE between ${query_start_date} and ${query_end_date} order by DATE ;
    Log  ${output_Trading_turnover}


    ${output_rsi}=    Query  SELECT DISTINCT rsi,DATE FROM daily_stock_rsi WHERE stock_id = '2330' AND DATE between ${query_start_date} and ${query_end_date} order by DATE ;
    Log  ${output_rsi}

    
    ${output_rsv}=    Query  SELECT DISTINCT rsv,DATE FROM daily_stock_rsv WHERE stock_id = '2330' AND DATE between ${query_start_date} and ${query_end_date} order by DATE ;
    Log  ${output_rsv}


    ${output_k}=    Query  SELECT DISTINCT today_k,DATE FROM daily_stock_kdj WHERE stock_id = '2330' AND DATE between ${query_start_date} and ${query_end_date} order by DATE ;
    Log  ${output_k}

    ${output_d}=    Query  SELECT DISTINCT today_d,DATE FROM daily_stock_kdj WHERE stock_id = '2330' AND DATE between ${query_start_date} and ${query_end_date} order by DATE ;
    Log  ${output_d}

    ${output_3d-2k}=    Query  SELECT DISTINCT [today_3d-2k],DATE FROM daily_stock_kdj WHERE stock_id = '2330' AND DATE between ${query_start_date} and ${query_end_date} order by DATE ;
    Log  ${output_3d-2k}

    ${output_3k-2d}=    Query  SELECT DISTINCT [today_3k-2d],DATE FROM daily_stock_kdj WHERE stock_id = '2330' AND DATE between ${query_start_date} and ${query_end_date} order by DATE ;
    Log  ${output_3k-2d}


    ${output_assets}=    Query  SELECT DISTINCT [today_stock_id],today_date FROM assets WHERE strategy_id = 1 AND DATE between ${query_start_date} and ${query_end_date} order by DATE ;
    Log  ${output_3k-2d}

    ${stock_kind_total}=  get length  ${output_assets}

    FOR  ${list_j}  IN  ${output_assets}  

         ${output_close}=      Query  SELECT DISTINCT close,DATE FROM daily_stock WHERE ${list_j}[1] = '2330' AND DATE between ${query_start_date} and ${query_end_date} order by DATE ;
    Log  ${output_close}

         ${output_equity}=      Query  SELECT DISTINCT amount_NTD,DATE FROM equity WHERE strategy_id = 1 AND DATE between ${query_start_date} and ${query_end_date} order by DATE ;

        ${RoR_amoung_NTD}=  evaluate  ${output_equity}[1] + ${output_close} * ${stock_volume}

        ${output_sql}=  Execute Sql String  INSERT INTO ${table_name} VALUES ( ${strategy_id}, '${today_date}', ${RoR_amount_NTD} )


    END  

### variable module

    
    ${buyin}=  set variable  0
    ${buyin_signal}=  set variable  0
    ${equity}=  set variable  0
    ${longterm_position}=  set variable  0
    ${longterm_position_list}=  Create List
    ${primary_key}=  set variable  0
    ${amount_price}=  set variable  0
    ${limit_up}=  set variable  0

    ${length_date}=  get length  ${output_DATE}
    FOR  ${i}  IN RANGE  ${length_date}

### strategy module



        log  ${output_k}[${i}]
        log  ${output_d}[${i}]

        log  ${output_k}[${i}][0]
        log  ${output_d}[${i}][0]

        IF  ${output_k}[${i}][0] > ${output_d}[${i}][0]
            ${buyin_signal}=  set variable  1
            ${buyin_signal_volume}=  set variable  10
        END


### buyin module
        IF  ${buyin_signal} == 1
    
            ${position}=  set variable  ${buyin_signal_volume}  
            ${buyin}=  set variable  0
            ${equity}=  evaluate  ${equity} - ${position}
            ${longterm_position}=  evaluate  ${longterm_position} + ${position}
            ${longterm_position_i}=  Create List  ${longterm_position}  ${output_k}[${i}][1]
            IF  ${limit_up} == 1
                ${cannot_buy_signla}= set variable  1
            END
        ELSE
            ${buyin_signal_volume}=  set variable  0
            ${position}=  set variable  ${buyin_signal_volume}  
            ${longterm_position}=  set variable  ${longterm_position} + ${position}
            ${longterm_position_i}=  Create List  ${longterm_position}  ${output_k}[${i}][1]
        END

        Append_To_list  ${longterm_position_list}  ${longterm_position_i} 


        ${primary_key}=  evaluate  ${primary_key} + 1
        ${class}=  set variable  tw_stock
        ${in_or_out}=  set variable  in
        ${volume}=     set variable  ${position}
        ${unit_price}=  set variable  1000
        ${amount_price}=  evaluate  ${volume} * ${amount_price}

        ${today_date}=  set variable  ${output_close}[${i}][1]
        ${today_stock_id}=  set variable  2330
        ${strategy_id}=  set variable  1
        ${table_name}=  set variable  assets

#        Append_To_list  ${primary_key}  ${strategy_id}  ${today_date}    ${class}  ${today_stock_id}  ${in_or_out}  ${volume}  ${unit_price}  ${amount_price} 

        ${output_sql}=  Execute Sql String  INSERT INTO ${table_name} VALUES ( ${primary_key}, ${strategy_id}, '${today_date}', '${class}', '${today_stock_id}', '${in_or_out}', ${volume}, ${unit_price}, ${amount_price} )


        ${table_name}=  set variable  equity
        ${currency}=    set variable  0
        ${class}=       set variable  cash
        ${in_or_out}=   set variable  in
        ${exchange_rate}=  set variable  1
        ${amount_NTD}=  set variable  0

        ${output_sql}=  Execute Sql String  INSERT INTO ${table_name} VALUES ( ${primary_key}, ${strategy_id}, '${today_date}', '${class}', '${in_or_out}', ${currency}, ${exchange_rate}, ${amount_NTD} )


        ${table_name}=  set variable  RoR

        ${output_sql}=  Execute Sql String  INSERT INTO ${table_name} VALUES ( ${strategy_id}, '${today_date}', ${amount_NTD} )



#        ${output_sql}=    Execute Sql String    INSERT INTO ${table_name} VALUES ( '${today_date}', '${today_stock_id}', ${today_rsv}, ${today_k}, ${today_d}, ${today_3d-2k}, ${today_3k-2d} )



### plot module

    END
    log  ${longterm_position}
    log  ${longterm_position_list}








    
    
    





            post_chart_genYamlStart   chart4.yaml 


            post_chart_genYaml2       chart4.yaml  mychart4  ${output_DATE}


            post_chart_genYaml3       chart4.yaml   line  today_close  '#e8c3b9'  ${empty}  false  'y-axis-1'  true  ${output_close}

            post_chart_genYaml3       chart4.yaml   line  longterm_position_list  '#36a2eb'  ${empty}  false  'y-axis-1'  true  ${longterm_position_list}


            post_chart_genYaml3       chart4.yaml   bar  bar_test  ${empty}  '#ff6384'  false  'y-axis-2'  true  ${output_Trading_turnover}

            post_chart_genYaml4       chart4.yaml   0  100000




            post_chart_genYaml2       chart4.yaml  mychart5  ${output_DATE}


            post_chart_genYaml3       chart4.yaml   line  today_rsv  '#36a2eb'  ${empty}  false  'y-axis-1'  true  ${output_rsv}

            post_chart_genYaml3       chart4.yaml   line  today_k    '#ff6384'  ${empty}  false  'y-axis-1'  true  ${output_k}

            post_chart_genYaml3       chart4.yaml   line  today_d    '#e8c3b9'  ${empty}  false  'y-axis-1'  true  ${output_d}

            post_chart_genYaml3       chart4.yaml   line  today_3d-2k    '#0f0f0f'  ${empty}  false  'y-axis-1'  true  ${output_3d-2k}

            post_chart_genYaml3       chart4.yaml   line  today_3k-2d    '#9f9f9f'  ${empty}  false  'y-axis-1'  true  ${output_3k-2d}

            post_chart_genYaml3       chart4.yaml   bar  bar_test  ${empty}  '#cc65fe'  false  'y-axis-2'  true  ${output_Trading_turnover}

            post_chart_genYaml4       chart4.yaml   0  100000


            post_chart_genChart2      chart4.yaml  chart4.html



#            [RETURN]    hello 
#            RETURN    ${1st_stock_no}  ${1st_stock_share_num}  ${2nd_stock_no}  ${2nd_stock_share_num}  ${3th_stock_no}  ${3th_stock_share_num}


