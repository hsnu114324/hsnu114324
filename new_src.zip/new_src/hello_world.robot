*** Keywords ***
hello world
    [Documentation]    hello world
    ...    hello world
    [Tags]    hello world

#    imagehorizonlibrary.set reference folder   ${CURDIR}

    Log_To_Console	${BMC_IP}

