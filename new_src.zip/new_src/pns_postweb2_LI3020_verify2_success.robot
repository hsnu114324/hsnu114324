*** Keywords ***
pns_postweb2_LI3020_verify2_success
	[Arguments]    ${user_no}  ${CR_no}
	[Documentation]
	[Tags]
#***
        log  ${CR_no}

        Close Browser    ALL

	post_postweb2_pnsBackEndlogin  https://pnstest.post.gov.tw/LI.adm/Login.aspx
#***
	post_postweb2_ClickPnsBackEndLoginUsername    ${user_no}
#	174646
#	#165406
#***
	post_postweb2_ClickPnsBackEndLoginEnter
	Sleep  1s  
#***
	post_postweb2_ClickPnsBackEndtvFunctionti  查證作業
#***
	post_postweb2_ClickPnsBackEndtvFunctiontj  LI3020
#***
	post_postweb2_ClickPnsBackEndContent1_btnQuery
#***
	post_postweb2_CheckPnsBackEndContent1_gvList_LinkButton_0   ${CR_no}
	post_postweb2_ClickPnsBackEndContent1_gvList_LinkButton_0
#***

        ${fvw2_btnFvwChange_is_visible}=  post_postweb2_FetchPnsBackEndContent1_fvw2_btnFvwChange
        Log  ${fvw2_btnFvwChange_is_visible}


########
    	IF	'${fvw2_btnFvwChange_is_visible}' == 'True'
	
	        ${HavePrint_match}  ${message}=  post_postweb2_FetchPnsBackEndContent1_fvw2_HavePrint
                Log  ${HavePrint_match}
                Log  ${message}

	        IF	'${HavePrint_match}' == 'PASS'
	            Sleep  1
	        ELSE IF	 '${HavePrint_match}' == 'FAIL'
                    post_postweb2_ClickPnsBackEndContent1_fvw2Print
	        END
	
	
                ${HaveUploadPicture_match}  ${message}=  Run Keyword And Ignore Error  post_postweb2_FetchPnsBackEndContent1_HaveUploadPicture

                Log  ${HaveUploadPicture_match}
                Log  ${message}

	        IF	'${HaveUploadPicture_match}' == 'PASS'

                    Sleep  1

	        ELSE IF	 '${HaveUploadPicture_match}' == 'FAIL'

                    post_postweb2_fvw2_ChooseVerifyPicture


                    Sleep  1
                    post_postweb2_ClickPnsBackEndContent1_fvw2_btnUpload
                    
	        END
	        post_postweb2_ClickPnsBackEndContent1_fvw2_ResultStateSuccess
    	        post_postweb2_ClickPnsBackEndContent1_btnFvw1Save
		
    	ELSE IF	 '${fvw2_btnFvwChange_is_visible}' == 'False'
                post_postweb2_ClickPnsBackEndContent1_fvw3_ResultStateSuccess
		post_postweb2_ClickPnsBackEndContent1_btnFvw2Save
    	END
########

#        post_postweb2_ClickPnsBackEndContent1_fvw3_ResultStateSuccess
#***
        
#***
        Sleep  1s

