*** Variables ***
${SOL_BIOS_OUTPUT}    ubuntu
${IPMI_SOL_LOG_FILE}    IPMI_SOL_LOG_FILE.txt

*** Keywords ***
test_stock







	@{list_csv_before_yesterday}=  read_csv_file_to_list  STOCK_DAY_ALL_20230216.csv
	${list_csv_by_cnt}=    Get length    ${list_csv_before_yesterday}
	Log_To_Console  list_csv_by_cnt ${list_csv_by_cnt}

	@{list_csv_yesterday}=  read_csv_file_to_list  STOCK_DAY_ALL_20230217.csv
	${list_csv_y_cnt}=    Get length    ${list_csv_yesterday}
	Log_To_Console  list_csv_y_cnt ${list_csv_y_cnt}



	@{pre_new_trans}=    Create List  0

#	FOR  ${s1}  IN RANGE  1  ${list_csv_by_cnt}  1
	FOR  ${s1}  IN RANGE  1  15  1

	Log_To_Console  s1 ${s1}
	${s1_by_array}=  get_from_list  ${list_csv_before_yesterday}  ${s1}
	Log_To_Console  s1_by_array ${s1_by_array}
	${s1_by}=  evaluate    1 + (${s1_by_array}[8]/${s1_by_array}[4])
	Log_To_Console  s1_by ${s1_by}
	${s1_y_array}=  get_from_list  ${list_csv_yesterday}  ${s1}
	Log_To_Console  s1_y_array ${s1_y_array}
	${s1_y}=  evaluate    1 + (${s1_y_array}[8]/${s1_y_array}[4])
	Log_To_Console  s1_y ${s1_y}

		@{pre_new_trans_array}=    Create List  0

#		FOR  ${s2}  IN RANGE  1  ${list_csv_y_cnt}  1
		FOR  ${s2}  IN RANGE  1  15  1

		${s2_by_array}=  get_from_list  ${list_csv_before_yesterday}  ${s2}
		Log_To_Console  s2_by_array ${s2_by_array}
		${s2_by}=  evaluate    1 + (${s2_by_array}[8]/${s2_by_array}[4])
		Log_To_Console  s2_by ${s2_by}
		${s2_y_array}=  get_from_list  ${list_csv_yesterday}  ${s2}
		Log_To_Console  s2_y_array ${s2_y_array}
		${s2_y}=  evaluate    1 + (${s2_y_array}[8]/${s2_y_array}[4])
		Log_To_Console  s2_y ${s2_y}
		
		${pre_new_trans_cell}=  evaluate   (${s1_by}/${s2_by})*(${s2_y}/${s1_y}) 
		append_to_list  ${pre_new_trans_array}  ${pre_new_trans_cell}  
		Log_To_Console  pre_new_trans_array ${s2} : ${pre_new_trans_array}[${s2}]

#		pre_new_trans[s1][s2] = (s1_by/s2_by) * (s2_y/s1_y) 
#		pre_new_trans[s1][s2] = (s1_by/s2_by) * (s2_y/s1_y) 
	
		END

	append_to_list  ${pre_new_trans}  ${pre_new_trans_array}	
	Log_To_Console  ${pre_new_trans}[${s1}]	
	Log_To_Console  ${pre_new_trans}


	END


	${test_sqrt}=   evaluate  random.random()
	Log_To_Console  test_sqrt ${test_sqrt}
	${test_sqrt}=  evaluate    math.sqrt(2)
	Log_To_Console  test_sqrt ${test_sqrt}


	
	@{list_csv_before_yesterday}=  read_csv_file_to_list  STOCK_DAY_ALL_20230216.csv
	@{list_csv_yesterday}=  read_csv_file_to_list  STOCK_DAY_ALL_20230217.csv
	@{list_csv_today}=  read_csv_file_to_list  STOCK_DAY_ALL_20210728.csv


	Log_To_Console  s1 ${s1}
	${s1_by_array}=  get_from_list  ${list_csv_before_yesterday}  ${s1}
	Log_To_Console  s1_by_array ${s1_by_array}
	${s1_by}=  evaluate    1 + (${s1_by_array}[8]/${s1_by_array}[4])
	Log_To_Console  s1_by ${s1_by}
	${s1_y_array}=  get_from_list  ${list_csv_yesterday}  ${s1}
	Log_To_Console  s1_y_array ${s1_y_array}
	${s1_y}=  evaluate    1 + (${s1_y_array}[8]/${s1_y_array}[4])
	Log_To_Console  s1_y ${s1_y}

	${s1_t_array}=  get_from_list  ${list_csv_today}  ${s1}
	Log_To_Console  s1_t_array ${s1_t_array}

	${standard_deviation_update}=  set variable  1
	${stock_price_predict}=  set variable  1
	${stock_price_update}=  set variable  1
	${stock_price_update_pre3}=  set_variable  1
	${stock_price_update_pre2}=  set_variable  1
	${stock_price_update_pre}=  set_variable  1

#	FOR  ${s1}  IN RANGE  ${n}
	FOR  ${s1}  IN RANGE  1  15  1
		${stock_price_average}=  evaluate  (${s1_by_array}[4] + ${s1_y_array}[4] + ${s1_t_array}[4])/3
		
		Log_To_Console  marco
		${sigma_predict}=  evaluate  (${s1_by_array}[4] - ${stock_price_average})**2 + (${s1_by_array}[4] - ${stock_price_average})**2 + (${s1_by_array}[4] - ${stock_price_average})**2
		Log_To_Console  marco
		${standard_deviation_predict}=  evaluate  math.sqrt(${sigma_predict}/3)
		Log_To_Console  marco
		Log_To_Console  standard_deviation_predict ${standard_deviation_predict}
		${k_gain}=  evaluate  ${standard_deviation_predict}/(${standard_deviation_predict + ${standard_deviation_update}})

		${stock_price_estimate}=  evaluate  (${k_gain} * ${stock_price_predict}) + ((1-${k_gain}) * ${stock_price_update})

		${stock_price_update_pre3}=  set_variable  ${stock_price_update_pre2}
		${stock_price_update_pre2}=  set_variable  ${stock_price_update_pre}
		${stock_price_update_pre}=  set_variable  ${stock_price_update}
		${stock_price_update}=  set_variable  ${stock_price_update}

		${stock_price_update_average}=  evaluate  (${stock_price_update_pre2} + ${stock_price_update_pre} + ${stock_price_update} )/3
		
		${sigma_update}=  evaluate  (${stock_price_update_pre2} - ${stock_price_update_average})**2 + (${stock_price_update_pre} - ${stock_price_update_average})**2 + (${stock_price_update} - ${stock_price_update_average})**2  

		${standard_deviation_predict}=  evaluate  math.sqrt(${sigma_update}/3)
	


	END



#	${x}=  get_from_list  ${list_csv2}  0 
#	Log_To_Console  ${x}
#	${y}=  get_from_list  ${x}  0 
#	Log_To_Console  ${y}

#	FOR  ${list}  IN  @{list_csv2}
#		Log_To_Console  ${list}[0]
#		Log_To_Console  ${list}[1]
#		Log_To_Console  ${list}
#	END















