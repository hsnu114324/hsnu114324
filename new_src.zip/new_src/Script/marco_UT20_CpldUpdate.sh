# Author : Andrey_Yang@wistron.com / Andrey Yang(Jui Yang) 2022.04.221
# Auto MB/Fanout/SW CPLD Update in UT2.0 Chassis

## ---History Log--- ##
# v0.0.1 - Not support get current version.
##-------------------##

#!/bin/bash 

# ========================================
# CPLD Type Select Command (AMI_OEM)
# ========================================
CPLDSelect="0x32 0xD6"
Mode="0x01"	#update mode
IdCode="0x00 0x00 0x00 0x00"
# ========================================
# HPM Execute Parameter
# ========================================
UPGRADE="upgrade"
CHECK="check"
# ========================================
# CPLD Version Command - req order(WIS_OEM)
# ========================================
MB_No="0x00"
FO_No=""
SW_No=""

Usage()
{
    echo "Usage: $0"
	echo " Option :"
	echo " -V                   Tool Verison"
	echo " -H                   BMC IP"
	echo " -U                   BMC user name"
	echo " -P                   BMC password"
	echo " -s <cpld type>       Select CPLD"
	echo "                           0 : MB"
	echo "                           1 : SW"
	echo "                           2 : Fanout"
#	echo " -v                   Get the EXISTING CPLD version"	
	echo " -u                   Get the CPLD firmware version to be updated"
	echo " -f  <fw file name>	Upgrade/Downgrade image name"
	echo " -I <1 | 0>           Interface."
	echo "                           0 : KCS"
	echo "                           1 : LAN"
	echo " -h                   Help!"
	echo ""
	echo " Example: "
	echo " Help! - $0 -h"
	echo " Check Tool Version - $0 -V"
#	echo " Get CPLD version(KCS) - ./UT20_CpldUpdate.sh -I 0 -v"
#	echo " Get CPLD version(LAN) - ./UT20_CpldUpdate.sh -I 1 -v -H <BMC_IP> -U admin -P admin"
	echo " CPLD FW Upgrade/Downgrade(KCS) - $0 -I 0 -s <cpld type> -f [file_name]"
	echo " CPLD FW Upgrade/Downgrade(LAN) - $0 -I 1 -H <BMC_IP> -U admin -P admin -s <cpld typel> -f [file_name]"
	echo " ex: $0 -H 10.32.25.107 -U admin -P admin -I 1 -s 0 -f UT20_MB_CPLD_v004_enc.hpm"
    echo ""
	exit 1
}

ipmi()
{	
	if [ "$SELECT_IF" = "1" ]
	then
		ipmitool -I lanplus -H $BMCIP -U $USER -P $PWD raw $*
	else
		ipmitool raw $*
	fi
}

# ipmitool hpm CLI update
ipmihpm()		
{
	if [ "$SELECT_IF" = "1" ]
	then

pwd
echo 1 > log_UT20_CpldUpdate.txt
date -R				 | tee -a log_UT20_CpldUpdate.txt
echo BMCIP        ${BMCIP}       | tee -a log_UT20_CpldUpdate.txt
echo USER         ${USER}        | tee -a log_UT20_CpldUpdate.txt
echo PWD          ${PWD}         | tee -a log_UT20_CpldUpdate.txt
echo SELECT_IF    ${SELECT_IF}   | tee -a log_UT20_CpldUpdate.txt
echo SELECT_CPLD  ${SELECT_CPLD} | tee -a log_UT20_CpldUpdate.txt
echo FILE_NAME    ${FILE_NAME}   | tee -a log_UT20_CpldUpdate.txt


#ipmitool -I lanplus -H $BMCIP -U $USER -P $PWD hpm $* force -z 0x8000

String='echo "y" |ipmitool -I lanplus -H $BMCIP -U $USER -P $PWD hpm $* force -z 0x8000   2>&1 | tee -a log_UT20_CpldUpate.txt '
echo $String | tee -a log_UT20_CpldUpdate.txt
eval $String
date -R				 | tee -a log_UT20_CpldUpdate.txt

	else
		ipmitool hpm $* force -z 0x8000
	fi
}

# Check ALL CPLD Version Cmd
GetCurrentCPLDVersion()	
{
	if [ "$SELECT_IF" = "1" ]
	then
		ipmitool -I lanplus -H $BMCIP -U $USER -P $PWD raw 0x3c 0x0f $MB_No
		ipmitool -I lanplus -H $BMCIP -U $USER -P $PWD raw 0x3c 0x0f $FO_No
		ipmitool -I lanplus -H $BMCIP -U $USER -P $PWD raw 0x3c 0x0f $SW_No
	else
		ipmitool raw 0x3c 0x0f $MB_No
		ipmitool raw 0x3c 0x0f $FO_No
		ipmitool raw 0x3c 0x0f $SW_No
	fi
}

echo -e "\n================================================="

InputParsing()
{
#while getopts "V H: U: P: s: f: v u I: h " opt; do
while getopts "V H: U: P: s: f: u I: h " opt; do		## remove v(current version checking)
  case $opt in
    V)
		echo "CPLD Update Tool Version : v0.0.1"
#		echo "Tool Verion!" 
		echo -e "\n--------------------"
		Usage
		exit
		;;
	H)
#		echo "Input IP"
		BMCIP=$OPTARG
		echo BMCIP "$BMCIP"
		;;
	U)
#		echo "Input User Name"
		USER=$OPTARG
		echo USER "$USER"
		;;
	P)
#		echo "Input Password"
		PWD=$OPTARG
		echo PWD "$PWD"
		;;
    u)
#		echo "Upgrade Version " 
		OPTION_U=1
		;;
    s)
#		echo "CPLD Select"
		SELECT_CPLD=$OPTARG
		echo SELECT_CPLD "$SELECT_CPLD"
		;;
    f)
#		echo "CPLD Upgrade Filename"
		FILE_NAME=$OPTARG
		echo FILE_NAME "$FILE_NAME"
		OPTION_F=1
		;;
	I)
#		echo "Interface(KCS/LAN)"
		SELECT_IF=$OPTARG
		echo SELECT_IF "$SELECT_IF"
		OPTION_L=1
		;;
    h)
#		echo "Help! / Usage!" 
		Usage
		exit
		;;
#	v)
##		echo "Current Version" 
#		OPTION_V=1
#		;;
    ?)
		echo "Invalid opt: -$OPTARG" 
		Usage
		exit
		;;
  esac
done
}

declare -i a=0

if [ "$*" = "" ]
then
	Usage
	exit
fi

InputParsing $@ 

if [ "$OPTION_L" != "1" ]
then
	Usage
	exit
else
	if [ "$SELECT_IF" = "" ]
	then
		Usage
		exit
	elif [ "$SELECT_IF" = "1" ]
	then
		if [ "$BMCIP" = "" ] || [ "$USER" = "" ] || [ "$PWD" = "" ]
		then
			Usage
			exit
		fi
	elif [ "$SELECT_IF" != "1" ] && [ "$SELECT_IF" != "0" ]
	then
		Usage
		exit
	fi
fi

#if [ "$OPTION_V" == "1" ]		# Current Version (-v)
#then
#	if [ "$SELECT_CPLD" == "" ]
#	then
#		Usage
#		exit
#	else	
#		GetCurrentCPLDVersion
#	fi
#	OPTION_V=0
#fi

if [ "$OPTION_F" = "1" ] || [ "$OPTION_U" = "1" ]		# File	(-f) || Upgrade Version (-u)
then

	if [ "$OPTION_U" = "1" ]	# Upgrade Version (-u)
	then
		if [ "$FILE_NAME" = "" ] 
		then
			Usage
			exit
		else
			ipmihpm $CHECK $FILE_NAME
		fi
		OPTION_U=0
		OPTION_F=0
	else

		if [ "$FILE_NAME" = "" ] 
		then
			Usage
			exit
		else	
			ipmi 0x3c 0x85 0x00								# stop sensor monitor
			ipmi $CPLDSelect $Mode $IdCode $SELECT_CPLD		# select 
			ipmihpm $UPGRADE $FILE_NAME
			sleep 5
		fi
		
		OPTION_F=0
		OPTION_L=0
	fi	
fi

echo -e "\n================================================="
echo "Done"
rm -rf $EXECUTE_HPM_UP
date -R
