#====================================================
#Yafuflash Update BMC via Network. Andrey20180427
#====================================================
#!/bin/bash
#UpdateImg="LUNA8BmcFwV000201.ima"
#BMCIP="10.32.25.119"
#USER=admin
#PWD=dgxluna.admin

#=====================
#Update Type :
#0x01 BMC
#=====================
UpdateType=0x01

#=====================
#SPIFlash :
#0 Inactive
#1 Image 1
#2 Image 2
#3 Both Image
#=====================
#SPIFlash=1

Uasge()
{
	echo "  Uasge: $0 [UpdateTool] [BMC_IP] [User_Name] [Password] [Image_Name] [Update_SPIFlash]"
	echo "  UpdateTool      ex: Yafuflash"
	echo "  BMC_IP          ex: 10.32.25.64"
	echo "  User_Name      	ex: admin"
	echo "  Password        ex: admin"
	echo "  Image_Name      ex: LUNA8BmcFwV000201.ima"
	echo "  Update_SPIFlash ex: 0:Inactive, 1: Image 1, 2:Image 2, 3: Both Image"
	echo "  Example: $0 Yafuflash 10.32.25.64 admin dgxluna.admin LUNA8BmcFwV000201.ima 3"
	exit 1
}

ipmi()
{
ipmitool -I lanplus -H $BMCIP -U $USER -P $PWD raw $*
}

GetCurrentVersion()
{
case $1 in
        "0x00")
                CurrentBMC=`ipmi $GetDeviceID | cut -d ' ' -f 4-5`
                echo -e "BMC Firmware version : $CurrentBMC"
                ;;
esac
}

StopNVService()
{
	service nvsm-apis stop
	sleep 5;
	service nvsm-apis-selwatcher stop
	sleep 5;
	service nvsm-apis-plugin-environment stop
	sleep 5;
	service nvsm-apis-plugin-memory stop
	sleep 5;
	service nvsm-apis-mongodb stop
	sleep 5;
	service nvsm-apis-mqtt stop
	sleep 5;
	service nvsm-env-dshm stop
	sleep 5;
	service nvsm-storage-dshm stop
	sleep 5;
	service nvsm-sys-dshm stop
	sleep 5;
	service nvidia-fabricmanager stop
	sleep 5;
	service nvidia-fallback stop
	sleep 5;
	service nvidia-persistenced stop
	sleep 5;
	service nv_peer_mem stop
	sleep 5;
	rmmod nvidia_drm
	sleep 5;
	rmmod nvidia_modeset
	sleep 5;
	rmmod nvidia_uvm
	sleep 5;
	rmmod nvidia
	sleep 5;
}

StartNVService()
{
	date
	service nvsm-apis start
	sleep 1;
	service nvsm-apis-selwatcher start
	sleep 1;
	service nvsm-apis-plugin-environment start
	sleep 1;
	service nvsm-apis-plugin-memory start
	sleep 1;
	service nvsm-apis-mongodb start
	sleep 1;
	service nvsm-apis-mqtt start
	sleep 1;
	service nvsm-env-dshm start
	sleep 1;
	service nvsm-storage-dshm start
	sleep 1;
	service nvsm-sys-dshm start
	sleep 1;
	service nvidia-fabricmanager start
	sleep 1;
	service nvidia-fallback start
	sleep 1;
	service nvidia-persistenced start
	sleep 1;
	service nv_peer_mem start
	sleep 1;
	modprobe nvidia_drm
	sleep 1;
	modprobe nvidia_modeset
	sleep 1;
	modprobe nvidia_uvm
	sleep 1;
	modprobe nvidia
	sleep 1;
}

PreDo()
{
	ENV_VERSION=`lsb_release -sr`
	if [ "$ENV_VERSION" = "18.04" ]
	then
		echo "Env Version : $ENV_VERSION"
		sudo apt-get install libssl1.0-dev
	elif [ "$ENV_VERSION" = "16.04" ]
	then
		echo "Env Version : $ENV_VERSION"
		sudo apt-get install libssl-dev
	fi
	sleep 20
}

UpdateProcess()
{
#Get Current Firmware Version
GetCurrentVersion $UpdateType
echo ""
date

#Yafuflash Update Firmware Command. Andrey20180427

yafu_log='log1'

pwd
echo 1 > log_LAN_YafuUpdate.txt
pwd | tee -a log_LAN_YafuUpdate.txt
echo UpdateTool ${UpdateTool}  | tee -a log_LAN_YafuUpdate.txt
echo BMCIP      ${BMCIP}       | tee -a log_LAN_YafuUpdate.txt
echo USER       ${USER}        | tee -a log_LAN_YafuUpdate.txt
echo PWD        ${PWD}         | tee -a log_LAN_YafuUpdate.txt
echo SPIFlash   ${SPIFLash}    | tee -a log_LAN_YafuUpdate.txt
echo UpdateType ${UpdateType}  | tee -a log_LAN_YafuUpdate.txt
echo UpdateImg  ${UpdateImg}   | tee -a log_LAN_YafuUpdate.txt
String='$UpdateTool -nw -ip $BMCIP -u $USER -p $PWD -mse $SPIFlash -d $UpdateType -fb -ieo -pfru -psel -pipmi -pauth -pnet -psnmp -pssh -pkvm -psyslog $UpdateImg 2>&1 | tee -a log_LAN_YafuUpdate.txt' 	# -fb = skip interactive/ -ieo = -ignore-existing-overrides
echo String= ${String}  | tee -a log_LAN_YafuUpdate.txt
eval $String
}


echo -e "\n================================================="
if [ $# -lt 5 ]
then
	Uasge
else
	UpdateTool=$1
	BMCIP=$2
	USER=$3
	PWD=$4
	UpdateImg=$5
	SPIFlash=$6
fi

echo "Yafuflash Update via Network process has been start"
echo "It may take you a few minutes of time"
echo -e "================================================="
declare -i a=0
PreDo
if [ "$ENV_VERSION" = "18.04" ]
then
	StopNVService
fi

UpdateProcess $UpdateImg
#sleep 360


if [ "$ENV_VERSION" = "18.04" ]
then
	StartNVService
fi

echo -e "\n================================================="
echo "Yafuflash Update via Network process has been done"
echo -e "================================================="
date

