import pandas as pd
import numpy as np

# 读取CSV文件并提取所需的列数据
#df = pd.read_csv('data.csv', usecols=[4, 5, 6, 7]).fillna(0)
df = pd.read_csv('data.csv', usecols=[7]).fillna(0)


# 将数据转换为NumPy数组
arr = df.to_numpy(dtype=float)

print(arr)

# 计算反矩阵
#inv_arr = np.linalg.inv(arr)

# 打印反矩阵
#print(inv_arr)
