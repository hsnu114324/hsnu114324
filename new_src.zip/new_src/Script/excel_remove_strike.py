import sys
import openpyxl

def remove_strike(file_name, sheet_name):
    book = openpyxl.load_workbook(file_name)
     
    sheet = book[sheet_name]
     
    for row in sheet.rows:
        for cell in row:
            if cell.font.strike:
                print(cell.value)
                cell.value=""
                print(cell.value)
                pass
    book.save(file_name)
    

if __name__ == '__main__':
    print("leng of argv", len(sys.argv) )
    if len(sys.argv) < 3:
        print('ex: python3 excel_remove_strike.py  file.xlsx  sheet_name')
        sys.exit()
    print(sys.argv[0])
    print(sys.argv[1])
    print("sheet_name : ",sys.argv[2])
    file_name = sys.argv[1]
    sheet_name = sys.argv[2]
    print(file_name)
    print(sheet_name)
    remove_strike( file_name ,sheet_name )    
