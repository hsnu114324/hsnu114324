#====================================================
#bios_update.sh
#====================================================
#!/bin/bash
#UpdateImg="LUNA8BmcFwV000201.ima"
#BMCIP="10.32.25.119"
#USER=admin
#PWD=dgxluna.admin

#=====================
#Update Type :
#0x01 BMC
#=====================
UpdateType=0x01

#=====================
#SPIFlash :
#0 Inactive
#1 Image 1
#2 Image 2
#3 Both Image
#=====================
#SPIFlash=1

Uasge()
{
	echo "  Uasge: $0 [UpdateTool] [BMC_IP] [User_Name] [Password] [Image_Name] "
	echo "  UpdateTool      ex: Yafuflash"
	echo "  BMC_IP          ex: 10.32.25.107"
	echo "  User_Name      	ex: admin"
	echo "  Password        ex: admin"
	echo "  Image_Name      ex: UT20_BIOS_010_enc.hpm"
#	echo "  Update_SPIFlash ex: 0:Inactive, 1: Image 1, 2:Image 2, 3: Both Image"
	echo "  Example: $0 Yafuflash 10.32.25.107 admin admin UT20_BIOS_010_enc.hpm"
	exit 1
}

ipmi()
{
ipmitool -I lanplus -H $BMCIP -U $USER -P $PWD raw $*
}

GetCurrentVersion()
{
                Current=`ipmi 0x30 0x81 0x1 0xa8 0x20 0x0 0x80`
		echo  "Current : $Current"
                CurrentBMC=`ipmi 0x30 0x81 0x1 0xa8 0x20 0x0 0x80 | head -n 1 | cut -d ' ' -f 4`
                echo  "bios Firmware version : $CurrentBMC"
                
}



UpdateProcess()
{
#Get Current Firmware Version
GetCurrentVersion
echo ""
date

#Yafuflash Update Firmware Command. Andrey20180427


pwd
echo 1 > log_bios_update_yafu.txt
pwd | tee -a log_bios_update_yafu.txt
echo UpdateTool ${UpdateTool}  | tee -a log_bios_update_yafu.txt
echo BMCIP      ${BMCIP}       | tee -a log_bios_update_yafu.txt
echo USER       ${USER}        | tee -a log_bios_update_yafu.txt
echo PWD        ${PWD}         | tee -a log_bios_update_yafu.txt
echo UpdateImg  ${UpdateImg}   | tee -a log_bios_update_yafu.txt
#String='echo -e "y" |ipmitool -I lanplus -H $BMCIP -U $USER -P $PWD hpm upgrade $UpdateImg -z 0x8000'
String='$UpdateTool -nw -ip $BMCIP -u $USER -p $PWD -fb -d 0x02 $UpdateImg  2>&1 | tee -a log_bios_update_yafu.txt '
echo $String | tee -a log_bios_update_yafu.txt
eval $String 

}


echo -e "\n================================================="
if [ $# -lt 4 ]
then
	Uasge
else
	UpdateTool=$1
	BMCIP=$2
	USER=$3
	PWD=$4
	UpdateImg=$5
#	SPIFlash=$5
fi

echo "bios Update via Network process has been start"
echo "It may take you a few minutes of time"
echo -e "================================================="

UpdateProcess $UpdateImg
#sleep 60


echo -e "\n================================================="
echo "bios Update via Network process has been done"
echo -e "================================================="
date

