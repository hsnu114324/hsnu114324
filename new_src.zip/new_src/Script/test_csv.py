import numpy as np
import csv

data = []
with open('data.csv', 'r') as file:
    reader = csv.reader(file)
    next(reader)
    for row in reader:
        # 提取收盘价、最高价、最低价和开盘价数据，并转换为浮点数
        prices = []
        for value in row[7:8]:
            if value.strip():  # 检查字符串是否非空
                prices.append(float(value))
            else:
                prices.append(0.0)  # 将空字符串替换为0.0或其他合适的值
        data.append(prices)

arr = np.array(data)
print(arr)
#inv_arr = np.linalg.inv(arr)
#print(inv_arr)

