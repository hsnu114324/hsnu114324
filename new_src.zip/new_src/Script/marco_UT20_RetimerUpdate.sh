# Author : John_Hsieh@wistron.com / John Hsieh 2022.06.11
# Auto Fanout/Interposer Re-timer Update in UT2.0 Chassis

## ---History Log--- ##
# v0.0.1 - 	First Version
# v0.0.2 -  Fix Set update target command (remove "0x" string)
# v0.0.3 -  Change the script for KCS IFC.
# v0.0.4 -  Change board type to accept string parameter
##-------------------##

#!/bin/bash 

# ========================================
# HPM Execute Parameter
# ========================================
UPGRADE="upgrade"
CHECK="check"

Usage()
{
    echo "Usage: $0"
	echo " Option :"
	echo " -V                    Tool Verison"
	echo " -H                    BMC IP"
	echo " -U                    BMC user name"
	echo " -P                    BMC password"
	echo " -s <Board type>       Select board type"
	echo "                           'fanout'     : Fanout Board"
	echo "                           'interposer' : Interposer Board"
	echo " -n <Re-timer number>  Select Re-timer number"
	echo "                           Fanout     : 0 ~ 3"
	echo "                           Interposer : 0 ~ 7"
	echo " -u                    Get the Re-timer firmware version to be updated"
	echo " -f <fw file name>     Upgrade/Downgrade image name"
	echo " -I <1 | 0>            Interface."
	echo "                           0 : KCS"
	echo "                           1 : LAN"
	echo " -h                    Help!"
	echo ""
	echo " Example: "
	echo " Help! - $0 -h"
	echo " Check Tool Version - $0 -V"
	echo " Re-timer FW Upgrade/Downgrade(KCS) - $0 -I 0 -s fanout -n <Re-timer number> -f [file_name]"
	echo " Re-timer FW Upgrade/Downgrade(LAN) - $0 -I 1 -H <BMC_IP> -U admin -P admin -s interposer -n <Re-timer number> -f [file_name]"
	echo " ex: $0 -H 10.32.25.107 -U admin -P admin -I 1 -s fanout -n 0 -f UT20_G4_RETIMER_011501_enc.hpm "
    echo ""
	exit 1
}

ipmi()
{	
	if [ "$SELECT_IF" = "1" ]
	then
		ipmitool -I lanplus -H $BMCIP -U $USER -P $PWD raw $*
	else
		ipmitool raw $*
	fi
}

# ipmitool hpm CLI update
ipmihpm()		
{
	if [ "$SELECT_IF" = "1" ]
	then


pwd
echo 1 > log_UT20_RetimerUpdate.txt
echo BMCIP          ${BMCIP}          | tee -a log_UT20_RetimerUpdate.txt
echo USER           ${USER}           | tee -a log_UT20_RetimerUpdate.txt
echo PWD            ${PWD}            | tee -a log_UT20_RetimerUpdate.txt
echo SELECT_IF      ${SELECT_IF}      | tee -a log_UT20_RetimerUpdate.txt
echo SELECT_BOARD   ${SELECT_BOARD}   | tee -a log_UT20_RetimerUpdate.txt
echo SELECT_NUMBER  ${SELECT_NUMBER}  | tee -a log_UT20_RetimerUpdate.txt
echo FILE_NAME      ${FILE_NAME}      | tee -a log_UT20_RetimerUpdate.txt


#ipmitool -I lanplus -H $BMCIP -U $USER -P $PWD hpm $* force -z 0x8000

String='echo "y" |ipmitool -I lanplus -H $BMCIP -U $USER -P $PWD hpm $* force -z 0x8000   2>&1 | tee -a log_UT20_RetimerUpdate.txt '
echo $String | tee -a log_UT20_RetimerUpdate.txt
eval $String




	else
		ipmitool hpm $* force -z 0x100
	fi
}

# Check current target re-timer Version Cmd
GetCurrentTargetRetimerVersion()	
{
	if [ "$SELECT_BOARD" = "fanout" ]
	then
		if [ "$SELECT_IF" = "1" ]
		then
echo			ipmitool -I lanplus -H $BMCIP -U $USER -P $PWD raw 0x3c 0x0f 0x3$SELECT_NUMBER
			ipmitool -I lanplus -H $BMCIP -U $USER -P $PWD raw 0x3c 0x0f 0x3$SELECT_NUMBER
		else 
			ipmitool raw 0x3c 0x0f 0x3$SELECT_NUMBER
		fi
	elif [ "$SELECT_BOARD" = "interposer" ]
	then
		if [ "$SELECT_IF" = "1" ]
		then
echo			ipmitool -I lanplus -H $BMCIP -U $USER -P $PWD raw 0x3c 0x0f 0x4$SELECT_NUMBER
			ipmitool -I lanplus -H $BMCIP -U $USER -P $PWD raw 0x3c 0x0f 0x4$SELECT_NUMBER
		else 
			ipmitool raw 0x3c 0x0f 0x4$SELECT_NUMBER
		fi
	fi
	
	if [ "$?" != "0" ] 
	then
		Usage
		exit
	fi
}

# Set update target Retimer Cmd
SetUpdateTargetRetimer()	
{
	if [ "$SELECT_BOARD" = "fanout" ]
	then
		if [ "$SELECT_IF" = "1" ]
		then
			ipmitool -I lanplus -H $BMCIP -U $USER -P $PWD raw 0x3c 0x49 $SELECT_NUMBER
		else 
			ipmitool raw 0x3c 0x49 $SELECT_NUMBER
		fi
	elif [ "$SELECT_BOARD" = "interposer" ]
	then
		INTERPOSER_NUM=$((4+$SELECT_NUMBER))
		#echo "$INTERPOSER_NUM"
		if [ "$SELECT_IF" = "1" ]
		then
			ipmitool -I lanplus -H $BMCIP -U $USER -P $PWD raw 0x3c 0x49 $INTERPOSER_NUM
		else 
			ipmitool raw 0x3c 0x49 $INTERPOSER_NUM
		fi
	fi
	
	if [ "$?" != "0" ] 
	then
		Usage
		exit
	fi
}

echo -e "\n================================================="

InputParsing()
{
while getopts "V H: U: P: s: n: f: u I: h " opt; do	
  case $opt in
    V)
		echo "Re-timer Update Tool Version : v0.0.4"
		echo "" 
#		echo -e "\n--------------------"
#		Usage
		exit
		;;
	H)
#		echo "Input IP"
		BMCIP=$OPTARG
		echo BMC_IP "$BMCIP"
		;;
	U)
#		echo "Input User Name"
		USER=$OPTARG
		echo USER "$USER"
		;;
	P)
#		echo "Input Password"
		PWD=$OPTARG
		echo PWD "$PWD"
		;;
    u)
#		echo "Upgrade Version " 
		OPTION_U=1
		;;
    s)
#		echo "Board Select"
		SELECT_BOARD=$OPTARG
		echo SELECT_BOARD "$SELECT_BOARD"
		;;
	n)
#		echo "Number Select"
		SELECT_NUMBER=$OPTARG
		echo SELECT_NUMBER "$SELECT_NUMBER"
		;;
    f)
#		echo "Re-timer Upgrade Filename"
		FILE_NAME=$OPTARG
		echo FILE_NAME "$FILE_NAME"
		OPTION_F=1
		;;
	I)
#		echo "Interface(KCS/LAN)"
		SELECT_IF=$OPTARG
		echo SELECT_IF "$SELECT_IF"
		OPTION_L=1
		;;
    h)
#		echo "Help! / Usage!" 
		Usage
		exit
		;;
    ?)
		echo "Invalid opt: -$OPTARG" 
		Usage
		exit
		;;
  esac
done
}

#declare -i a=0

if [ "$*" = "" ]
then
	Usage
	exit
fi
InputParsing $@ 

if [ "$OPTION_L" != "1" ]
then
	Usage
	exit
else
	if [ "$SELECT_IF" = "" ]
	then
		Usage
		exit
	elif [ "$SELECT_IF" = "1" ]
	then
		if [ "$BMCIP" = "" ] || [ "$USER" = "" ] || [ "$PWD" = "" ]
		then
			Usage
			exit
		fi
	elif [ "$SELECT_IF" != "1" ] && [ "$SELECT_IF" != "0" ]
	then
		Usage
		exit
	fi
fi

if [ "$SELECT_BOARD" != "fanout" ] && [ "$SELECT_BOARD" != "interposer" ]
then
	Usage
	exit
fi


if [ "$OPTION_F" = "1" ] || [ "$OPTION_U" = "1" ]		# File	(-f) || Upgrade Version (-u)
#if [ "$OPTION_F" == "1" ]
then

	if [ "$OPTION_U" = "1" ]	# Upgrade Version (-u)
	then
		if [ "$FILE_NAME" = "" ] 
		then
			Usage
			exit
		else
			ipmihpm $CHECK $FILE_NAME
		fi
		OPTION_U=0
		OPTION_F=0
	else

		if [ "$FILE_NAME" = "" ] 
		then
			Usage
			exit
		else	
			ipmi 0x3c 0x85 0x00								# stop sensor monitor
			echo "Current version"
			GetCurrentTargetRetimerVersion			# check current version
#			if [ "$?" != "0" ]
#			then
#				echo "Can't not get the current version!"
#				exit
#			fi
			SetUpdateTargetRetimer						# set target update re-timer
			ipmihpm $UPGRADE $FILE_NAME
			sleep 5
			echo "Current version"
			GetCurrentTargetRetimerVersion				# check current version
		fi		
		OPTION_F=0
		OPTION_L=0
	fi	
fi

echo -e "\n================================================="
echo "Done"
rm -rf $EXECUTE_HPM_UP
date
