import os
import sys
import openpyxl
import pandas as pd
import numpy as np

def test_numpy(B_name, C_name):
#    array = np.loadtxt(B_name, skiprows=1, delimiter=',')
#    print(array)
    df_B = pd.read_csv(B_name, usecols=[7]).fillna(0)
    B = df_B.to_numpy(dtype=float)
    print("B : ", B)

    df_C = pd.read_csv(C_name, usecols=[7]).fillna(0)
    C = df_C.to_numpy(dtype=float)
    print("C : ",C)

    B_inv = np.linalg.pinv(B)
    print("B_inv : ", B_inv )
    A = np.dot(C, B_inv)
    print("A : ", A)
    print("A * B = C : ", np.dot(A, B))


if __name__ == '__main__':
    print("leng of argv", len(sys.argv) )
    if len(sys.argv) < 3:
        print('ex: ( A * B = C ) ==> (A = C * B_inv )')
        print('ex: python3 ' + os.path.basename(__file__)  + ' B.csv  C.csv')
        sys.exit()
    print(sys.argv[0])
    print("B.csv : ",sys.argv[1])
    print("C.csv : ",sys.argv[2])
    B_name = sys.argv[1]
    C_name = sys.argv[2]
    print(B_name)
    print(C_name)
    test_numpy( B_name ,C_name )    
