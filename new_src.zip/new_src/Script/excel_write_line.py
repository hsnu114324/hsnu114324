import sys
import openpyxl

def remove_strike(file_name, sheet_name):
    book = openpyxl.load_workbook(file_name)
     
    sheet = book[sheet_name]
     
    for row in sheet.rows:
        for cell in row:
            if cell.font.strike:
                print(cell.value)
                cell.value=""
                print(cell.value)
                pass
    book.save(file_name)
    
#def write_line(file_name, sheet_name, listtitle, listdata)
def write_line(tupledata):
    
    listdata = list(tupledata)
    print("listdata : ", listdata)
    print("listdata[0] : ", listdata[0])

    file_name = listdata[1]
    sheet_name = listdata[2]
    line_num = listdata[3]

    print("file_name : ", file_name)
    print("sheet_name : ", sheet_name)
    print("line_num : ", line_num)
    

    book = openpyxl.load_workbook(file_name)
     
    sheet = book[sheet_name]
     
     
    
    for column_num in range(len(listdata)-4):
        line_num = int(line_num)
        print("line_num : ", line_num)
        column_num = column_num+1
        print("column_num : ", column_num)
        sheet.cell(row=line_num, column=column_num).value = listdata[column_num+3] 
        pass
     

    book.save(file_name)


if __name__ == '__main__':
#    print("leng of argv", len(sys.argv) )
    if len(sys.argv) < 3:
#        print('ex: python3 ' ,sys.argv[0], ' file.xlsx  sheet_name')
        print('ex: python3 excel_write_line file.xlsx  sheet_name line_data')
        print('ex: python3 excel_write_line file.xlsx  sheet_name 1 2 3 4 5')
        sys.exit()
#    print(sys.argv[0])
#    print(sys.argv[1])
#    print("sheet_name : ",sys.argv[2])
    file_name = sys.argv[1]
    sheet_name = sys.argv[2]
#    print(file_name)
#    print(sheet_name)
#    remove_strike( file_name ,sheet_name )    
    write_line(sys.argv)    
