*** Keywords ***
dms_dmsweb2_b1d0_upload
    [Arguments]  ${excel_file_data}
  
#  ${MON_PAY}
	[Documentation]
	[Tags]
#***

    Log  ${excel_file_data}

#***
	dms_dmsweb2_pnsFrontEndloginChrome  http://localhost:3000/
#	post_postweb2_pnsFrontEndloginFirefox  https://pnstest.post.gov.tw/LI.Web/LI0010.aspx


#    Debug

    dms_dmsweb2_ClickDmsFrontEnduserID_DM_login

    dms_dmsweb2_ClickDmsFrontEndMenuInput  b1d0

    dms_dmsweb2_ClickDmsFrontEnd_b1d0ACC_DATE  ${excel_file_data}[1] 
    
    dms_dmsweb2_ClickDmsFrontEnd_b1d0CNTR_NO  ${excel_file_data}[2] 

    dms_dmsweb2_ClickDmsFrontEnd_b1d0SEGC_NO  ${excel_file_data}[3] 

    dms_dmsweb2_ClickDmsFrontEnd_b1d0FetchButton

    Take Screenshot

    dms_dmsweb2_ClickDmsFrontEnd_b1d0UploadButton

    

    Sleep  1s
    
    dms_dmsweb2_ClickDmsFrontEnduserID_logout

    Sleep  3s

#	Return  ${CR_no}
