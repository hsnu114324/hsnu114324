*** Variables ***
${fanout_upgrade_version}      10
${fanout_downgrade_version}    00
${fanout_upgrade_image}        UT20_FANOUT_CPLD_v011_enc.hpm
${fanout_downgrade_image}      UT20_FANOUT_CPLD_v010_enc.hpm



*** Keywords ***
cpld_ipmi_update_fanout

	wistron_bmcweb_logout
###
  FOR  ${i}  IN RANGE  2

	${CpldVersion}=   wistron_ipmi_GetFanoutCpldVersion
        Log_To_Console  CpldVerion ${CpldVersion}

	${CpldVersion_match}=	Get Regexp Matches	${CpldVersion}		${fanout_upgrade_version}
	IF	${CpldVersion_match}
		${CpldVersion_major}	Set Variable	${EMPTY}
		${CpldVersion_major}	Set Variable	${fanout_downgrade_version}
		Log_To_Console  CpldVersion_major ${CpldVersion_major}
		Log_To_Console  ${CpldVersion}
		Log_To_Console  ${fanout_downgrade_image}
		wistron_ipmi_updatecpld_fanout  ${fanout_downgrade_image}
	ELSE
		${CpldVersion_major}	Set Variable	${EMPTY}
		${CpldVersion_major}	Set Variable	${fanout_upgrade_version}
		Log_To_Console  CpldVersion_major ${CpldVersion_major}
		Log_To_Console  ${CpldVersion}
		Log_To_Console  ${fanout_upgrade_image}
		wistron_ipmi_updatecpld_fanout  ${fanout_upgrade_image}
	END


###

	${target_CpldVersion}=   wistron_ipmi_GetFanoutCpldVersion
    	Should Be Equal    ${target_CpldVersion}    ${CpldVersion_Major}

  END



