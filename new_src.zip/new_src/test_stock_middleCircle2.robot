*** Keywords ***
test_stock_middleCircle2


#FOR list
#read csv
#score = macd + ma / 2
#
#position
#
#true money
#
#total = 
#
#1st_money_shoud_be = 5000?
#
#5000 / 1st_stock_price = stcok_share_num
#
#buy 1st_stock_num  stock_share_num
#
#
#100
#50
#20
#


#1.    FOR year 

#2.       FOR file in taiwan_stock_no

#       ${old1_csv_content}=    Get File    stock_csv_new_macd_dif/${stock_no}_dif_2023.csv    encoding=UTF-8-SIG    encoding_errors=strict





#       ${list_3}=   Read Csv File To Associative  stock_csv_new_macd_dif/0050_dif_2023.csv  line_numbers="0"
#
#       log  ${list_3}
#       log  ${list_3}[1]
#       log  ${list_3}[1][日期]
#       log  ${list_3}[1][日期][1]
#
#       ${list_3_length}=  get length  ${list_3}
#       log  ${list_3_length}
#       ${list_3_1_length}=  get length  ${list_3}[1]
#       log  ${list_3_1_length}
#       ${list_3_1_0_length}=  get length  ${list_3}[1][日期]
#       log  ${list_3_1_0_length}
#       ${list_3_1_0_1_length}=  get length  ${list_3}[1][日期][1]
#       log  ${list_3_1_0_1_length}

       ${old1_csv_content}=    Get File    stock_csv_new_macd_dif/0050_dif_2023.csv    encoding=UTF-8-SIG    encoding_errors=strict
        @{list_1}=  Read Csv String To List  ${old1_csv_content}


       ${old2_csv_content}=    Get File    stock_csv_new_macd_dif/0051_dif_2023.csv    encoding=UTF-8-SIG    encoding_errors=strict
        @{list_2}=  Read Csv String To List  ${old2_csv_content}



        ${list_value}=  Create List
        Append To List  ${list_value}  ${list_1}  ${list_2}
        log  ${list_value}
        log  ${list_value}[0]
        ${list_value_0}=  set variable  ${list_value}[0]
        log  ${list_value_0}[0]
        log  ${list_value_0}[1]


            ${length}=  Get length  ${list_1}
            ${length+1}=  evaluate  ${length} + 1


#3. day? gen score
            FOR  ${j}  IN RANGE  1  ${length}  1

                        ${list_1_j}=  set variable  ${list_1}[${j}]

#4. 
#                 FOR  ${}

#                        ${score}[${j}]=  evaluate  ${list_1_j}[5]

#                        Sort List

#                 END

            END

            ${st_stock_no}=          set variable  hello
            ${1st_stock_share_num}=   set variable  5
            ${2nd_stock_no}=          set variable  0051
            ${2nd_stock_share_num}=   set variable  3
            ${3th_stock_no}=          set variable  0052
            ${3th_stock_share_num}=   set variable  2









     Connect To Database Using Custom Params  sqlite3  database="./test.db"

    ${query_start_date}=  set variable  '1994-09-13'
    ${query_end_date}=    set variable  '2007-12-31'


    ${output_DATE}=    Query  SELECT DISTINCT DATE FROM daily_stock WHERE stock_id = '2330' AND DATE between ${query_start_date} and ${query_end_date} order by DATE ;
    Log  ${output_DATE}

    ${output_open}=    Query  SELECT DISTINCT open,DATE FROM daily_stock WHERE stock_id = '2330' AND DATE between ${query_start_date} and ${query_end_date} order by DATE ;
    Log  ${output_open}


    ${output_high}=    Query  SELECT DISTINCT max,DATE FROM daily_stock WHERE stock_id = '2330' AND DATE between ${query_start_date} and ${query_end_date} order by DATE ;
    Log  ${output_high}


    ${output_low}=    Query  SELECT DISTINCT min,DATE FROM daily_stock WHERE stock_id = '2330' AND DATE between ${query_start_date} and ${query_end_date} order by DATE ;
    Log  ${output_low}


    ${output_close}=    Query  SELECT DISTINCT close,DATE FROM daily_stock WHERE stock_id = '2330' AND DATE between ${query_start_date} and ${query_end_date} order by DATE ;
    Log  ${output_close}

    ${output_Trading_turnover}=    Query  SELECT DISTINCT Trading_turnover,DATE FROM daily_stock WHERE stock_id = '2330' AND DATE between ${query_start_date} and ${query_end_date} order by DATE ;
    Log  ${output_Trading_turnover}








            post_chart_genYamlStart   chart4.yaml 


            post_chart_genYaml2       chart4.yaml  mychart4  ${output_DATE}


            post_chart_genYaml3       chart4.yaml   line  line_test  '#e8c3b9'  ${empty}  false  'y-axis-1'  true  ${output_open}

            post_chart_genYaml3       chart4.yaml   bar  bar_test  ${empty}  '#ff6384'  false  'y-axis-2'  true  ${output_Trading_turnover}

            post_chart_genYaml4       chart4.yaml   0  100000




            post_chart_genYaml2       chart4.yaml  mychart5  ${output_DATE}


            post_chart_genYaml3       chart4.yaml   line  line_test  '#36a2eb'  ${empty}  false  'y-axis-1'  true  ${output_high}

            post_chart_genYaml3       chart4.yaml   line  line_test  '#ff6384'  ${empty}  false  'y-axis-1'  true  ${output_low}

            post_chart_genYaml3       chart4.yaml   bar  bar_test  ${empty}  '#cc65fe'  false  'y-axis-2'  true  ${output_Trading_turnover}

            post_chart_genYaml4       chart4.yaml   0  100000


            post_chart_genChart2      chart4.yaml  chart4.html



#            [RETURN]    hello 
#            RETURN    ${1st_stock_no}  ${1st_stock_share_num}  ${2nd_stock_no}  ${2nd_stock_share_num}  ${3th_stock_no}  ${3th_stock_share_num}


