*** Variables ***

*** Keywords ***
test_calculate_transfer_matrix

  [Arguments]  ${start_date}  ${end_date}


###read csv
#
#	read_csv_file_to_list
#        @{list_csv_before_yesterday}=  read_csv_file_to_list  STOCK_DAY_ALL_20230216.csv

#look sensor_read

# eval + - * /

# numpy ?

  
  ${date_range}=  finmind_GetDateRange  ${start_date}  ${end_date}


  ${date_1}  Set Variable  ${date_range}[0]
  Log_To_Console  date_1 : ${date_1}
  ${date_2}  Set Variable  ${date_range}[1]
  Log_To_Console  date_2 : ${date_2}

  ${B_filename}  Set Variable  ${date_1}.csv
  Log_To_Console  B_filename : ${B_filename}
  ${C_filename}  Set Variable  ${date_2}.csv
  Log_To_Console  C_filename : ${C_filename}

    ${rc}    ${output}    Run And Return Rc And Output    python3 ${local_path}/${Script_folder_path}/test_numpy.py ${local_path}/${Csv_folder_path}/${Stock_Csv_folder_path}/${B_filename} ${local_path}/${Csv_folder_path}/${Stock_Csv_folder_path}/${C_filename}    
    Log_To_Console  output : ${output}
    Should Be Equal As Integers    ${rc}    0    # 根据脚本的退出码进行断言



  FOR  ${date}  IN  @{date_range}[2:]

	Log_To_Console  ${local_path}/${Csv_folder_path}/${Stock_Csv_folder_path}/${date}.csv
        ${file_exists}=  Run Keyword And Return Status  OperatingSystem.File_Should_Exist  ${local_path}/${Csv_folder_path}/${Stock_Csv_folder_path}/${date}.csv
        #Run Keyword If  ${file_exists}  BREAK
	Log_To_Console  file_exists ${file_exists}
        #IF  not ${file_exists}  BREAK
	Continue For Loop If   not ${file_exists}



	${date_1}  Set Variable  ${date_2} 
	${date_2}  Set Variable  ${date} 
	Log_To_Console  date_1 : ${date_1}
	Log_To_Console  date_2 : ${date_2}
#	Log_To_Console  date : ${date}

	${B_filename}  Set Variable  ${date_1}.csv
	Log_To_Console  B_filename : ${B_filename}
	${C_filename}  Set Variable  ${date_2}.csv
	Log_To_Console  C_filename : ${C_filename}

       

    ${rc}    ${output}    Run And Return Rc And Output    python3 ${local_path}/${Script_folder_path}/test_numpy.py ${local_path}/${Csv_folder_path}/${Stock_Csv_folder_path}/${B_filename} ${local_path}/${Csv_folder_path}/${Stock_Csv_folder_path}/${C_filename}    
    Log_To_Console  output : ${output}
    Should Be Equal As Integers    ${rc}    0    # 根据脚本的退出码进行断言


  END

	

###save new csv
	append_to_csv_file  1.csv  ${output}

# append to csv file



###read new csv




###get transfer matrix



###save transfer matrix csv














