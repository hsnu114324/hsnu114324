*** Settings ***
Library  OperatingSystem
Library  ExcelLibrary
Library  String
Library  Collections
Library  CSVLibrary
Library  DateTime
Library  DatabaseLibrary
Resource  Common/common_stock.robot
Resource  Common/common_finmind.robot


*** Variables ***
@{stock_list}    @{EMPTY}


#*** Keywords ***
*** Test Cases ***
test_stock_kline_search
    [Documentation]    Load sensor list file and prepare list


    ${search_kline}=  set variable  %


    ${query2_stock_id}=    set variable  '2330'
    ${query2_start_date}=  set variable  '2024-03-01'
    ${query2_end_date}=    set variable  '2024-04-01'

    Connect To Database Using Custom Params  sqlite3  database="./test.db"  

    ${output}=    Query    SELECT DATE,stock_id,Trading_Volume,Trading_money,open,max,min,close,spread,Trading_turnover FROM daily_stock WHERE stock_id = ${query2_stock_id} AND DATE between ${query2_start_date} and ${query2_end_date} order by DATE  
    Log  ${output}

  ${output_length}=  get length  ${output}

  FOR  ${i}  IN RANGE  0  ${output_length}  1

#    ${date}=  set variable  ${output}[${i}][0]     

        IF  ${i} == 1
    
        ${init_date}=  set variable  ${output}[${i}][0]

        END




    ${today_close}=  set variable  ${output}[${i}][7]
    ${today_spread}=  set variable  ${output}[${i}][8]

    ${change}=  evaluate  (${today_spread}*100)/${today_close}



       


    IF  ${change} > -0.5
        ${new_kline_char}=  set variable  a
    END
    IF  ${change} >= 0.5
        ${new_kline_char}=  set variable  b
    END
    IF  ${change} >= 1.5
        ${new_kline_char}=  set variable  c
    END
    IF  ${change} >= 2.5
        ${new_kline_char}=  set variable  d
    END
    IF  ${change} >= 3.5
        ${new_kline_char}=  set variable  e
    END
    IF  ${change} >= 4.5
        ${new_kline_char}=  set variable  f
    END
    IF  ${change} >= 5.5
        ${new_kline_char}=  set variable  g
    END
    IF  ${change} >= 6.5
        ${new_kline_char}=  set variable  h
    END
    IF  ${change} >= 7.5
        ${new_kline_char}=  set variable  i
    END
    IF  ${change} >= 8.5
        ${new_kline_char}=  set variable  j
    END
    IF  ${change} >= 9.5
        ${new_kline_char}=  set variable  k
    END
    IF  ${change} <= -0.5
        ${new_kline_char}=  set variable  n
    END
    IF  ${change} <= -1.5
        ${new_kline_char}=  set variable  o
    END
    IF  ${change} <= -2.5
        ${new_kline_char}=  set variable  p
    END
    IF  ${change} <= -3.5
        ${new_kline_char}=  set variable  q
    END
    IF  ${change} <= -4.5
        ${new_kline_char}=  set variable  r
    END
    IF  ${change} <= -5.5
        ${new_kline_char}=  set variable  s
    END
    IF  ${change} <= -6.5
        ${new_kline_char}=  set variable  t
    END
    IF  ${change} <= -7.5
        ${new_kline_char}=  set variable  u
    END
    IF  ${change} <= -8.5
        ${new_kline_char}=  set variable  v
    END
    IF  ${change} <= -9.5
        ${new_kline_char}=  set variable  w
    END

    log  ${new_kline_char}





    ${search_kline}=  set variable  ${search_kline}${new_kline_char}%   





  END


   log  ${search_kline}



######################################################## 

    ${query_start_date}=  set variable  '2024-01-01'
    ${query_end_date}=    set variable  '2024-04-01'












    Connect To Database Using Custom Params  sqlite3  database="./test2.db"  

    ${history_kline}=  set variable  ${empty}


    ${output_kline}=    Query    SELECT stock_id,init_date,history_kline FROM kline WHERE history_kline like '${search_kline}'
    Log  ${output_kline}























