*** Keywords ***
us_stock_sql_insert_cashflow
#    [Arguments]    ${excel_file_data}
#    [Arguments]  ${start_date}  ${end_date}
    [Documentation]
    [Tags]
#    Connect To Database
#    ...    pymssql
#    ...    dbName=DLIQSERV
#    ...    dbUsername=DLIQTASK
#    ...    dbPassword=DLIQTASK3817
#    ...    dbHost=10.201.52.130
#    ...    dbPort=1433



    


    ${stock_id}=  set variable  nvda

    Connect To Database Using Custom Params  sqlite3  database="./test.db"


#    ${output}=   Execute Sql String     CREATE TABLE ${table_name} ( ${name_1} ${type_1}, ${name_2} ${type_2}, ${name_3} ${type_3}, ${name_4} ${type_4}, ${name_5} ${type_5}, ${name_6} ${type_6}, ${name_7} ${type_7}, ${name_8} ${type_8}, ${name_9} ${type_9}, ${name_10} ${type_10} ) ;
#    Log  ${output}


                ${table_name}=  set variable  cashflow
                ${name_1}=      set variable  primary_key
                ${type_1}=      set variable  INT
                ${name_2}=      set variable  date
                ${type_2}=      set variable  DATE
                ${name_3}=      set variable  class
                ${type_3}=      set variable  varchar(100)
                ${name_4}=      set variable  stock_id
                ${type_4}=      set variable  varchar(100)
                ${name_5}=      set variable  stock_name
                ${type_5}=      set variable  varchar(100)
                ${name_6}=      set variable  type
                ${type_6}=      set variable  varchar(100)
                ${name_7}=      set variable   Treasury Shares Number
                ${type_7}=      set variable  INT
                ${name_8}=      set variable   Ordinary Shares Number
                ${type_8}=      set variable  INT
                ${name_9}=      set variable   Share Issued
                ${type_9}=      set variable  INT
                ${name_10}=      set variable   Total Debt
                ${type_10}=      set variable  INT
                ${name_11}=      set variable   Tangible Book Value
                ${type_11}=      set variable  INT
                ${name_12}=      set variable   Invested Capital
                ${type_12}=      set variable  INT
                ${name_13}=      set variable   Working Capital
                ${type_13}=      set variable  INT
                ${name_14}=      set variable   Net Tangible Assets
                ${type_14}=      set variable  INT
                ${name_15}=      set variable   Capital Lease Obligations
                ${type_15}=      set variable  INT
                ${name_16}=      set variable   Common Stock Equity
                ${type_16}=      set variable  INT
                ${name_17}=      set variable   Total Capitalization
                ${type_17}=      set variable  INT
                ${name_18}=      set variable   Total Equity Gross Minority Interest
                ${type_18}=      set variable  INT
                ${name_19}=      set variable   Minority Interest
                ${type_19}=      set variable  INT
                ${name_20}=      set variable   Stockholders Equity
                ${type_20}=      set variable  INT
                ${name_21}=      set variable   Other Equity Interest
                ${type_21}=      set variable  INT
                ${name_22}=      set variable   Gains Losses Not Affecting Retained Earnings
                ${type_22}=      set variable  INT
                ${name_23}=      set variable   Other Equity Adjustments
                ${type_23}=      set variable  INT
                ${name_24}=      set variable   Treasury Stock
                ${type_24}=      set variable  INT
                ${name_25}=      set variable   Retained Earnings
                ${type_25}=      set variable  INT
                ${name_26}=      set variable   Additional Paid In Capital
                ${type_26}=      set variable  INT
                ${name_27}=      set variable   Capital Stock
                ${type_27}=      set variable  INT
                ${name_28}=      set variable   Common Stock
                ${type_28}=      set variable  INT
                ${name_29}=      set variable   Total Liabilities Net Minority Interest
                ${type_29}=      set variable  INT
                ${name_30}=      set variable   Total Non Current Liabilities Net Minority Interest
                ${type_30}=      set variable  INT
                ${name_31}=      set variable   Other Non Current Liabilities
                ${type_31}=      set variable  INT
                ${name_32}=      set variable   Employee Benefits
                ${type_32}=      set variable  INT
                ${name_33}=      set variable   Non Current Pension And Other Postretirement Benefit Plans
                ${type_33}=      set variable  INT
                ${name_34}=      set variable   Non Current Deferred Liabilities
                ${type_34}=      set variable  INT
                ${name_35}=      set variable   Non Current Deferred Taxes Liabilities
                ${type_35}=      set variable  INT
                ${name_36}=      set variable   Long Term Debt And Capital Lease Obligation
                ${type_36}=      set variable  INT
                ${name_37}=      set variable   Long Term Capital Lease Obligation
                ${type_37}=      set variable  INT
                ${name_38}=      set variable   Long Term Debt
                ${type_38}=      set variable  INT
                ${name_39}=      set variable   Current Liabilities
                ${type_39}=      set variable  INT
                ${name_40}=      set variable   Other Current Liabilities
                ${type_40}=      set variable  INT
                ${name_41}=      set variable   Current Debt And Capital Lease Obligation
                ${type_41}=      set variable  INT
                ${name_42}=      set variable   Current Debt
                ${type_42}=      set variable  INT
                ${name_43}=      set variable   Other Current Borrowings
                ${type_43}=      set variable  INT
                ${name_44}=      set variable   Pensionand Other Post Retirement Benefit Plans Current
                ${type_44}=      set variable  INT
                ${name_45}=      set variable   Payables And Accrued Expenses
                ${type_45}=      set variable  INT
                ${name_46}=      set variable   Current Accrued Expenses
                ${type_46}=      set variable  INT
                ${name_47}=      set variable   Payables
                ${type_47}=      set variable  INT
                ${name_48}=      set variable   Other Payable
                ${type_48}=      set variable  INT
                ${name_49}=      set variable   Dueto Related Parties Current
                ${type_49}=      set variable  INT
                ${name_50}=      set variable   Dividends Payable
                ${type_50}=      set variable  INT
                ${name_51}=      set variable   Total Tax Payable
                ${type_51}=      set variable  INT
                ${name_52}=      set variable   Income Tax Payable
                ${type_52}=      set variable  INT
                ${name_53}=      set variable   Accounts Payable
                ${type_53}=      set variable  INT
                ${name_54}=      set variable   Total Assets
                ${type_54}=      set variable  INT
                ${name_55}=      set variable   Total Non Current Assets
                ${type_55}=      set variable  INT
                ${name_56}=      set variable   Other Non Current Assets
                ${type_56}=      set variable  INT
                ${name_57}=      set variable   Non Current Prepaid Assets
                ${type_57}=      set variable  INT
                ${name_58}=      set variable   Non Current Deferred Assets
                ${type_58}=      set variable  INT
                ${name_59}=      set variable   Non Current Deferred Taxes Assets
                ${type_59}=      set variable  INT
                ${name_60}=      set variable   Investments And Advances
                ${type_60}=      set variable  INT
                ${name_61}=      set variable   Investmentin Financial Assets
                ${type_61}=      set variable  INT
                ${name_62}=      set variable   Held To Maturity Securities
                ${type_62}=      set variable  INT
                ${name_63}=      set variable   Available For Sale Securities
                ${type_63}=      set variable  INT
                ${name_64}=      set variable   Financial Assets Designatedas Fair Value Through Profitor Loss Total
                ${type_64}=      set variable  INT
                ${name_65}=      set variable   Long Term Equity Investment
                ${type_65}=      set variable  INT
                ${name_66}=      set variable   Investmentsin Associatesat Cost
                ${type_66}=      set variable  INT
                ${name_67}=      set variable   Goodwill And Other Intangible Assets
                ${type_67}=      set variable  INT
                ${name_68}=      set variable   Other Intangible Assets
                ${type_68}=      set variable  INT
                ${name_69}=      set variable   Goodwill
                ${type_69}=      set variable  INT
                ${name_70}=      set variable   Net PPE
                ${type_70}=      set variable  INT
                ${name_71}=      set variable   Accumulated Depreciation
                ${type_71}=      set variable  INT
                ${name_72}=      set variable   Gross PPE
                ${type_72}=      set variable  INT
                ${name_73}=      set variable   Construction In Progress
                ${type_73}=      set variable  INT
                ${name_74}=      set variable   Other Properties
                ${type_74}=      set variable  INT
                ${name_75}=      set variable   Machinery Furniture Equipment
                ${type_75}=      set variable  INT
                ${name_76}=      set variable   Buildings And Improvements
                ${type_76}=      set variable  INT
                ${name_77}=      set variable   Land And Improvements
                ${type_77}=      set variable  INT
                ${name_78}=      set variable   Properties
                ${type_78}=      set variable  INT
                ${name_79}=      set variable   Current Assets
                ${type_79}=      set variable  INT
                ${name_80}=      set variable   Other Current Assets
                ${type_80}=      set variable  INT
                ${name_81}=      set variable   Hedging Assets Current
                ${type_81}=      set variable  INT
                ${name_82}=      set variable   Inventory
                ${type_82}=      set variable  INT
                ${name_83}=      set variable   Finished Goods
                ${type_83}=      set variable  INT
                ${name_84}=      set variable   Work In Process
                ${type_84}=      set variable  INT
                ${name_85}=      set variable   Raw Materials
                ${type_85}=      set variable  INT
                ${name_86}=      set variable   Receivables
                ${type_86}=      set variable  INT
                ${name_87}=      set variable   Receivables Adjustments Allowances
                ${type_87}=      set variable  INT
                ${name_88}=      set variable   Duefrom Related Parties Current
                ${type_88}=      set variable  INT
                ${name_89}=      set variable   Notes Receivable
                ${type_89}=      set variable  INT
                ${name_90}=      set variable   Accounts Receivable
                ${type_90}=      set variable  INT
                ${name_91}=      set variable   Gross Accounts Receivable
                ${type_91}=      set variable  INT
                ${name_92}=      set variable   Cash Cash Equivalents And Short Term Investments
                ${type_92}=      set variable  INT
                ${name_93}=      set variable   Other Short Term Investments
                ${type_93}=      set variable  INT
                ${name_94}=      set variable   Cash And Cash Equivalents
                ${type_94}=      set variable  INT
                ${name_95}=      set variable   Cash Equivalents
                ${type_95}=      set variable  INT
                ${name_96}=      set variable   Cash Financial
                ${type_96}=      set variable  INT





#    ${output}=   Execute Sql String     CREATE TABLE ${table_name} ( '${name_1}' ${type_1}, '${name_2}' ${type_2}, '${name_3}' ${type_3}, '${name_4}' ${type_4}, '${name_5}' ${type_5}, '${name_6}' ${type_6}, '${name_7}' ${type_7}, '${name_8}' ${type_8}, '${name_9}' ${type_9}, '${name_10}' ${type_10}, '${name_11}' ${type_11}, '${name_12}' ${type_12}, '${name_13}' ${type_13}, '${name_14}' ${type_14}, '${name_15}' ${type_15}, '${name_16}' ${type_16}, '${name_17}' ${type_17}, '${name_18}' ${type_18}, '${name_19}' ${type_19}, '${name_20}' ${type_20}, '${name_21}' ${type_21}, '${name_22}' ${type_22}, '${name_23}' ${type_23}, '${name_24}' ${type_24}, '${name_25}' ${type_25}, '${name_26}' ${type_26}, '${name_27}' ${type_27}, '${name_28}' ${type_28}, '${name_29}' ${type_29}, '${name_30}' ${type_30}, '${name_31}' ${type_31}, '${name_32}' ${type_32}, '${name_33}' ${type_33}, '${name_34}' ${type_34}, '${name_35}' ${type_35}, '${name_36}' ${type_36}, '${name_37}' ${type_37}, '${name_38}' ${type_38}, '${name_39}' ${type_39}, '${name_40}' ${type_40}, '${name_41}' ${type_41}, '${name_42}' ${type_42}, '${name_43}' ${type_43}, '${name_44}' ${type_44}, '${name_45}' ${type_45}, '${name_46}' ${type_46}, '${name_47}' ${type_47}, '${name_48}' ${type_48}, '${name_49}' ${type_49}, '${name_50}' ${type_50}, '${name_51}' ${type_51}, '${name_52}' ${type_52}, '${name_53}' ${type_53}, '${name_54}' ${type_54}, '${name_55}' ${type_55}, '${name_56}' ${type_56}, '${name_57}' ${type_57}, '${name_58}' ${type_58}, '${name_59}' ${type_59}, '${name_60}' ${type_60}, '${name_61}' ${type_61}, '${name_62}' ${type_62}, '${name_63}' ${type_63}, '${name_64}' ${type_64}, '${name_65}' ${type_65}, '${name_66}' ${type_66}, '${name_67}' ${type_67}, '${name_68}' ${type_68}, '${name_69}' ${type_69}, '${name_70}' ${type_70}, '${name_71}' ${type_71}, '${name_72}' ${type_72}, '${name_73}' ${type_73}, '${name_74}' ${type_74}, '${name_75}' ${type_75}, '${name_76}' ${type_76}, '${name_77}' ${type_77}, '${name_78}' ${type_78}, '${name_79}' ${type_79}, '${name_80}' ${type_80}, '${name_81}' ${type_81}, '${name_82}' ${type_82}, '${name_83}' ${type_83}, '${name_84}' ${type_84}, '${name_85}' ${type_85}, '${name_86}' ${type_86}, '${name_87}' ${type_87}, '${name_88}' ${type_88}, '${name_89}' ${type_89}, '${name_90}' ${type_90}, '${name_91}' ${type_91}, '${name_92}' ${type_92}, '${name_93}' ${type_93}, '${name_94}' ${type_94}, '${name_95}' ${type_95}, '${name_96}' ${type_96} ) ;


#    Log  ${output}







#    ${folder}=    set variable    ../stock_csv    # 更換成目標資料>夾的路徑



#    ${date_range}=  finmind_GetDateRange  ${start_date}  ${end_date}  


#  FOR  ${date}  IN  @{date_range}

#  log_to_console  date: ${date}

#    ${file_exists}=  Run Keyword And Return Status  OperatingSystem.File_Should_Exist   ${folder}/${date}.csv
#    IF  '${file_exists}' == 'False'
#        CONTINUE FOR LOOP 
#    END
    
#    @{list_csv_before_yesterday}=  read_csv_file_to_list  Excel/daily_stock.csv

    @{list_csv_before_yesterday}=  read_csv_file_to_list  ${stock_id}_quarterly_cashflow.csv
    ${list_csv_by_cnt}=    Get length    ${list_csv_before_yesterday}
    Log  list_csv_by_cnt ${list_csv_by_cnt}


        ${data_header_list}=   create list   2         #date
#        ${data_list}=     create list        ${empty}

#        FOR  ${iii} in range  1  103
#             Append To List  ${data_header_list}  ${NULL}
#             Append To List  ${data_list}         ${NULL}
#        END  

   
#        ${data_list}=     create list        
        ${data_0}=     get from list  ${list_csv_before_yesterday}  0
        ${data_0_length}=  get length  ${data_0}
        FOR  ${j}  IN RANGE  1  ${data_0_length}  

            FOR  ${k}  IN RANGE  7  97

                log  ${data_0}[${j}]
                log  ${name_${k}}
                IF  '${data_0}[${j}]' == '${name_${k}}'
#                    append_to_list  ${data_list} ${k}
#                    set variable  ${k-7}  ${k} - 7
#                    set list value  ${data_header_list}  ${k}  ${j} 
                    Append To List  ${data_header_list}  ${k}
                    log  ${data_header_list}[${j}]
                    log  ${data_header_list}
#                    Continue For Loop
                    ${set_null}=   Set variable  0
                    BREAK
                END  
            END
            IF  ${set_null} == 1
                    Append To List  ${data_header_list}  ${NULL}
            END
            ${set_null}=   Set variable  1
#            Append To List  ${data_list}  ${NULL}
        END


    FOR  ${i}  IN RANGE  1  ${list_csv_by_cnt}  1

        ${data}=     get from list  ${list_csv_before_yesterday}  ${i}
#        ${data_1}=   set variable  ${data}[0]
#        ${data_2}=   set variable  ${data}[1]
#        ${data_3}=   set variable  ${data}[2]
#        ${data_4}=   set variable  ${data}[3]
#        ${data_5}=   set variable  ${data}[4]
#        ${data_6}=   set variable  ${data}[5]
#        ${data_7}=   set variable  ${data}[6]
#        ${data_8}=   set variable  ${data}[7]
#        ${data_9}=   set variable  ${data}[8]
#        ${data_10}=  set variable  ${data}[9]
#
#        ${output}=    Execute Sql String    INSERT INTO ${table_name} VALUES ( '${data_1}', '${data_2}', ${data_3}, ${data_4}, ${data_5}, ${data_6}, ${data_7}, ${data_8}, ${data_9}, ${data_10} )


        
        log  ${data_header_list}

        ${data_list}=  Create list
        log  ${data_list}
        FOR  ${iii}  IN RANGE  0  97
            Append To List  ${data_list}  NULL    
        END

        log  ${data_list}
#        Append To List  ${data_list}
        

        FOR  ${ii}  IN RANGE  0  ${data_0_length}
              log  ${ii}
              log  ${data_header_list}[${ii}]
              log  ${data_header_list}
              log  ${data}[${ii}]
              IF  '${data_header_list}[${ii}]' == 'None'
                  Continue For Loop
              END
#              log  ${data}[${data_header_list}[${ii}]]
#              Append To List  ${data_list}  ${data}[${data_header_list}[${ii}]]

              
              IF  '${data}[${ii}]' == '${empty}'
                  ${data}[${ii}]=  set variable  NULL
              END
              Set List Value  ${data_list}  ${data_header_list}[${ii}]  ${data}[${ii}]    #equal to  ${data_list}[${data_header_list[${ii}]}]=  set variable  ${data}[${ii}]

              log  ${data_list}
        END

        log  ${data_list}

        ${output}=    Execute Sql String    INSERT INTO ${table_name} VALUES ( 0, '${data_list}[2]', 'us_stock', '${stock_id}', 'stock_name', 'quarterly', ${data_list}[7], ${data_list}[8], ${data_list}[9], ${data_list}[10], ${data_list}[11], ${data_list}[12], ${data_list}[13], ${data_list}[14], ${data_list}[15], ${data_list}[16], ${data_list}[17], ${data_list}[18], ${data_list}[19], ${data_list}[20], ${data_list}[21], ${data_list}[22], ${data_list}[23], ${data_list}[24], ${data_list}[25], ${data_list}[26], ${data_list}[27], ${data_list}[28], ${data_list}[29], ${data_list}[30], ${data_list}[31], ${data_list}[32], ${data_list}[33], ${data_list}[34], ${data_list}[35], ${data_list}[36], ${data_list}[37], ${data_list}[38], ${data_list}[39], ${data_list}[40], ${data_list}[41], ${data_list}[42], ${data_list}[43], ${data_list}[44], ${data_list}[45], ${data_list}[46], ${data_list}[47], ${data_list}[48], ${data_list}[49], ${data_list}[50], ${data_list}[51], ${data_list}[52], ${data_list}[53], ${data_list}[54], ${data_list}[55], ${data_list}[56], ${data_list}[57], ${data_list}[58], ${data_list}[59], ${data_list}[60], ${data_list}[61], ${data_list}[62], ${data_list}[63], ${data_list}[64], ${data_list}[65], ${data_list}[66], ${data_list}[67], ${data_list}[68], ${data_list}[69], ${data_list}[70], ${data_list}[71], ${data_list}[72], ${data_list}[73], ${data_list}[74], ${data_list}[75], ${data_list}[76], ${data_list}[77], ${data_list}[78], ${data_list}[79], ${data_list}[80], ${data_list}[81], ${data_list}[82], ${data_list}[83], ${data_list}[84], ${data_list}[85], ${data_list}[86], ${data_list}[87], ${data_list}[88], ${data_list}[89], ${data_list}[90], ${data_list}[91], ${data_list}[92], ${data_list}[93], ${data_list}[94], ${data_list}[95], ${data_list}[96] )


        Log  ${output}


    END

#  END

