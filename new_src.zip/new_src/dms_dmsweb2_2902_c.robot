*** Keywords ***
dms_dmsweb2_2902_c
    [Arguments]  ${excel_file_data}
  
#  ${MON_PAY}
	[Documentation]
	[Tags]
#***

    Log  ${excel_file_data}

#***
	dms_postweb2_pnsFrontEndloginChrome  http://localhost:3000/





    dms_dmsweb2_ClickDmsFrontEnduserID_login

	dms_dmsweb2_ClickDmsFrontEndMenuButton
#***
	dms_dmsweb2_ClickDmsFrontEndMenu_ListOP1
#***

	dms_dmsweb2_ClickDmsFrontEndMenu_ListOP1_2900
#***
	dms_dmsweb2_ClickDmsFrontEnd_2000ACC_DATE  ${excel_file_data}[1]
#***
	dms_dmsweb2_ClickDmsFrontEnd_2000TOUR_NO  ${excel_file_data}[2]
#***
	dms_dmsweb2_ClickDmsFrontEnd_2000FetchButton  
#***

    Take Screenshot

    ${match1}  ${match2}=    dms_dmsweb2_DmsFrontEnd_2000_stage1_1  ${excel_file_data}    login   2900

    Log  ${match1}
    Log  ${match2}

    ${match2}  ${match3}=    dms_dmsweb2_DmsFrontEnd_2000_stage1_i  ${match2}  ${excel_file_data}    login  2900

    Log  ${match2}
    Log  ${match3}

#Should Match Regexp  ${para2_date}  ^\\d{4}$

    ${type_match1}=    Evaluate     type($match1)
    ${type_match3}=    Evaluate     type($match3)
    Log   ${type_match1}
    Log   ${type_match3}
    
    
    IF  '${match1}' != 'PASS'
        
        ${MLIST_NO_M1A0}=  set variable  ${match1}
    ELSE
        IF  '${match3}' != 'PASS'
            
            ${MLIST_NO_M1A0}=  set variable  ${match3}
        END
    END


#***
	dms_dmsweb2_ClickDmsFrontEndMenu_ListOP1_2902
#***
	dms_dmsweb2_ClickDmsFrontEnd_2000ACC_DATE  ${excel_file_data}[1]
#***
	dms_dmsweb2_ClickDmsFrontEnd_2000TOUR_NO  ${excel_file_data}[2]
#***
#    dms_dmsweb2_ClickDmsFrontEnd_2000STAFF_NO  ${excel_file_data}[2]

    dms_dmsweb2_ClickDmsFrontEnd_2000MLIST_NO_M1A0   ${MLIST_NO_M1A0}

#	dms_dmsweb2_ClickDmsFrontEnd_2000FetchButton


    Take Screenshot
    Sleep  2s
    Take Screenshot
    Click    ${xpath_DmsFrontEnd_2300EndButton}
    Sleep  2s
    Take Screenshot



#==================

    Take Screenshot



    ${match1}  ${match2}=    dms_dmsweb2_DmsFrontEnd_2000_stage22_1  ${excel_file_data}  login  2902   

    Log  ${match1}
    Log  ${match2}

    ${match2}  ${match3}=    dms_dmsweb2_DmsFrontEnd_2000_stage22_i  ${match2}  ${excel_file_data}  login  2902  

    Log  ${match2}
    Log  ${match3}

    IF  '${match2}' == 'False'

        dms_dmsweb2_DmsFrontEnd_2000_stage22_c   ${excel_file_data}  2902

    END





    Take Screenshot

#==================



##    dms_dmsweb2_ClickDmsFrontEnd_2000_MList_letter_MAIL_NO
#    Fill Text  //*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr/td/div/div/input  ${excel_file_data}[5]
#	Sleep  1s

##    dms_dmsweb2_ClickDmsFrontEnd_2000_MList_letter_save_button
#    Click    ${xpath_DmsFrontEnd_2300SendButton}
#	Sleep  1s

#    Take Screenshot

##    dms_dmsweb2_ClickDmsFrontEnd_2000_MList_letter_end_button
#    Click    ${xpath_DmsFrontEnd_2300EndButton}
#	Sleep  1s

##    Debug


	

 

    dms_dmsweb2_ClickDmsFrontEnduserID_logout 

    Sleep  3s

#	Return  ${CR_no}
