*** Keywords ***
us_stock_sql_create_balanceSheet_table
#    [Arguments]  ${start_date}  ${end_date}
    [Documentation]
    [Tags]


    Connect To Database Using Custom Params  sqlite3  database="./test.db"


                ${table_name}=  set variable  balanceSheet
                ${name_1}=      set variable  primary_key
                ${type_1}=      set variable  INT
                ${name_2}=      set variable  date
                ${type_2}=      set variable  DATE
                ${name_3}=      set variable  class
                ${type_3}=      set variable  varchar(100)
                ${name_4}=      set variable  sotck_id
                ${type_4}=      set variable  varchar(100)
                ${name_5}=      set variable  sotck_id
                ${type_5}=      set variable  varchar(100)
                ${name_6}=      set variable  Total Assets
                ${type_6}=      set variable  INT
                ${name_7}=      set variable  Total Assets
                ${type_7}=      set variable  INT
                ${name_8}=      set variable  Current Assets
                ${type_8}=      set variable  INT
                ${name_9}=      set variable  Cash Cash Equivalents And Short Term Investments
                ${type_9}=      set variable  INT
                ${name_10}=     set variable  Cash And Cash Equivalents
                ${type_10}=     set variable  INT
                ${name_11}=     set variable  Cash
                ${type_11}=     set variable  INT
                ${name_12}=     set variable  Cash Equivalents
                ${type_12}=     set variable  INT
                ${name_13}=     set variable  Other Short Term Investments
                ${type_13}=     set variable  INT
                ${name_14}=     set variable  Receivables
                ${type_14}=     set variable  INT
                ${name_15}=     set variable  Accounts receivable
                ${type_15}=     set variable  INT
                ${name_16}=     set variable  Gross Accounts Receivable
                ${type_16}=     set variable  INT
                ${name_17}=     set variable  Allowance For Doubtful Accounts Receivable
                ${type_17}=     set variable  INT
                ${name_18}=     set variable  Notes Receivable
                ${type_18}=     set variable  INT
                ${name_19}=     set variable  Duefrom Related Parties Current
                ${type_19}=     set variable  INT
                ${name_20}=     set variable  Other Receivables
                ${type_20}=     set variable  INT
                ${name_21}=     set variable  Receivables Adjustments Allowances
                ${type_21}=     set variable  INT
                ${name_22}=     set variable  Inventory
                ${type_22}=     set variable  INT
                ${name_23}=     set variable  Raw Materials
                ${type_23}=     set variable  INT
                ${name_24}=     set variable  Work in Process
                ${type_24}=     set variable  INT
                ${name_25}=     set variable  Finished Goods
                ${type_25}=     set variable  INT
                ${name_26}=     set variable  Prepaid Assets
                ${type_26}=     set variable  INT
                ${name_27}=     set variable  Hedging Assets Current
                ${type_27}=     set variable  INT
                ${name_28}=     set variable  Other Current Assets
                ${type_28}=     set variable  INT
                ${name_29}=     set variable  Total non-current assets
                ${type_29}=     set variable  INT
                ${name_30}=     set variable  Net PPE
                ${type_30}=     set variable  INT
                ${name_31}=     set variable  Gross PPE
                ${type_31}=     set variable  INT
                ${name_32}=     set variable  Land And Improvements
                ${type_32}=     set variable  INT
                ${name_33}=     set variable  Machinery Furniture Equipment
                ${type_33}=     set variable  INT
                ${name_34}=     set variable  Other Properties
                ${type_34}=     set variable  INT
                ${name_35}=     set variable  Construction in Progress
                ${type_35}=     set variable  INT
                ${name_36}=     set variable  Leases
                ${type_36}=     set variable  INT
                ${name_37}=     set variable  Accumulated Depreciation
                ${type_37}=     set variable  INT
                ${name_38}=     set variable  Goodwill And Other Intangible Assets
                ${type_38}=     set variable  INT
                ${name_39}=     set variable  Goodwill
                ${type_39}=     set variable  INT
                ${name_40}=     set variable  Other Intangible Assets
                ${type_40}=     set variable  INT
                ${name_41}=     set variable  Investments And Advances
                ${type_41}=     set variable  INT
                ${name_42}=     set variable  Long Term Equity Investment
                ${type_42}=     set variable  INT
                ${name_43}=     set variable  Investmentsin Associatesat Cost
                ${type_43}=     set variable  INT
                ${name_44}=     set variable  Investmentin Financial Assets
                ${type_44}=     set variable  INT
                ${name_45}=     set variable  Financial Assets Designatedas Fair Value Through Profitor Loss Total
                ${type_45}=     set variable  INT
                ${name_46}=     set variable  Available For Sale Securities
                ${type_46}=     set variable  INT
                ${name_47}=     set variable  Held To Maturity Securities
                ${type_47}=     set variable  INT
                ${name_48}=     set variable  Other Investments
                ${type_48}=     set variable  INT
                ${name_49}=     set variable  Non Current Deferred Assets
                ${type_49}=     set variable  INT
                ${name_50}=     set variable  Non Current Deferred Taxes Liabilities
                ${type_50}=     set variable  INT
                ${name_51}=     set variable  Non Current Prepaid Assets
                ${type_51}=     set variable  INT
                ${name_52}=     set variable  Other Non Current Assets
                ${type_52}=     set variable  INT
                ${name_53}=     set variable  Total Liabilities Net Minority Interest
                ${type_53}=     set variable  INT
                ${name_54}=     set variable  Current Liabilities
                ${type_54}=     set variable  INT
                ${name_55}=     set variable  Payables And Accrued Expenses
                ${type_55}=     set variable  INT
                ${name_56}=     set variable  Payables
                ${type_56}=     set variable  INT
                ${name_57}=     set variable  Accounts Payable
                ${type_57}=     set variable  INT
                ${name_58}=     set variable  Total Tax Payable
                ${type_58}=     set variable  INT
                ${name_59}=     set variable  Income Tax Payable
                ${type_59}=     set variable  INT
                ${name_60}=     set variable  Dividends Payable
                ${type_60}=     set variable  INT
                ${name_61}=     set variable  Dueto Related Parties Current
                ${type_61}=     set variable  INT
                ${name_62}=     set variable  Other Payable
                ${type_62}=     set variable  INT
                ${name_63}=     set variable  Current Accrued Expenses
                ${type_63}=     set variable  INT
                ${name_64}=     set variable  Pensionand Other Post Retirement Benefit Plans Current
                ${type_64}=     set variable  INT
                ${name_65}=     set variable  Current Provisions
                ${type_65}=     set variable  INT
                ${name_66}=     set variable  Current Debt And Capital Lease Obligation
                ${type_66}=     set variable  INT
                ${name_67}=     set variable  Current Debt
                ${type_67}=     set variable  INT
                ${name_68}=     set variable  Commercial Paper
                ${type_68}=     set variable  INT
                ${name_69}=     set variable  Other Current Borrowings
                ${type_69}=     set variable  INT
                ${name_70}=     set variable  Current Capital Lease Obligation
                ${type_70}=     set variable  INT
                ${name_71}=     set variable  Current Deferred Liabilities
                ${type_71}=     set variable  INT
                ${name_72}=     set variable  Current Deferred Revenue 
                ${type_72}=     set variable  INT
                ${name_73}=     set variable  Other Current Liabilities
                ${type_73}=     set variable  INT
                ${name_74}=     set variable  Total Non Current Liabilities Net Minority Interest
                ${type_74}=     set variable  INT
                ${name_75}=     set variable  Long Term Debt And Capital Lease Obligation 
                ${type_75}=     set variable  INT
                ${name_76}=     set variable  Long Term Debt
                ${type_76}=     set variable  INT
                ${name_77}=     set variable  Long Term Capital Lease Obligation
                ${type_77}=     set variable  INT
                ${name_78}=     set variable  Non Current Deferred Liabilities
                ${type_78}=     set variable  INT
                ${name_79}=     set variable  Non Current Deferred Taxes Assets
                ${type_79}=     set variable  INT
                ${name_80}=     set variable  Non Current Deferred Revenue
                ${type_80}=     set variable  INT
                ${name_81}=     set variable  Tradeand Other Payables Non Current
                ${type_81}=     set variable  INT
                ${name_82}=     set variable  Employee Benefits
                ${type_82}=     set variable  INT
                ${name_83}=     set variable  Non Current Pension And Other Postretirement Benefit Plans
                ${type_83}=     set variable  INT
                ${name_84}=     set variable  Other Non Current Liabilities
                ${type_84}=     set variable  INT
                ${name_85}=     set variable  Total Equity Gross Minority Interest
                ${type_85}=     set variable  INT
                ${name_86}=     set variable  Stockholders' Equity
                ${type_86}=     set variable  INT
                ${name_87}=     set variable  Capital Stock
                ${type_87}=     set variable  INT
                ${name_88}=     set variable  Common Stock
                ${type_88}=     set variable  INT
                ${name_89}=     set variable  Additional Paid in Capital
                ${type_89}=     set variable  INT
                ${name_90}=     set variable  Retained Earnings
                ${type_90}=     set variable  INT
                ${name_91}=     set variable  Gains Losses Not Affecting Retained Earnings
                ${type_91}=     set variable  INT
                ${name_92}=     set variable  Other Equity Adjustments
                ${type_92}=     set variable  INT
                ${name_93}=     set variable  Total Capitalization
                ${type_93}=     set variable  INT
                ${name_94}=     set variable  Common Stock Equity
                ${type_94}=     set variable  INT
                ${name_95}=     set variable  Capital Lease Obligations
                ${type_95}=     set variable  INT
                ${name_96}=     set variable  Net Tangible Assets
                ${type_96}=     set variable  INT
                ${name_97}=     set variable  Working Capital
                ${type_97}=     set variable  INT
                ${name_98}=     set variable  Invested Capital
                ${type_98}=     set variable  INT
                ${name_99}=     set variable  Tangible Book Value
                ${type_99}=     set variable  INT
                ${name_100}=     set variable  Total Debt
                ${type_100}=     set variable  INT
                ${name_101}=     set variable  Net Debt
                ${type_101}=     set variable  INT
                ${name_102}=     set variable  Share Issued
                ${type_102}=     set variable  FLOAT
                ${name_103}=     set variable  Ordinary_Shares_Number
                ${type_103}=     set variable  FLOAT







#    ${output}=   Execute Sql String     CREATE TABLE ${table_name} ( ${name_1} ${type_1}, ${name_2} ${type_2}, ${name_3} ${type_3}, ${name_4} ${type_4}, ${name_5} ${type_5}, ${name_6} ${type_6}, ${name_7} ${type_7}, ${name_8} ${type_8} ) ;

    ${output}=   Execute Sql String     CREATE TABLE ${table_name} ( ${name_1} ${type_1}, ${name_2} ${type_2}, ${name_3} ${type_3}, ${name_4} ${type_4}, ${name_5} ${type_5}, ${name_6} ${type_6}, ${name_7} ${type_7}, ${name_8} ${type_8}, ${name_9} ${type_9}, ${name_10} ${type_10}, ${name_11} ${type_11}, ${name_12} ${type_12}, ${name_13} ${type_13}, ${name_14} ${type_14}, ${name_15} ${type_15}, ${name_16} ${type_16}, ${name_17} ${type_17}, ${name_18} ${type_18}, ${name_19} ${type_19}, ${name_20} ${type_20}, ${name_21} ${type_21}, ${name_22} ${type_22}, ${name_23} ${type_23}, ${name_24} ${type_24}, ${name_25} ${type_25}, ${name_26} ${type_26}, ${name_27} ${type_27}, ${name_28} ${type_28}, ${name_29} ${type_29}, ${name_30} ${type_30}, ${name_31} ${type_31}, ${name_32} ${type_32}, ${name_33} ${type_33}, ${name_34} ${type_34}, ${name_35} ${type_35}, ${name_36} ${type_36}, ${name_37} ${type_37}, ${name_38} ${type_38}, ${name_39} ${type_39}, ${name_40} ${type_40}, ${name_41} ${type_41}, ${name_42} ${type_42}, ${name_43} ${type_43}, ${name_44} ${type_44}, ${name_45} ${type_45}, ${name_46} ${type_46}, ${name_47} ${type_47}, ${name_48} ${type_48}, ${name_49} ${type_49}, ${name_50} ${type_50}, ${name_51} ${type_51}, ${name_52} ${type_52}, ${name_53} ${type_53}, ${name_54} ${type_54}, ${name_55} ${type_55}, ${name_56} ${type_56}, ${name_57} ${type_57}, ${name_58} ${type_58}, ${name_59} ${type_59}, ${name_60} ${type_60}, ${name_61} ${type_61}, ${name_62} ${type_62}, ${name_63} ${type_63}, ${name_64} ${type_64}, ${name_65} ${type_65}, ${name_66} ${type_66}, ${name_67} ${type_67}, ${name_68} ${type_68}, ${name_69} ${type_69}, ${name_70} ${type_70}, ${name_71} ${type_71}, ${name_72} ${type_72}, ${name_73} ${type_73}, ${name_74} ${type_74}, ${name_75} ${type_75}, ${name_76} ${type_76}, ${name_77} ${type_77}, ${name_78} ${type_78}, ${name_79} ${type_79}, ${name_80} ${type_80}, ${name_81} ${type_81}, ${name_82} ${type_82}, ${name_83} ${type_83}, ${name_84} ${type_84}, ${name_85} ${type_85}, ${name_86} ${type_86}, ${name_87} ${type_87}, ${name_88} ${type_88}, ${name_89} ${type_89}, ${name_90} ${type_90}, ${name_91} ${type_91}, ${name_92} ${type_92}, ${name_93} ${type_93}, ${name_94} ${type_94}, ${name_95} ${type_95}, ${name_96} ${type_96}, ${name_97} ${type_97}, ${name_98} ${type_98}, ${name_99} ${type_99}, ${name_100} ${type_100}, ${name_101} ${type_101}, ${name_102} ${type_102}, ${name_103} ${type_103} ) ;

    Log  ${output}









