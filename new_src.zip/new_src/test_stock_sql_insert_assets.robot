*** Keywords ***
test_stock_sql_insert_assets
#    [Arguments]    ${excel_file_data}
#    [Arguments]  ${start_date}  ${end_date}
    [Documentation]
    [Tags]
#    Connect To Database
#    ...    pymssql
#    ...    dbName=DLIQSERV
#    ...    dbUsername=DLIQTASK
#    ...    dbPassword=DLIQTASK3817
#    ...    dbHost=10.201.52.130
#    ...    dbPort=1433



    




    Connect To Database Using Custom Params  sqlite3  database="./test.db"



                ${table_name}=  set variable  assets
                ${name_1}=      set variable  primary_key
                ${type_1}=      set variable  INT
                ${name_2}=      set variable  strategy_id
                ${type_2}=      set variable  INT
                ${name_3}=      set variable  date
                ${type_3}=      set variable  DATE
                ${name_4}=      set variable  class
                ${type_4}=      set variable  varchar(100)
                ${name_5}=      set variable  stock_id
                ${type_5}=      set variable  varchar(100)
                ${name_6}=      set variable  assets_in_or_out
                ${type_6}=      set variable  varchar(10)

                ${name_7}=      set variable  number_of_share
                ${type_7}=      set variable  INT

                ${name_8}=      set variable  unit_price
                ${type_8}=      set variable  FLOAT
                ${name_9}=      set variable  share_amount_price
                ${type_9}=      set variable  FLOAT





#  ${output}=  Execute Sql String  INSERT INTO ${table_name} VALUES ( 1, 1, '2024-01-02', 'tw_stock', '2330', 'in', 1000, 626, 626000 )
#  Log  ${output}

  ${output}=  Execute Sql String  INSERT INTO ${table_name} VALUES ( 2, 1, '2024-01-03', 'tw_stock', '2330', 'out', -1000, 625, 625000 )
  Log  ${output}

  ${output}=  Execute Sql String  INSERT INTO ${table_name} VALUES ( 3, 1, '2024-01-04', 'tw_stock', '2330', 'in', 1000, 698, 698000 )
  Log  ${output}

  ${output}=  Execute Sql String  INSERT INTO ${table_name} VALUES ( 4, 1, '2024-01-05', 'tw_stock', '2330', 'out', -1000, 696, 696000 )
  Log  ${output}

  ${output}=  Execute Sql String  INSERT INTO ${table_name} VALUES ( 5, 1, '2024-02-21', 'tw_stock', '2330', 'in', 1000, 679, 679000 )
  Log  ${output}

  ${output}=  Execute Sql String  INSERT INTO ${table_name} VALUES ( 6, 1, '2024-02-22', 'tw_stock', '2330', 'out', -1000, 680, 680000 )
  Log  ${output}

  ${output}=  Execute Sql String  INSERT INTO ${table_name} VALUES ( 7, 1, '2024-02-23', 'tw_stock', '2330', 'in', 1000, 702, 702000 )
  Log  ${output}

  ${output}=  Execute Sql String  INSERT INTO ${table_name} VALUES ( 8, 1, '2024-02-29', 'tw_stock', '2330', 'out', -1000, 700, 700000 )
  Log  ${output}

  ${output}=  Execute Sql String  INSERT INTO ${table_name} VALUES ( 9, 1, '2024-03-05', 'tw_stock', '2330', 'in', 1000, 736, 736000 )
  Log  ${output}

  ${output}=  Execute Sql String  INSERT INTO ${table_name} VALUES ( 10, 1, '2024-03-12', 'tw_stock', '2330', 'out', -1000, 738, 738000 )
  Log  ${output}

  ${output}=  Execute Sql String  INSERT INTO ${table_name} VALUES ( 11, 1, '2024-03-15', 'tw_stock', '2330', 'in', 1000, 772, 772000 )
  Log  ${output}

  ${output}=  Execute Sql String  INSERT INTO ${table_name} VALUES ( 12, 1, '2024-03-18', 'tw_stock', '2330', 'out', -1000, 770, 770000 )
  Log  ${output}

#  ${output}=  Execute Sql String  INSERT INTO ${table_name} VALUES ( 13, 1, '2024-03-22', 'tw_stock', '2330', 'in', 1000, 789, 789000 )
#  Log  ${output}




  ${output}=  Execute Sql String  INSERT INTO ${table_name} VALUES ( 14, 1, '2024-01-22', 'tw_stock', '2454', 'in', 1000, 929, 929000 )
  Log  ${output}

  ${output}=  Execute Sql String  INSERT INTO ${table_name} VALUES ( 15, 1, '2024-02-02', 'tw_stock', '2454', 'out', -1000, 928, 928000 )
  Log  ${output}

  ${output}=  Execute Sql String  INSERT INTO ${table_name} VALUES ( 16, 1, '2024-02-19', 'tw_stock', '2454', 'in', 1000, 974, 974000 )
  Log  ${output}

  ${output}=  Execute Sql String  INSERT INTO ${table_name} VALUES ( 17, 1, '2024-03-04', 'tw_stock', '2454', 'out', -1000, 988, 988000 )
  Log  ${output}




  ${output}=  Execute Sql String  INSERT INTO ${table_name} VALUES ( 18, 2, '2024-01-04', 'tw_stock', '2330', 'in', 1000, 774, 774000 )
  Log  ${output}

  ${output}=  Execute Sql String  INSERT INTO ${table_name} VALUES ( 19, 2, '2024-01-05', 'tw_stock', '2330', 'out', -1000, 775, 775000 )
  Log  ${output}

