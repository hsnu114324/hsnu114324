*** Keywords ***
pnstestmail_sql_remove
#    [Arguments]    ${excel_file_data}
    [Documentation]
    [Tags]
    Connect To Database
    ...    pymssql
    ...    dbName=DLIQSERV
    ...    dbUsername=DLIQTASK
    ...    dbPassword=DLIQTASK3817
    ...    dbHost=10.201.52.130
    ...    dbPort=1433


    ${output}=    Query    SELECT * FROM QuestData WHERE Q_SID = '08FE0PujSqB';
    Log_To_Console  ${output}
    ${output}=    Execute Sql String    delete　from QuestData where Q_SID = '08FE0PujSqB';
    Log_To_Console  ${output}
    ${output}=    Execute Sql String    delete from QuestMain where Q_SID = '08FE0PujSqB';
    Log_To_Console  ${output}
    ${output}=    Execute Sql String    delete from T_QUESTREPORT where DID = '111621120300000011';
    Log_To_Console  ${output}
    ${output}=    Execute Sql String    DELETE　from T_QUESTREPORT_LOG where DID = '111621120300000011';
    Log_To_Console  ${output}