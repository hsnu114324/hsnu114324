*** Keywords ***
pnstestmail_sql_dump
#    [Arguments]    ${excel_file_data}
    [Documentation]
    [Tags]
    Connect To Database
    ...    pymssql
    ...    dbName=DLIQSERV
    ...    dbUsername=DLIQTASK
    ...    dbPassword=DLIQTASK3817
    ...    dbHost=10.201.52.130
    ...    dbPort=1433


#    ${Q_SID_value}=  set variable  '08FE0PujSqB'
#    ${testmail_no}=  set variable  '111621120300000011'

    ${Q_SID_value}=  set variable  '08FBANRss8S'
    ${testmail_no}=  set variable  '111611121200000004'


    ${output}=    Query    SELECT * FROM QuestData WHERE Q_SID = ${Q_SID_value};
    Log  ${output}
    OperatingSystem.Run  echo ${output} >> QuestData.txt

#    ${output}=    Query    SELECT * from QuestMain where Q_SID = ${Q_SID_value};
    ${output}=    Query    SELECT * from QuestMain where Q_DID = ${testmail_no};
    Log  ${output}
    OperatingSystem.Run  echo ${output} >> QuestMain.txt

    ${output}=    Query    SELECT * from T_QUESTREPORT where DID = ${testmail_no};
    Log  ${output}
    OperatingSystem.Run  echo ${output} >> T_QUESTREPORT.txt

    ${output}=    Query    SELECT * from T_QUESTREPORT_LOG where DID = ${testmail_no};
    Log  ${output}
    OperatingSystem.Run  echo ${output} >> T_QUESTREPORT_LOG.txt













