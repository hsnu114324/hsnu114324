#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Date    : 2020-07-23 16:53:58


import sys
import os
import robot
from robot.api import logger
from robot.utils.asserts import assert_not_none
from robot.api import TestSuite
from robot.api import ResultWriter
from robot.conf import RobotSettings
from robot.libraries.BuiltIn import BuiltIn

from ruamel.yaml import YAML
from ruamel.yaml.constructor import SafeConstructor

def yaml_to_obj(yaml_file):

    import codecs
    yaml = YAML()
    yaml.allow_duplicate_keys = True

    try:
        with codecs.open(yaml_file, 'rb', 'utf-8') as f:
            datas_dict = yaml.load(f)
            if not datas_dict:
                raise Exception("Please check the file: {}".format(yaml_file))
            return datas_dict

    except Exception as e:
        raise e


def get_yaml_configures(yaml_obj):
    if not yaml_obj:
        raise Exception("get_yaml_configures parameter cannot be empty")

    print("yaml_obj.get('config')",yaml_obj.get('config'))
    print("marco")
    return yaml_obj.get('config')


def get_yaml_cases(yaml_obj):
    if not yaml_obj:
        raise Exception("get_yaml_cases parameter cannot be empty")

    return yaml_obj.get('testcases')


def get_all_py_files(path):
    if not path or not os.path.exists(path):
        raise Exception("Cannot find a path or file: {}".format(path))
    results = []
    for root, dirs, files in os.walk(path):
        if not files:
            raise Exception(
                "Cannot find any keywords files in the path: {}".format(path))
        for file in files:
            if file.endswith('.py'):
                results.append(path + "/" + file)

    return results


def create_test_keyword(test, name, args=None, kw_type=None, assign=None):
    print("test name",name)
    print("test args",args)
    print("test assign",assign)
    if not args:
        test.body.create_keyword(name)
    elif not assign:
        test.body.create_keyword(name, args=args)
    else:
        #test.body.create_keyword(name, args=args)
        test.body.create_keyword(name, args=args, assign=assign)


def create_if_func(test, name, args, kw_type, base):
    print("if name",name)
    print("if args",args)
    print("if args[0]",args[0])
    print("if type",kw_type)
    print("if base",base)
    if not args:
        print("if function need arg: ")
    else:
        print("if function test: ")
        #new_test = test.body.create_branch(type=type, condition=args)
        new_test = test.body.create_branch(type=kw_type, condition=args[0])
        #new_test.body.create_keyword('Log To Console', args=['break!'])
        #new_test.body.create_break()
        create_test_step(new_test, base)

def create_keyword_if_func(test, obj):
    print("keyword_if test",test)
    print("keyword_if obj",obj)

    new_test = test.body.create_if()

    for step in obj:
        kw_args = step.get('args')
        print("kw_args",kw_args)
        kw_base = step.get('base')
        print("kw_else",kw_base)
        if_func = step.get('if')
        print("if_func",if_func)
        elif_func = step.get('elif')
        else_func = step.get('else')

        if if_func:
            print("marco if_func")
            #new_test = test.body.create_branch(type='IF', condition=args)
            create_if_func(new_test, if_func, kw_args, 'IF', kw_base)
        elif elif_func:
            print("marco elif_func")
            #new_test = test.body.create_branch(type='ELIF', condition=args)
            create_if_func(new_test, elif_func, kw_args, "'ELIF'", kw_base)
        elif else_func:
            print("marco else_func")
            create_if_func(new_test, else_func, kw_args, "'ELSE'", kw_base)
        else:
            print("marco error!")

    #new_test = test.body.create_if()
    #create_if_func(new_test, name, args, if_func)

def create_for_func(test, name, args, base):
    print("for name",name)
    print("for args",args)
    print("for args[0]",args[0])
    print("for args[1]",args[1])
    print("for args[2]",args[2])
    print("for base",base)
    if not args:
        print("for function neet arg: ")
    else:
        print("for function test: ")
        #new_test = test.body.create_for(variables=[ args[0] ], flavor=args[1], values=args[2])
        new_test = test.body.create_for([ args[0] ], args[1], args[2])
        #new_test.body.create_keyword('Log To Console', args=['${x}'])
        create_test_step(new_test, base)

   

def create_test_step(test, obj):

    print("marco obj",obj)
    if obj is not None:  
        for step in obj:
            kw_name = step.get('keyword')
            kw_args = step.get('args')
            kw_type = step.get('type')
    
            kw_assign = step.get('assign')
            kw_base = step.get('base')
            for_func = step.get('for')
            if_func = step.get('$if')
            break_func = step.get('break')
            continue_func = step.get('continue')
    
            if for_func:
                create_for_func(test, kw_name, kw_args, kw_base)
                print("marco !")
            elif if_func:
                print("marco $if",if_func)
                create_keyword_if_func(test, if_func)
            elif break_func:
                print("marco break",break_func)
                test.body.create_break()
            elif continue_func:
                print("marco continue",continue_func)
                test.body.create_continue()
            else:
                print("marco kw_name",kw_name)
                create_test_keyword(test, kw_name, kw_args, kw_type, kw_assign)
        else:
            print("obj is not initial")


#    if has_kw_if or has_kw_for
#    test1 => create_test_keyword(test?, kw_name, kw_args, kw_type)


def create_test_case_step(test, testcases):
    if not testcases:
        logger.warn("If config test-steps into yaml file will be better")
        return

    create_test_step(test, testcases)


def create_test_assertion_step(test, assertions):
    if not assertions:
        logger.warn("If config assertions into yaml file will be better")
        return
    create_test_step(test, assertions)




def create_suite_keyword(suite, name, args=None, kw_type=None):
    print("suite name",name)
    print("suite args",args)
    if not args:
        #suite.resource.keywords.create(name, type=kw_type)
        suite.resource.keywords.create(name)
    else:
        #suite.resource.keywords.create(name, args=['${args}'])
        suite.resource.keywords.create(name, args=['${args}'])

def create_suite_step(suite, obj):

    for step in obj:
        kw_name = step.get('keyword')
        kw_args = step.get('args')
        kw_type = step.get('type')
        
        print("marco kw_name",kw_name)
        create_suite_keyword(suite, kw_name, kw_args, kw_type)


def create_suite_case_step(suite, testcases):
    if not testcases:
        logger.warn("If config test-steps into yaml file will be better")
        return

    create_suite_step(suite, testcases)


def create_suite_assertion_step(suite, assertions):
    if not assertions:
        logger.warn("If config assertions into yaml file will be better")
        return
    create_suite_step(suite, assertions)


def get_setup_or_teardown_numbers(suite_steps, kw_type='setup'):

    numbers = [index for index, item in enumerate(
        suite_steps) if item.get('type') == kw_type]
    if len(numbers) >= 2:
        raise Exception(
            "At least two {} were found in config steps: {}".format(kw_type, suite_steps))


def order_suite_setup_and_teardown(suite_steps):
    '''
    If find teardown and setup in steps,
    then make sure create setup keyword first
    '''
    get_setup_or_teardown_numbers(suite_steps)
    get_setup_or_teardown_numbers(suite_steps, 'teardown')
#
    b_teardown = False
    index_td = 0
    import copy
    cp_steps = copy.deepcopy(suite_steps)
    for index, step in enumerate(suite_steps):

        kw_type = step.get('type')
        if kw_type == 'teardown':
            b_teardown = True
            index_td = index
        if kw_type == 'setup':
            if b_teardown and index > index_td:
                cp_steps[index_td], cp_steps[index] = cp_steps[index], cp_steps[index_td]

    return cp_steps

import sys

# 查看 sys.argv 列表內容
print("sys.argv 內容：", sys.argv)

# 第 2 個參數
print("第 1 個參數：", sys.argv[1])

#yaml_file = 'cases.yaml'
yaml_file = sys.argv[1]
print("yaml_file：", yaml_file)

yaml_obj = yaml_to_obj(yaml_file)
configs = get_yaml_configures(yaml_obj)
testcases = get_yaml_cases(yaml_obj)


suite_name = configs.get('suite_name')
librarys = configs.get('librarys')
librarys_path = configs.get('librarys_path')
resource = configs.get('resource')
respirce_path = configs.get('resource_path')
suite_steps = configs.get('steps')

suite = TestSuite(suite_name)

for _lib in librarys:
    suite.resource.imports.library('{}'.format(_lib))

for _res in resource:
    suite.resource.imports.resource('{}'.format(_res))

# un-comment follows line, see what happen

if suite_steps is not None:
    suite_steps = order_suite_setup_and_teardown(suite_steps)
    print("2-1")
    create_suite_case_step(suite, suite_steps)
    print("2-2")
else:
    print("suite_steps is not initial")

for case in testcases:
    test_case_name = case.get('name')
    tags = case.get('tags')
    steps = case.get('steps')
    assertions = case.get('assertions')

    # test = suite.tests.create(test_case_name, tags=tags)
    test = suite.tests.create(test_case_name, tags=tags)
    # test.keywords.create('test_builtin_keyword')
    print("1-1")
    create_test_case_step(test, steps)
    print("1-2")
    create_test_assertion_step(test, assertions)

path = "reports"
apiname = 'skynet'
options = {
    "output": "{}-output.xml".format(apiname),
    "log": "{}-log.html".format(apiname),
    "report": "{}-reporter.html".format(apiname),
    "outputdir": path,
    # "include": ['CI']
    # "exclude": ['SMOKE']
}
settings = RobotSettings(options)
suite.configure(**settings.suite_config)
#result = suite.run(settings, critical='smoke')

#ResultWriter(settings.output if settings.log
#             else result).write_results(
#    report=settings.report, log=settings.log)



result = suite.run(output="./output.xml")
print("result : ", result)
print("result.return_code : ", result.return_code)
print("result.suite.tests[0] : ", result.suite.tests[0])
print("result.suite.statistics : ", result.suite.statistics)
ResultWriter("./output.xml").write_results()
exit(result.return_code)

