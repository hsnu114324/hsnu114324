*** Variables ***
${EventLength_TargetVal}   3000

*** Keywords ***

sel_full
	[Documentation]
	[Tags]

###
	wistron_ipmi_fullsel

###
	wistron_bmcweb_login
	wistron_bmcweb_GoAndCheckSELEventPage

###

	Wait Until Page Contains Element  ${xpath_eventlength}
	${EventLength}=    Get Text    ${xpath_eventlength}
        Log_To_Console    EventLength ${EventLength}
    	@{split_list}=    Split String    ${EventLength}
	${EventLength_Val}=  Set Variable  ${split_list}[5]
	Should Be True    ${EventLength_Val} > ${EventLength_TargetVal}


	wistron_bmcweb_logout
