*** Keywords ***
bulk_postweb2_SysJobsTracking_FDBK31
    [Arguments] 	${excel_file_data}
	[Documentation]
	[Tags]
#***

    Log  ${excel_file_data}

    ${time} =	Get Current Date	result_format=%H%M%S
    log  ${time}

    ${SENDERMAIL}=    set variable    shaohunglu@mail.post.gov.tw
    ${RECEIVERMAIL}=  set variable    testfdbk@mail.post.gov.tw
    ${SUBJECT1}=      set variable    test1
    ${TEXT1}=         set variable    ${time}

    # RECEIVERMAIL Should be chosen in every suite seperatly
    @{FIRST_MAIL}=   Create List     ${SENDERMAIL}    ${RECEIVERMAIL}  ${SUBJECT1}   ${TEXT1}
#    @{SECOND_MAIL}    ${SENDERMAIL}    ${RECEIVERMAIL}  ${SUBJECT2}   ${TEXT2}
#    @{THIRD_MAIL}     ${SENDERMAIL}    ${RECEIVERMAIL}  ${SUBJECT3}   ${TEXT3}

    log  ${FIRST_MAIL}

    ${ENV_USER}=    set variable   shaohunglu
    ${ENV_PASS}=    set variable   Jy99jy88
    ${ENV_MAIL_SERVER}=   set variable   m2k.post.gov.tw
    ${ENV_IMAP_PORT}=     set variable   143
    ${ENV_POP3_PORT}=     set variable   110
    ${ENV_SMTP_PORT}=     set variable   25
    ${ENV_IMAP_SSL_PORT}=     set variable   993
    ${ENV_POP3_SSL_PORT}=     set variable   995
    ${ENV_SMTP_SSL_PORT}=     set variable   465


    Set_Smtp_Username_And_Password   ${ENV_USER}      ${ENV_PASS}
    Set_Pop3_Username_And_Password   ${ENV_USER}      ${ENV_PASS}
    Set_Imap_Username_And_Password   ${ENV_USER}      ${ENV_PASS}
    Set_Mail_Server_Address          ${ENV_MAIL_SERVER}
    Set_Both_Imap_Ports              ${ENV_IMAP_SSL_PORT}  ${ENV_IMAP_PORT}
    Set_Both_Pop3_Ports              ${ENV_POP3_SSL_PORT}  ${ENV_POP3_PORT}
    Set_Both_Smtp_Ports              ${ENV_SMTP_SSL_PORT}  ${ENV_SMTP_PORT}



    Send Mail    @{FIRST_MAIL}

#***
	bulk_postweb2_loginChrome  https://10.201.52.167/
#***
	bulk_postweb2_loginUsername  714838
#***
	bulk_postweb2_loginPassword  Xm3gl4cj/678
#***
	Sleep  10s
	bulk_postweb2_loginEnter
	Sleep  1s
	bulk_postweb2_adminloginEnter
	Sleep  1s	

###********
	bulk_postweb2_ClickSY000
#***
	bulk_postweb2_ClickSY000List3
#***
	bulk_postweb2_ClickSY000List3bean_search 
#***
    Sleep  1s

    ${new_status_xpath}  ${new_button_xpath}=  bulk_postweb2_FetchTableGridButton   jqgrid  	Job_O_Bulk_FDBK31_S0S1

    log  ${new_status_xpath}
    log  ${new_button_xpath}

    bulk_postweb2_ClickTableGridButton   ${new_button_xpath}  jqgrid  	Job_O_Bulk_FDBK31_S0S1

    Wait Until Keyword Succeeds  20s  2s  bulk_postweb2_Check_Status_And_Refresh_If_Needed   Job_O_Bulk_FDBK31_S0S1 

    

#***
	bulk_postweb2_ClickBU000
#***
	bulk_postweb2_ClickBU000List2
#***
	bulk_postweb2_ClickBU000List2bean_search


#***
	bulk_postweb2_ClickBU000List2erste
    
    bulk_postweb2_ClickBU000List2ersteS1
    Sleep  1s

    ${S1log_name}=  bulk_postweb2_FetchBU000List2ersteS1log_name

    log  ${S1log_name}

    ${dir_download}=  set variable     C:/Users/714838/Downloads

    bulk_postweb2_DownloadBU000List2ersteS1_log   ${dir_download}  ${time}

    bulk_postweb2_CheckBU000List2ersteS1_log   ${dir_download}  ${time}  Out



    


###********
	bulk_postweb2_ClickSY000
#***
	bulk_postweb2_ClickSY000List3
#***
	bulk_postweb2_ClickSY000List3bean_search 
#***
    Sleep  1s

    ${new_status_xpath}  ${new_button_xpath}=  bulk_postweb2_FetchTableGridButton   jqgrid  	Job_O_Bulk_FDBK31_S2

    log  ${new_status_xpath}
    log  ${new_button_xpath}

    bulk_postweb2_ClickTableGridButton   ${new_button_xpath}  jqgrid  	Job_O_Bulk_FDBK31_S2

    Wait Until Keyword Succeeds  20s  2s  bulk_postweb2_Check_Status_And_Refresh_If_Needed  Job_O_Bulk_FDBK31_S2  

    

#***
	bulk_postweb2_ClickBU000
#***
	bulk_postweb2_ClickBU000List2
#***
	bulk_postweb2_ClickBU000List2bean_search 
#***
	bulk_postweb2_ClickBU000List2erste
    

    bulk_postweb2_ClickBU000List2ersteS2
    Sleep  1s

    ${S2log_name}=  bulk_postweb2_FetchBU000List2ersteS2log_name

    log  ${S2log_name}

    ${dir_download}=  set variable     C:/Users/714838/Downloads

    bulk_postweb2_DownloadBU000List2ersteS2_log   ${dir_download}  ${time}

    bulk_postweb2_CheckBU000List2ersteS2_log   ${dir_download}  ${time}  Out







###********
	bulk_postweb2_ClickSY000
#***
	bulk_postweb2_ClickSY000List3
#***
	bulk_postweb2_ClickSY000List3bean_search 
#***
    Sleep  1s

    ${new_status_xpath}  ${new_button_xpath}=  bulk_postweb2_FetchTableGridButton   jqgrid  	Job_O_Bulk_FDBK31_S3

    log  ${new_status_xpath}
    log  ${new_button_xpath}

    bulk_postweb2_ClickTableGridButton   ${new_button_xpath}  jqgrid  	Job_O_Bulk_FDBK31_S3

    Wait Until Keyword Succeeds  20s  2s  bulk_postweb2_Check_Status_And_Refresh_If_Needed  Job_O_Bulk_FDBK31_S3  

    

#***
	bulk_postweb2_ClickBU000
#***
	bulk_postweb2_ClickBU000List2
#***
	bulk_postweb2_ClickBU000List2bean_search 
#***
	bulk_postweb2_ClickBU000List2erste
    

    bulk_postweb2_ClickBU000List2ersteS3
    Sleep  1s

    ${S3log_name}=  bulk_postweb2_FetchBU000List2ersteS3log_name

    log  ${S3log_name}

    ${dir_download}=  set variable     C:/Users/714838/Downloads

    bulk_postweb2_DownloadBU000List2ersteS3_log   ${dir_download}  ${time}

    bulk_postweb2_CheckBU000List2ersteS3_log   ${dir_download}  ${time}  Out







#	Return  ${CR_no}