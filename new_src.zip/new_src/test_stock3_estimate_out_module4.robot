*** Keywords ***
#*** Test Cases ***
test_stock3_estimate_out_module4
    [Documentation]    Load sensor list file and prepare list
#    [Arguments]     ${query_start_date}  ${query_end_date}  ${query_stock_id}  ${query_database}
    [Arguments]     ${query_start_date}  ${query_end_date}  ${query_database}  ${currency}



#    Connect To Database Using Custom Params  sqlite3  database="./test.db"
    Connect To Database Using Custom Params  sqlite3  database="./${query_database}"

#    ${query_start_date}=  set variable  '2024-01-01'
#    ${query_end_date}=    set variable  '2024-04-01'














#            ${list_1}=    post_csv_get_strategy_data    stock_csv_new_macd_dif/1_strategy_2024.csv
            ${list_1}=    post_csv_get_strategy_data    stock_csv_new_macd_dif/1_evaluate_out_2024.csv
            ${length}=  Get length  ${list_1}
            ${length+1}=  evaluate  ${length} + 1
















  ${strategy_id}=  set variable  1 
#  ${buyin}=  set variable  0
  ${buyin_signal}=  set variable  0
  ${buyin_signal_volume}=  set variable  0
  ${buyin_among_NTD}=  set variable  0

#    ${longterm_position}=  set variable  0
#    ${longterm_position_list}=  Create List
    ${primary_key}=  set variable  0
    ${share_amount_price}=  set variable  0

    ${limit_up}=  set variable  0
 

#  ${date_length}=  get length  ${output_k}

  FOR  ${i}  IN RANGE  1  ${length}  1

    log   ${list_1}[${i}]    
    ${date}=  set variable  ${list_1}[${i}][0]     
    ${buyin_signal}=  set variable  ${list_1}[${i}][2]     
#    ${buyin_signal_volume}=  set variable  ${list_1}[${i}][5]     
    ${buyin_signal_volume}=  set variable  ${list_1}[${i}][6]     

        IF  ${buyin_signal} >= 1
#        Fail 
            IF  ${buyin_signal_volume} == 0
                Fail
                Continue For Loop
            END

            ${position}=  set variable  ${buyin_signal_volume}  
            ${buyin}=  set variable  0
#            ${equity}=  evaluate  ${equity} - ${position}
            ${currency}=  evaluate  ${currency} - ${position}
#            ${longterm_position}=  evaluate  ${longterm_position} + ${position}
#            ${longterm_position_i}=  Create List  ${longterm_position}  ${date}
            IF  ${limit_up} == 1
                ${cannot_buy_signla}= set variable  1
                Continue For Loop
            END
        ELSE
            ${buyin_signal_volume}=  set variable  0
            ${position}=  set variable  ${buyin_signal_volume}  
#            ${longterm_position}=  set variable  0
#            ${longterm_position_i}=  Create List  ${longterm_position}  ${date}

                Continue For Loop
        END

#        Append_To_list  ${longterm_position_list}  ${longterm_position_i} 


        ${primary_key}=  evaluate  ${primary_key} + 1
        ${class}=  set variable  tw_stock
        ${assets_in_or_out}=  set variable  in
        ${number_of_share}=     set variable  ${position}
        ${unit_price}=  set variable  1000
        ${share_amount_price}=  evaluate  ${number_of_share} * ${unit_price}

#        ${today_date}=  set variable  ${output_close}[${i}][1]
        ${stock_id}=  set variable  2330
        ${strategy_id}=  set variable  1
        ${table_name}=  set variable  assets

        ${assets_i}=  create list


        insert_assets_data_to_database  ${table_name}  ${assets_i}  ${primary_key}  ${strategy_id}  ${date}    ${class}  ${stock_id}  ${assets_in_or_out}  ${number_of_share}  ${unit_price}  ${share_amount_price} 

#        Append_To_list  ${assets_i}  ${primary_key}  ${strategy_id}  ${date}    ${class}  ${stock_id}  ${assets_in_or_out}  ${number_of_share}  ${unit_price}  ${share_amount_price} 

#        ${output_sql}=  Execute Sql String  INSERT INTO ${table_name} VALUES ( ${primary_key}, ${strategy_id}, '${date}', '${class}', '${stock_id}', '${assets_in_or_out}', ${number_of_share}, ${unit_price}, ${share_amount_price} )


        ${table_name}=  set variable  equity
#        ${currency}=    set variable  0
        ${class}=       set variable  cash
        ${equity_in_or_out}=   set variable  in
        ${exchange_rate}=  set variable  1
        ${currency_amount_NTD}=  set variable  0

        ${equity_i}=  create list


        insert_equity_data_to_database  ${table_name}  ${equity_i}  ${primary_key}  ${strategy_id}  ${date}  ${class}  ${equity_in_or_out}  ${currency}  ${exchange_rate}  ${currency_amount_NTD}


#        Append_To_list  ${equity_i}  ${primary_key}  ${strategy_id}  ${date}  ${class}  ${equity_in_or_out}  ${currency}  ${exchange_rate}  ${currency_amount_NTD} 

#        ${output_sql}=  Execute Sql String  INSERT INTO ${table_name} VALUES ( ${primary_key}, ${strategy_id}, '${date}', '${class}', '${equity_in_or_out}', ${currency}, ${exchange_rate}, ${currency_amount_NTD} )


#################


       ${assets_csv_header_string}=  set variable  primary_key,策略代號,日期,種類,股票代碼,買進或賣出,成交量,收盤價,成交金額\n
       ${assets_csv_string}=  set variable  ${primary_key}, ${strategy_id}, ${date}, ${class}, ${stock_id}, ${assets_in_or_out}, ${number_of_share}, ${unit_price}, ${share_amount_price}\n
        post_csv_setdata    stock_csv_new_macd_dif/${strategy_id}_assets_${date}[0:4].csv  ${assets_csv_header_string}  ${assets_csv_string}  



       ${equity_csv_header_string}=  set variable   primary_key,策略代號,日期,種類,買入或賣出,通貨,匯率,總新台幣金額\n

       ${equity_csv_string}=  set variable    ${primary_key}, ${strategy_id}, ${date}, ${class}, ${stock_id}, ${equity_in_or_out}, ${currency}, ${exchange_rate}, ${currency_amount_NTD}\n

        post_csv_setdata    stock_csv_new_macd_dif/${strategy_id}_equity_${date}[0:4].csv  ${equity_csv_header_string}  ${equity_csv_string}  












    END

