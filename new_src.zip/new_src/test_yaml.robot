*** Settings ***
Library  yaml
Library  OperatingSystem
Library  Collections

*** Test Cases ***
Load YAML into Robot and edit it
  ${YAML}=  Get File  ${CURDIR}${/}chart2.yaml
  ${LOADED}=  yaml.Safe Load  ${YAML}
#  Set To Dictionary  ${LOADED}[chartjs]\[options][scales][yAxes][1][ticks][max]  value=200
  Set To Dictionary  ${LOADED["chartjs"][1]["options"]["scales"]["yAxes"][1]["ticks"]}  min=200

  ${list_value}=  Create List  
  Append To List  ${list_value}  300  400  500

  Set To Dictionary  ${LOADED["chartjs"][1]["options"]["scales"]["yAxes"][1]["ticks"]}  max=${list_value}
  ${OUTPUT}=  yaml.Dump  ${LOADED}
  Create File  newchart2.yaml  ${OUTPUT}
