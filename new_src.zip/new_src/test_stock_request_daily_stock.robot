*** Keywords ***
test_stock_request_daily_stock

    [Arguments]     ${start_date}      ${end_date}   
    Log   ${start_date}
    Log   ${end_date}
    Log_To_Console  start_date : ${start_date}
    Log_To_Console  end_date : ${end_date}


#    ${start_date}=    Set Variable    20190103
#    ${end_date}    Set Variable    20240415



#    ${str_max_num}=    Convert_To_String    ${max_num}


    ${folder}=    set variable    finmind_folder    # 更換成目標資料>夾的路徑


    ${max_file}    Set Variable    none
    ${max_num}    Set Variable    0
    ${files}    OperatingSystem.List_Files_In_Directory    ${folder}    *.csv



    FOR    ${file}    IN    @{files}
        ${file_split_pre}=    Split String    ${file}    .
        Log_To_Console  ${file_split_pre}[0]
#        ${file_split}=    Split String    ${file_split_pre}[0]    _
#        Log_To_Console  ${file_split}[1]
        ${file_num}=  Convert_Date  ${file_split_pre}[0]    result_format=%Y%m%d    date_format=%Y-%m-%d
        ${num}    Evaluate    ${file_num}
        IF    ${num} > ${max_num}
            ${max_file}    Set Variable    ${file}
            ${max_num}    Set Variable    ${num}
        END
    END
    Log_To_Console    Max CSV file: ${max_file}
    Log    Max CSV file: ${max_file}
    Log_To_Console    Max num: ${max_num}
    ${int_max_num}=    Convert_To_Integer    ${max_num}
    ${str_max_num}=    Convert_To_String    ${max_num}
    Log_To_Console    int Max num: ${int_max_num}
    Log_To_Console    str Max num: ${str_max_num}















  ${date_range}=  finmind_GetDateRange  ${str_max_num}  ${end_date}

#   log  ${date_range}

  ${current_time}=   set variable  0
  

  FOR  ${date}  IN  @{date_range}


      ${past_time}=     set variable  ${current_time}
      ${current_time}=  Get Current Date  result_format=%Y%m%d%H%M
      ${spend_time}=  evaluate  ${current_time} - ${past_time}
      IF  ${spend_time} > 40
          ${sleep_enable}=  set variable  0
      ELSE
          ${sleep_enable}=  set variable  1
      END


    log_to_console  ${date}

    ${file_exists}=  Run Keyword And Return Status  OperatingSystem.File_Should_Exist   finmind_folder/${date}.csv

                IF  '${file_exists}' == 'True'
                    CONTINUE FOR LOOP
                END


#    &{params_data}=    Create dictionary  dataset=TaiwanStockKBar  data_id=9962  start_date=${date}  token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRlIjoiMjAyNC0wMy0xNCAxOTozMjoyOSIsInVzZXJfaWQiOiJoc251MTE0MzI0IiwiaXAiOiIyMjMuMTQwLjE1My40OSJ9.s4YB40C3oeXvVirm6aciA4gG1KLUO12Yw9JuIk6GYek
    &{params_data}=    Create dictionary  dataset=TaiwanStockPrice  start_date=${date}  end_date=${date}  token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRlIjoiMjAyNC0wMy0xNCAxOTozMjoyOSIsInVzZXJfaWQiOiJoc251MTE0MzI0IiwiaXAiOiIyMjMuMTQwLjE1My40OSJ9.s4YB40C3oeXvVirm6aciA4gG1KLUO12Yw9JuIk6GYek

    Delete All Sessions

    create session  api  https://api.finmindtrade.com
    ${resp}=  get request  api  /api/v4/data  params=${params_data}
    ${resp_json_data}=  set variable  ${resp.json()["data"]}

#    log  ${resp_json_data}

    ${empty_data}  Create list  

    IF  ${resp_json_data} == ${empty_data}
        log  empty
        CONTINUE　FOR LOOP
    END







    log_to_console  ${date}

    ${file_exists}=  Run Keyword And Return Status  OperatingSystem.File_Should_Exist   findmin_folder/${date}.csv

                IF  '${file_exists}' == 'True'
                    CONTINUE FOR LOOP
                END






    IF  ${sleep_enable} == 1
        sleep  300ms
    ELSE
        sleep  200ms
    END

#    &{params_data}=    Create dictionary  dataset=TaiwanStockKBar  data_id=${stock_id}  start_date=${date}  token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRlIjoiMjAyNC0wMy0xNCAxOTozMjoyOSIsInVzZXJfaWQiOiJoc251MTE0MzI0IiwiaXAiOiIyMjMuMTQwLjE1My40OSJ9.s4YB40C3oeXvVirm6aciA4gG1KLUO12Yw9JuIk6GYek
    &{params_data}=    Create dictionary  dataset=TaiwanStockPrice  start_date=${date}  end_date=${date}  token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRlIjoiMjAyNC0wMy0xNCAxOTozMjoyOSIsInVzZXJfaWQiOiJoc251MTE0MzI0IiwiaXAiOiIyMjMuMTQwLjE1My40OSJ9.s4YB40C3oeXvVirm6aciA4gG1KLUO12Yw9JuIk6GYek


    create session  api  https://api.finmindtrade.com
    ${resp}=  get request  api  /api/v4/data  params=${params_data}
#    ${resp}=   Get   https://api.finmindtrade.com/api/v4/data  params=${params_data}   
    ${resp_json_data}=  set variable  ${resp.json()["data"]}






           ${length}=  Get length  ${resp_json_data} 
        
            log  ${length}
        
            FOR  ${resp_i}  IN RANGE  0  ${length}  1
        
                 ${resp_i_list}=  set variable  ${resp_json_data}[${resp_i}]
                 ${resp_i_list_length}=  Get length  ${resp_i_list}
        #         FOR  ${resp_j}  IN RANGE  0  ${resp_i_list_length}  1
        







#    ${type string}=    Evaluate     type(${resp_json_data})
#    Log To Console     ${type string}

#    ${type string}=    Evaluate     type(${resp_i_list})
#    Log To Console     ${type string}

#    ${list_xd}=    Convert To List    ${resp_i_list}
#    ${str_xd}=     Convert To String  ${resp_i_list}

#    log  ${list_xd}
#    log  ${str_xd}


         END


#    log  ${resp_json_data}

    ${empty_data}  Create list  

    IF  ${resp_json_data} == ${empty_data}
        log  empty
        CONTINUE　FOR LOOP
    END


    ${file_exists}=  Run Keyword And Return Status  OperatingSystem.File_Should_Exist   finmind_folder/${date}.csv

                IF  '${file_exists}' == 'False'
                    Copy File  csv.csv  finmind_folder/${date}.csv
                ELSE
                    CONTINUE FOR LOOP

                END

    Append To Csv File    finmind_folder/${date}.csv  ${resp_json_data}

            END









