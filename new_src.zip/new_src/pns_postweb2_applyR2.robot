*** Keywords ***
pns_postweb2_applyR2
    [Arguments] 	${excel_file_data}
	[Documentation]
	[Tags]
#***

    Log  ${excel_file_data}
#***
	post_postweb2_pnsFrontEndloginChrome  https://pnstest.post.gov.tw/LI.Web/LI0010.aspx
#***
	post_postweb2_ClickPnsFrontEndLoginUsername  0963038476
#***
	post_postweb2_ClickPnsFrontEndLoginPassword  Jy99jy88
#***
	Sleep  10s
	post_postweb2_ClickPnsFrontEndLoginEnter
	Sleep  5s
#***

	post_postweb2_ClickPnsFrontEndMenuList1
#***
	post_postweb2_ClickPnsFrontEndMenuList1Button3
#***
	post_postweb2_ClickPnsFrontEndcbConfirm
#***
	post_postweb2_ClickPnsFrontEndddlNewCity_ddl1  ${excel_file_data}[4]
#***
	post_postweb2_ClickPnsFrontEndddlOldCity_ddl1  ${excel_file_data}[8]
#***
	post_postweb2_ClickPnsFrontEndbtnSend
#***


	post_postweb2_ClickPnsFrontEndMenuList2
#***
	post_postweb2_ClickPnsFrontEndMenuList2Button1
#***  
	post_postweb2_ClickPnsFrontEndbtnQuery

    ${CR_no}=  post_postweb2_FetchPnsFrontEndlbtnReqNo_0

	post_postweb2_ClickPnsFrontEndlbtnReqNo_0
#	post_postweb2_ClickPnsFrontEndCancelbtnSave
#***

	[Return]  ${CR_no}