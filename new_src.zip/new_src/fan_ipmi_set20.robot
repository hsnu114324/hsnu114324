*** Variables ***
${fan_target_pwm_20}	  0x14
${inlet_rotor_minimum_20}    3219
${inlet_rotor_maximum_20}    3934
${outlet_rotor_minimum_20}   2995
${outlet_rotor_maximum_20}	  3660


*** Keywords ***
fan_ipmi_set20
	wistron_ipmi_FanSetManual
	wistron_ipmi_FanSet	${fan_target_pwm_20}
	wistron_ipmi_FanGetDuty  ${inlet_rotor_minimum_20}    ${inlet_rotor_maximum_20}    ${outlet_rotor_minimum_20}    ${outlet_rotor_maximum_20}
	wistron_ipmi_FanSetAuto


