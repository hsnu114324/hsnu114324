*** Variables ***
${SOL_BIOS_OUTPUT}    ubuntu
${IPMI_SOL_LOG_FILE}    IPMI_SOL_LOG_FILE.txt

*** Keywords ***
test_sol



        wistron_bmcweb_logout
        wistron_bmcweb_ExpectPowerOff
        wistron_bmcweb_login

	wistron_ipmi_PowerOn


        wistron_bmcweb_GoToPage  ${url_remote_control}
        Sleep  3
        Click Element    ${xpath_H5View_button}
        Sleep  3

        ${titles}  Get Window Titles
        Log_To_Console  ${titles}
        ${titles2}      Get From List   ${titles}   1
        Log_To_Console  ${titles2}
        ${titles1}      Get From List   ${titles}   0
        Log_To_Console  ${titles1}
        Switch Window    title=${titles2}

	Sleep  1

                Wait Until Element Is Not Visible    ${xpath_kvm_processing_image}    timeout=${BROWSER_PROCESSING_TIMEOUT}

#***

        FOR  ${i}  IN RANGE  30

                Wait Until Element Is Not Visible    ${xpath_kvm_processing_image}    timeout=${BROWSER_PROCESSING_TIMEOUT}

                Capture Element Screenshot      id:cursor_canvas        test_sol_element_screenshot-${i}.png

                ${rc}   ${output}=   Run Keyword And Ignore Error    Compare Images   ${local_path}/${Picture_folder_path}/nvidia.png    test_sol_element_screenshot-${i}.png
                Log_To_Console  rc ${rc}
                Log_To_Console  output ${output}

                Exit For Loop If  '${rc}' == 'PASS'
                Sleep  1

        END

#***

        FOR  ${i}  IN RANGE  60

                Wait Until Element Is Not Visible    ${xpath_kvm_processing_image}    timeout=${BROWSER_PROCESSING_TIMEOUT}

                Capture Element Screenshot      id:cursor_canvas        test_sol_nvidia_login_element_screenshot-${i}.png

                ${rc}   ${output}=   Run Keyword And Ignore Error    Compare Images   ${local_path}/${Picture_folder_path}/nvidia_login.png    test_sol_nvidia_login_element_screenshot-${i}.png
                Log_To_Console  rc ${rc}
                Log_To_Console  output ${output}

                Exit For Loop If  '${rc}' == 'PASS'

        	Press Keys      None    F2

                Sleep  1

        END





#***

    ${output}=   OperatingSystem.Run   ipmitool -I lanplus -H ${BMC_IP} -U ${IPMI_USERNAME} -P ${IPMI_PASSWORD} sol deactivate
    Log To Console    output: ${output}    




    Spawn    /usr/bin/ipmitool -I lanplus -H ${BMC_IP} -U ${IPMI_USERNAME} -P ${IPMI_PASSWORD} sol activate usesolkeepalive	encoding='utf-8'	codec_errors=ignore


    ${data}    Read Line
    Log To Console    Received: ${data}    

    sleep  2    
    Send Line	'\x1b[C'
    sleep  2    
    Send Line	'\x1b[C'
#    sleep  2    
#    Send Line	'\x1b[C'
#    sleep  2    
#    Send Line	'\x1b[C'
#    sleep  2    
#    Send Line	'\x1b[C'



	FOR  ${i}  IN RANGE  10

    	    sleep  2    
	    Capture Element Screenshot      id:cursor_canvas	test_sol-${i}.png
	
	    ${status1}=  Run Keyword And Return Status    Compare Images   ${local_path}/${Picture_folder_path}/sol_1.png    test_sol-${i}.png
	    Log To Console	status1 ${status1}

	    ${status2}=  Run Keyword And Return Status    Compare Images   ${local_path}/${Picture_folder_path}/sol_2.png    test_sol-${i}.png
	    Log To Console	status2 ${status2}
	    ${status22}=  Run Keyword And Return Status    Compare Images   ${local_path}/${Picture_folder_path}/sol_22.png    test_sol-${i}.png
	    Log To Console	status22 ${status22}

	    ${status3}=  Run Keyword And Return Status    Compare Images   ${local_path}/${Picture_folder_path}/sol_3.png    test_sol-${i}.png
	    Log To Console	status3 ${status3}
	    ${status32}=  Run Keyword And Return Status    Compare Images   ${local_path}/${Picture_folder_path}/sol_32.png    test_sol-${i}.png
	    Log To Console	status32 ${status32}

	    ${status4}=  Run Keyword And Return Status    Compare Images   ${local_path}/${Picture_folder_path}/sol_4.png    test_sol-${i}.png
	    Log To Console	status4 ${status4}
	    ${status4}=  Run Keyword And Return Status    Compare Images   ${local_path}/${Picture_folder_path}/sol_4.png    test_sol-${i}.png
	    Log To Console	status42 ${status42}

	    ${status5}=  Run Keyword And Return Status    Compare Images   ${local_path}/${Picture_folder_path}/sol_5.png    test_sol-${i}.png
	    Log To Console	status5 ${status5}
	    ${status52}=  Run Keyword And Return Status    Compare Images   ${local_path}/${Picture_folder_path}/sol_52.png    test_sol-${i}.png
	    Log To Console	status52 ${status52}

	    ${status6}=  Run Keyword And Return Status    Compare Images   ${local_path}/${Picture_folder_path}/sol_6.png    test_sol-${i}.png
	    Log To Console	status6 ${status6}
	    ${status62}=  Run Keyword And Return Status    Compare Images   ${local_path}/${Picture_folder_path}/sol_62.png    test_sol-${i}.png
	    Log To Console	status62 ${status62}

	    ${status7}=  Run Keyword And Return Status    Compare Images   ${local_path}/${Picture_folder_path}/sol_7.png    test_sol-${i}.png
	    Log To Console	status7 ${status7}
	    ${status72}=  Run Keyword And Return Status    Compare Images   ${local_path}/${Picture_folder_path}/sol_72.png    test_sol-${i}.png
	    Log To Console	status72 ${status72}
	
	    Run Keyword If    ${status1} == ${True} 	Send Line	'\x1b[C'
	    Run Keyword If    ${status2} == ${True} 	Send Line	'\x1b[C'
	    Run Keyword If    ${status22} == ${True} 	Send Line	'\x1b[C'
	    Run Keyword If    ${status3} == ${True} 	Send Line	'\x1b[C'
	    Run Keyword If    ${status32} == ${True} 	Send Line	'\x1b[C'
	    Run Keyword If    ${status4} == ${True} 	Send Line	'\x1b[C'
	    Run Keyword If    ${status42} == ${True} 	Send Line	'\x1b[C'
	    Run Keyword If    ${status5} == ${True} 	Send Line	'\x1b[B'
	    Run Keyword If    ${status52} == ${True} 	Send Line	'\x1b[B'
	    Run Keyword If    ${status6} == ${True} 	Send Line	'\r'
	    Run Keyword If    ${status62} == ${True} 	Send Line	'\r'
	    Run Keyword If    ${status7} == ${True} 	Send Line	'\r'
	    Run Keyword If    ${status72} == ${True} 	Send Line	'\r'

	END

	
#****

	FOR	${i}	IN RANGE	10
    	    sleep  2    
	    Send Line	'\r'
	END
	
#****

	FOR	${i}	IN RANGE	10000
	    ${data2}    Read Line
	    Log To Console    Received: ${data2}    

	    ${data2_match}=	Get Regexp Matches	${data2}	Ubuntu 18.04.4 LTS ubuntu ttyS1
	    Log To Console    data2_march ${data2_match}    
	    Exit For Loop IF   ${data2_match} == ['Ubuntu 18.04.4 LTS ubuntu ttyS1'] 
	END

	Should Contain    ${data2_match}    Ubuntu 18.04.4 LTS ubuntu ttyS1

    ${data}    Read Line
    Log To Console    Received: ${data}    



    Close

        wistron_bmcweb_logout





















