*** Keywords ***
pnstestmail_postweb2_setVerB



    [Arguments] 	${path_excel}  ${sheet_name}
    Log_To_Console	path_excel : ${path_excel}
    Log_To_Console	sheet_name : ${sheet_name}

    ${sensor_check_list}=  post_excel_getdata_for_ezpost    ${path_excel}  ${sheet_name} 

    ${list_count} =    Get length    ${sensor_check_list}
    Log_To_Console   list_count ${list_count}
	Log_To_Console   ${sensor_check_list}

    FOR  ${sensor_name}  IN  @{sensor_check_list}

		Log   sensor_name: ${sensor_name}
		Log   ${sensor_name}[0]

    END




  FOR  ${sensor_name}  IN  @{sensor_check_list}
    IF  '${sensor_name}[0]' == 'web'
	    Log_To_Console	${sensor_name}[0]
	    Log	 ${sensor_name}[0]
    ELSE
    	Log_To_Console	${sensor_name}[0]
    	Log  ${sensor_name}[0]
    	CONTINUE For Loop
    END

#***
#	post_postweb2_pnsFrontEndlogin  https://pnstest.post.gov.tw/LI.Web/Quest.aspx?q_sid=08FE0PujSqB

	Log  ${sensor_name}
	Log  ${sensor_name}[1]
	post_postweb2_pnsFrontEndloginbyExcel  ${sensor_name}[1]
#***

#	post_postweb2_ClickPnsFrontEndLoginUsername  0963038476
#***
#	post_postweb2_ClickPnsFrontEndLoginPassword  Jy99jy88
#***
#	Sleep  10s
#	post_postweb2_ClickPnsFrontEndLoginEnter
	post_postweb2_ClickPnstestmailFrontEndLoginEnter
#	Sleep  5s
#***

	post_postweb2_ClickPnsFrontEndQ2_VerB
	post_postweb2_ClickPnsFrontEndQ3_VerB
	post_postweb2_ClickPnsFrontEndQ4_VerB
	post_postweb2_ClickPnsFrontEndQ5_VerB  ${sensor_name}[5]
	post_postweb2_ClickPnsFrontEndQ6_VerB
	post_postweb2_ClickPnsFrontEndQ7_VerB
	post_postweb2_ClickPnsFrontEndQ8_1_VerB
	post_postweb2_ClickPnsFrontEndQ8_2_VerB
	post_postweb2_ClickPnsFrontEndQ8_3_VerB
#	post_postweb2_ClickPnsFrontEndQ9_VerA
	post_postweb2_ClickPnsFrontEnd_cbTreatyConfirm
	post_postweb2_ClickPnsFrontEnd_Submit
	Sleep  1s


#	post_postweb2_ClickPnsFrontEndMenuList2
#***
#	post_postweb2_ClickPnsFrontEndMenuList2Button1
#***  
#	post_postweb2_ClickPnsFrontEndbtnQuery

#    ${CR_no}=  post_postweb2_FetchPnsFrontEndlbtnReqNo_0

#	post_postweb2_ClickPnsFrontEndlbtnReqNo_0
#	post_postweb2_ClickPnsFrontEndCancelbtnSave
#***

  END

#	[Return]  ${CR_no}
