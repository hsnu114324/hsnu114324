*** Variables ***
@{az_list}=  a  b  c  d  e  f  g  h  i  j  k  m  n  o  p  q  t  u  v  w  x  z

*** Keywords ***
test_csv_map_com
    [Arguments]     ${ii}  
    Log   ${ii}



#    post_postweb2_mapcomFrontEndlogin  https://www.map.com.tw

#    FOR  ${ii}  IN   @{az_list}
#        log  ${ii}

        ${file_exists}=  Run Keyword And Return Status  OperatingSystem.File_Should_Exist   lvr_landcsv/${ii}_lvr_land_a_gps.csv
 

        ${start_num}=  set variable  2

        IF  '${file_exists}' == 'True'

        
    
            ${old_csv_content}=    Get File    lvr_landcsv/${ii}_lvr_land_a_gps.csv    encoding=UTF-8-SIG    encoding_errors=strict

            @{old_csv_content_list}=  Read Csv String To List  ${old_csv_content}   
            ${old_csv_content_count}=    Get length    ${old_csv_content_list}

            ${old_csv_content_count_1}=  Evaluate  ${old_csv_content_count}-1

            ${old_csv_content_array}=  get_from_list  ${old_csv_content_list}  ${old_csv_content_count_1}

            log  ${old_csv_content_array}
            log  ${old_csv_content_array}[2]

            ${restart_csv_string}=  set variable  ${old_csv_content_array}[2]

            log  ${restart_csv_string}


            ${CsvFileContent}    Get File    lvr_landcsv/${ii}_lvr_land_a.csv    encoding=UTF-8-SIG    encoding_errors=strict


            @{list_csv_before_yesterday}=  Read Csv String To List  ${CsvFileContent}

            ${list_csv_by_cnt}=    Get length    ${list_csv_before_yesterday}
            
            FOR  ${old_j}  IN RANGE  2  ${list_csv_by_cnt}  1

                ${s1_by_array}=  get_from_list  ${list_csv_before_yesterday}  ${old_j}
                Log  s1_by_array ${s1_by_array}

                Log  ${s1_by_array}[2]

#                ${sensor_match}=   Get Regexp Matches  ${s1_by_array}[2]   ${restart_csv_string}

                log  ${restart_csv_string}

                IF  '${s1_by_array}[2]' == '${restart_csv_string}'

                    ${start_num}=  Evaluate  ${old_j}+1
                    log  ${old_j}
                    log  ${start_num}
                    Exit For Loop

                ELSE
                    CONTINUE For Loop
                END



            END

            
        END

        log  ${start_num}



#        ${CsvFileContent}    Get File    lvr_landcsv\\${ii}_lvr_land_a.csv    encoding=UTF-8-SIG    encoding_errors=strict
        ${CsvFileContent}    Get File    lvr_landcsv/${ii}_lvr_land_a.csv    encoding=UTF-8-SIG    encoding_errors=strict
#        ${CsvFileContent}    Get File    ${ii}_lvr_land_a.csv    encoding=UTF-8    encoding_errors=strict
#UTF-8-SIG

		@{list_csv_before_yesterday}=  Read Csv String To List  ${CsvFileContent}
#		@{list_csv_before_yesterday}=  read_csv_file_to_list  a_lvr_land_a.csv    
		${list_csv_by_cnt}=    Get length    ${list_csv_before_yesterday}

		FOR  ${j}  IN RANGE  ${start_num}  ${list_csv_by_cnt}  1

			${s1_by_array}=  get_from_list  ${list_csv_before_yesterday}  ${j}
		    Log  s1_by_array ${s1_by_array}

        	Log  ${s1_by_array}[1]

		${sensor_match}=   Get Regexp Matches  ${s1_by_array}[1]   房地
                Log  ${sensor_match}
                IF    "${sensor_match}" == "[]"
                    CONTINUE For Loop
                END

#           Log_To_Console   2 ${i}
#            Should Be True    ${sensor_data}[1] > ${inlet_rotor_minimum}
#                Should Be True    ${sensor_data}[1] < ${inlet_rotor_maximum}
        

        	Log  ${s1_by_array}[2]

	        post_postweb2_mapcomFrontEndlogin  https://www.map.com.tw


            ${s1_by_array_2_split}=    Split String    ${s1_by_array}[2]    號

            Log  ${s1_by_array_2_split}[0]
            Log  ${s1_by_array_2_split}[1]
            ${str_number}=  set variable  號

            ${s1_by_array_2_split_0}=  set variable  ${s1_by_array_2_split}[0]${str_number}

            Log  ${s1_by_array_2_split_0}

    	    Fill Text   xpath=//*[@id="searchWord"]   ${s1_by_array_2_split_0}
#    	    Fill Text   xpath=//*[@id="searchboxinput"]   ${s1_by_array}[2]

        	Browser.click  xpath=//*[@id="btnAddrSearch"]

#            take screenshot


    ${str_title1}=  Get_text    xpath=//*[@id="customMarkinfowindow"]/div/iframe >>> xpath=//*[@id="defaultInfo"]/table/tbody/tr[1]/td/table/tbody/tr[2]/td


    log  ${str_title1}

    ${str_title2}=  Get_text  //*[@id="customMarkinfowindow"]/div/iframe >>> //*[@id="location"]/table/tbody/tr[2]/td/div

    log  ${str_title2}














		IF  '${s1_by_array_2_split_0}' != '${str_title1}'


            Fill Text   xpath=//*[@id="searchWord"]   ${s1_by_array_2_split_0}

            Browser.click  xpath=//*[@id="btnAddrSearch"]

            take screenshot

            ${str_title1}=  Get_text    xpath=//*[@id="customMarkinfowindow"]/div/iframe >>> xpath=//*[@id="defaultInfo"]/table/tbody/tr[1]/td/table/tbody/tr[2]/td

            log  ${str_title1}

            ${str_title2}=  Get_text  //*[@id="customMarkinfowindow"]/div/iframe >>> //*[@id="location"]/table/tbody/tr[2]/td/div

            log  ${str_title2}

			    IF  '${s1_by_array_2_split_0}' != '${str_title1}'
                                    
                        FAIL

                END
		END


        ${file_split}=    Split String    ${str_title2}    \xa0\xa0\xa0

	    ${file_split_count}=    Get length    ${file_split}


#    	    FOR  ${i}  IN RANGE  0  ${file_split_count} 
#        FOR  ${i}  IN RANGE  1  10

        	    Log  ${file_split}[0]
            	${sensor_match}=    Get Regexp Matches    ${file_split}[0]    ：
	            IF    ${sensor_match}
    	            Log   ${file_split}[0]
        	        ${file_split2}=    Split String    ${file_split}[0]    ：
                    Log  ${file_split2}[0]
                    Log  ${file_split2}[1]
                END

                Log  ${file_split}[1]
                ${sensor_match}=    Get Regexp Matches    ${file_split}[1]    ：
                IF    ${sensor_match}
                    Log   ${file_split}[1]
                    ${file_split3}=    Split String    ${file_split}[1]    ：
                    Log  ${file_split3}[0]
                    Log  ${file_split3}[1]
                END

        	Log  ${s1_by_array}[14]
        	Log  ${s1_by_array}[15]
        	Log  ${s1_by_array}[16]

                ${pyeong_num}=  set variable  ${empty}
                ${float_pyeong_num}=  evaluate  round(${s1_by_array}[15]*0.3025, 2)
                ${pyeong_num}=  Convert To String  ${float_pyeong_num}


        	Log  ${s1_by_array}[21]
        	Log  ${s1_by_array}[22]
        	Log  ${s1_by_array}[23]

                ${UnitPrice_per_pyeong}=  set variable  ${empty}
                ${int_UnitPrice_per_pyeong}=  evaluate  round(${s1_by_array}[22]*3.305785)
                ${UnitPrice_per_pyeong}=  Convert To String  ${int_UnitPrice_per_pyeong}

	        append_to_list  ${s1_by_array}  ${file_split3}[1]  ${file_split2}[1]  ${pyeong_num}  ${UnitPrice_per_pyeong}
    	        log  ${s1_by_array}

#                ${csv_content}=  Get File  lvr_landcsv/${ii}_lvr_land_a_gps.csv
#                log  ${csv_content}


                ${file_exists}=  Run Keyword And Return Status  OperatingSystem.File_Should_Exist   lvr_landcsv/${ii}_lvr_land_a_gps.csv
 
                IF  '${file_exists}' == 'False'
                    Copy File  lvr_landcsv/a_lvr_land_a_header.csv  lvr_landcsv/${ii}_lvr_land_a_gps.csv
                END

            

            ${csv_string}=  set variable  ${empty}
            ${str_s1_by_array}=   Evaluate  ",".join(${s1_by_array})   

            ${csv_string}=  set variable  ${str_s1_by_array}\n
            log  ${csv_string}

            Append To File   lvr_landcsv/${ii}_lvr_land_a_gps.csv  ${csv_string}



#        	Append To Csv File  lvr_landcsv/${ii}_lvr_land_a_gps.csv  ${s1_by_array}


		END

        


#    END



















