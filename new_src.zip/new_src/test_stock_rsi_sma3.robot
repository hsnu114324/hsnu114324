*** Settings ***
Library  OperatingSystem
Library  ExcelLibrary
Library  String
Library  Collections
Library  CSVLibrary
Library  DateTime
Library  DatabaseLibrary
Resource  Common/common_stock.robot
Resource  Common/common_finmind.robot


*** Variables ***
@{stock_list}    @{EMPTY}


#*** Keywords ***
*** Test Cases ***
test_stock_rsi_sma3
#    [Arguments]     ${excel_file_name}  ${sheet_name}
    [Documentation]    Load sensor list file and prepare list
#    Log_To_Console   excel_file_name : ${excel_file_name}
#    Log_To_Console   sheet_name : ${sheet_name}



    Connect To Database Using Custom Params  sqlite3  database="./test.db"

    ${rsi_length}=      set_variable   6    
    ${rsi_length-1}=    evaluate       ${rsi_length} - 1    
    log   ${rsi_length-1}

    ${str_start_date}=  set_variable   2024-01-01
    ${str_end_date}=    set_variable   2024-04-01



    ${output}=    Query    SELECT DATE,stock_id,Trading_Volume,Trading_money,open,max,min,close,spread,Trading_turnover FROM daily_stock WHERE stock_id = '2330' AND DATE between '${str_start_date}' and '${str_end_date}' order by DATE ;
    Log  ${output}







            ${sum_U}=     set variable  0
            ${count_U}=   set variable  0
            ${sum_D}=     set variable  0
            ${count_D}=   set variable  0

            ${close}=     set variable  7
            ${spread}=    set variable  8
            ${pointer}=   set variable  0
            ${rsi_data}=  Create List  


	    
            ${date_length}=  get length  ${output}

            FOR  ${i}  IN RANGE  ${date_length}

    ${today_date}=  set variable  ${output}[${i}][0]     
    ${today_stock_id}=  set variable  ${output}[${i}][1]     
    ${today_trading_volume}=  set variable  ${output}[${i}][2]     
    ${today_trading_money}=  set variable  ${output}[${i}][3]     
    ${today_open}=  set variable  ${output}[${i}][4]     
    ${today_high}=  set variable  ${output}[${i}][5]     
    ${today_low}=  set variable  ${output}[${i}][6]     
    ${today_close}=  set variable  ${output}[${i}][7]     
    ${today_spread}=  set variable  ${output}[${i}][8]     
    ${today_trading_turnover}=  set variable  ${output}[${i}][9]  


    ${yesterday_spread}=  set variable  0

                IF  ${rsi_length} > ${i}
                    Append To List  ${rsi_data}  ${today_spread}
                    
                    IF  ${output}[${i}][${spread}] > 0
		        ${sum_U}=    evaluate  ${sum_U} + ${today_spread}
                        ${count_U}=  evaluate  ${count_U} + 1 
		    ELSE IF  ${output}[${i}][${spread}] < 0
		        ${sum_D}=    evaluate  ${sum_D} + ${today_spread}
                        ${count_D}=  evaluate  ${count_D} + 1 
		    END

                    ${rsi}=  set variable  0

#                    CONTINUE FOR LOOP

                ELSE IF  ${rsi_length} == ${i}

                    IF  ${count_U} != 0    
                        log  ${sum_U}/${count_U}
                        ${sma_U}=  evaluate  ${sum_U}/${count_U}
                    ELSE
                        ${sma_U}=  set variable  0
                    END
    
                    IF  ${count_D} != 0
                        log  ${sum_D}/${count_D}
                        ${sma_D}=  evaluate  ${sum_D}/${count_D}
                    ELSE
                        ${sma_D}=  set variable  0
                    END

                
                    log  ${sma_U}/(${sma_U} - ${sma_D})
                    ${rsi}=  evaluate  ( ${sma_U}/(${sma_U} - ${sma_D}) ) * 100




#                    CONTINUE FOR LOOP
                ELSE

#                    log  ${rsi_data}
#                    ${old_i}=  evaluate  ${i} - ${rsi_length}
#                    ${old_rsi_i_data}=  set variable  ${rsi_data}[${pointer}]
#                    ${rsi_data}[${pointer}]=  set variable  ${output}[${i}][${spread}]


#                    IF  ${output}[${old_i}][${spread}] > 0
#		        ${sum_U}=    evaluate  ${sum_U} - ${old_rsi_i_data}
#                        ${count_U}=  evaluate  ${count_U} - 1 
#                    ELSE IF  ${output}[${old_i}][${spread}] < 0
#		        ${sum_D}=    evaluate  ${sum_D} - ${old_rsi_i_data}
#                        ${count_D}=  evaluate  ${count_D} - 1 
#                    END

                    IF  ${output}[${i}][${spread}] > 0

                        ${sma_U}=  evaluate  ( ${sma_U}*${rsi_length-1} + ${today_spread} ) / ${rsi_length}
                        ${sma_D}=  evaluate  ( ${sma_D}*${rsi_length-1} + 0 ) / ${rsi_length}

#		        ${sum_U}=    evaluate  ${sum_U} + ${rsi_data}[${pointer}]
#                        ${count_U}=  evaluate  ${count_U} + 1 
                    ELSE IF  ${output}[${i}][${spread}] < 0


                        ${sma_U}=  evaluate  ( ${sma_U}*${rsi_length-1} + 0 ) / ${rsi_length}
                        ${sma_D}=  evaluate  ( ${sma_D}*${rsi_length-1} + ${today_spread} ) / ${rsi_length}

#		        ${sum_D}=    evaluate  ${sum_D} + ${rsi_data}[${pointer}]
#                        ${count_D}=  evaluate  ${count_D} + 1 
                    END

                    log  ${sma_U}/(${sma_U} - ${sma_D})
                    ${rsi}=  evaluate  ( ${sma_U}/(${sma_U} - ${sma_D}) ) * 100
                    
#                    log  ${pointer}
#                    IF  ${pointer} >= ${rsi_length-1}
#                        ${pointer}=  set variable  0
#                    ELSE
#                        ${pointer}=  evaluate  ${pointer}+1
#                    END
                END


   






#                IF  ${count_U} != 0    
#                    log  ${sum_U}/${count_U}
#                    ${sma_U}=  evaluate  ${sum_U}/${count_U}
#                ELSE
#                    ${sma_U}=  set variable  0
#                END

#                IF  ${count_D} != 0
#                    log  ${sum_D}/${count_D}
#                    ${sma_D}=  evaluate  ${sum_D}/${count_D}
#                ELSE
#                    ${sma_D}=  set variable  0
#                END

                
#                    log  ${sma_U}/(${sma_U} - ${sma_D})
#                    ${rsi}=  evaluate  ( ${sma_U}/(${sma_U} - ${sma_D}) ) * 100










                ${file_exists}=  Run Keyword And Return Status  OperatingSystem.File_Should_Exist   stock_csv_new_kd_rsv/${today_stock_id}_rsi_${today_date}[0:4].csv

                IF  '${file_exists}' == 'False'
                    Copy File  lvr_landcsv/a_lvr_land_a_header.csv  stock_csv_new_kd_rsv/${today_stock_id}_rsi_${today_date}[0:4].csv
                    Append To File   stock_csv_new_kd_rsv/${today_stock_id}_rsi_${today_date}[0:4].csv   日期,股票代碼,成交量,成交金額,開盤價,最高價,最低價,收盤價,漲跌幅,交易筆數,rsi\n
                END




#                ${high_low_value}=   set variable  ${today_date},${today_stock_id},${today},${list_i_j-1_3},${list_i_j-1_4},${list_i_j-1_5},${list_i_j-1_6},${list_i_j-1_7},${list_i_j-1_8},${list_i_j-1_9},${highest9}[${j}],${lowest9}[${j}],${rsv9}[${j}],${today_k},${today_d}
                ${high_low_value}=   set variable  ${today_date},${today_stock_id},${today_trading_volume},${today_trading_money},${today_open},${today_high},${today_low},${today_close},${today_spread},${today_trading_turnover},${rsi}
                log  ${high_low_value}

                ${high_low_by_array}=  set variable  ${high_low_value}

                log  ${high_low_by_array}


                ${csv_string}=  set variable  ${high_low_by_array}\n
                log  ${csv_string}

                Append To File   stock_csv_new_kd_rsv/${today_stock_id}_rsi_${today_date}[0:4].csv   ${csv_string}




                ${table_name}=  set variable  daily_stock_rsi
                ${name_1}=      set variable  date
                ${type_1}=      set variable  DATE
                ${name_2}=      set variable  stock_id
                ${type_2}=      set variable  varchar(100)

                ${name_3}=      set variable  rsi
                ${type_3}=      set variable  FLOAT

                ${name_4}=      set variable  buyin
                ${type_4}=      set variable  INT
            
                IF  ${rsi} < 30
                    ${buyin}=  set variable  1 
                ELSE IF  ${rsi} > 70  
                    ${buyin}=  set variable  -1
	        ELSE
                    ${buyin}=  set variable  0		    
                END


                ${output_sql}=    Execute Sql String    INSERT INTO ${table_name} VALUES ( '${today_date}', '${today_stock_id}', ${rsi}, ${buyin} )

                log  ${output_sql}




  END



















