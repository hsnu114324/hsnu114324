*** Keywords ***
test_stock_KBar

    [Arguments]     ${start_date}      ${end_date}   
    Log   ${start_date}
    Log   ${end_date}
    Log_To_Console  start_date : ${start_date}
    Log_To_Console  end_date : ${end_date}


#    ${start_date}=    Set Variable    20190103
#    ${end_date}    Set Variable    20190315



#    ${str_max_num}=    Convert_To_String    ${max_num}


    ${folder}=    set variable    KBar    # 更換成目標資料>夾的路徑


    ${max_file}    Set Variable    none
    ${max_num}    Set Variable    0
    ${files}    OperatingSystem.List_Files_In_Directory    ${folder}    *.csv



    FOR    ${file}    IN    @{files}
        ${file_split_pre}=    Split String    ${file}    .
        Log_To_Console  ${file_split_pre}[0]
        ${file_split}=    Split String    ${file_split_pre}[0]    _
        Log_To_Console  ${file_split}[1]
        ${file_num}=  Convert_Date  ${file_split}[1]    result_format=%Y%m%d    date_format=%Y-%m-%d
        ${num}    Evaluate    ${file_num}
        IF    ${num} > ${max_num}
            ${max_file}    Set Variable    ${file}
            ${max_num}    Set Variable    ${num}
        END
    END
    Log_To_Console    Max CSV file: ${max_file}
    Log    Max CSV file: ${max_file}
    Log_To_Console    Max num: ${max_num}
    ${int_max_num}=    Convert_To_Integer    ${max_num}
    ${str_max_num}=    Convert_To_String    ${max_num}
    Log_To_Console    int Max num: ${int_max_num}
    Log_To_Console    str Max num: ${str_max_num}















  ${date_range}=  finmind_GetDateRange  ${str_max_num}  ${end_date}

#   log  ${date_range}

  ${current_time}=   set variable  0
  

  FOR  ${date}  IN  @{date_range}


      ${past_time}=     set variable  ${current_time}
      ${current_time}=  Get Current Date  result_format=%Y%m%d%H%M
      ${spend_time}=  evaluate  ${current_time} - ${past_time}
      IF  ${spend_time} > 40
          ${sleep_enable}=  set variable  0
      ELSE
          ${sleep_enable}=  set variable  1
      END


    log_to_console  9962_${date}

    ${file_exists}=  Run Keyword And Return Status  OperatingSystem.File_Should_Exist   KBar/9962_${date}.csv

                IF  '${file_exists}' == 'True'
                    CONTINUE FOR LOOP
                END


    &{params_data}=    Create dictionary  dataset=TaiwanStockKBar  data_id=9962  start_date=${date}  token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRlIjoiMjAyNC0wMy0xNCAxOTozMjoyOSIsInVzZXJfaWQiOiJoc251MTE0MzI0IiwiaXAiOiIyMjMuMTQwLjE1My40OSJ9.s4YB40C3oeXvVirm6aciA4gG1KLUO12Yw9JuIk6GYek

    Delete All Sessions

    create session  api  https://api.finmindtrade.com
    ${resp}=  get request  api  /api/v4/data  params=${params_data}
    ${resp_json_data}=  set variable  ${resp.json()["data"]}

#    log  ${resp_json_data}

    ${empty_data}  Create list  

    IF  ${resp_json_data} == ${empty_data}
        log  empty
        CONTINUE　FOR LOOP
    END





        ${old1_csv_content}=    Get File    台股總覽.csv    encoding=UTF-8-SIG    encoding_errors=strict
        @{list_1}=  Read Csv String To List  ${old1_csv_content}

            ${length}=  Get length  ${list_1}
            ${length+1}=  evaluate  ${length} + 1

            FOR  ${j}  IN RANGE  1  ${length+1}  1 

                 ${list_1_j}=  set variable  ${list_1}[${j}]
                 ${stock_id}=  set variable  ${list_1_j}[1]
                 log  ${list_1_j}
                 log  ${stock_id}

                 IF  "${stock_id}" == "Automobile"
                     BREAK
                 END


    log_to_console  ${stock_id}_${date}

    ${file_exists}=  Run Keyword And Return Status  OperatingSystem.File_Should_Exist   KBar/${stock_id}_${date}.csv

                IF  '${file_exists}' == 'True'
                    CONTINUE FOR LOOP
                END






    IF  ${sleep_enable} == 1
        sleep  300ms
    ELSE
        sleep  200ms
    END

    &{params_data}=    Create dictionary  dataset=TaiwanStockKBar  data_id=${stock_id}  start_date=${date}  token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRlIjoiMjAyNC0wMy0xNCAxOTozMjoyOSIsInVzZXJfaWQiOiJoc251MTE0MzI0IiwiaXAiOiIyMjMuMTQwLjE1My40OSJ9.s4YB40C3oeXvVirm6aciA4gG1KLUO12Yw9JuIk6GYek


    create session  api  https://api.finmindtrade.com
    ${resp}=  get request  api  /api/v4/data  params=${params_data}
#    ${resp}=   Get   https://api.finmindtrade.com/api/v4/data  params=${params_data}   
    ${resp_json_data}=  set variable  ${resp.json()["data"]}
#    Dump Json To File  output.json  ${resp_json_data}


#   ${rc}    ${output}    Run And Return Rc And Output    python C:/Users/714838/Downloads/new_src/output.json 


#    Log_To_Console  output : ${output}

#    Append To Csv String  ${resp_json_data}


#   ${dict_resp}=   Get From Dictionary  ${resp_json_data}[0]   minute
#   ${list_resp}=    Get From List        ${resp_json_data}  0

#   log  ${dict_resp}
#   log  ${list_resp}


           ${length}=  Get length  ${resp_json_data} 
        
            log  ${length}
        
            FOR  ${resp_i}  IN RANGE  0  ${length}  1
        
                 ${resp_i_list}=  set variable  ${resp_json_data}[${resp_i}]
                 ${resp_i_list_length}=  Get length  ${resp_i_list}
        #         FOR  ${resp_j}  IN RANGE  0  ${resp_i_list_length}  1
        
#                 ${open_resp_i}=   Get From Dictionary  ${resp_json_data}[${resp_i}]  open
#                 ${str_open_resp_i}=    Convert_To_String    ${open_resp_i}
#                
#                 ${split_open_resp_i}=  split String  ${str_open_resp_i}  .
#                 ${split_open_resp_i_length}=  Get length  ${split_open_resp_i}
#                 log  ${split_open_resp_i_length}
#                 IF  ${split_open_resp_i_length} == 2
#                     ${str_split_open_resp_i_1}=    Convert_To_String    ${split_open_resp_i}[1]
#                     IF  '${str_split_open_resp_i_1}' == '0'
#                         Set To Dictionary  ${resp_json_data}[${resp_i}]  open=${split_open_resp_i}[0]
#                     END
#                 END
# 
#
#        
#                 ${high_resp_i}=   Get From Dictionary  ${resp_json_data}[${resp_i}]  high
#                 ${str_high_resp_i}=    Convert_To_String    ${high_resp_i}
#                
#                 ${split_high_resp_i}=  split String  ${str_high_resp_i}  .
#                 ${split_high_resp_i_length}=  Get length  ${split_high_resp_i}
#                 log  ${split_high_resp_i_length}
#                 IF  ${split_high_resp_i_length} == 2
#                     ${str_split_high_resp_i_1}=    Convert_To_String    ${split_high_resp_i}[1]
#                     IF  '${str_split_high_resp_i_1}' == '0'
#                         Set To Dictionary  ${resp_json_data}[${resp_i}]  high=${split_high_resp_i}[0]
#                     END
#                 END
#        
#        
#                 ${low_resp_i}=   Get From Dictionary  ${resp_json_data}[${resp_i}]  low
#                 ${str_low_resp_i}=    Convert_To_String    ${low_resp_i}
#                
#                 ${split_low_resp_i}=  split String  ${str_low_resp_i}  .
#                 ${split_low_resp_i_length}=  Get length  ${split_low_resp_i}
#                 log  ${split_low_resp_i_length}
#                 IF  ${split_low_resp_i_length} == 2
#                     ${str_split_low_resp_i_1}=    Convert_To_String    ${split_low_resp_i}[1]
#                     IF  '${str_split_low_resp_i_1}' == '0'
#                         Set To Dictionary  ${resp_json_data}[${resp_i}]  low=${split_low_resp_i}[0]
#                     END
#                 END
# 
#       
#
#
# 
#                 ${close_resp_i}=   Get From Dictionary  ${resp_json_data}[${resp_i}]  close
#                 ${str_close_resp_i}=    Convert_To_String    ${close_resp_i}
#                
#                 ${split_close_resp_i}=  split String  ${str_close_resp_i}  .
#                 ${split_close_resp_i_length}=  Get length  ${split_close_resp_i}
#                 log  ${split_close_resp_i_length}
#                 IF  ${split_close_resp_i_length} == 2
#                     ${str_split_close_resp_i_1}=    Convert_To_String    ${split_close_resp_i}[1]
#                     IF  '${str_split_close_resp_i_1}' == '0'
#                         Set To Dictionary  ${resp_json_data}[${resp_i}]  close=${split_close_resp_i}[0]
#                     END
#                 END
# 







#    ${type string}=    Evaluate     type(${resp_json_data})
#    Log To Console     ${type string}

#    ${type string}=    Evaluate     type(${resp_i_list})
#    Log To Console     ${type string}

#    ${list_xd}=    Convert To List    ${resp_i_list}
#    ${str_xd}=     Convert To String  ${resp_i_list}

#    log  ${list_xd}
#    log  ${str_xd}


         END


#    log  ${resp_json_data}

    ${empty_data}  Create list  

    IF  ${resp_json_data} == ${empty_data}
        log  empty
        CONTINUE　FOR LOOP
    END


    ${file_exists}=  Run Keyword And Return Status  OperatingSystem.File_Should_Exist   KBar/${stock_id}_${date}.csv

                IF  '${file_exists}' == 'False'
                    Copy File  csv.csv  KBar/${stock_id}_${date}.csv
                ELSE
                    CONTINUE FOR LOOP

                END

    Append To Csv File    KBar/${stock_id}_${date}.csv  ${resp_json_data}

            END
  END









