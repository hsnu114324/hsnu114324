*** Keywords ***
pnstestmail_postweb2_setVerA
#    [Arguments] 	${excel_file_data}
	[Documentation]
	[Tags]
#***

#    Log  ${excel_file_data}
#***
	post_postweb2_pnsFrontEndlogin  https://pnstest.post.gov.tw/LI.Web/Quest.aspx?q_sid=08FE0PujSqB
#***
#	post_postweb2_ClickPnsFrontEndLoginUsername  0963038476
#***
#	post_postweb2_ClickPnsFrontEndLoginPassword  Jy99jy88
#***
#	Sleep  10s
#	post_postweb2_ClickPnsFrontEndLoginEnter
	post_postweb2_ClickPnstestmailFrontEndLoginEnter
#	Sleep  5s
#***

	post_postweb2_ClickPnsFrontEndQ2_VerA
	post_postweb2_ClickPnsFrontEndQ3_VerA
	post_postweb2_ClickPnsFrontEndQ4_VerA
	post_postweb2_ClickPnsFrontEndQ5_VerA
	post_postweb2_ClickPnsFrontEndQ6_VerA
	post_postweb2_ClickPnsFrontEndQ7_VerA
	post_postweb2_ClickPnsFrontEndQ8_1_VerA
	post_postweb2_ClickPnsFrontEndQ8_2_VerA
	post_postweb2_ClickPnsFrontEndQ8_3_VerA
	post_postweb2_ClickPnsFrontEndQ9_VerA
	post_postweb2_ClickPnsFrontEnd_cbTreatyConfirm
	post_postweb2_ClickPnsFrontEnd_Submit
	Sleep  1s


#	post_postweb2_ClickPnsFrontEndMenuList2
#***
#	post_postweb2_ClickPnsFrontEndMenuList2Button1
#***  
#	post_postweb2_ClickPnsFrontEndbtnQuery

#    ${CR_no}=  post_postweb2_FetchPnsFrontEndlbtnReqNo_0

#	post_postweb2_ClickPnsFrontEndlbtnReqNo_0
#	post_postweb2_ClickPnsFrontEndCancelbtnSave
#***

#	[Return]  ${CR_no}