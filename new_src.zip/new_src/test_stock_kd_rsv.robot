*** Settings ***
Library  OperatingSystem
Library  ExcelLibrary
Library  String
Library  Collections
Library  CSVLibrary
Library  DateTime
Resource  Common/common_stock.robot
Resource  Common/common_finmind.robot


*** Variables ***
@{stock_list}    @{EMPTY}


#*** Keywords ***
*** Test Cases ***
test_stock_kd_rsv
#    [Arguments]     ${excel_file_name}  ${sheet_name}
    [Documentation]    Load sensor list file and prepare list
#    Log_To_Console   excel_file_name : ${excel_file_name}
#    Log_To_Console   sheet_name : ${sheet_name}

 
    ${files}    OperatingSystem.List_Files_In_Directory    stock_csv_new_2023    *.csv
   
    FOR    ${file}    IN    @{files}



        ${file0_split}=    Split String    ${file}    .
        Log_To_Console  ${file0_split}[0]
        ${file1_split}=    Split String    ${file0_split}[0]    _
        Log_To_Console  ${file1_split}[0]

        ${old1_csv_content}=    Get File    stock_csv_new_2023/${file1_split}[0]_2023.csv    encoding=UTF-8-SIG    encoding_errors=strict
        @{list_pre_1}=  Read Csv String To List  ${old1_csv_content}


        ${old0_csv_content}=    Get File    stock_csv_new_2022/${file1_split}[0]_2022.csv    encoding=UTF-8-SIG    encoding_errors=strict
        @{list_pre_0}=  Read Csv String To List  ${old0_csv_content}






        @{list_1}=  Read Csv String To List  ${old1_csv_content} 

        @{list_0}=  Read Csv String To List  ${old0_csv_content} 



            ${csv_string}=  set variable  ${empty}
            ${high_low_by_array}=  set variable  ${empty}

            ${yesterday_k}=  set variable  0
            ${yesterday_d}=  set variable  0
            ${today_k}=  set variable  0
            ${today_d}=  set variable  0

            ${length}=  Get length  ${list_1}
            ${length+1}=  evaluate  ${length} + 1

            ${highest9}=  Create List  ${EMPTY}
            ${lowest9}=  Create List  ${EMPTY}
            ${rsv9}=  Create List  ${EMPTY}

            FOR  ${j}  IN RANGE  1  ${length+1}  1 
                log list  ${highest9}
                ${length_highest9}=  Get length  ${highest9}
                IF  ${length_highest9} == 0
                    Append To List  ${highest9}  0 
                END
                Append To List  ${highest9}  0 

                log list  ${lowest9}
                ${length_lowest9}=  Get length  ${lowest9}
                IF  ${length_lowest9} == 0
                    Append To List  ${lowest9}  999999999 
                END
                Append To List  ${lowest9}  999999999

                log list  ${rsv9}
                ${length_rsv9}=  Get length  ${rsv9}
                IF  ${length_rsv9} == 0
                    Append To List  ${rsv9}  0 
                END
                Append To List  ${rsv9}  0 



                    
                    ${j-9}=  evaluate  ${j} - 9
                    IF  ${j-9} < 0
                        ${list_0_j-9}=  set variable  ${list_0}[${j-9}]
                        ${list_i_j-9_5}=  set variable  ${list_0_j-9}[5]
                        ${list_i_j-9_6}=  set variable  ${list_0_j-9}[6]
                    ELSE
                        ${list_1_j-9}=  set variable  ${list_1}[${j-9}]
                        ${list_i_j-9_5}=  set variable  ${list_1_j-9}[5]
                        ${list_i_j-9_6}=  set variable  ${list_1_j-9}[6]
                    END
                    
                    ${j-8}=  evaluate  ${j} - 8
                    IF  ${j-8} < 0
                        ${list_0_j-8}=  set variable  ${list_0}[${j-8}]
                        ${list_i_j-8_5}=  set variable  ${list_0_j-8}[5]
                        ${list_i_j-8_6}=  set variable  ${list_0_j-8}[6]
                    ELSE
                        ${list_1_j-8}=  set variable  ${list_1}[${j-8}]
                        ${list_i_j-8_5}=  set variable  ${list_1_j-8}[5]
                        ${list_i_j-8_6}=  set variable  ${list_1_j-8}[6]
                    END
                    
                    ${j-7}=  evaluate  ${j} - 7
                    IF  ${j-7} < 0
                        ${list_0_j-7}=  set variable  ${list_0}[${j-7}]
                        ${list_i_j-7_5}=  set variable  ${list_0_j-7}[5]
                        ${list_i_j-7_6}=  set variable  ${list_0_j-7}[6]
                    ELSE
                        ${list_1_j-7}=  set variable  ${list_1}[${j-7}]
                        ${list_i_j-7_5}=  set variable  ${list_1_j-7}[5]
                        ${list_i_j-7_6}=  set variable  ${list_1_j-7}[6]
                    END
                    
                    ${j-6}=  evaluate  ${j} - 6
                    IF  ${j-6} < 0
                        ${list_0_j-6}=  set variable  ${list_0}[${j-6}]
                        ${list_i_j-6_5}=  set variable  ${list_0_j-6}[5]
                        ${list_i_j-6_6}=  set variable  ${list_0_j-6}[6]
                    ELSE
                        ${list_1_j-6}=  set variable  ${list_1}[${j-6}]
                        ${list_i_j-6_5}=  set variable  ${list_1_j-6}[5]
                        ${list_i_j-6_6}=  set variable  ${list_1_j-6}[6]
                    END
                    
                    ${j-5}=  evaluate  ${j} - 5
                    IF  ${j-5} < 0
                        ${list_0_j-5}=  set variable  ${list_0}[${j-5}]
                        ${list_i_j-5_5}=  set variable  ${list_0_j-5}[5]
                        ${list_i_j-5_6}=  set variable  ${list_0_j-5}[6]
                    ELSE
                        ${list_1_j-5}=  set variable  ${list_1}[${j-5}]
                        ${list_i_j-5_5}=  set variable  ${list_1_j-5}[5]
                        ${list_i_j-5_6}=  set variable  ${list_1_j-5}[6]
                    END
                    
                    ${j-4}=  evaluate  ${j} - 4
                    IF  ${j-4} < 0
                        ${list_0_j-4}=  set variable  ${list_0}[${j-4}]
                        ${list_i_j-4_5}=  set variable  ${list_0_j-4}[5]
                        ${list_i_j-4_6}=  set variable  ${list_0_j-4}[6]
                    ELSE
                        ${list_1_j-4}=  set variable  ${list_1}[${j-4}]
                        ${list_i_j-4_5}=  set variable  ${list_1_j-4}[5]
                        ${list_i_j-4_6}=  set variable  ${list_1_j-4}[6]
                    END
                    
                    ${j-3}=  evaluate  ${j} - 3
                    IF  ${j-3} < 0
                        ${list_0_j-3}=  set variable  ${list_0}[${j-3}]
                        ${list_i_j-3_5}=  set variable  ${list_0_j-3}[5]
                        ${list_i_j-3_6}=  set variable  ${list_0_j-3}[6]
                    ELSE
                        ${list_1_j-3}=  set variable  ${list_1}[${j-3}]
                        ${list_i_j-3_5}=  set variable  ${list_1_j-3}[5]
                        ${list_i_j-3_6}=  set variable  ${list_1_j-3}[6]
                    END
                    
                    ${j-2}=  evaluate  ${j} - 2
                    IF  ${j-2} < 0
                        ${list_0_j-2}=  set variable  ${list_0}[${j-2}]
                        ${list_i_j-2_5}=  set variable  ${list_0_j-2}[5]
                        ${list_i_j-2_6}=  set variable  ${list_0_j-2}[6]
                    ELSE
                        ${list_1_j-2}=  set variable  ${list_1}[${j-2}]
                        ${list_i_j-2_5}=  set variable  ${list_1_j-2}[5]
                        ${list_i_j-2_6}=  set variable  ${list_1_j-2}[6]
                    END
                    
                    ${j-1}=  evaluate  ${j} - 1
                    IF  ${j-1} < 0
                        ${list_0_j-1}=  set variable  ${list_0}[${j-1}]
                        ${list_i_j-1_5}=  set variable  ${list_0_j-1}[5]
                        ${list_i_j-1_6}=  set variable  ${list_0_j-1}[6]
                    ELSE
                        ${list_1_j-1}=  set variable  ${list_1}[${j-1}]
                        ${list_i_j-1_5}=  set variable  ${list_1_j-1}[5]
                        ${list_i_j-1_6}=  set variable  ${list_1_j-1}[6]
                    END
                    
#                    ${j-0}=  evaluate  ${j} - 0
#                    IF  ${j-0} < 0
#                        ${list_0_j-0}=  set variable  ${list_0}[${j-0}]
#                        ${list_i_j-0_5}=  set variable  ${list_0_j-0}[5]
#                        ${list_i_j-0_6}=  set variable  ${list_0_j-0}[6]
#                    ELSE
#                        ${list_1_j-0}=  set variable  ${list_1}[${j-0}]
#                        ${list_i_j-0_5}=  set variable  ${list_1_j-0}[5]
#                        ${list_i_j-0_6}=  set variable  ${list_1_j-0}[6]
#                    END

 
                    log  ${list_i_j-9_5}, ${list_i_j-8_5}, ${list_i_j-7_5}, ${list_i_j-6_5}, ${list_i_j-5_5}, ${list_i_j-4_5}, ${list_i_j-3_5}, ${list_i_j-2_5}, ${list_i_j-1_5}

                    ${highest9}[${j}]=  evaluate  max(${list_i_j-9_5}, ${list_i_j-8_5}, ${list_i_j-7_5}, ${list_i_j-6_5}, ${list_i_j-5_5}, ${list_i_j-4_5}, ${list_i_j-3_5}, ${list_i_j-2_5}, ${list_i_j-1_5})

                    log  ${list_i_j-9_6}, ${list_i_j-8_6}, ${list_i_j-7_6}, ${list_i_j-6_6}, ${list_i_j-5_6}, ${list_i_j-4_6}, ${list_i_j-3_6}, ${list_i_j-2_6}, ${list_i_j-1_6}

                    ${lowest9}[${j}]=  evaluate  min(${list_i_j-9_6}, ${list_i_j-8_6}, ${list_i_j-7_6}, ${list_i_j-6_6}, ${list_i_j-5_6}, ${list_i_j-4_6}, ${list_i_j-3_6}, ${list_i_j-2_6}, ${list_i_j-1_6})

                    log  ( (${list_1_j-1}[7] - ${lowest9}[${j}] ) / ( ${highest9}[${j}] - ${lowest9}[${j}]) ) * 100  #RSV= (今日收盤價–最近n天最低價) ÷ (最近n天的最高價–最近n天最低價) × 100



                    ${rsv9}[${j}]=  evaluate  ( (${list_1_j-1}[7] - ${lowest9}[${j}] ) / ( ${highest9}[${j}] - ${lowest9}[${j}]) ) * 100

                    
                    ${today_k}=  evaluate  ${yesterday_k}*(2/3) + ${rsv9}[${j}]*(1/3)
                    ${today_d}=  evaluate  ${yesterday_d}*(2/3) + ${today_k}*(1/3)














                ${list_i_j-1_0}=  set variable  ${list_1_j-1}[0]
                ${list_i_j-1_1}=  set variable  ${list_1_j-1}[1]
                ${list_i_j-1_2}=  set variable  ${list_1_j-1}[2]
                ${list_i_j-1_3}=  set variable  ${list_1_j-1}[3]
                ${list_i_j-1_4}=  set variable  ${list_1_j-1}[4]
                ${list_i_j-1_5}=  set variable  ${list_1_j-1}[5]
                ${list_i_j-1_6}=  set variable  ${list_1_j-1}[6]
                ${list_i_j-1_7}=  set variable  ${list_1_j-1}[7]
                ${list_i_j-1_8}=  set variable  ${list_1_j-1}[8]
                ${list_i_j-1_9}=  set variable  ${list_1_j-1}[9]









                ${file_exists}=  Run Keyword And Return Status  OperatingSystem.File_Should_Exist   stock_csv_new_kd_rsv/${file1_split}[0]_rsv_${file1_split}[1].csv

                IF  '${file_exists}' == 'False'
                    Copy File  lvr_landcsv/a_lvr_land_a_header.csv  stock_csv_new_kd_rsv/${file1_split}[0]_rsv_${file1_split}[1].csv
                    Append To File   stock_csv_new_kd_rsv/${file1_split}[0]_rsv_${file1_split}[1].csv   日期,股票代碼,成交量,成交金額,開盤價,最高價,最低價,收盤價,漲跌幅,交易筆數,最近9天的最高價,最近9天的最低價,RSV,今日K值,今日D值
                END




                ${high_low_value}=   set variable  ${list_i_j-1_0},${list_i_j-1_1},${list_i_j-1_2},${list_i_j-1_3},${list_i_j-1_4},${list_i_j-1_5},${list_i_j-1_6},${list_i_j-1_7},${list_i_j-1_8},${list_i_j-1_9},${highest9}[${j}],${lowest9}[${j}],${rsv9}[${j}],${today_k},${today_d}
                log  ${high_low_value}

                ${high_low_by_array}=  set variable  ${high_low_value}

                log  ${high_low_by_array}


                ${csv_string}=  set variable  ${high_low_by_array}\n
                log  ${csv_string}

                Append To File   stock_csv_new_kd_rsv/${file1_split}[0]_rsv_${file1_split}[1].csv   ${csv_string}

                ${yesterday_k}=  set variable  ${today_k}
                ${yesterday_d}=  set variable  ${today_d}


            END


    END

    Log_To_Console    Max CSV file: ${max_file}
    Log    Max CSV file: ${max_file}
    Log_To_Console    Max num: ${max_num}
    ${int_max_num}=    Convert_To_Integer    ${max_num}
    ${str_max_num}=    Convert_To_String    ${max_num}
    Log_To_Console    int Max num: ${int_max_num}
    Log_To_Console    str Max num: ${str_max_num}























