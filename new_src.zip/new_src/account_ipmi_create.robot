*** Keywords ***
account_ipmi_create
	[Documentation]
	[Tags]

	wistron_bmcweb_account_remove

###

   FOR  ${user_id}  IN RANGE  3  11
	Log_To_Console   user_id ${user_id}

	wistron_ipmi_SetUserName  ${user_id}

	wistron_ipmi_SetUserPassword  ${user_id}

	wistron_ipmi_SetChannelAccess  ${user_id}

	wistron_ipmi_EnableUser  ${user_id}

	wistron_bmcweb_CheckLoginWebUI  ${user_id}

	wistron_ipmi_GetAdminPrivilege  ${user_id}

	wistron_ipmi_GetOperatorPrivilege  ${user_id}

	wistron_ipmi_GetUserPrivilege  ${user_id}

   END

   wistron_bmcweb_logout



