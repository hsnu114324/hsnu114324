*** Variables ***
${board_type_interposer}  interposer
${Re-timer_number}    0

*** Keywords ***
interposer_ipmi_update_interposer


	wistron_ipmi_updateinterposer  ${board_type_interposer}  ${Re-timer_number}  UT20_G5_RETIMER_011300_enc.hpm 
	wistron_ipmi_ExpectInterposerVersion  ${board_type_interposer}  ${Re-timer_number}  0d
	wistron_ipmi_updateinterposer  ${board_type_interposer}  ${Re-timer_number}  UT20_G5_RETIMER_012200_enc.hpm 
	wistron_ipmi_ExpectInterposerVersion  ${board_type_interposer}  ${Re-timer_number}  16
