*** Keywords ***
pns_postweb_verify2
	[Documentation]
	[Tags]
#***


	post_postweb_pnsBackEndlogin  https://pnstest.post.gov.tw/LI.adm/Login.aspx
#***
	post_postweb_ClickPnsBackEndLoginUsername  174646
#	#165406
#***
	post_postweb_ClickPnsBackEndLoginEnter
	Sleep  1s  
#***
	post_postweb_ClickPnsBackEndtvFunctiont1
#***
	post_postweb_ClickPnsBackEndtvFunctiont3
#***
	post_postweb_ClickPnsBackEndContent1_btnQuery
#***
	post_postweb_ClickPnsBackEndContent1_gvList_LinkButton_0
#***
        post_postweb_ClickPnsBackEndContent1_fvw3_ResultStateSuccess
#***
        post_postweb_ClickPnsBackEndContent1_btnFvw2Save
#***


