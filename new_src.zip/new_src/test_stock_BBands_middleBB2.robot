*** Settings ***
Library  OperatingSystem
Library  ExcelLibrary
Library  String
Library  Collections
Library  CSVLibrary
Library  DateTime
Library  DatabaseLibrary
Resource  Common/common_stock.robot
Resource  Common/common_finmind.robot


*** Variables ***
@{stock_list}    @{EMPTY}


#*** Keywords ***
*** Test Cases ***
test_stock_BBands_middleBB2
#    [Arguments]     ${excel_file_name}  ${sheet_name}
    [Documentation]    Load sensor list file and prepare list
#    Log_To_Console   excel_file_name : ${excel_file_name}
#    Log_To_Console   sheet_name : ${sheet_name}



    Connect To Database Using Custom Params  sqlite3  database="./test.db"

    ${bb_length}=      set_variable   20    
    ${bb_length-1}=    evaluate       ${bb_length} - 1    
    log   ${bb_length-1}

    ${str_start_date}=  set_variable   2024-01-01
    ${str_end_date}=    set_variable   2024-04-01



    ${output}=    Query    SELECT DATE,stock_id,Trading_Volume,Trading_money,open,max,min,close,spread,Trading_turnover FROM daily_stock WHERE stock_id = '2330' AND DATE between '${str_start_date}' and '${str_end_date}' order by DATE ;
    Log  ${output}







#            ${sum_U}=  set variable  0
#            ${count_U}=  set variable  0
#            ${sum_D}=  set variable  0
#            ${count_D}=  set variable  0

            ${close}=     set variable  7
            ${spread}=    set variable  8
            ${pointer}=   set variable  0
            ${bb_data}=  Create List  


	    
            ${date_length}=  get length  ${output}

            FOR  ${i}  IN RANGE  ${date_length}

    ${today_date}=  set variable  ${output}[${i}][0]     
    ${today_stock_id}=  set variable  ${output}[${i}][1]     
    ${today_trading_volume}=  set variable  ${output}[${i}][2]     
    ${today_trading_money}=  set variable  ${output}[${i}][3]     
    ${today_open}=  set variable  ${output}[${i}][4]     
    ${today_high}=  set variable  ${output}[${i}][5]     
    ${today_low}=  set variable  ${output}[${i}][6]     
    ${today_close}=  set variable  ${output}[${i}][7]     
    ${today_spread}=  set variable  ${output}[${i}][8]     
    ${today_trading_turnover}=  set variable  ${output}[${i}][9]  


                IF  ${bb_length} > ${i}
                    Append To List  ${bb_data}  ${today_close}
                    
#                    IF  ${output}[${i}][${spread}] > 0
#		        ${sum_U}=    evaluate  ${sum_U} + ${today_spread}
#                        ${count_U}=  evaluate  ${count_U} + 1 
#		    ELSE IF  ${output}[${i}][${spread}] < 0
#		        ${sum_D}=    evaluate  ${sum_D} + ${today_spread}
#                        ${count_D}=  evaluate  ${count_D} + 1 
#		    END

#                    CONTINUE FOR LOOP

                     ${middle_bb}=  set variable  0
                     ${SD20}=       set variable  0
                     ${upper_bb}=   set variable  0
                     ${lower_bb}=   set variable  0
                     ${percent_b}=  set variable  0

                ELSE
                    log  ${bb_data}
                    ${old_i}=  evaluate  ${i} - ${bb_length}
                    ${old_rsi_i_data}=  set variable  ${bb_data}[${pointer}]
                    ${bb_data}[${pointer}]=  set variable  ${output}[${i}][${close}]


#                    IF  ${output}[${old_i}][${spread}] > 0
#		        ${sum_U}=    evaluate  ${sum_U} - ${old_rsi_i_data}
#                        ${count_U}=  evaluate  ${count_U} - 1 
#                    ELSE IF  ${output}[${old_i}][${spread}] < 0
#		        ${sum_D}=    evaluate  ${sum_D} - ${old_rsi_i_data}
#                        ${count_D}=  evaluate  ${count_D} - 1 
#                    END
#
#                    IF  ${output}[${i}][${spread}] > 0
#		        ${sum_U}=    evaluate  ${sum_U} + ${rsi_data}[${pointer}]
#                        ${count_U}=  evaluate  ${count_U} + 1 
#                    ELSE IF  ${output}[${i}][${spread}] < 0
#		        ${sum_D}=    evaluate  ${sum_D} + ${rsi_data}[${pointer}]
#                        ${count_D}=  evaluate  ${count_D} + 1 
#                    END



                     log  statistics.mean( ${bb_data} )

                     ${middle_bb}=  evaluate  statistics.mean( ${bb_data})

                     log  ${middle_bb}

                     
                    log  statistics.stdev( ${bb_data} )  

                    ${SD20}=  evaluate  statistics.stdev( ${bb_data} )  

                    ${upper_bb}=   evaluate  ${middle_bb} + 2*${SD20}
                    ${lower_bb}=   evaluate  ${middle_bb} - 2*${SD20}

                    ${percent_b}=  evaluate  ( (${today_close}-${lower_bb}) / (${upper_bb}/${lower_bb}) )






                    log  ${pointer}
                    IF  ${pointer} >= ${bb_length-1}
                        ${pointer}=  set variable  0
                    ELSE
                        ${pointer}=  evaluate  ${pointer}+1
                    END


                END




   

                    
		    
		    






#                IF  ${count_U} != 0    
#                    log  ${sum_U}/${count_U}
#                    ${sma_U}=  evaluate  ${sum_U}/${count_U}
#                ELSE
#                    ${sma_U}=  set variable  0
#                END
#
#                IF  ${count_D} != 0
#                    log  ${sum_D}/${count_D}
#                    ${sma_D}=  evaluate  ${sum_D}/${count_D}
#                ELSE
#                    ${sma_D}=  set variable  0
#                END

                
#                    log  ${sma_U}/(${sma_U} - ${sma_D})
#                    ${rsi}=  evaluate  ( ${sma_U}/(${sma_U} - ${sma_D}) ) * 100










                ${file_exists}=  Run Keyword And Return Status  OperatingSystem.File_Should_Exist   stock_csv_new_middleBB/${today_stock_id}_bb_${today_date}[0:4].csv

                IF  '${file_exists}' == 'False'
                    Copy File  lvr_landcsv/a_lvr_land_a_header.csv  stock_csv_new_middleBB/${today_stock_id}_bb_${today_date}[0:4].csv
                    Append To File   stock_csv_new_middleBB/${today_stock_id}_middleBB_${today_date}[0:4].csv   日期,股票代碼,成交量,成交金額,開盤價,最高價,最低價,收盤價,漲跌幅,交易筆數,middle_bb,SD20,upper_bb,lower_bb\n
                END




#                ${high_low_value}=   set variable  ${today_date},${today_stock_id},${today},${list_i_j-1_3},${list_i_j-1_4},${list_i_j-1_5},${list_i_j-1_6},${list_i_j-1_7},${list_i_j-1_8},${list_i_j-1_9},${highest9}[${j}],${lowest9}[${j}],${rsv9}[${j}],${today_k},${today_d}
                ${high_low_value}=   set variable  ${today_date},${today_stock_id},${today_trading_volume},${today_trading_money},${today_open},${today_high},${today_low},${today_close},${today_spread},${today_trading_turnover},${middle_bb},${SD20},${upper_bb},${lower_bb}
                log  ${high_low_value}

                ${high_low_by_array}=  set variable  ${high_low_value}

                log  ${high_low_by_array}


                ${csv_string}=  set variable  ${high_low_by_array}\n
                log  ${csv_string}

                Append To File   stock_csv_new_middleBB/${today_stock_id}_bb_${today_date}[0:4].csv   ${csv_string}




                ${table_name}=  set variable  daily_stock_bb
                ${name_1}=      set variable  date
                ${type_1}=      set variable  DATE
                ${name_2}=      set variable  stock_id
                ${type_2}=      set variable  varchar(100)

                ${name_3}=      set variable  middle_bb
                ${type_3}=      set variable  FLOAT

                ${name_4}=      set variable  SD20
                ${type_4}=      set variable  FLOAT
                ${name_5}=      set variable  upper_bb
                ${type_5}=      set variable  FLOAT
                ${name_6}=      set variable  lower_bb
                ${type_6}=      set variable  FLOAT
                ${name_7}=      set variable  percent_b
                ${type_7}=      set variable  FLOAT
            
#                IF  ${rsi} < 30
#                    ${buyin}=  set variable  1 
#                ELSE IF  ${rsi} > 70  
#                    ${buyin}=  set variable  -1
#	        ELSE
#                    ${buyin}=  set variable  0		    
#                END


                ${output_sql}=    Execute Sql String    INSERT INTO ${table_name} VALUES ( '${today_date}', '${today_stock_id}', ${middle_bb}, ${SD20}, ${upper_bb}, ${lower_bb}, ${percent_b} )

                log  ${output_sql}




  END



















