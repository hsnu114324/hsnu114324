*** Keywords ***
pnstestmail_sql_setVerB



    [Arguments] 	${path_excel}  ${sheet_name}
    Log_To_Console	path_excel : ${path_excel}
    Log_To_Console	sheet_name : ${sheet_name}

    ${sensor_check_list}=  post_excel_getdata_for_ezpost    ${path_excel}  ${sheet_name} 

    ${list_count} =    Get length    ${sensor_check_list}
    Log_To_Console   list_count ${list_count}
	Log_To_Console   ${sensor_check_list}

    FOR  ${sensor_name}  IN  @{sensor_check_list}

		Log   sensor_name: ${sensor_name}
		Log   ${sensor_name}[0]

    END


#  Connect_To_pnstest_Databases
  Connect_To_dmstest_Databases

  FOR  ${sensor_name}  IN  @{sensor_check_list}
    IF  '${sensor_name}[0]' == 'sql'
	    Log_To_Console	${sensor_name}[0]
	    Log	 ${sensor_name}[0]
    ELSE
    	Log_To_Console	${sensor_name}[0]
    	Log  ${sensor_name}[0]
    	CONTINUE For Loop
    END

#    update_data_from_pnstest_database	${sensor_name}[1]	${sensor_name}[3]	${sensor_name}[5]

    query_data_from_dmstest_database  ${sensor_name}[7]  ${sensor_name}[8]  ${sensor_name}[4]

  END

#	[Return]  ${CR_no}
