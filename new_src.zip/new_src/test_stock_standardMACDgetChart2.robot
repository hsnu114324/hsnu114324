*** Settings ***
Library  OperatingSystem
Library  ExcelLibrary
Library  String
Library  Collections
Library  CSVLibrary
Library  DateTime
Resource  Common/common_stock.robot
Resource  Common/common_finmind.robot


*** Variables ***
@{stock_list}    @{EMPTY}


#*** Keywords ***
*** Test Cases ***
test_stock_standardMACDgenChart2


    ${files}    OperatingSystem.List_Files_In_Directory    stock_csv_new_2023    *.csv



    FOR    ${file}    IN    @{files}



        ${file0_split}=    Split String    ${file}    .
        Log_To_Console  ${file0_split}[0]
        ${file1_split}=    Split String    ${file0_split}[0]    _
        Log_To_Console  ${file1_split}[0]

        ${old1_csv_content}=    Get File    stock_csv_new_2023/${file1_split}[0]_2023.csv    encoding=UTF-8-SIG    encoding_errors=strict
        @{list_pre_1}=  Read Csv String To List  ${old1_csv_content}


        ${old0_csv_content}=    Get File    stock_csv_new_kd_rsv/${file1_split}[0]_rsv_${file1_split}[1][0:4].csv    encoding=UTF-8-SIG    encoding_errors=strict
        @{list_pre_0}=  Read Csv String To List  ${old0_csv_content}





        @{list_1}=  Read Csv String To List  ${old1_csv_content}
#
#        @{list_0}=  Read Csv String To List  ${old0_csv_content}
#        ${list_0_j-1}=  set variable  ${list_0}[-1]
#
#
#
#            ${csv_string}=  set variable  ${empty}
#            ${high_low_by_array}=  set variable  ${empty}
#


    END

 
    Remove_File  chart5.html
   



    ${chartjs5file1_content}=  Get_file  chartjs5file1.txt

    append_to_file  chart5.html  ${chartjs5file1_content}




            ${length}=  Get length  ${list_1}
            ${length+1}=  evaluate  ${length} + 1


            FOR  ${j}  IN RANGE  0  ${length}  1

                        ${list_1_j}=  set variable  ${list_1}[${j}]



#    append_to_file  chart5.html  ${chartjs5file2_content}
#    append_to_file  chart5.html  ${old1_csv_content}
    append_to_file  chart5.html  ['${list_1_j}[0]', '${list_1_j}[1]', ${list_1_j}[4], ${list_1_j}[5], ${list_1_j}[6], ${list_1_j}[7], ${list_1_j}[9]],\n

            END


    ${chartjs5file3_content}=  Get_file  chartjs5file3.txt

#    append_to_file  chart5.html  ${chartjs5file3_content}

    append_to_file  chart5.html  ${chartjs5file3_content}

    append_to_file  chart5.html  '${list_1_j}[1]'

    ${chartjs5file5_content}=  Get_file  chartjs5file5.txt

    append_to_file  chart5.html  ${chartjs5file5_content}



