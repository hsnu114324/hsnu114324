*** Keywords ***
ezpost_postweb_set
	[Documentation]
	[Tags]
#***
    [Arguments] 	${path_excel}  ${sheet_name}
    Log_To_Console	path_excel : ${path_excel}
    Log_To_Console	sheet_name : ${sheet_name}

    ${sensor_check_list}=  post_excel_getdata_for_ezpost    ${path_excel}  ${sheet_name} 

	Log_To_Console   ${sensor_check_list}

    FOR  ${sensor_name}  IN  @{sensor_check_list}

		Log_To_Console   sensor_name: ${sensor_name}
		Log_To_Console   ${sensor_name}[0]



    END




#***
	post_postweb_ezpostFrontEndlogin  https://ezpost.post.gov.tw/
#***
	post_postweb_ClickezpostFrontEndLoginUsername  0963038476
#***
	post_postweb_ClickezpostFrontEndLoginPassword  Jy99jy88
#***
	Sleep  10s
	post_postweb_ClickezpostFrontEndLoginEnter
	Sleep  1s
#***

#  FOR  ${sensor_name}  IN  @{sensor_check_list}

#***
	post_postweb_ClickezpostFrontEndMenu_DParcel_Dropdown
#***
	post_postweb_ClickezpostFrontEndMenu_DParcel_edit
#***
    post_postweb_ClickezpostFrontEndcbUnderstand
#***
    post_postweb_ClickezpostFrontEnd_D_txtSNAME
#***
    post_postweb_ClickezpostFrontEnd_D_txtSPHONE
#***
    post_postweb_ClickezpostFrontEndselectSADDCity
#***
    post_postweb_ClickezpostFrontEndselectSADDArea
#***
    post_postweb_ClickezpostFrontEndselectSADDOther
#***
    post_postweb_ClickezpostFrontEnd_D_txtRNAME
#***
    post_postweb_ClickezpostFrontEnd_D_txtRPHONE
#***
    post_postweb_ClickezpostFrontEndselectRADDCity
#***
    post_postweb_ClickezpostFrontEndselectRADDArea
#***
    post_postweb_ClickezpostFrontEndselectRADDO
#***
    post_postweb_ClickezpostFrontEndselectRADDOther  1號
#***
    post_postweb_ClickezpostFrontEndDParcelcheckboxCONTENTS_1
#***
    post_postweb_ClickezpostFrontEnd_DParcel_MailSize
#***
    post_postweb_ClickezpostFrontEndDParcelValueDeclared
#***
#    post_postweb_ClickezpostFrontEndDParceltextVALUE_DECLARED_AMOUNT    ${sensor_name}[0]
#    post_postweb_ClickezpostFrontEndDParceltextVALUE_DECLARED_AMOUNT    999
#***
    post_postweb_ClickezpostFrontEndDParcelUNDELIVER_OPTNO
#***
    post_postweb_ClickezpostFrontEndDParcelbtn_row
#***

#***
	post_postweb_ClickezpostFrontEndMenu_DEMS_Dropdown
#***
	post_postweb_ClickezpostFrontEndMenu_DEMS_edit
#***
    post_postweb_ClickezpostFrontEndcbUnderstand
#***
    post_postweb_ClickezpostFrontEnd_D_txtSNAME
#***
    post_postweb_ClickezpostFrontEnd_D_txtSPHONE
#***
    post_postweb_ClickezpostFrontEndselectSADDCity
#***
    post_postweb_ClickezpostFrontEndselectSADDArea
#***
    post_postweb_ClickezpostFrontEndselectSADDOther
#***
    post_postweb_ClickezpostFrontEnd_D_txtRNAME
#***
    post_postweb_ClickezpostFrontEnd_D_txtRPHONE
#***
    post_postweb_ClickezpostFrontEndselectRADDCity
#***
    post_postweb_ClickezpostFrontEndselectRADDArea
#***
    post_postweb_ClickezpostFrontEndselectRADDO
#***
    post_postweb_ClickezpostFrontEndselectRADDOther  1號
#***
    post_postweb_ClickezpostFrontEndDParcelcheckboxCONTENTS_1
#***
    post_postweb_ClickezpostFrontEnd_DParcel_MailSize
#***
    post_postweb_ClickezpostFrontEndDParcelValueDeclared
#***
#    post_postweb_ClickezpostFrontEndDParceltextVALUE_DECLARED_AMOUNT    ${sensor_name}[0]
#    post_postweb_ClickezpostFrontEndDParceltextVALUE_DECLARED_AMOUNT    999
#***
    post_postweb_ClickezpostFrontEndDParcelUNDELIVER_OPTNO
#***
    post_postweb_ClickezpostFrontEndDParcelbtn_row
#***


#  END


#***

#***

#***
	post_postweb_ClickezpostFrontEndMenu_DEMS_Dropdown
#***
	post_postweb_ClickezpostFrontEndMenu_DEMS_edit
#***
	post_postweb_ClickezpostFrontEndMenu_DTW_Dropdown
#***
	post_postweb_ClickezpostFrontEndMenu_DTW_edit
#***
#	post_postweb_ClickPnsFrontEndddlOldCity_ddl1
#***
##	post_postweb_ClickPnsFrontEndbtnSend
#***





