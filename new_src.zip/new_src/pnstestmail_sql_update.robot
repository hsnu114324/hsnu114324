*** Keywords ***
pnstestmail_sql_update
#    [Arguments]    ${excel_file_data}
    [Documentation]
    [Tags]
    Connect To Database
    ...    pymssql
    ...    dbName=DLIQSERV
    ...    dbUsername=DLIQTASK
    ...    dbPassword=DLIQTASK3817
    ...    dbHost=10.201.52.130
    ...    dbPort=1433


    ${Q_SID_value}=  set variable  '08FE0PujSqB'
    ${testmail_no}=  set variable  '111621120300000011'


    ${output}=    Query    SELECT * FROM QuestMain WHERE Q_SID = ${Q_SID_value};
    Log_To_Console  ${output}


    ${output}=    Execute Sql String    UPDATE QuestMain SET CREATE_DATE = '2023-01-01 01:01:01.001' where Q_SID = ${Q_SID_value}
    Log_To_Console  ${output}


    ${output}=    Query    SELECT * FROM QuestMain WHERE Q_SID = ${Q_SID_value};
    Log_To_Console  ${output}

    ${output}=    Execute Sql String    UPDATE QuestMain SET INSPECTOR_SSO_ID = '714838' where Q_SID = ${Q_SID_value}
    Log_To_Console  ${output}


    ${output}=    Query    SELECT * FROM QuestMain WHERE Q_SID = ${Q_SID_value};
    Log_To_Console  ${output}


    ${output}=    Query    SELECT * FROM QuestData WHERE Q_SID = ${Q_SID_value};
    Log_To_Console  ${output}

    ${output}=    Execute Sql String    UPDATE QuestData SET Q_VALUE = '測驗中' where Q_SID = ${Q_SID_value} and Q_SNO = '33'
    Log_To_Console  ${output}


    ${output}=    Query    SELECT * FROM QuestData WHERE Q_SID = ${Q_SID_value};
    Log_To_Console  ${output}


#    ${output}=    Execute Sql String    UPDATE T_QUESTREPORT SET FIRST_INSPECTOR_ID = '714838' where DID = '111621120300000011'
#    Log_To_Console  ${output}

#    ${output}=    Execute Sql String    UPDATE T_QUESTREPORT SET SECOND_INSPECTOR_ID = '647701' where DID = '111621120300000011'
#    Log_To_Console  ${output}
