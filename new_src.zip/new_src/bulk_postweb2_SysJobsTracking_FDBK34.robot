*** Keywords ***
bulk_postweb2_SysJobsTracking_FDBK34
    [Arguments] 	${excel_file_data}
	[Documentation]
	[Tags]
#***

    Log  ${excel_file_data}
#***
	bulk_postweb2_loginChrome  https://10.201.52.167/
#***
	bulk_postweb2_loginUsername  714838
#***
	bulk_postweb2_loginPassword  Xm3gl4cj/678
#***
	Sleep  1s
	bulk_postweb2_loginEnter
	Sleep  1s
	bulk_postweb2_adminloginEnter
	Sleep  1s	
#***

	bulk_postweb2_ClickSY000
#***
	bulk_postweb2_ClickSY000List3
#***
	bulk_postweb2_ClickSY000List3bean_search 
#***
    Sleep  1s

    ${new_xpath}=  bulk_postweb2_FetchTableGridButton   jqgrid  Job_C_Bulk_FDBK34

    bulk_postweb2_ClickTableGridButton   ${new_xpath}  jqgrid  Job_C_Bulk_FDBK34

#***
	post_postweb2_ClickPnsFrontEndddlOldCity_ddl1  ${excel_file_data}[8]
#***
	post_postweb2_ClickPnsFrontEndbtnSend
#***


	post_postweb2_ClickPnsFrontEndMenuList2
#***
	post_postweb2_ClickPnsFrontEndMenuList2Button1
#***  
	post_postweb2_ClickPnsFrontEndbtnQuery

    ${CR_no}=  post_postweb2_FetchPnsFrontEndlbtnReqNo_0

	post_postweb2_ClickPnsFrontEndlbtnReqNo_0
#	post_postweb2_ClickPnsFrontEndCancelbtnSave
#***

	[Return]  ${CR_no}