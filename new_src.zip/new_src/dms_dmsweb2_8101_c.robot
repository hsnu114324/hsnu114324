*** Keywords ***
dms_dmsweb2_8101_c
    [Arguments]  ${excel_file_data}
#    [Arguments] 	${ACC_DATE}  ${TOUR_NO}  ${CAR_NO}  ${RCV_STAFF_ID}  ${RCV_KIND}  ${CUS_PH_NO}  ${SND_TEL}  ${BNS_TYPE}  ${ZIP_CODE}  ${SPL_OFFICE}  ${MAIL_NO}  ${MAIL_LENGTH}  ${MAIL_WIDTH}  ${MAIL_HEIGHT}  ${MAIL_WEIGHT}  ${DST_NT_CODE}  ${MAIL_TYPE}  ${DSN_TYPE}  ${MAIL_TYPE1}  ${ISR_CHARGE}  ${PAY_CASH_AMT}  ${PAY_POSTAL_AMT}  ${PAY_STMP_AMT}  ${MON_PAY}  ${CustomsFlag}  ${RCV_TEL}  ${TOL_POSTAL}  
#  ${MON_PAY}
	[Documentation]
	[Tags]
#***

    Log  ${excel_file_data}
#    Log  ${ACC_DATE} ${TOUR_NO} ${CAR_NO} ${RCV_STAFF_ID} ${RCV_KIND} ${CUS_PH_NO} ${SND_TEL} ${BNS_TYPE} ${ZIP_CODE} ${SPL_OFFICE} ${MAIL_NO} ${MAIL_LENGTH} ${MAIL_WIDTH} ${MAIL_HEIGHT} ${MAIL_WEIGHT} ${DST_NT_CODE} ${MAIL_TYPE} ${DSN_TYPE} ${MAIL_TYPE1} ${ISR_CHARGE} ${PAY_CASH_AMT} ${PAY_POSTAL_AMT} ${PAY_STMP_AMT} ${CustomsFlag} ${RCV_TEL} ${TOL_POSTAL}
#***
	dms_postweb2_pnsFrontEndloginChrome  http://localhost:3000/
#	post_postweb2_pnsFrontEndloginFirefox  https://pnstest.post.gov.tw/LI.Web/LI0010.aspx


#    Debug

#***
	dms_dmsweb2_ClickDmsFrontEndLoginUsername  DS000013
#***
    dms_dmsweb2_ClickdmsFrontEndLoginSelectOffice
#***
	dms_dmsweb2_ClickDmsFrontEndLoginPassword  B11011101.
#***
#	Sleep  10s
	dms_dmsweb2_ClickDmsFrontEndLoginEnter
#	Sleep  1s
#***

	dms_dmsweb2_ClickDmsFrontEndMenuButton
#***
	dms_dmsweb2_ClickDmsFrontEndMenu_ListDR1
#***
	dms_dmsweb2_ClickDmsFrontEndMenu_ListDR1_8101
#***
	dms_dmsweb2_ClickDmsFrontEnd_8101NewNoneM5A0Button
#***

#***
	dms_dmsweb2_ClickDmsFrontEnd_8120ACC_DATE  ${excel_file_data}[1]
#	Sleep  1s

	dms_dmsweb2_ClickDmsFrontEnd_8120TOUR_NO  ${excel_file_data}[2]

#	Sleep  1s	

	dms_dmsweb2_ClickDmsFrontEnd_8120CAR_NO  ${excel_file_data}[3]

#	Sleep  1s
	
	dms_dmsweb2_ClickDmsFrontEnd_8120RCV_STAFF_ID  ${excel_file_data}[4]

#	Sleep  1s
	
	dms_dmsweb2_ClickDmsFrontEnd_8120RCV_KIND  ${excel_file_data}[5]

#	Sleep  1s
	
	dms_dmsweb2_ClickDmsFrontEnd_8120CUS_PH_NO  ${excel_file_data}[6]

#	Sleep  1s
	
	dms_dmsweb2_ClickDmsFrontEnd_8120SND_TEL  ${excel_file_data}[7]

#	Sleep  1s
	
	dms_dmsweb2_ClickDmsFrontEnd_8120BNS_TYPE  ${excel_file_data}[8]

#	Sleep  1s
	
	dms_dmsweb2_ClickDmsFrontEnd_8120ZIP_CODE  ${excel_file_data}[9]

#	Sleep  1s
	
	dms_dmsweb2_ClickDmsFrontEnd_8120SPL_OFFICE  ${excel_file_data}[10]

#	Sleep  1s
	
	dms_dmsweb2_ClickDmsFrontEnd_8120MAIL_NO  ${excel_file_data}[11]

#	Sleep  1s
	
	dms_dmsweb2_ClickDmsFrontEnd_8120DST_NT_CODE  ${excel_file_data}[12]

#	Sleep  1s
	
	dms_dmsweb2_ClickDmsFrontEnd_8120MAIL_TYPE  ${excel_file_data}[13]

#	Sleep  1s
	
	dms_dmsweb2_ClickDmsFrontEnd_8120MAIL_WEIGHT  ${excel_file_data}[14]

#	Sleep  1s
	
	dms_dmsweb2_ClickDmsFrontEnd_8120MAIL_LENGTH  ${excel_file_data}[15]

#	Sleep  1s
	
	dms_dmsweb2_ClickDmsFrontEnd_8120MAIL_WIDTH  ${excel_file_data}[16]

#	Sleep  1s
	
	dms_dmsweb2_ClickDmsFrontEnd_8120MAIL_HEIGHT  ${excel_file_data}[17]

#	Sleep  1s
	
	dms_dmsweb2_ClickDmsFrontEnd_8120DSN_TYPE  ${excel_file_data}[18]

#	Sleep  1s
	
	dms_dmsweb2_ClickDmsFrontEnd_8120MAIL_TYPE1  ${excel_file_data}[19]

#	Sleep  1s
	
	dms_dmsweb2_ClickDmsFrontEnd_8120ISR_CHARGE  ${excel_file_data}[20]

#	Sleep  1s
	
	dms_dmsweb2_ClickDmsFrontEnd_8120PAY_CASH_AMT  ${excel_file_data}[21]

#	Sleep  1s
	
	dms_dmsweb2_ClickDmsFrontEnd_8120PAY_POSTAL_AMT  ${excel_file_data}[22]

#	Sleep  1s
	
	dms_dmsweb2_ClickDmsFrontEnd_8120PAY_STMP_AMT  ${excel_file_data}[23]

#	Sleep  1s
	
	dms_dmsweb2_ClickDmsFrontEnd_8120MON_PAY  ${excel_file_data}[24]

#	Sleep  1s
	
	dms_dmsweb2_ClickDmsFrontEnd_8120CustomsFlag    ${excel_file_data}[25]

#	Sleep  1s
	
	dms_dmsweb2_ClickDmsFrontEnd_8120RCV_TEL    ${excel_file_data}[26]

#	Sleep  1s
	
	dms_dmsweb2_ClickDmsFrontEnd_8120TOL_POSTAL    ${excel_file_data}[27]

	Take Screenshot

#	Debug

	Click   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[3]/button[2]

#	Click   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[3]/button[3]

#	Sleep  1s
	

 




#	Return  ${CR_no}
