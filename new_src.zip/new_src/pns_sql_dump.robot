*** Keywords ***
pns_sql_dump
    [Arguments]    ${REQUISITION_NO_value}
    [Documentation]
    [Tags]
    Connect To Database
    ...    pymssql
    ...    dbName=DLIQSERV
    ...    dbUsername=DLIQTASK
    ...    dbPassword=DLIQTASK3817
    ...    dbHost=10.201.52.130
    ...    dbPort=1433
    ...    alias=pnstest

#    ${Q_SID_value}=  set variable  '08FE0PujSqB'
#    ${testmail_no}=  set variable  '111621120300000011'

#    ${Q_SID_value}=  set variable  '08FBANRss8S'
#    ${testmail_no}=  set variable  '111611121200000004'

#    ${REQUISITION_NO_value}=  set variable  ''


    ${output}=    Query    SELECT * FROM T_EMAIL WHERE REQUISITION_NO = '${REQUISITION_NO_value}'  alias=pnstest
    Log  ${output}
    OperatingSystem.Run  echo ${output} >> T_EMAIL.txt

    ${output}=    Query    SELECT * from T_REQUISITION where REQUISITION_NO = '${REQUISITION_NO_VALUE}'  alias=pnstest
    Log  ${output}
    OperatingSystem.Run  echo ${output} >> T_REQUISITION.txt

    ${output}=    Query    SELECT * from T_VERIFICATION where REQUISITION_NO = '${REQUISITION_NO_VALUE}'  alias=pnstest
    Log  ${output}
    OperatingSystem.Run  echo ${output} >> T_VERIFICATION.txt

    ${output}=    Query    SELECT * from T_REASSIGN where REQUISITION_NO = '${REQUISITION_NO_VALUE}'  alias=pnstest
    Log  ${output}
    OperatingSystem.Run  echo ${output} >> T_REASSIGN.txt

    ${output}=    Query    SELECT * from T_ADDRESS where REQUISITION_NO = '${REQUISITION_NO_VALUE}'  alias=pnstest
    Log  ${output}
    OperatingSystem.Run  echo ${output} >> T_ADDRESS.txt

    ${output}=    Query    SELECT * from T_REQUISITION_LOG where REQUISITION_NO = '${REQUISITION_NO_VALUE}'  alias=pnstest
    Log  ${output}
    OperatingSystem.Run  echo ${output} >> T_REQUISITION_LOG.txt














