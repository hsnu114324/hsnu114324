*** Keywords ***
test_stock_sql_insert_evaluate_in
#    [Arguments]    ${excel_file_data}
#    [Arguments]  ${start_date}  ${end_date}
    [Documentation]
    [Tags]
#    Connect To Database
#    ...    pymssql
#    ...    dbName=DLIQSERV
#    ...    dbUsername=DLIQTASK
#    ...    dbPassword=DLIQTASK3817
#    ...    dbHost=10.201.52.130
#    ...    dbPort=1433



    




    Connect To Database Using Custom Params  sqlite3  database="./test.db"



                ${table_name}=  set variable  evaluate_in
                ${name_1}=      set variable  primary_key
                ${type_1}=      set variable  INT
                ${name_2}=      set variable  date
                ${type_2}=      set variable  DATE
                ${name_3}=      set variable  strategy_id
                ${type_3}=      set variable  INT
                ${name_4}=      set variable  buyin_signal
                ${type_4}=      set variable  INT
                ${name_5}=      set variable  class
                ${type_5}=      set variable  varchar(100)
                ${name_6}=      set variable  stock_id
                ${type_6}=      set variable  varchar(100)
                ${name_7}=      set variable  evaluate_in_or_out
                ${type_7}=      set variable  varchar(100)
                ${name_8}=      set variable  close
                ${type_8}=      set variable  INT

                ${name_9}=      set variable  number_of_share
                ${type_9}=      set variable  INT
                ${name_10}=      set variable  share_amount_price
                ${type_10}=      set variable  FLOAT

                ${name_11}=      set variable  evaluate_in_strategy_ror
                ${type_11}=      set variable  FLOAT
                ${name_12}=      set variable  strategy_in_parent_id
                ${type_12}=      set variable  INT
                ${name_13}=      set variable  estimate_in_children_id
                ${type_13}=      set variable  INT




  ${output}=  Execute Sql String  INSERT INTO ${table_name} VALUES ( 1, 1, 1, '2024-01-02', 'tw_stock', '2330', 'in', 1000, 626, 626000 )
  Log  ${output}


  ${output}=  Execute Sql String  INSERT INTO ${table_name} VALUES ( 2, 2, 1, '2024-01-02', 'tw_stock', '2330', 'in', 1000, 774, 774000 )
  Log  ${output}


