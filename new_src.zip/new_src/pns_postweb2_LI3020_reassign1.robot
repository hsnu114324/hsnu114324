*** Keywords ***
pns_postweb2_LI3020_reassign1
    [Arguments]    ${user_no}  ${CR_no}
	[Documentation]
	[Tags]
#***



#***

	post_postweb2_pnsBackEndlogin  https://pnstest.post.gov.tw/LI.adm/Login.aspx
#***
	post_postweb2_ClickPnsBackEndLoginUsername   ${user_no}
#	post_postweb2_ClickPnsBackEndLoginUsername   174646
#	#165406
#***
	post_postweb2_ClickPnsBackEndLoginEnter
	Sleep  1s  
#***
	post_postweb2_ClickPnsBackEndtvFunctionti  查證作業
#***
	post_postweb2_ClickPnsBackEndtvFunctiontj  LI3020
#***
	post_postweb2_ClickPnsBackEndContent1_btnQuery
#***
	post_postweb2_CheckPnsBackEndContent1_gvList_LinkButton_0   ${CR_no}
	post_postweb2_ClickPnsBackEndContent1_gvList_LinkButton_0
#***
    post_postweb2_ClickPnsBackEndContent1_fvw1Change
#	post_postweb2_ClickPnsBackEndContent1_fvw1_btnFvwPrint_btnPrint
#***
#        Sleep  10




