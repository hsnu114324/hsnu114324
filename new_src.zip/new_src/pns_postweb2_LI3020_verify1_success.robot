*** Keywords ***
pns_postweb2_LI3020_verify1_success
	[Arguments]    ${user_no}  ${CR_no}
	[Documentation]
	[Tags]
#***




	post_postweb2_pnsBackEndlogin  https://pnstest.post.gov.tw/LI.adm/Login.aspx
#***
	post_postweb2_ClickPnsBackEndLoginUsername    ${user_no} 
#	174646
#	#165406
#***
	post_postweb2_ClickPnsBackEndLoginEnter
	Sleep  1s  
#***
	post_postweb2_ClickPnsBackEndtvFunctionti  查證作業
#***
	post_postweb2_ClickPnsBackEndtvFunctiontj  LI3020
#***
	post_postweb2_ClickPnsBackEndContent1_btnQuery
#***
	post_postweb2_CheckPnsBackEndContent1_gvList_LinkButton_0   ${CR_no}
	post_postweb2_ClickPnsBackEndContent1_gvList_LinkButton_0
#***	




        ${fvw1_btnFvwChange_is_disabled}  ${message}=  post_postweb2_FetchPnsBackEndContent1_fvw1_btnFvwChange
        Log  ${fvw1_btnFvwChange_is_disabled}
        Log  ${message}


        ${HavePrint_match}  ${message}=  post_postweb2_FetchPnsBackEndContent1_HavePrint
        Log  ${HavePrint_match}
        Log  ${message}



	IF	'${HavePrint_match}' == 'PASS'
	    Sleep  1
	ELSE IF	 '${HavePrint_match}' == 'FAIL'
            post_postweb2_ClickPnsBackEndContent1_fvw1Print
	END


#***

 
        ${HaveUploadPicture_match}  ${message}=  Run Keyword And Ignore Error  post_postweb2_FetchPnsBackEndContent1_HaveUploadPicture

        Log  ${HaveUploadPicture_match}
        Log  ${message}

	IF	'${HaveUploadPicture_match}' == 'PASS'

            Sleep  1

	ELSE IF	 '${HaveUploadPicture_match}' == 'FAIL'

            post_postweb2_ChooseVerifyPicture


            Sleep  1
            post_postweb2_ClickPnsBackEndContent1_fvw1_btnUpload

	END



#***
        post_postweb2_ClickPnsBackEndContent1_fvw1_ResultStateSuccess
#***

#***

	post_postweb2_ClickPnsBackEndContent1_btnFvwSave

#***
        Sleep  1

#        ${titles}  Get Window Titles
#        Log_To_Console  all_titles: ${titles}
#        ${titles2}      Get From List   ${titles}   1
#        Log_To_Console  titles_2: ${titles2}
#        ${titles1}      Get From List   ${titles}   0
#        Log_To_Console  titles_1: ${titles1}
#        Switch Window    title=${titles2}





