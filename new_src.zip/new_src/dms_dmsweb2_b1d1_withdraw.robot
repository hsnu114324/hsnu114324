*** Keywords ***
dms_dmsweb2_b1d1_withdraw
    [Arguments]  ${excel_file_data}
  
#  ${MON_PAY}
	[Documentation]
	[Tags]
#***

    Log  ${excel_file_data}

#***
	dms_dmsweb2_pnsFrontEndloginChrome  http://localhost:3000/
#	post_postweb2_pnsFrontEndloginFirefox  https://pnstest.post.gov.tw/LI.Web/LI0010.aspx


#    Debug

    dms_dmsweb2_ClickDmsFrontEnduserID_DM_login

    dms_dmsweb2_ClickDmsFrontEndMenuInput  b1d1

    dms_dmsweb2_ClickDmsFrontEnd_b1d1ACC_START_DATE  ${excel_file_data}[1] 
    
    dms_dmsweb2_ClickDmsFrontEnd_b1d1ACC_END_DATE  ${excel_file_data}[1]

    dms_dmsweb2_ClickDmsFrontEnd_b1d1CNTR_NO  ${excel_file_data}[2] 

    dms_dmsweb2_ClickDmsFrontEnd_b1d1SEGC_NO  ${excel_file_data}[3] 

    dms_dmsweb2_ClickDmsFrontEnd_b1d1FetchButton

    dms_dmsweb2_ClickDmsFrontEnd_b1d1WithdrawButton

    dms_dmsweb2_ClickDmsFrontEnd_b1d1SendButton

    Sleep  1s
    Take Screenshot
    Keyboard Key    press    Enter
    Take Screenshot
    Sleep  1s
    Take Screenshot
    Keyboard Key    press    Enter
    Take Screenshot
    Sleep  1s
    Take Screenshot
#***



#    ${Q_ACC_MONTH_SER}=    dms_dmsweb2_DmsFrontEnd_b1d0_stage1_1    ${excel_file_data}    

    ${Q_ACC_MONTH_SER}=    dms_dmsweb2_DmsFrontEnd_b1d0_stage1_1    

    Log  ${Q_ACC_MONTH_SER}


#***    

    dms_dmsweb2_ClickDmsFrontEnduserID_logout

    Sleep  3s

	RETURN   ${Q_ACC_MONTH_SER}
