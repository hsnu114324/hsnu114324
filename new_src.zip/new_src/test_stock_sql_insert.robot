*** Keywords ***
test_stock_sql_insert
#    [Arguments]    ${excel_file_data}
    [Arguments]  ${start_date}  ${end_date}
    [Documentation]
    [Tags]
#    Connect To Database
#    ...    pymssql
#    ...    dbName=DLIQSERV
#    ...    dbUsername=DLIQTASK
#    ...    dbPassword=DLIQTASK3817
#    ...    dbHost=10.201.52.130
#    ...    dbPort=1433



    




    Connect To Database Using Custom Params  sqlite3  database="./test.db"


#    ${output}=   Execute Sql String     CREATE TABLE ${table_name} ( ${name_1} ${type_1}, ${name_2} ${type_2}, ${name_3} ${type_3}, ${name_4} ${type_4}, ${name_5} ${type_5}, ${name_6} ${type_6}, ${name_7} ${type_7}, ${name_8} ${type_8}, ${name_9} ${type_9}, ${name_10} ${type_10} ) ;
#    Log  ${output}


    ${table_name}=  set variable  daily_stock
    ${name_1}=      set variable  date 
    ${type_1}=      set variable  DATE
    ${name_2}=      set variable  stock_id
    ${type_2}=      set variable  varchar(100)
    ${name_3}=      set variable  Trading_Volume
    ${type_3}=      set variable  INT
    ${name_4}=      set variable  Trading_money
    ${type_4}=      set variable  INT
    ${name_5}=      set variable  open
    ${type_5}=      set variable  FLOAT
    ${name_6}=      set variable  max
    ${type_6}=      set variable  FLOAT
    ${name_7}=      set variable  min
    ${type_7}=      set variable  FLOAT
    ${name_8}=      set variable  close
    ${type_8}=      set variable  FLOAT
    ${name_9}=      set variable  spread
    ${type_9}=      set variable  FLOAT
    ${name_10}=     set variable  Trading_turnover
    ${type_10}=     set variable  INT


    ${output}=   Execute Sql String     CREATE TABLE ${table_name} ( ${name_1} ${type_1}, ${name_2} ${type_2}, ${name_3} ${type_3}, ${name_4} ${type_4}, ${name_5} ${type_5}, ${name_6} ${type_6}, ${name_7} ${type_7}, ${name_8} ${type_8}, ${name_9} ${type_9}, ${name_10} ${type_10} ) ;
    Log  ${output}







    ${folder}=    set variable    ../stock_csv    # 更換成目標資料>夾的路徑


#    ${max_file}    Set Variable    none
#    ${max_num}    Set Variable    0
#    ${files}    OperatingSystem.List_Files_In_Directory    ${folder}    *.csv
#
#    FOR    ${file}    IN    @{files}
#        ${file_split}=    Split String    ${file}    .
#        Log_To_Console  ${file_split}[0]
#        ${file_num}=  Convert_Date  ${file_split}[0]    result_format=%Y%m%d    date_format=%Y-%m-%d
#        ${num}    Evaluate    ${file_num}
#        IF    ${num} > ${max_num}
#            ${max_file}    Set Variable    ${file}
#            ${max_num}    Set Variable    ${num}
#        END
#    END
#    Log_To_Console    Max CSV file: ${max_file}
#    Log    Max CSV file: ${max_file}
#    Log_To_Console    Max num: ${max_num}
#    ${int_max_num}=    Convert_To_Integer    ${max_num}
#    ${str_max_num}=    Convert_To_String    ${max_num}
#    Log_To_Console    int Max num: ${int_max_num}
#    Log_To_Console    str Max num: ${str_max_num}
#

    ${date_range}=  finmind_GetDateRange  ${start_date}  ${end_date}  


  FOR  ${date}  IN  @{date_range}

  log_to_console  date: ${date}

    ${file_exists}=  Run Keyword And Return Status  OperatingSystem.File_Should_Exist   ${folder}/${date}.csv
    IF  '${file_exists}' == 'False'
        CONTINUE FOR LOOP 
    END
    
    @{list_csv_before_yesterday}=  read_csv_file_to_list  ${folder}/${date}.csv
    ${list_csv_by_cnt}=    Get length    ${list_csv_before_yesterday}
    Log  list_csv_by_cnt ${list_csv_by_cnt}



    FOR  ${i}  IN RANGE  1  ${list_csv_by_cnt}  1

        ${data}=     get from list  ${list_csv_before_yesterday}  ${i}
#        ${data_1}=   set variable  ${data}[0]
#        ${data_2}=   set variable  ${data}[1]
#        ${data_3}=   set variable  ${data}[2]
#        ${data_4}=   set variable  ${data}[3]
#        ${data_5}=   set variable  ${data}[4]
#        ${data_6}=   set variable  ${data}[5]
#        ${data_7}=   set variable  ${data}[6]
#        ${data_8}=   set variable  ${data}[7]
#        ${data_9}=   set variable  ${data}[8]
#        ${data_10}=  set variable  ${data}[9]
#
#        ${output}=    Execute Sql String    INSERT INTO ${table_name} VALUES ( '${data_1}', '${data_2}', ${data_3}, ${data_4}, ${data_5}, ${data_6}, ${data_7}, ${data_8}, ${data_9}, ${data_10} )

        ${output}=    Execute Sql String    INSERT INTO ${table_name} VALUES ( '${data}[0]', '${data}[1]', ${data}[2], ${data}[3], ${data}[4], ${data}[5], ${data}[6], ${data}[7], ${data}[8], ${data}[9] )
#        Log  ${output}


    END

  END

#
#    ${output}=    Query    SELECT * FROM QuestMain WHERE Q_SID = '08FE0PujSqB';
#    Log_To_Console  ${output}
#
#    ${output}=    Execute Sql String    UPDATE QuestMain SET INSPECTOR_SSO_ID = '714838' where Q_SID = '08FE0PujSqB'
#    Log_To_Console  ${output}
#
#
#    ${output}=    Query    SELECT * FROM QuestMain WHERE Q_SID = '08FE0PujSqB';
#    Log_To_Console  ${output}
#
#
#    ${output}=    Query    SELECT * FROM QuestData WHERE Q_SID = '08FE0PujSqB';
#    Log_To_Console  ${output}
#
#    ${output}=    Execute Sql String    UPDATE QuestData SET Q_VALUE = '測驗中' where Q_SID = '08FE0PujSqB' and Q_SNO = '33'
#    Log_To_Console  ${output}
#
#
#    ${output}=    Query    SELECT * FROM QuestData WHERE Q_SID = '08FE0PujSqB';
#    Log_To_Console  ${output}
#

#    ${output}=    Execute Sql String    UPDATE T_QUESTREPORT SET FIRST_INSPECTOR_ID = '714838' where DID = '111621120300000011'
#    Log_To_Console  ${output}

#    ${output}=    Execute Sql String    UPDATE T_QUESTREPORT SET SECOND_INSPECTOR_ID = '647701' where DID = '111621120300000011'
#    Log_To_Console  ${output}
