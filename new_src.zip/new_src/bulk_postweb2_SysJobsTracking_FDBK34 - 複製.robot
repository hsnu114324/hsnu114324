*** Keywords ***
bulk_postweb2_SysJobsTracking_FDBK34
    [Arguments] 	${excel_file_data}
	[Documentation]
	[Tags]
#***

    Log  ${excel_file_data}
#***
	bulk_postweb2_loginChrome  https://10.201.52.167/
#***
	bulk_postweb2_loginUsername  714838
#***
	bulk_postweb2_loginPassword  Xm3gl4cj/678
#***
	Sleep  1s
	bulk_postweb2_loginEnter
	Sleep  1s
	bulk_postweb2_adminloginEnter
	Sleep  1s	
#***

	bulk_postweb2_ClickSY000
#***
	bulk_postweb2_ClickSY000List3
#***
	bulk_postweb2_ClickSY000List3bean_search 
#***
    Sleep  1s
    ${Count}=   Browser.Get Element Count    xpath=//*[@id="gview_jqgrid"]/div[2]/div/table
    Sleep  1s
#    ${element} =    Browser.Get Element    	text="Job_C_Bulk_FDBK34"
#    ${element} =    Browser.Get Element     xpath=/html/body/div[2]/div[3]/div/div[3]/div[3]/div/table/tbody/tr[8]/td[12]/input
    ${element} =    Browser.Get Element     xpath=/html/body/div[2]/div[3]/div/div[3]/div[3]/div/table/tbody/tr[8]/td[12]
   
    ${idx}=    Get Table Cell Index    ${element}
    
    ${rdx}=    Get Table Row Index    ${element}

    ${id}=  Get Property  ${element}  id
    log  ${id}
    ${class}=  Get Property  ${element}  className
    log  ${class}



    ${element_selector1}=  set variable      text="Job_C_Bulk_FDBK34"
    ${element_selector2}=  set variable          xpath=/html/body/div[2]/div[3]/div/div[3]/div[3]/div/table/tbody/tr[8]/td[12]

    ${idx}=    Get Table Cell Index    ${element}
    
    ${rdx}=    Get Table Row Index    ${element}

    ${id}=  Get Property  ${element}  id
    log  ${id}
    ${class}=  Get Property  ${element}  className
    log  ${class}








    
    # 先取得元素
    ${element}=    Browser.Get Element    text="Job_C_Bulk_FDBK34"
    
    # 使用 Evaluate JavaScript 將元素轉成 XPath
    ${original_xpath}=    Evaluate JavaScript    ${element}    
    ...    (element) => {
    ...        function getXPath(node) {
    ...            if (node.id) {
    ...                return '//*[@id="' + node.id + '"]';
    ...            }
    ...            if (node === document.body) {
    ...                return '/html/body';
    ...            }
    ...            let position = 0;
    ...            let siblings = node.parentNode.childNodes;
    ...            for (let i = 0; i < siblings.length; i++) {
    ...                let sibling = siblings[i];
    ...                if (sibling === node) {
    ...                    return getXPath(node.parentNode) + '/' + node.tagName.toLowerCase() + '[' + (position + 1) + ']';
    ...                }
    ...                if (sibling.nodeType === 1 && sibling.tagName === node.tagName) {
    ...                    position++;
    ...                }
    ...            }
    ...        }
    ...        return getXPath(element);
    ...    }
    
   
    Log    The XPath is: ${original_xpath}

    ${origin_id_string_list}=    Get Regexp Matches    ${original_xpath}    \\[@id="(\\d+)"\\]
    ${origin_td_string_list}=    Get Regexp Matches    ${original_xpath}    td\\[(\\d+)\\]$
    
    ${origin_id_string_list1}=  Split String    ${origin_id_string_list}[0]    [@id="
    ${origin_id_list2}=      Split String    ${origin_id_string_list1}[1]    "]
    ${origin_id_num}=  set variable  ${origin_id_list2}[0]

    ${origin_td_string_list1}=  Split String    ${origin_td_string_list}[0]    td[
    ${origin_td_list2}=      Split String    ${origin_td_string_list1}[1]    ]
    ${origin_td_num}=  set variable  ${origin_td_list2}[0]

    ${new_id_num}=   set variable    ${origin_id_num}
    ${new_td_num}=   Evaluate    ${origin_td_num} + 7

    ${new_xpath}=    Set Variable    //*[@id="${new_id_num}"]/td[${new_td_num}]/input


    Click   ${new_xpath}
    Sleep  1s
    Click   ${new_xpath}

    Sleep  1s
    ${idx}=    Get Table Cell Index    ${element}
    Sleep  1s
    ${rdx}=    Get Table Row Index    ${element}
    Sleep  1s
	${e}=    Get Table Cell Element    xpath=//*[@id="jqgrid"]   4   7
	log  ${e}
	Sleep  1s
#***



    ${rows}=    Browser.Get_Elements    xpath=//*[@id="jqgrid"]/tbody/tr
    ${length}  Get Length   ${rows}
    log   ${rows}

    ${full_table}=    Create List

    Take Screenshot 

    FOR  ${row}   IN  @{rows}
        ${cells}=    Browser.Get_Elements    ${row} >> css=td, th
        ${row_data}=    Create_List
        FOR    ${cell}    IN    @{cells}
            ${text}=    Get_Text    ${cell}
            Append_To_List    ${row_data}    ${text}
        END
        Append_To_List    ${full_table}    ${row_data}
    END

    Take Screenshot

    FOR  ${index_i}    ${i}    IN ENUMERATE   @{rows}
        log   ${index_i} ${i}
        FOR  ${index_j}    ${j}    IN ENUMERATE  @{full_table[${index_i}]}
            log   ${j}
            IF  '${j}' == 'Job_C_Bulk_FDBK34'
                log  'Job_C_Bulk_FDBK34'
                log  ${index_i}
                log  ${index_j}
                Click  //*[@id="jqgrid"]/tbody/tr[8]/td[12]/input
                Take Screenshot
                Debug
                BREAK
            END
        END
    END

#***
	post_postweb2_ClickPnsFrontEndddlOldCity_ddl1  ${excel_file_data}[8]
#***
	post_postweb2_ClickPnsFrontEndbtnSend
#***


	post_postweb2_ClickPnsFrontEndMenuList2
#***
	post_postweb2_ClickPnsFrontEndMenuList2Button1
#***  
	post_postweb2_ClickPnsFrontEndbtnQuery

    ${CR_no}=  post_postweb2_FetchPnsFrontEndlbtnReqNo_0

	post_postweb2_ClickPnsFrontEndlbtnReqNo_0
#	post_postweb2_ClickPnsFrontEndCancelbtnSave
#***

	[Return]  ${CR_no}