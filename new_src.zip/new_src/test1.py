import requests
url = "https://api.web.finmindtrade.com/v2/user_info"
payload = {
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRlIjoiMjAyNC0wMy0xNiAwMDo1MjoxMSIsInVzZXJfaWQiOiJoc251MTE0MzI0IiwiaXAiOiIyMjMuMTQwLjE1My40OSJ9.3DFtUoz5X3rbxqG7oCiPco7x4HuN7v5Csc3P2gA6AmU",
}
resp = requests.get(url, params=payload)
resp.json()["user_count"]  # 使用次數
resp.json()["api_request_limit"]  # api 使用上限
data=resp.json()

print(data)
