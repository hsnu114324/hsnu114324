*** Keywords ***
bmc_bmcweb_update

	wistron_bmcweb_logout

	${initial_filters}=  wistron_bmcweb_Get_initial_filters
	${initial_userlist}=  wistron_ipmi_Get_initial_userlist
###
  FOR  ${i}  IN RANGE  2
	wistron_bmcweb_login

	wistron_bmcweb_GoToPage  ${url_FW_upgrade}

	@{BmcVersion}=  wistron_ipmi_GetBmcVersion
	Log_To_Console  BmcVerion ${BmcVersion}[0].${BmcVersion}[1].${BmcVersion}[2]
	
	${BmcVersion_match}=	Get Regexp Matches	${BmcVersion}[1]	09
	IF	${BmcVersion_match}
		${BmcVersion_minor}	Set Variable	${EMPTY}
		${BmcVersion_minor}	Set Variable	08
		Log_To_Console  BmcVersion_minor ${BmcVersion_minor}
		Log_To_Console  ${BmcVersion}[1]
		Log_To_Console  Update 220825.ima
		wistron_bmcweb_ChooseBmcImage  UT2.0BmcFwV220825.ima
	ELSE
		${BmcVersion_minor}	Set Variable	${EMPTY}
		${BmcVersion_minor}	Set Variable	09
		Log_To_Console  BmcVersion_minor ${BmcVersion_minor}
		Log_To_Console  ${BmcVersion}[1]
		Log_To_Console  Update 220915.ima
		wistron_bmcweb_ChooseBmcImage  UT2.0BmcFwV220915.ima
	END

	wistron_bmcweb_ClickFirmwareUpdateButton3
	wistron_bmcweb_ClickFirmwareUpdateButton4

	wistron_bmcweb_logout


###
	wistron_bmcweb_CheckPEFpolicy  ${initial_filters}
#	wistron_ipmi_CheckNetworkInterface  ${BmcVersion}[1]
	wistron_ipmi_CheckNetworkInterface  ${BmcVersion_minor}
	wistron_ipmi_CheckUserConfiguration  ${initial_userlist}
  END
