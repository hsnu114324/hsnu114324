*** Settings ***
Library  OperatingSystem
Library  ExcelLibrary
Library  String
Library  Collections
Library  CSVLibrary
Library  DateTime
Resource  Common/common_stock.robot
Resource  Common/common_finmind.robot


*** Variables ***
@{stock_list}    @{EMPTY}


#*** Keywords ***
*** Test Cases ***
test_stock_macd_dif
#    [Arguments]     ${excel_file_name}  ${sheet_name}
    [Documentation]    Load sensor list file and prepare list
#    Log_To_Console   excel_file_name : ${excel_file_name}
#    Log_To_Console   sheet_name : ${sheet_name}

 
    ${files}    OperatingSystem.List_Files_In_Directory    stock_csv_new_2023    *.csv
   
    FOR    ${file}    IN    @{files}



        ${file0_split}=    Split String    ${file}    .
        Log_To_Console  ${file0_split}[0]
        ${file1_split}=    Split String    ${file0_split}[0]    _
        Log_To_Console  ${file1_split}[0]

        ${old1_csv_content}=    Get File    stock_csv_new_2023/${file1_split}[0]_2023.csv    encoding=UTF-8-SIG    encoding_errors=strict
        @{list_pre_1}=  Read Csv String To List  ${old1_csv_content}


        ${old0_csv_content}=    Get File    stock_csv_new_kd_rsv/${file1_split}[0]_rsv_${file1_split}[1][0:4].csv    encoding=UTF-8-SIG    encoding_errors=strict
        @{list_pre_0}=  Read Csv String To List  ${old0_csv_content}






        @{list_1}=  Read Csv String To List  ${old1_csv_content} 

        @{list_0}=  Read Csv String To List  ${old0_csv_content} 
        ${list_0_j-1}=  set variable  ${list_0}[-1]



            ${csv_string}=  set variable  ${empty}
            ${high_low_by_array}=  set variable  ${empty}

#            ${yesterday_k}=  set variable  0
#            ${yesterday_d}=  set variable  0
            ${yesterday_macd}=  set variable  0
            ${yesterday_ema12}=  set variable  ${list_0_j-1}[10]
            ${yesterday_ema26}=  set variable  ${list_0_j-1}[11]
#            ${today_k}=  set variable  0
#            ${today_d}=  set variable  0
            ${today_macd}=  set variable  0
            ${today_ema12}=  set variable  0
            ${today_ema16}=  set variable  0

            ${length}=  Get length  ${list_1}
            ${length+1}=  evaluate  ${length} + 1

            ${highest9}=  Create List  ${EMPTY}
            ${lowest9}=  Create List  ${EMPTY}
            ${rsv9}=  Create List  ${EMPTY}

            FOR  ${j}  IN RANGE  1  ${length+1}  1 

                


                log list  ${highest9}
                ${length_highest9}=  Get length  ${highest9}
                IF  ${length_highest9} == 0
                    Append To List  ${highest9}  0 
                END
                Append To List  ${highest9}  0 

                log list  ${lowest9}
                ${length_lowest9}=  Get length  ${lowest9}
                IF  ${length_lowest9} == 0
                    Append To List  ${lowest9}  999999999 
                END
                Append To List  ${lowest9}  999999999

                log list  ${rsv9}
                ${length_rsv9}=  Get length  ${rsv9}
                IF  ${length_rsv9} == 0
                    Append To List  ${rsv9}  0 
                END
                Append To List  ${rsv9}  0 






                    


                    ${j-1}=  evaluate  ${j} - 1
                    IF  ${j-1} < 0
                        ${list_0_j-1}=  set variable  ${list_0}[${j-1}]
                        ${list_i_j-1_5}=  set variable  ${list_0_j-1}[5]
                        ${list_i_j-1_6}=  set variable  ${list_0_j-1}[6]
                        ${list_i_j-1_4}=  set variable  ${list_0_j-1}[4]
                    ELSE
                        ${list_1_j-1}=  set variable  ${list_1}[${j-1}]
                        ${list_i_j-1_5}=  set variable  ${list_1_j-1}[5]
                        ${list_i_j-1_6}=  set variable  ${list_1_j-1}[6]
                        ${list_i_j-1_4}=  set variable  ${list_1_j-1}[4]
                    END
                    
#                    ${j-0}=  evaluate  ${j} - 0
#                    IF  ${j-0} < 0
#                        ${list_0_j-0}=  set variable  ${list_0}[${j-0}]
#                        ${list_i_j-0_5}=  set variable  ${list_0_j-0}[5]
#                        ${list_i_j-0_6}=  set variable  ${list_0_j-0}[6]
#                    ELSE
#                        ${list_1_j-0}=  set variable  ${list_1}[${j-0}]
#                        ${list_i_j-0_5}=  set variable  ${list_1_j-0}[5]
#                        ${list_i_j-0_6}=  set variable  ${list_1_j-0}[6]
#                    END

 

                    log  ${list_i_j-1_4}*2/(12+1) + ${yesterday_ema12}*(12-1)/(12+1)
                    ${today_ema12}=  evaluate  ${list_i_j-1_4}*2/(12+1) + ${yesterday_ema12}*(12-1)/(12+1)

                    log  ${list_i_j-1_4}*2/(26+1) + ${yesterday_ema12}*(26-1)/(26+1)
                    ${today_ema26}=  evaluate  ${list_i_j-1_4}*2/(26+1) + ${yesterday_ema26}*(26-1)/(26+1)


                    log  ${today_ema12}-${today_ema26}]
                    
		    ${dif}=  evaluate  ${today_ema12}-${today_ema26}

                    log  ${dif}*2/(9+1) + ${yesterday_macd}*(9-1)/(9+1)

                    ${today_macd}=  evaluate  ${dif}*2/(9+1) + ${yesterday_macd}*(9-1)/(9+1)








                ${list_i_j-1_0}=  set variable  ${list_1_j-1}[0]
                ${list_i_j-1_1}=  set variable  ${list_1_j-1}[1]
                ${list_i_j-1_2}=  set variable  ${list_1_j-1}[2]
                ${list_i_j-1_3}=  set variable  ${list_1_j-1}[3]
                ${list_i_j-1_4}=  set variable  ${list_1_j-1}[4]
                ${list_i_j-1_5}=  set variable  ${list_1_j-1}[5]
                ${list_i_j-1_6}=  set variable  ${list_1_j-1}[6]
                ${list_i_j-1_7}=  set variable  ${list_1_j-1}[7]
                ${list_i_j-1_8}=  set variable  ${list_1_j-1}[8]
                ${list_i_j-1_9}=  set variable  ${list_1_j-1}[9]









                ${file_exists}=  Run Keyword And Return Status  OperatingSystem.File_Should_Exist   stock_csv_new_macd_dif/${file1_split}[0]_dif_${file1_split}[1].csv

                IF  '${file_exists}' == 'False'
                    Copy File  lvr_landcsv/a_lvr_land_a_header.csv  stock_csv_new_macd_dif/${file1_split}[0]_dif_${file1_split}[1].csv
                    Append To File   stock_csv_new_macd_dif/${file1_split}[0]_dif_${file1_split}[1].csv   日期,股票代碼,成交量,成交金額,開盤價,最高價,最低價,收盤價,漲跌幅,交易筆數,today_ema12,today_ema26,dif,today_macd\n
                END




                ${macd_dif_value}=   set variable  ${list_i_j-1_0},${list_i_j-1_1},${list_i_j-1_2},${list_i_j-1_3},${list_i_j-1_4},${list_i_j-1_5},${list_i_j-1_6},${list_i_j-1_7},${list_i_j-1_8},${list_i_j-1_9},${today_ema12}],${today_ema26},${dif},${today_macd}
                log  ${macd_dif_value}

                ${macd_dif_by_array}=  set variable  ${macd_dif_value}

                log  ${macd_dif_by_array}


                ${csv_string}=  set variable  ${macd_dif_by_array}\n
                log  ${csv_string}

                Append To File   stock_csv_new_macd_dif/${file1_split}[0]_dif_${file1_split}[1].csv   ${csv_string}

#                ${yesterday_k}=  set variable  ${today_k}
#                ${yesterday_d}=  set variable  ${today_d}
                ${yesterday_macd}=  set variable  ${today_macd}


            END


    END

    Log_To_Console    Max CSV file: ${max_file}
    Log    Max CSV file: ${max_file}
    Log_To_Console    Max num: ${max_num}
    ${int_max_num}=    Convert_To_Integer    ${max_num}
    ${str_max_num}=    Convert_To_String    ${max_num}
    Log_To_Console    int Max num: ${int_max_num}
    Log_To_Console    str Max num: ${str_max_num}























