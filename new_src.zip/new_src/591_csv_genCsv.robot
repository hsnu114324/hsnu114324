*** Keywords ***
591_csv_genCsv

    [Arguments]     ${ii}      ${path_csv}   
    Log   ${ii}
    Log_To_Console  path_csv : ${path_csv}





    ${old_csv_content}=    Get File    lvr_landcsv/${path_csv}    encoding=UTF-8-SIG    encoding_errors=strict
    @{list_csv_before_yesterday}=  Read Csv String To List  ${old_csv_content}
    ${list_csv_by_cnt}=    Get length    ${list_csv_before_yesterday}
            
    FOR  ${old_j}  IN RANGE  0  ${list_csv_by_cnt}  1

        ${s1_by_array}=  get_from_list  ${list_csv_before_yesterday}  ${old_j}

        Log  s1_by_array ${s1_by_array}
        Log  ${s1_by_array}[2]
        Log  ${s1_by_array}[33]
        Log  ${s1_by_array}[34]
        Log  ${s1_by_array}[35]
        Log  ${s1_by_array}[36]


        ${s1_substring} =    Get Substring   ${s1_by_array}[33]   0   7
        log  ${s1_substring}
        ${s2_substring} =    Get Substring   ${s1_by_array}[33]   0   7
        log  ${s2_substring}
 



                ${file_exists}=  Run Keyword And Return Status  OperatingSystem.File_Should_Exist   591_csv/${ii}_lvr_land_a_gps_${s1_subsring}[3:6]_${s2_substring}[4:7].csv
 
                IF  '${file_exists}' == 'False'
                    Copy File  lvr_landcsv/a_lvr_land_a_header.csv  591_csv/${ii}_lvr_land_a_gps_${s1_substring}[3:6]_${s2_substring}[4:7].csv
                END

            

            ${csv_string}=  set variable  ${empty}
            ${str_s1_by_array}=   Evaluate  ",".join(${s1_by_array})   

            ${csv_string}=  set variable  ${str_s1_by_array}\n
            log  ${csv_string}

            Append To File   591_csv/${ii}_lvr_land_a_gps_${s1_substring}[3:6]_${s2_substring}[4:7].csv  ${csv_string}


    END







