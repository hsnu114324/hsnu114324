*** Keywords ***
test_stock_sql_insert_daily_stock_test
#    [Arguments]    ${excel_file_data}
#    [Arguments]  ${start_date}  ${end_date}
    [Documentation]
    [Tags]
#    Connect To Database
#    ...    pymssql
#    ...    dbName=DLIQSERV
#    ...    dbUsername=DLIQTASK
#    ...    dbPassword=DLIQTASK3817
#    ...    dbHost=10.201.52.130
#    ...    dbPort=1433



    




    Connect To Database Using Custom Params  sqlite3  database="./test.db"


#    ${output}=   Execute Sql String     CREATE TABLE ${table_name} ( ${name_1} ${type_1}, ${name_2} ${type_2}, ${name_3} ${type_3}, ${name_4} ${type_4}, ${name_5} ${type_5}, ${name_6} ${type_6}, ${name_7} ${type_7}, ${name_8} ${type_8}, ${name_9} ${type_9}, ${name_10} ${type_10} ) ;
#    Log  ${output}


    ${table_name}=  set variable  daily_stock
    ${name_1}=      set variable  date 
    ${type_1}=      set variable  DATE
    ${name_2}=      set variable  stock_id
    ${type_2}=      set variable  varchar(100)
    ${name_3}=      set variable  Trading_Volume
    ${type_3}=      set variable  INT
    ${name_4}=      set variable  Trading_money
    ${type_4}=      set variable  INT
    ${name_5}=      set variable  open
    ${type_5}=      set variable  FLOAT
    ${name_6}=      set variable  max
    ${type_6}=      set variable  FLOAT
    ${name_7}=      set variable  min
    ${type_7}=      set variable  FLOAT
    ${name_8}=      set variable  close
    ${type_8}=      set variable  FLOAT
    ${name_9}=      set variable  spread
    ${type_9}=      set variable  FLOAT
    ${name_10}=     set variable  Trading_turnover
    ${type_10}=     set variable  INT


    ${output}=   Execute Sql String     CREATE TABLE ${table_name} ( ${name_1} ${type_1}, ${name_2} ${type_2}, ${name_3} ${type_3}, ${name_4} ${type_4}, ${name_5} ${type_5}, ${name_6} ${type_6}, ${name_7} ${type_7}, ${name_8} ${type_8}, ${name_9} ${type_9}, ${name_10} ${type_10} ) ;
    Log  ${output}







#    ${folder}=    set variable    ../stock_csv    # 更換成目標資料>夾的路徑



#    ${date_range}=  finmind_GetDateRange  ${start_date}  ${end_date}  


#  FOR  ${date}  IN  @{date_range}

#  log_to_console  date: ${date}

#    ${file_exists}=  Run Keyword And Return Status  OperatingSystem.File_Should_Exist   ${folder}/${date}.csv
#    IF  '${file_exists}' == 'False'
#        CONTINUE FOR LOOP 
#    END
    
    @{list_csv_before_yesterday}=  read_csv_file_to_list  Excel/daily_stock.csv
    ${list_csv_by_cnt}=    Get length    ${list_csv_before_yesterday}
    Log  list_csv_by_cnt ${list_csv_by_cnt}



    FOR  ${i}  IN RANGE  1  ${list_csv_by_cnt}  1

        ${data}=     get from list  ${list_csv_before_yesterday}  ${i}
#        ${data_1}=   set variable  ${data}[0]
#        ${data_2}=   set variable  ${data}[1]
#        ${data_3}=   set variable  ${data}[2]
#        ${data_4}=   set variable  ${data}[3]
#        ${data_5}=   set variable  ${data}[4]
#        ${data_6}=   set variable  ${data}[5]
#        ${data_7}=   set variable  ${data}[6]
#        ${data_8}=   set variable  ${data}[7]
#        ${data_9}=   set variable  ${data}[8]
#        ${data_10}=  set variable  ${data}[9]
#
#        ${output}=    Execute Sql String    INSERT INTO ${table_name} VALUES ( '${data_1}', '${data_2}', ${data_3}, ${data_4}, ${data_5}, ${data_6}, ${data_7}, ${data_8}, ${data_9}, ${data_10} )

        ${output}=    Execute Sql String    INSERT INTO ${table_name} VALUES ( '${data}[0]', '${data}[1]', ${data}[2], ${data}[3], ${data}[4], ${data}[5], ${data}[6], ${data}[7], ${data}[8], ${data}[9] )
#        Log  ${output}


    END

#  END

