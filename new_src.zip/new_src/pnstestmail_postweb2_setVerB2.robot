*** Keywords ***
pnstestmail_postweb2_setVerB2



#    [Arguments] 	${path_excel}  ${sheet_name}
#    Log_To_Console	path_excel : ${path_excel}
#    Log_To_Console	sheet_name : ${sheet_name}
    
    [Arguments] 	${excel_file_data}  ${q_sid}
	[Documentation]
	[Tags]
#***


		Log  ${excel_file_data}
		Log  ${excel_file_data}[26]
		Log  ${excel_file_data}[27] 


#***
#		post_postweb2_pnsFrontEndlogin  https://pnstest.post.gov.tw/LI.Web/Quest.aspx?q_sid=08FE0PujSqB


    IF  '${excel_file_data}[26]' == 'web'
    
        post_postweb2_pnsFrontEndloginbyExcel  ${excel_file_data}[27] 

    ELSE IF  '${excel_file_data}[26]' == 'sql'

        post_postweb2_pnsFrontEndloginbyExcel  ${q_sid}

    ELSE
        Fail
    END

        Take Screenshot

#***


		post_postweb2_ClickPnstestmailFrontEndLoginEnter
#		Sleep  5s
#***

		post_postweb2_ClickPnsFrontEndQ2_VerB
		post_postweb2_ClickPnsFrontEndQ3_VerB
		post_postweb2_ClickPnsFrontEndQ4_VerB
		post_postweb2_ClickPnsFrontEndQ5_VerB  ${excel_file_data}[6]
		post_postweb2_ClickPnsFrontEndQ6_VerB
		post_postweb2_ClickPnsFrontEndQ7_VerB
		post_postweb2_ClickPnsFrontEndQ8_1_VerB
		post_postweb2_ClickPnsFrontEndQ8_2_VerB
		post_postweb2_ClickPnsFrontEndQ8_3_VerB
#		post_postweb2_ClickPnsFrontEndQ9_VerA
        Take Screenshot



    IF  '${excel_file_data}[35]' == 'y'
    
		post_postweb2_ClickPnsFrontEnd_cbTreatyConfirm
		post_postweb2_ClickPnsFrontEnd_Submit
		Sleep  1s 

    ELSE IF  '${excel_file_data}[35]' == 'n'

        Take Screenshot

    ELSE
        Fail
    END



#	[Return]  ${CR_no}
