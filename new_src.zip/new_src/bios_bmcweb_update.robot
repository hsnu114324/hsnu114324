*** Keywords ***
bios_bmcweb_update

	wistron_bmcweb_logout
###
  FOR  ${i}  IN RANGE  2
	wistron_bmcweb_login

	wistron_bmcweb_GoToPage  ${url_FW_upgrade}

	${BiosVersion}=   wistron_ipmi_GetBiosVersion
    Log_To_Console  BiosVerion ${BiosVersion}
	wistron_bmcweb_ExpectPowerOn

	${BiosVersion_match}=	Get Regexp Matches	${BiosVersion}		09
	IF	${BiosVersion_match}
		${BiosVersion_major}	Set Variable	${EMPTY}
		${BiosVersion_major}	Set Variable	0a
		Log_To_Console  BiosVersion_major ${BiosVersion_major}
		Log_To_Console  ${BiosVersion}
		Log_To_Console  Update UT20_BIOS_010_enc.hpm
		wistron_bmcweb_ChooseBiosImage  UT20_BIOS_010_enc.hpm
	ELSE
		${BiosVersion_major}	Set Variable	${EMPTY}
		${BiosVersion_major}	Set Variable	09
		Log_To_Console  BiosVersion_major ${BiosVersion_major}
		Log_To_Console  ${BiosVersion}
		Log_To_Console  Update UT20_BIOS_009_enc.hpm
		wistron_bmcweb_ChooseBiosImage  UT20_BIOS_009_enc.hpm
	END

	wistron_bmcweb_ClickFirmwareUpdateButton1
	wistron_bmcweb_ClickFirmwareUpdateButton2

	wistron_bmcweb_logout

###
	wistron_ipmi_PowerCycle
	sleep  10s
	wistron_ssh_WaitPowerOn

	${target_BiosVersion}=   wistron_ipmi_GetBiosVersion
    	Should Be Equal    ${target_BiosVersion}    ${BiosVersion_Major}

  END



