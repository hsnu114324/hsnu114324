*** Variables ***


*** Keywords ***
kvm_timeout


    FOR  ${i}  IN RANGE  3

        wistron_bmcweb_logout
        wistron_bmcweb_login



#***

        wistron_bmcweb_GoToPage  ${url_services}
#***
        Click Element    ${xpath_kvm_edit}

        Wait Until Element Is Enabled    ${xpath_input_kvm_timeout_value}    timeout=${BROWSER_CONNECTION_TIMEOUT}
        Wait Until Element Is Enabled    ${xpath_button_kvm_setting_saving}    timeout=${BROWSER_CONNECTION_TIMEOUT}
        Input Text    ${xpath_input_kvm_timeout_value}    ${kvm_timeout_value}

        Click Element    ${xpath_button_kvm_setting_saving}
        Handle Alert

        Sleep  3



#***

        wistron_bmcweb_GoToPage  ${url_remote_control}
        Click Element    ${xpath_H5View_button}
        Sleep  3

        ${titles}  Get Window Titles
        Log_To_Console  ${titles}
        ${titles2}      Get From List   ${titles}   1
        Log_To_Console  ${titles2}
        ${titles1}      Get From List   ${titles}   0
        Log_To_Console  ${titles1}
        Switch Window    title=${titles2}

        Sleep    ${kvm_timeout_value}

	FOR  ${i}  IN RANGE  10
        	Sleep   10
        	Capture Page Screenshot  kvm_timeout-${i}.png
        	${string_alert}=   Get Text  ${xpath_kvm_timeout_string}
        	Log_To_Console   string_alert ${string_alert}
		${timeout_string_match}=   Get Regexp Matches      ${string_alert}         KVM Session Timed-out. Closing the Viewer...
		Log_To_Console	string_alert ${string_alert}
		Log_To_Console	timeout_string_match ${timeout_string_match}

		Exit For Loop IF   ${timeout_string_match} == ['KVM Session Timed-out. Closing the Viewer...']    

	END

        Log_To_Console   ${string_alert}

        Capture Page Screenshot  kvm_timeout.png

        ${result}=    Should Contain  ${string_alert}    KVM Session Timed-out. Closing the Viewer...

        Log_To_Console   ${result}


#***
        wistron_bmcweb_logout

    END
