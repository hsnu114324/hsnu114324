*** Keywords ***
test_stock_sql_create_kdj_table
#    [Arguments]  ${start_date}  ${end_date}
    [Documentation]
    [Tags]


    Connect To Database Using Custom Params  sqlite3  database="./test.db"


                ${table_name}=  set variable  daily_stock_kdj
                ${name_1}=      set variable  date
                ${type_1}=      set variable  DATE
                ${name_2}=      set variable  stock_id
                ${type_2}=      set variable  varchar(100)

                ${name_3}=      set variable  today_rsv
                ${type_3}=      set variable  FLOAT

                ${name_4}=      set variable  today_k
                ${type_4}=      set variable  FLOAT
                ${name_5}=      set variable  today_d
                ${type_5}=      set variable  FLOAT
                ${name_6}=      set variable  today_3d-2k
                ${type_6}=      set variable  FLOAT
                ${name_7}=      set variable  today_3k-2d
                ${type_7}=      set variable  FLOAT


    ${output}=   Execute Sql String     CREATE TABLE ${table_name} ( ${name_1} ${type_1}, ${name_2} ${type_2}, ${name_3} ${type_3}, ${name_4} ${type_4}, ${name_5} ${type_5}, [${name_6}] ${type_6}, [${name_7}] ${type_7} ) ;
    Log  ${output}









