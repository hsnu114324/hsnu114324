*** Keywords ***
dms_dmsweb2_2900_mail_transfer
    [Arguments]  ${excel_file_data}
 
#  ${MON_PAY}
	[Documentation]
	[Tags]
#***

    Log  ${excel_file_data}

#***
	dms_postweb2_pnsFrontEndloginChrome  http://localhost:3000/





    dms_dmsweb2_ClickDmsFrontEnduserID_login

	dms_dmsweb2_ClickDmsFrontEndMenuButton
#***
	dms_dmsweb2_ClickDmsFrontEndMenu_ListOP1
#***
	dms_dmsweb2_ClickDmsFrontEndMenu_ListOP1_2900
#***
	dms_dmsweb2_ClickDmsFrontEnd_2000ACC_DATE  ${excel_file_data}[1]
#***
	dms_dmsweb2_ClickDmsFrontEnd_2000TOUR_NO  ${excel_file_data}[2]
#***
#    dms_dmsweb2_ClickDmsFrontEnd_2000STAFF_NO



	dms_dmsweb2_ClickDmsFrontEnd_2000FetchButton  













         
    Take Screenshot

    ${match1}  ${match2}=    dms_dmsweb2_DmsFrontEnd_2000_stage1_1  ${excel_file_data}    login   2900

    Log  ${match1}
    Log  ${match2}







    ${match2}  ${match3}=    dms_dmsweb2_DmsFrontEnd_2000_stage1_i  ${match2}  ${excel_file_data}    login  2900

    Log  ${match2}
    Log  ${match3}


    ${match1}  ${match2}=    dms_dmsweb2_DmsFrontEnd_2000_stage22_1  ${excel_file_data}  transfer  2900 

    Log  ${match1}
    Log  ${match2}

    ${match2}  ${match3}=    dms_dmsweb2_DmsFrontEnd_2000_stage22_i  ${match2}  ${excel_file_data}  transfer  2900    

    Log  ${match2}
    Log  ${match3}



#************************************************


    dms_dmsweb2_DmsFrontEnd_2000_stage3_transfer_fetch   ${excel_file_data}  2900


    ${match1}  ${match2}=    dms_dmsweb2_DmsFrontEnd_2000_stage3_1  ${excel_file_data}  2900

    Log  ${match1}
    Log  ${match2}

    ${match2}  ${match3}=    dms_dmsweb2_DmsFrontEnd_2000_stage3_i  ${match2}  ${excel_file_data}  2900

    Log  ${match2}
    Log  ${match3}      


	
    dms_dmsweb2_ClickDmsFrontEnduserID_logout 

    Sleep  3s

#	Return  ${CR_no}
