*** Variables ***
${fan_target_pwm_80}	  0x50
${inlet_rotor_minimum_80}    11980
${inlet_rotor_maximum_80}    14643
${outlet_rotor_minimum_80}   10948
${outlet_rotor_maximum_80}	  13381


*** Keywords ***
fan_ipmi_set80
	wistron_ipmi_FanSetManual
	wistron_ipmi_FanSet	${fan_target_pwm_80}
	wistron_ipmi_FanGetDuty  ${inlet_rotor_minimum_80}    ${inlet_rotor_maximum_80}    ${outlet_rotor_minimum_80}    ${outlet_rotor_maximum_80}
	wistron_ipmi_FanSetAuto


