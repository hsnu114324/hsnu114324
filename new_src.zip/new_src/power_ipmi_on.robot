*** Keywords ***

power_ipmi_on
	[Documentation]
	[Tags]
#***
	wistron_bmcweb_login
	wistron_bmcweb_ExpectPowerOff
	wistron_bmcweb_logout

#***
#
#***
#
#***
	wistron_ipmi_PowerOn
#***
	wistron_ipmi_WaitPowerOn
#***
	wistron_ssh_WaitPowerOn
#***
	wistron_bmcweb_login
	wistron_bmcweb_GoToPage  ${url_event_log_ipmi}
#***
	wistron_bmcweb_ExpectOemEventLog  
#***
	wistron_bmcweb_logout



