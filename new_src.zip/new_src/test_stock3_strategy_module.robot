*** Keywords ***
#*** Test Cases ***
test_stock3_strategy_module
#    [Arguments]     ${excel_file_name}  ${sheet_name}
    [Arguments]     ${excel_file_data}  
    [Documentation]    Load sensor list file and prepare list
#    Log_To_Console   excel_file_name : ${excel_file_name}
#    Log_To_Console   sheet_name : ${sheet_name}
    Log    ${excel_file_data}



    Connect To Database Using Custom Params  sqlite3  database="./test.db"

    ${query_start_date}=  set variable  '2024-01-01'
    ${query_end_date}=    set variable  '2024-04-01'

#    ${str_start_date}=  set_variable   2023-01-01
#    ${str_end_date}=    set_variable   2024-03-31



#    ${date_range}=  finmind_GetDateRange  ${start_date}  ${end_date}







    ${output}=    Query    SELECT DATE,stock_id,Trading_Volume,Trading_money,open,max,min,close,spread,Trading_turnover FROM daily_stock WHERE stock_id = '2330' AND DATE between ${query_start_date} and ${query_end_date} order by DATE ;
    Log  ${output}



    ${output_k}=    Query  SELECT DISTINCT today_k,DATE FROM daily_stock_kdj WHERE stock_id = '2330' AND DATE between ${query_start_date} and ${query_end_date} order by DATE ;
    Log  ${output_k}

    ${output_d}=    Query  SELECT DISTINCT today_d,DATE FROM daily_stock_kdj WHERE stock_id = '2330' AND DATE between ${query_start_date} and ${query_end_date} order by DATE ;
    Log  ${output_d}


#    ${output_DATE}=    Query  SELECT DISTINCT DATE FROM daily_stock WHERE stock_id = '2330' AND DATE between ${query_start_date} and ${query_end_date} order by DATE ;
#    Log  ${output_DATE}

  ${strategy_id}=  set variable  1 
#  ${buyin}=  set variable  0
  ${buyin_signal}=  set variable  0
  ${buyin_signal_volume}=  set variable  0
  ${buyin_among_NTD}=  set variable  0



  ${date_length}=  get length  ${output_k}

  FOR  ${i}  IN RANGE  ${date_length}

        log  ${output_k}[${i}]
        log  ${output_d}[${i}]

        log  ${output_k}[${i}][0]
        log  ${output_d}[${i}][0]

    ${today_close}=  set variable  ${output}[${i}][7]     

        IF  ${output_k}[${i}][0] > ${output_d}[${i}][0]
            ${buyin_signal}=  set variable  1
            ${buyin_signal_volume}=  set variable  10
            ${buyin_among_NTD}=  evaluate  ${buyin_signal} * ${today_close} * ${buyin_signal_volume} 
	ELSE
            ${buyin_signal}=  set variable  0
            ${buyin_signal_volume}=  set variable  0
            ${buyin_among_NTD}=  evaluate  ${buyin_signal} * ${today_close} * ${buyin_signal_volume} 
        END



    ${today_date}=  set variable  ${output_k}[${i}][1]     
    ${today_stock_id}=  set variable  2330     

#    ${today_stock_id}=  set variable  ${output}[${i}][1]     
#    ${today_trading_volume}=  set variable  ${output}[${i}][2]     
#    ${today_trading_money}=  set variable  ${output}[${i}][3]     
#    ${today_open}=  set variable  ${output}[${i}][4]     
#    ${today_high}=  set variable  ${output}[${i}][5]     
#    ${today_low}=  set variable  ${output}[${i}][6]     
#    ${today_close}=  set variable  ${output}[${i}][7]     
#    ${today_spread}=  set variable  ${output}[${i}][8]     
#    ${today_trading_turnover}=  set variable  ${output}[${i}][9]     
 

#                    log  ( ${today_close}*2 + ${yesterday_ema12}*(12-1) )/(12+1)
#                    ${today_ema12}=  evaluate  ( ${today_close}*2 + ${yesterday_ema12}*(12-1) )/(12+1)

#                    log  ( ${today_close}*2 + ${yesterday_ema26}*(26-1) )/(26+1)
#                    ${today_ema26}=  evaluate  ( ${today_close}*2 + ${yesterday_ema26}*(26-1) )/(26+1)


#                    log  ${today_ema12}-${today_ema26}
                    
#		    ${dif}=  evaluate  ${today_ema12}-${today_ema26}

#                    log  ( ${dif}*2 + ${yesterday_macd}*(9-1) )/(9+1)

#                    ${today_macd}=  evaluate  ( ${dif}*2 + ${yesterday_macd}*(9-1) )/(9+1)

















                ${file_exists}=  Run Keyword And Return Status  OperatingSystem.File_Should_Exist   stock_csv_new_macd_dif/${strategy_id}_strategy_${today_date}[0:4].csv

                IF  '${file_exists}' == 'False'
                    Copy File  lvr_landcsv/a_lvr_land_a_header.csv  stock_csv_new_macd_dif/${strategy_id}_strategy_${today_date}[0:4].csv
                    Append To File   stock_csv_new_macd_dif/${strategy_id}_strategy_${today_date}[0:4].csv   日期,策略代號,買入訊號,股票代碼,收盤價,成交量,成交金額\n
#                    Append To File   stock_csv_new_macd_dif/${strategy_id}_strategy_${today_date}[0:4].csv   日期,策略代號,股票代碼,收盤價,成交量,成交金額,開盤價,最高價,最低價,收盤價,漲跌幅,交易筆數,today_ema12,today_ema26,dif,today_macd\n
                END




#                ${macd_dif_value}=   set variable  ${list_i_j-1_0},${list_i_j-1_1},${list_i_j-1_2},${list_i_j-1_3},${list_i_j-1_4},${list_i_j-1_5},${list_i_j-1_6},${list_i_j-1_7},${list_i_j-1_8},${list_i_j-1_9},${today_ema12}],${today_ema26},${dif},${today_macd}
#                ${macd_dif_value}=   set variable  ${today_date},${today_stock_id},${today_trading_volume},${today_trading_money},${today_open},${today_high},${today_low},${today_close},${today_spread},${today_trading_turnover},${today_ema12},${today_ema26},${dif},${today_macd}
#                log  ${macd_dif_value}

#                ${macd_dif_by_array}=  set variable  ${macd_dif_value}

#                log  ${macd_dif_by_array}


                ${csv_string}=  set variable  ${today_date}, ${strategy_id}, ${buyin_signal}, ${today_stock_id}, ${today_close}, ${buyin_signal_volume}, ${buyin_among_NTD}\n
                log  ${csv_string}

                Append To File   stock_csv_new_macd_dif/${strategy_id}_strategy_${today_date}[0:4].csv   ${csv_string}

#                ${yesterday_k}=  set variable  ${today_k}
#                ${yesterday_d}=  set variable  ${today_d}
#                ${yesterday_macd}=  set variable  ${today_macd}
#                ${yesterday_ema12}=  set variable  ${today_ema12}
#                ${yesterday_ema26}=  set variable  ${today_ema26}


  END

























