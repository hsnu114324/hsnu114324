*** Keywords ***
dms_dmsweb2_a100_OP
    [Arguments]  ${excel_file_data}

	[Documentation]
	[Tags]
#***

    Log  ${excel_file_data}

#***
	dms_dmsweb2_pnsFrontEndloginChrome  http://localhost:3000/
#	post_postweb2_pnsFrontEndloginFirefox  https://pnstest.post.gov.tw/LI.Web/LI0010.aspx


#    Debug

    dms_dmsweb2_ClickDmsFrontEnduserID_OP_login

	dms_dmsweb2_ClickDmsFrontEndMenuButton
#***
	dms_dmsweb2_ClickDmsFrontEndMenu_ListMM1
#***
	dms_dmsweb2_ClickDmsFrontEndMenu_ListMM1_a100
#***
	dms_dmsweb2_ClickDmsFrontEndMenu_ListMM1_a100_BSC
#***
	dms_dmsweb2_ClickDmsFrontEndMenu_ListMM1_a100_BSC_20OP
#***
	dms_dmsweb2_ClickDmsFrontEndMenu_ListMM1_a100_BSC_20OP_1
#***
	dms_dmsweb2_ClickDmsFrontEndMenu_ListMM1_a100_BSC_DATE  ${excel_file_data}[1]
#	dms_dmsweb2_ClickDmsFrontEndMenu_ListMM1_a100_BSC_today_button
#***    
	dms_dmsweb2_ClickDmsFrontEndMenu_ListMM1_a100_BSC_TOUR_NO  ${excel_file_data}[2]
#	dms_dmsweb2_ClickDmsFrontEndMenu_ListMM1_a100_BSC_plus_button
#***
	dms_dmsweb2_ClickDmsFrontEndMenu_ListMM1_a100_BSC_save_button
#***

#***
	dms_dmsweb2_ClickDmsFrontEndMenu_ListMM1_a100_BSC_20OP_3
#***
	dms_dmsweb2_ClickDmsFrontEndMenu_ListMM1_a100_BSC_DATE  ${excel_file_data}[1]
#	dms_dmsweb2_ClickDmsFrontEndMenu_ListMM1_a100_BSC_today_button
#***
	dms_dmsweb2_ClickDmsFrontEndMenu_ListMM1_a100_BSC_TOUR_NO  ${excel_file_data}[2]
#	dms_dmsweb2_ClickDmsFrontEndMenu_ListMM1_a100_BSC_plus_button
#***
	dms_dmsweb2_ClickDmsFrontEndMenu_ListMM1_a100_BSC_save_button
#***

	

 


#***
	dms_dmsweb2_ClickDmsFrontEnduserID_logout

#	RETURN  ${CR_no}
