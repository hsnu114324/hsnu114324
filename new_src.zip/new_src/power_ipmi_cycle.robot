*** Keywords ***

power_ipmi_cycle
	[Documentation]
	[Tags]
#***
	wistron_bmcweb_login
	wistron_bmcweb_ExpectPowerOn
	wistron_bmcweb_logout

#***
#
#***
#
#***
	wistron_ipmi_PowerCycle
#***
	wistron_ipmi_WaitPowerOff
	wistron_ipmi_WaitPowerOn
#***
	wistron_ssh_WaitPowerOn
#***
	wistron_bmcweb_login
	wistron_bmcweb_GoToPage  ${url_event_log_ipmi}
#***
	wistron_bmcweb_ExpectOemEventLog  
#***
	wistron_bmcweb_logout



