*** Variables ***
#${SOL_BIOS_OUTPUT}    ubuntu
#${IPMI_SOL_LOG_FILE}    IPMI_SOL_LOG_FILE.txt
#
##${BROWSER}  
##${URL}      https://www.google.com.tw/
#${URL}	    https://finmindtrade.com/
#
#${xpath_finmind_processing_image_1}	xpath=/html/body/div/div[1]/div/div[8]
#${xpath_finmind_processing_image_2}	xpath=//*[@id="Layer_1"]/rect[3]
#
#${xpath_finmind_login1_element}		xpath=/html/body/div/header[1]/div/div/div[2]/div[1]/ul/li[1]/a
#${xpath_login}	xpath=//*[@id="app"]/div/div[1]/div[1]/div[2]/div/div/div/div/div[2]/button
#
#${xpath_select_button_1}	xpath=//*[@id="__BVID__43___BV_tab_button__"]
#${xpath_select_button_2}	xpath=//*[@id="__BVID__48___BV_tab_button__"]
#${xpath_select_button_3}	xpath=//*[@id="__BVID__48"]/div/button
#${xpath_select_button_4}	xpath=//*[@id="app"]/div/div[3]/div[1]/div/div[3]/div/div/div[1]/div[1]/button
#
#${xpath_date_input}	xpath=//*[@id="__BVID__48"]/div/div/div/div/div/input
#
#${xpath_full_member_warning}	xpath=//*[@id="app"]/div/div[3]/div[1]/div/div[3]/div/div/h4
#
#${xpath_finmind_timeout_value}	30s
#
#${finmind_target_date}		2023-03-01 ~ 2023-03-01
#
*** Keywords ***
test_finmind


    ${date}=    Set Variable    20230201
    ${date_range}=    Set Global Variable    ${date} ~ ${date}
    Log    ${date_range}

#    Open Browser    ${URL}    ${BROWSER}
    Open Browser    ${URL}    ${GUI_BROWSER}
    Maximize Browser Window
#    Input Text      name=q    robot framework
#    Press Keys      name=q    RETURN
#    Wait Until Page Contains Element    css=.g
    Title Should Be  FinMind

#    Launch Browser And Login GUI
#    Wait Until Page Contains    FinMind    timeout=${xpath_finmind_timeout_value}

    Wait Until Element Is Not Visible    ${xpath_finmind_processing_image_1}    timeout=${xpath_finmind_timeout_value}
    Wait Until Element Is Visible    ${xpath_finmind_login1_element}    timeout=${xpath_finmind_timeout_value}
    sleep  1s
    Click_Element  ${xpath_finmind_login1_element}
    Click_Element  ${xpath_select_button_1}
    Click_Element  ${xpath_select_button_2}
    Input_Text	${xpath_date_input}	${finmind_target_date}
    Click_Element  ${xpath_select_button_3}

    Wait_Until_Element_Is_Not_Visible    ${xpath_finmind_processing_image_2}    timeout=${xpath_finmind_timeout_value}
    ${warning} =    Run_Keyword_And_Return_Status    Wait_Until_Page_Contains_Element   ${xpath_full_member_warning}
    Log_To_Console  ${warning}
    IF  '${warning}' == 'True'
	Log_To_Console	should login full member
    ELSE
    	Log_To_Console  ok!
    END


    Click_Element  ${xpath_select_button_4}
    sleep  10s
    Capture Page Screenshot
    sleep  10s
    Close Browser














