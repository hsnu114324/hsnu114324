*** Variables ***
${xpath_pnsFrontEnd_username}                 xpath=//*[@id="txtUserId"]
${xpath_pnsFrontEnd_password}                 xpath=//*[@id="txtInfo"]
${xpath_pnsFrontEnd_enterbutton}              xpath=//*[@id="btnLogin"]

${xpath_PnsFrontEndMenu_List2}                xpath=//*[@id="MenuList"]/li/a[2]/span[1]
${xpath_PnsFrontEndMenu_List2Button1}         xpath=//*[@id="MenuList"]/li/ul[2]/li[1]/a 
${xpath_PnsFrontEndbtnQuery}                  xpath=//*[@id="BodyMainContent_btnQuery"]
${xpath_PnsFrontEndlbtnReqNo_0}               xpath=//*[@id="BodyMainContent_gvList_lbtnReqNo_0"]
${xpath_PnsFrontEndCancelbtnSave}             xpath=//*[@id="BodyMainContent_fvw_btnSave"]



${xpath_PnsFrontEndMenu_List1}    		      xpath=//*[@id="MenuList"]/li/a[1]/span[1]
${xpath_PnsFrontEndMenu_List1Button1}		  xpath=//*[@id="MenuList"]/li/ul[1]/li[1]/a
${xpath_PnsFrontEndcbConfirm}                 xpath=//*[@id="BodyMainContent_cbConfirm"]
${xpath_PnsFrontEndbtnConfirm}                xpath=//*[@id="BodyMainContent_btnConfirm"]
${xpath_PnsddlNewCity_ddl1}                   xpath=//*[@id="BodyMainContent_ddlNewCity_ddl1"]
${select_value_TaipeiCity}                    臺北市
${xpath_PnsddlNewArea_ddl1}                   xpath=//*[@id="BodyMainContent_ddlNewArea_ddl1"]
${select_value_ZhongzhengDistrict}            中正區
${select_value_100ZhongzhengDistrict}            100中正區
${xpath_PnsddlNewRoad_ddl1}                   xpath=//*[@id="BodyMainContent_ddlNewRoad_ddl1"]
${select_value_SectionOneOfBadeRoad}          八德路１段
${xpath_PnstxtNewNumber}                      xpath=//*[@id="BodyMainContent_txtNewNumber"]

${xpath_PnsddlOldCity_ddl1}                   xpath=//*[@id="BodyMainContent_ddlOldCity_ddl1"]
${select_value_TaipeiCity}                    臺北市
${xpath_PnsddlOldArea_ddl1}                   xpath=//*[@id="BodyMainContent_ddlOldArea_ddl1"]
${select_value_ZhongzhengDistrict}            中正區
${xpath_PnsddlOldRoad_ddl1}                   xpath=//*[@id="BodyMainContent_ddlOldRoad_ddl1"]
${select_value_SanyuanStreet}                 三元街
${xpath_PnstxtOldNumber}                      xpath=//*[@id="BodyMainContent_txtOldNumber"]

${xpath_PnstxtCellPhone}                      xpath=//*[@id="BodyMainContent_txtCellPhone"]
${xpath_PnsbtnSend}                           xpath=//*[@id="BodyMainContent_btnSend"]

${xpath_pnsBackEnd_username}                  xpath=//*[@id="txtUserID"]
${xpath_pnsBackEnd_enterbutton}               xpath=//*[@id="btnLogin"]
${xpath_pnsBackEndSelectFrame1}               xpath=//*[@id="frameName"]/frame[1]
${xpath_pnsBackEndSelectFrame2}               xpath=//*[@id="frameName"]/frame[2]
${xpath_pnsBackEndtvFunctionn0Nodes}          xpath=//*[@id="tvFunctionn0Nodes"]
${xpath_pnsBackEndtvFunctiont1}               xpath=//*[@id="tvFunctiont1"]
${xpath_pnsBackEndtvFunctiont1i}              xpath=//*[@id="tvFunctiont1i"]
${xpath_pnsBackEndtvFunctiont3}               xpath=//*[@id="tvFunctiont3"]
${xpath_pnsBackEndContent1_btnQuery}          xpath=//*[@id="ContentPlaceHolder1_btnQuery"]
${xpath_pnsBackEndContent1_gvList_LinkButton_0}               xpath=//*[@id="ContentPlaceHolder1_gvList_LinkButton_0"]
${xpath_pnsBackEndContent1_fvw1_btnFvwPrint_btnPrint}          xpath=//*[@id="ContentPlaceHolder1_fvw1_btnFvwPrint_btnPrint"]
${xpath_pnsBackEndContent1_fvw1_btnFvwChange}         xpath=//*[@id="ContentPlaceHolder1_fvw1_btnFvwChange"]
${xpath_pnsBackEndContent1_btnFvwSave}        xpath=//*[@id="ContentPlaceHolder1_btnFvwSave"]
${xpath_pnsBackEndContent1_fvw1_ddlResult_ddl1}    xpath=//*[@id="ContentPlaceHolder1_fvw1_ddlResult_ddl1"]
${select_value_30success}                      30
${select_value_31fail}                         31
${xpath_pnsBackEnduploadVerifyPicture}        xpath=//*[@id="ContentPlaceHolder1_fvw1_FileUpload1"]
${xpath_pnsBackEndContent1_fvw1_btnUpload}                        xpath=//*[@id="ContentPlaceHolder1_fvw1_btnUpload"]
${xpath_pnsBackEndContent1_fvw1_lbtnFile}     xpath=//*[@id="ContentPlaceHolder1_fvw1_lbtnFile"]
${xpath_pnsBackEndContent1_fvw3_ddlResult_ddl1}    xpath=//*[@id="ContentPlaceHolder1_fvw3_ddlResult_ddl1"]
${xpath_pnsBackEndContent1_btnFvw2Save}        xpath=//*[@id="ContentPlaceHolder1_btnFvw2Save"]















${xpath_ezpostFrontEnd_login}                    xpath=//*[@id="btnLogin"]
${xpath_ezpostFrontEnd_username}                 xpath=//*[@id="inputEmail"]
${xpath_ezpostFrontEnd_password}                 xpath=//*[@id="inputPassword"]
${xpath_ezpostFrontEnd_enterbutton}              xpath=//*[@id="iframe"]/div/form/button


${xpath_ezpostFrontEndMenu_aMailDropdown}               xpath=/*[@id="aMailDropdown"]
${xpath_ezpostFrontEndMenu_DParcel_Dropdown}               xpath=//*[@id="a_DParcel_Dropdown"]
${xpath_ezpostFrontEndMenu_DEMS_Dropdown}                  xpath=//*[@id="a_DEMS_Dropdown"]
${xpath_ezpostFrontEndMenu_DTW_Dropdown}                   xpath=//*[@id="a_DTW_Dropdown"]
${xpath_ezpostFrontEndMenu_anewmail}               xpath=//*[@id="anewmail"]
${xpath_ezpostFrontEndMenu_DParcel_edit}                   xpath=//*[@id="a_DParcel_edit"]
${xpath_ezpostFrontEndMenu_DEMS_edit}                      xpath=//*[@id="a_DEMS_edit"]
${xpath_ezpostFrontEndMenu_DTW_edit}                       xpath=//*[@id="a_DTW_edit"]

${xpath_ezpostFrontEndcbUnderstand}                        xpath=//*[@id="cbUnderstand"] 
${xpath_ezpostFrontEndbtnGOTO}                             xpath=//*[@id="btnGOTO"]  
${xpath_ezpostFrontEnd_aMail_txtSName}                            xpath=//*[@id="txtSName"]
${xpath_ezpostFrontEnd_D_txtSNAME}                            xpath=//*[@id="txtSNAME"]
${xpath_ezpostFrontEnd_D_txtSPHONE}                           xpath=//*[@id="txtSPHONE"]
${xpath_ezpostFrontEndselectSADDCity}                      xpath=//*[@id="selectSADDCity"]
${xpath_ezpostFrontEndselectSADDArea}                      xpath=//*[@id="selectSADDArea"]
${xpath_ezpostFrontEndtxtDEMSSADDO}                      xpath=//*[@id="DEMSMailInfoForm"]/div[10]/div[2]/input[1]
${xpath_ezpostFrontEndtxtSADDOther}                      xpath=//*[@id="txtSADDOther"]
${xpath_ezpostFrontEnd_D_txtRNAME}                            xpath=//*[@id="txtRNAME"]
${xpath_ezpostFrontEnd_D_txtRPHONE}                           xpath=//*[@id="txtRPHONE"]
${xpath_ezpostFrontEndselectRADDCity}                      xpath=//*[@id="selectRADDCity"]
${xpath_ezpostFrontEndselectRADDArea}                      xpath=//*[@id="selectRADDArea"]
${xpath_ezpostFrontEndtxtDParcelRADDO}                      xpath=//*[@id="DParcelMailInfoForm"]/div[17]/div/input
${xpath_ezpostFrontEndtxtDEMSRADDO}                      xpath=//*[@id="DEMSMailInfoForm"]/div[17]/div/input
${xpath_ezpostFrontEndtxtDTWRADDO}                      xpath=//*[@id="DTWMailInfoForm"]/div[19]/div/input
${xpath_ezpostFrontEndtxtRADDOther}                      xpath=//*[@id="txtRADDOther"]


${xpath_ezpostFrontEndDParcelcheckboxCONTENTS_1}                      xpath=//*[@id="checkboxCONTENTS"]/label[1]/input

${xpath_ezpostFrontEndDParceltextWIDTH}                      xpath=//*[@id="textWIDTH"]
${xpath_ezpostFrontEndDParceltextHEIGHT}                      xpath=//*[@id="textHEIGHT"]
${xpath_ezpostFrontEndDParceltextDEPTH}                      xpath=//*[@id="textDEPTH"]

${xpath_ezpostFrontEndDParcelValueDeclared_true}                      xpath=//*[@id="DParcelMailInfoForm"]/div[30]/div[2]/label[3]/input
${xpath_ezpostFrontEndDEMSValueDeclared_true}                      xpath=//*[@id="DEMSMailInfoForm"]/div[31]/div[2]/label[3]/input
${xpath_ezpostFrontEndDTWValueDeclared_true}                      xpath=//*[@id="DTWMailInfoForm"]/div[26]/div[2]/label[3]/input

${xpath_ezpostFrontEndDParceltextVALUE_DECLARED_AMOUNT}                      xpath=//*[@id="textVALUE_DECLARED_AMOUNT"]

${xpath_ezpostFrontEndDParceltextPayment_true}                     xpath=//*[@id="DParcelMailInfoForm"]/div[31]/div[2]/label[3]/input
${xpath_ezpostFrontEndDEMStextPayment_true}                        xpath=//*[@id="DEMSMailInfoForm"]/div[32]/div[2]/label[3]/input
${xpath_ezpostFrontEndDTWtextPayment_true}                         xpath=//*[@id="DTWMailInfoForm"]/div[27]/div[2]/label[3]/input

${xpath_ezpostFrontEndDParceltextPayment_Name}                     xpath=//*[@id="textPayment_Name"]
${xpath_ezpostFrontEndDParceltextPayment_ACT}                      xpath=//*[@id="textPayment_ACT"]
${xpath_ezpostFrontEndDParceltextPayment_Amount}                   xpath=//*[@id="textPayment_Amount"]


${xpath_ezpostFrontEndDParcelUNDELIVER_OPTNO}                      
xpath=/html/body/div[1]/div/form/div[33]/div[2]/table/tbody/tr/td[2]/label[1]/input

${xpath_ezpostFrontEndDEMSUNDELIVER_OPTNO}                      xpath=//*[@id="DEMSMailInfoForm"]/div[34]/div[2]/table/tbody/tr/td[2]/label[3]/input

${xpath_ezpostFrontEndDTWUNDELIVER_OPTNO}                      xpath=?

${xpath_ezpostFrontEndDParcelbtn_row}                      xpath=//*[@id="btn_row"]/button


*** keywords ***




post_postweb_pnsFrontEndlogin
    [Arguments]     ${url}
    [Documentation]    Do bmc web login
    Open Browser  ${url}  firefox



post_postweb_ClickPnsFrontEndLoginUsername
    [Arguments]     ${username}
        [Documentation]
        [Tags]
        Input Text    ${xpath_pnsFrontEnd_username}    ${username}



post_postweb_ClickPnsFrontEndLoginPassword
    [Arguments]     ${password}
        [Documentation]
        [Tags]
        Input Password    ${xpath_pnsFrontEnd_password}    ${password}
#        Input Text    ${xpath_pnsFrontEnd_password}    ${password}

post_postweb_ClickPnsFrontEndLoginEnter
        [Documentation]
        Click Element    ${xpath_pnsFrontEnd_enterbutton}

post_postweb_ClickPnsFrontEndMenuList2
        [Documentation]
        [Tags]
        Element Should Be Enabled    ${xpath_PnsFrontEndMenu_List2}
        Click Element    ${xpath_PnsFrontEndMenu_List2}
        Sleep  1s
#        Handle Alert


post_postweb_ClickPnsFrontEndMenuList2Button1
        [Documentation]
        [Tags]
        Element Should Be Enabled    ${xpath_PnsFrontEndMenu_List2Button1}
        Click Element    ${xpath_PnsFrontEndMenu_List2Button1}
        Sleep  1s
#        Handle Alert

post_postweb_ClickPnsFrontEndbtnQuery
        [Documentation]
        [Tags]
        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}
        Click Element    ${xpath_PnsFrontEndbtnQuery}
        Sleep  1s

post_postweb_ClickPnsFrontEndlbtnReqNo_0
        [Documentation]
        Element Should Be Enabled    ${xpath_PnsFrontEndlbtnReqNo_0}
        Click Element    ${xpath_PnsFrontEndlbtnReqNo_0}    
        Sleep  1s

post_postweb_ClickPnsFrontEndCancelbtnSave
        [Documentation]
        Element Should Be Enabled    ${xpath_PnsFrontEndCancelbtnSave}
        Click Element    ${xpath_PnsFrontEndCancelbtnSave}    
        Sleep  1s
#        Capture Page Screenshot
        Sleep  1s
        Handle Alert




post_postweb_ClickPnsFrontEndMenuList1
        [Documentation]
        [Tags]
    	Element Should Be Enabled    ${xpath_PnsFrontEndMenu_List1}
    	Click Element    ${xpath_PnsFrontEndMenu_List1}
        Sleep  1s
#        Handle Alert


post_postweb_ClickPnsFrontEndMenuList1Button1
        [Documentation]
        [Tags]
    	Element Should Be Enabled    ${xpath_PnsFrontEndMenu_List1Button1}
    	Click Element    ${xpath_PnsFrontEndMenu_List1Button1}
    	Handle Alert

post_postweb_ClickPnsFrontEndcbConfirm
        [Documentation]
        [Tags]
        Element Should Be Enabled    ${xpath_PnsFrontEndcbConfirm}
        Click Element    ${xpath_PnsFrontEndcbConfirm}
        Sleep  1s
        Element Should Be Enabled    ${xpath_PnsFrontEndbtnConfirm}
        Click Element    ${xpath_PnsFrontEndbtnConfirm} 
        Sleep  1s



post_postweb_ClickPnsFrontEndddlNewCity_ddl1
        [Arguments]     ${NewNumber}
        Select From List By Value   ${xpath_PnsddlNewCity_ddl1}   ${select_value_TaipeiCity}
        Sleep  1s
        Select From List By Value   ${xpath_PnsddlNewArea_ddl1}   ${select_value_ZhongzhengDistrict}
        Sleep  1s
        Select From List By Value   ${xpath_PnsddlNewRoad_ddl1}   ${select_value_SectionOneOfBadeRoad}
        Sleep  1s
        Input_Text  ${xpath_PnstxtNewNumber}  ${NewNumber}
        Sleep  1s



post_postweb_ClickPnsFrontEndddlOldCity_ddl1
        [Arguments]     ${OldNumber}
        Select From List By Value   ${xpath_PnsddlOldCity_ddl1}   ${select_value_TaipeiCity}
        Sleep  1s
        Select From List By Value   ${xpath_PnsddlOldArea_ddl1}   ${select_value_ZhongzhengDistrict}
        Sleep  1s
        Select From List By Value   ${xpath_PnsddlOldRoad_ddl1}   ${select_value_SanyuanStreet}
        Sleep  1s
        Input_Text  ${xpath_PnstxtOldNumber}  ${OldNumber}
        Sleep  1s

post_postweb_ClickPnsFrontEndbtnSend
        Input_Text  ${xpath_PnstxtCellPhone}  0963038476
        Click Element    ${xpath_PnsbtnSend}
        Sleep  10s 
        Handle Alert
        Sleep  1s
        Capture Page Screenshot
#        Sleep  1s


post_postweb_pnsBackEndlogin
        [Arguments]     ${url}
        [Documentation]    Do bmc web login
        Open Browser  ${url}  firefox

post_postweb_ClickPnsBackEndLoginUsername
        [Arguments]     ${username}
        [Documentation]
        [Tags]
        Input Text    ${xpath_pnsBackEnd_username}    ${username}

post_postweb_ClickPnsBackEndLoginEnter
        [Documentation]
        Click Element    ${xpath_pnsBackEnd_enterbutton}
        Sleep  1s

post_postweb_ClickPnsBackEndtvFunctionn0Nodes
        [Documentation]
        Select_Frame     ${xpath_pnsBackEndSelectFrame1}
        Click Element    ${xpath_pnsBackEndtvFunctionn0Nodes}
        Unselect_Frame
        Sleep  1s

post_postweb_ClickPnsBackEndtvFunctiont1
        [Documentation]
        Select_Frame     ${xpath_pnsBackEndSelectFrame1}
        Click Element    ${xpath_pnsBackEndtvFunctiont1}
        Unselect_Frame
        Sleep  1s

post_postweb_ClickPnsBackEndtvFunctiont1i
        [Documentation]
        Click Element    ${xpath_pnsBackEndtvFunctiont1i}
        Sleep  1s

post_postweb_ClickPnsBackEndtvFunctiont3
        [Documentation]
        Select_Frame     ${xpath_pnsBackEndSelectFrame1}
        Click Element    ${xpath_pnsBackEndtvFunctiont3}
        Unselect_Frame
        Sleep  1s

post_postweb_ClickPnsBackEndContent1_btnQuery
        [Documentation]
        Select_Frame     ${xpath_pnsBackEndSelectFrame2}
        Click Element    ${xpath_pnsBackEndContent1_btnQuery}
        Unselect_Frame
        Sleep  1s


post_postweb_ClickPnsBackEndContent1_gvList_LinkButton_0
        [Documentation]
        Select_Frame     ${xpath_pnsBackEndSelectFrame2}
        Click Element    ${xpath_pnsBackEndContent1_gvList_LinkButton_0}
        Unselect_Frame
        Sleep  1s

post_postweb_ClickPnsBackEndContent1_fvw1Print
        [Documentation]
        Select_Frame     ${xpath_pnsBackEndSelectFrame2}
        Click Element    ${xpath_pnsBackEndContent1_fvw1_btnFvwPrint_btnPrint}
        Handle Alert
        Unselect_Frame
        Sleep  3s

        ${titles}  Get Window Titles
        Log_To_Console  all_titles: ${titles}
        ${titles1}      Get From List   ${titles}   0
        Log_To_Console  titles_1: ${titles1}
        ${titles2}      Get From List   ${titles}   1
        Log_To_Console  titles_2: ${titles2}
        Switch Window    title=${titles2}
        Capture Page Screenshot
        Close Window
        Switch Window    title=${titles1}






post_postweb_CheckPnsBackEndContent1_fvw1Print
        ${message}=  Element Should Be Visible    ${xpath_pnsBackEndContent1_fvw1_btnFvwPrint_btnPrint}
        [Return]  ${message}




post_postweb_ClickPnsBackEndContent1_fvw1Change
        [Documentation]
        Select_Frame     ${xpath_pnsBackEndSelectFrame2}
        Click Element    ${xpath_pnsBackEndContent1_fvw1_btnFvwChange}
        Handle Alert
        Unselect_Frame

post_postweb_CheckPnsBackEndContent1_HavePrint
        Select_Frame     ${xpath_pnsBackEndSelectFrame2}
        ${HavePrint_match1}  ${message}=  Run Keyword And Continue On Failure  Element Should Be Disabled    ${xpath_pnsBackEndContent1_fvw1_btnFvwChange}
        Unselect_Frame
        [Return]  ${HavePrint_match1}  ${message}


post_postweb_ClickPnsBackEndContent1_fvw1_ResultStateSuccess
        [Documentation]
        Select_Frame     ${xpath_pnsBackEndSelectFrame2}
        Select From List By Value   ${xpath_pnsBackEndContent1_fvw1_ddlResult_ddl1}      ${select_value_30success}
        Unselect_Frame                       
        Sleep  1s


post_postweb_ChooseVerifyPicture
        [Documentation]
        Log  ${local_path}\\${Picture_folder_path}\\pnsBackEndVerify.jpeg
        Log  ${local_path}\${Picture_folder_path}\\pnsBackEndVerify.jpeg
        Log  ${local_path}\\${Picture_folder_path}\pnsBackEndVerify.jpeg
        Log  ${local_path}\${Picture_folder_path}\pnsBackEndVerify.jpeg
        Log  .\\${Picture_folder_path}\\pnsBackEndVerify.jpeg
        Log  .\${Picture_folder_path}\\pnsBackEndVerify.jpeg
        Log  .\\${Picture_folder_path}\pnsBackEndVerify.jpeg
        Log  .\${Picture_folder_path}\pnsBackEndVerify.jpeg
        Log  ${local_path}\\${Picture_folder_path}\\pnsBackEndVerify.jpeg
        Log  ${CURDIR}

        Select_Frame     ${xpath_pnsBackEndSelectFrame2}
#        Choose File    ${xpath_pnsBackEnduploadVerifyPicture}    ${local_path}/${Picture_folder_path}/pnsBackEndVerify.jpeg
        Choose File    ${xpath_pnsBackEnduploadVerifyPicture}    ${local_path}\\${Picture_folder_path}\\pnsBackEndVerify.jpeg
        Unselect_Frame
        Sleep  1s


post_postweb_ClickPnsBackEndContent1_fvw1_btnUpload
        [Documentation]
        Select_Frame     ${xpath_pnsBackEndSelectFrame2}
        Click Element    ${xpath_pnsBackEndContent1_fvw1_btnUpload}
        Handle Alert
        Unselect_Frame


post_postweb_ClickPnsBackEndContent1_btnFvwSave
        [Documentation]
        Select_Frame     ${xpath_pnsBackEndSelectFrame2}
        Click Element    ${xpath_pnsBackEndContent1_btnFvwSave}
        Handle Alert
        Unselect_Frame
        Capture Page Screenshot
        ${titles}  Get Window Titles
        Log_To_Console  ${titles}


post_postweb_CheckPnsBackEndContent1_HaveUploadPicture
        Select_Frame     ${xpath_pnsBackEndSelectFrame2}
        ${HaveUploadPicture_match1}  ${message}=  Run Keyword And Continue On Failure    Element Should Be Visible    ${xpath_pnsBackEndContent1_fvw1_lbtnFile}
        Unselect_Frame
        [Return]  ${HaveUploadPicture_match1}  ${message}

post_postweb_ClickPnsBackEndContent1_fvw3_ResultStateSuccess
        [Documentation]
        Select_Frame     ${xpath_pnsBackEndSelectFrame2}
        Select From List By Value   ${xpath_pnsBackEndContent1_fvw3_ddlResult_ddl1}      ${select_value_30success}
        Unselect_Frame                       
        Sleep  1s

post_postweb_ClickPnsBackEndContent1_btnFvw2Save
        [Documentation]
        Select_Frame     ${xpath_pnsBackEndSelectFrame2}
        Click Element    ${xpath_pnsBackEndContent1_btnFvw2Save}
        Handle Alert
        Unselect_Frame
        Capture Page Screenshot
        ${titles}  Get Window Titles
        Log_To_Console  ${titles}





































###

post_postweb_ezpostFrontEndlogin
    [Arguments]     ${url}
    [Documentation]    Do bmc web login
    Open Browser  ${url}  firefox
    Sleep  1s
    Click Element    ${xpath_ezpostFrontEnd_login}
    Sleep  1s

post_postweb_ClickezpostFrontEndLoginUsername
    [Arguments]     ${username}
        [Documentation]
        [Tags]
        Input Text    ${xpath_ezpostFrontEnd_username}    ${username}

post_postweb_ClickezpostFrontEndLoginPassword
    [Arguments]     ${password}
        [Documentation]
        [Tags]
        Input Password    ${xpath_ezpostFrontEnd_password}    ${password}
#        Input Text    ${xpath_ezpostFrontEnd_password}    ${password}

post_postweb_ClickezpostFrontEndLoginEnter
        [Documentation]
        Click Element    ${xpath_ezpostFrontEnd_enterbutton}

post_postweb_ClickezpostFrontEndMenu_DParcel_Dropdown
        [Documentation]
        Click Element    ${xpath_ezpostFrontEndMenu_DParcel_Dropdown}
        Sleep  1s

post_postweb_ClickezpostFrontEndMenu_DParcel_edit
        [Documentation]
        Click Element    ${xpath_ezpostFrontEndMenu_DParcel_edit}
        Sleep  1s


post_postweb_ClickezpostFrontEndcbUnderstand
        Element Should Be Enabled    ${xpath_ezpostFrontEndcbUnderstand}
        Click Element    ${xpath_ezpostFrontEndcbUnderstand}
        Element Should Be Enabled    ${xpath_ezpostFrontEndbtnGOTO}
        Click Element    ${xpath_ezpostFrontEndbtnGOTO}
#        Handle Alert
        Sleep  1s

post_postweb_ClickezpostFrontEnd_D_txtSNAME
    [Arguments]     ${parameter}
        [Documentation]
        Input Text    ${xpath_ezpostFrontEnd_D_txtSNAME}         ${parameter}                            
        Sleep  1s

post_postweb_ClickezpostFrontEnd_D_txtSPHONE
        [Documentation]
        Input Text    ${xpath_ezpostFrontEnd_D_txtSPHONE}  0912345678                            
        Sleep  1s

post_postweb_ClickezpostFrontEndselectSADDCity
        [Documentation]
        Select From List By Value   ${xpath_ezpostFrontEndselectSADDCity}      ${select_value_TaipeiCity}                       
        Sleep  1s

post_postweb_ClickezpostFrontEndselectSADDArea
        [Documentation]
        Select From List By Value   ${xpath_ezpostFrontEndselectSADDArea}      ${select_value_100ZhongzhengDistrict}                                   
#        Sleep  1s

post_postweb_ClickezpostFrontEndtxtDEMSSADDO
        [Documentation]
        Input Text   ${xpath_ezpostFrontEndtxtDEMSSADDO}   ${select_value_SectionOneOfBadeRoad}                    
        Capture Page Screenshot
#        Sleep  1s


post_postweb_ClickezpostFrontEndselectSADDOther
        [Documentation]
        Input Text   ${xpath_ezpostFrontEndtxtSADDOther}   ${select_value_SectionOneOfBadeRoad}                    
#        Capture Page Screenshot
#        Sleep  1s


post_postweb_ClickezpostFrontEnd_D_txtRNAME
        [Documentation]
        Input Text    ${xpath_ezpostFrontEnd_D_txtRNAME}     收件人                            
#        Sleep  1s

post_postweb_ClickezpostFrontEnd_D_txtRPHONE
        [Documentation]
        Input Text    ${xpath_ezpostFrontEnd_D_txtRPHONE}  0987654321                            
#        Sleep  1s

post_postweb_ClickezpostFrontEndselectRADDCity
        [Documentation]
        Select From List By Value   ${xpath_ezpostFrontEndselectRADDCity}      ${select_value_TaipeiCity}                       
        Sleep  1s

post_postweb_ClickezpostFrontEndselectRADDArea
        [Documentation]
        Select From List By Value   ${xpath_ezpostFrontEndselectRADDArea}      ${select_value_100ZhongzhengDistrict} 
#        Sleep  1s

post_postweb_ClickezpostFrontEndtxtDParcelRADDO
        [Documentation]
        Input Text  ${xpath_ezpostFrontEndtxtDParcelRADDO}  ${select_value_SectionOneOfBadeRoad}              
#        Capture Page Screenshot
#        Sleep  1s

post_postweb_ClickezpostFrontEndtxtDEMSRADDO
        [Documentation]
        Input Text  ${xpath_ezpostFrontEndtxtDEMSRADDO}  ${select_value_SectionOneOfBadeRoad}              
#        Capture Page Screenshot
#        Sleep  1s

post_postweb_ClickezpostFrontEndtxtDTWRADDO
        [Documentation]
        Input Text  ${xpath_ezpostFrontEndtxtDTWRADDO}  ${select_value_SectionOneOfBadeRoad}              
#        Capture Page Screenshot
#        Sleep  1s

post_postweb_ClickezpostFrontEndselectRADDOther
        [Arguments]     ${parameter}
        [Documentation]
        Input Text  ${xpath_ezpostFrontEndtxtRADDOther}  ${parameter}                    
#        Capture Page Screenshot
#        Sleep  1s

post_postweb_ClickezpostFrontEndDParcelcheckboxCONTENTS_1
        [Documentation]
        Click Element   ${xpath_ezpostFrontEndDParcelcheckboxCONTENTS_1}
#        Sleep  1s 

post_postweb_ClickezpostFrontEnd_DParcel_MailSize
        [Documentation]
        Input Text    ${xpath_ezpostFrontEndDParceltextDEPTH}  10
        Input Text    ${xpath_ezpostFrontEndDParceltextWIDTH}  10  
        Input Text    ${xpath_ezpostFrontEndDParceltextHEIGHT}  10                             



post_postweb_ClickezpostFrontEndDParcelValueDeclared
        [Documentation]
        Click Element    ${xpath_ezpostFrontEndDParcelValueDeclared_true}
#        Sleep  1s

post_postweb_ClickezpostFrontEndDEMSValueDeclared
        [Documentation]
        Click Element    ${xpath_ezpostFrontEndDEMSValueDeclared_true}
#        Sleep  1s 

post_postweb_ClickezpostFrontEndDTWValueDeclared
        [Documentation]
        Click Element    ${xpath_ezpostFrontEndDTWValueDeclared_true}
#        Sleep  1s               

post_postweb_ClickezpostFrontEndDParceltextVALUE_DECLARED_AMOUNT
        [Arguments]     ${parameter}
        [Documentation]
        Input Text  ${xpath_ezpostFrontEndDParceltextVALUE_DECLARED_AMOUNT}  ${parameter}                    
        Capture Page Screenshot
#        Sleep  1s

post_postweb_ClickezpostFrontEndDParceltextPayment
        [Documentation]
        Click Element    ${xpath_ezpostFrontEndDParceltextPayment_true}
        Sleep  1s

post_postweb_ClickezpostFrontEndDEMStextPayment
        [Documentation]
        Click Element    ${xpath_ezpostFrontEndDEMStextPayment_true}
        Sleep  1s

post_postweb_ClickezpostFrontEndDTWtextPayment
        [Documentation]
        Click Element    ${xpath_ezpostFrontEndDTWtextPayment_true}
        Sleep  1s

post_postweb_ClickezpostFrontEndDParceltextPayment_Name
        [Arguments]     ${parameter}
        [Documentation]
        Input Text  ${xpath_ezpostFrontEndDParceltextPayment_Name}  ${parameter}                    
#        Capture Page Screenshot
#        Sleep  1s

post_postweb_ClickezpostFrontEndDParceltextPayment_ACT
        [Arguments]     ${parameter}
        [Documentation]
        Input Text  ${xpath_ezpostFrontEndDParceltextPayment_ACT}  ${parameter}                    
#        Capture Page Screenshot
#        Sleep  1s

post_postweb_ClickezpostFrontEndDParceltextPayment_Amount
        [Arguments]     ${parameter}
        [Documentation]
        Input Text  ${xpath_ezpostFrontEndDParceltextPayment_Amount}  ${parameter}                    
        Capture Page Screenshot
#        Sleep  1s

post_postweb_ClickezpostFrontEndDParcelUNDELIVER_OPTNO
        [Documentation]
        Click Element  ${xpath_ezpostFrontEndDParcelUNDELIVER_OPTNO}
#        Sleep  1s              

post_postweb_ClickezpostFrontEndDEMSUNDELIVER_OPTNO
        [Documentation]
        Click Element  ${xpath_ezpostFrontEndDEMSUNDELIVER_OPTNO}
#        Sleep  1s

post_postweb_ClickezpostFrontEndDTWUNDELIVER_OPTNO
        [Documentation]
        Click Element  ${xpath_ezpostFrontEndDTWUNDELIVER_OPTNO}
#        Sleep  1s

post_postweb_ClickezpostFrontEndDParcelbtn_row
        [Documentation]
        Click Element    ${xpath_ezpostFrontEndDParcelbtn_row}
        Capture Page Screenshot
        Sleep  1s

#***

post_postweb_ClickezpostFrontEndMenu_DEMS_Dropdown
        [Documentation]
        Click Element    ${xpath_ezpostFrontEndMenu_DEMS_Dropdown}
        Sleep  1s

post_postweb_ClickezpostFrontEndMenu_DEMS_edit
        [Documentation]
        Click Element    ${xpath_ezpostFrontEndMenu_DEMS_edit}
        Sleep  1s

#***

post_postweb_ClickezpostFrontEndMenu_DTW_Dropdown
        [Documentation]
        Click Element    ${xpath_ezpostFrontEndMenu_DTW_Dropdown}
        Sleep  1s

post_postweb_ClickezpostFrontEndMenu_DTW_edit
        [Documentation]
        Click Element    ${xpath_ezpostFrontEndMenu_DTW_edit}
        Sleep  1s














