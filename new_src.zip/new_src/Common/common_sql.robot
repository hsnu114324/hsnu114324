*** Variables ***

*** keywords ***

Connect_To_pnstest_Databases
        [Documentation]
#        Connect To Database
#        ...    pymssql
#        ...    dbName=DLIQSERV
#        ...    dbUsername=DLIQTASK
#        ...    dbPassword=DLIQTASK3817
#        ...    dbHost=10.201.52.130
#        ...    dbPort=1433
#        ...    alias=pnstest
        Connect To Database  pymssql  DLIQSERV  DLIQTASK  DLIQTASK3817  10.201.52.130  1433  alias=pnstest


Connect_To_dmstest_Databases
        [Documentation]
#        Connect To Database
#        ...    pymssql
#        ...    dbName=DDSQNDMS
#        ...    dbUsername=DSNDMSTEST
#        ...    dbPassword=p6u8FLzs
#        ...    dbHost=10.201.52.130
#        ...    dbPort=1433
#        ...    alias=dmstest
        Connect To Database  pymssql  DDSQNDMS  DSNDMSTEST  p6u8FLzs  10.201.52.130  1433  alias=dmstest


remove_data_from_pnstest_database
        [Arguments]     ${Q_SID_num}  ${DID_num}
        [Documentation]     
        ${output}=    Query    SELECT * FROM QuestData WHERE Q_SID = '${Q_SID_num}'    alias=pnstest
        Log_To_Console  ${output}
        ${output}=    Execute Sql String    delete　from QuestData where Q_SID = '${Q_SID_num}'    alias=pnstest
        Log_To_Console  ${output}
        ${output}=    Execute Sql String    delete from QuestMain where Q_SID = '${Q_SID_num}'    alias=pnstest
        Log_To_Console  ${output}
        ${output}=    Execute Sql String    delete from T_QUESTREPORT where DID = ${DID_num}    alias=pnstest
        Log_To_Console  ${output}
        ${output}=    Execute Sql String    DELETE　from T_QUESTREPORT_LOG where DID = ${DID_num}    alias=pnstest
        Log_To_Console  ${output}



update_data_from_pnstest_database
        [Arguments]     ${Q_SID_num}  ${CREATE_DATE_str}  ${Q_VALUE_str}  
        [Documentation] 

        Log  ${Q_SID_num}
        ${output}=    Query    SELECT * FROM QuestMain WHERE Q_SID = '${Q_SID_num}'  alias=pnstest
        Log_To_Console  ${output}

#        ${output}=    Execute Sql String    UPDATE QuestMain SET CREATE_DATE = '2024-01-01 01:01:01.001' where Q_SID = '${Q_SID_num}'  alias=pnstest

        ${CREATE_DATE_half_str1}=  Replace String Using Regexp  ${CREATE_DATE_str}    \\d{2}:\\d{2}:\\d{2}.\\d{3}    \     count=1

        ${CREATE_DATE_half_str2}=  Replace String Using Regexp  ${CREATE_DATE_half_str1}    -    /     

        ${output}=    Execute Sql String    UPDATE QuestData SET Q_VALUE = '${CREATE_DATE_half_str2}' where Q_SID = '${Q_SID_num}' and Q_SNO = '21'
        Log_To_Console  ${output}

        ${output}=    Execute Sql String    UPDATE QuestMain SET CREATE_DATE = '${CREATE_DATE_str}' where Q_SID = '${Q_SID_num}'  alias=pnstest
        Log_To_Console  ${output}

        ${output}=    Query    SELECT * FROM QuestMain WHERE Q_SID = '${Q_SID_num}'  alias=pnstest
        Log_To_Console  ${output}

        ${output}=    Execute Sql String    UPDATE QuestMain SET INSPECTOR_SSO_ID = '714838' where Q_SID = '${Q_SID_num}'
        Log_To_Console  ${output}  alias=pnstest

        ${output}=    Query    SELECT * FROM QuestMain WHERE Q_SID = '${Q_SID_num}'  alias=pnstest
        Log_To_Console  ${output}

        ${output}=    Query    SELECT * FROM QuestData WHERE Q_SID = '${Q_SID_num}'  alias=pnstest
        Log_To_Console  ${output}

        ${output}=    Execute Sql String    UPDATE QuestData SET Q_VALUE = '${Q_VALUE_str}' where Q_SID = '${Q_SID_num}' and Q_SNO = '33'  alias=pnstest
        Log_To_Console  ${output}

        ${output}=    Query    SELECT * FROM QuestData WHERE Q_SID = '${Q_SID_num}'  alias=pnstest
        Log_To_Console  ${output}

Convert ROC Date
    [Arguments]    ${roc_date}
    @{parts}=    Split String    ${roc_date}    /
    ${roc_year}=    Convert To Integer    ${parts}[0]
    ${western_year}=    Evaluate    ${roc_year} + 1911
    ${result}=    Set Variable    ${western_year}-${parts}[1]-${parts}[2]
    RETURN    ${result}

query_data_from_dmstest_database
#        [Arguments]     ${query_start_date}  ${query_end_date}  ${MAIL_NO} 
        [Arguments]     ${query_date}    ${Q_ACC_MONTH_SER}  
        [Documentation] 

#        IF  ${MAIL_NO} == 'NONE'
#            ${MAIL_NO}=  evaluate  ''
#        END

#        ${query_start_date_CE}=  Convert ROC Date   ${query_start_date}  
#        ${query_end_date_CE}=    Convert ROC Date   ${query_end_date}
        ${query_date_CE}=    Convert ROC Date   ${query_date}

#        Log  ${query_start_date_CE}
#        Log  ${query_end_date_CE}
        Log  ${query_date_CE}

#        ${output}=  Query    SELECT * FROM T_DMSD422_QUEST;  alias=dmstest

#        ${output}=  Query    SELECT * FROM T_DMSD422_QUEST WHERE WORK_DATE between '${query_start_date_CE}' and '${query_end_date_CE}' order by WORK_DATE;  alias=dmstest

        ${output}=  Query    SELECT Q_SID,Q_DID,Q_ACC_MONTH,Q_ACC_MONTH_SER,WORK_DATE,INSPECTOR_SSO_ID,Q_VER,CNTR_NO,SEGC_NO,MAIL_NO,MAIL_TYPE,RCV_NAME,RCV_ZIP,RCV_ADDR,RCV_ADDR_CITY,RCV_ADDR_TWP,RCV_ADDR_RD,RCV_ADDR_LN,RCV_ADDR_ALY,RCV_ADDR_NO,RCV_ADDR_NO_EXT,RCV_ADDR_FL,RCV_ADDR_FL_EXT,RCV_ADDR_RM,IS_INDB_UPLOAD,IS_MODI,IS_MODI_UPLOAD,IS_REVOKE,IS_REVOKE_UPLOAD,IS_PRINTED,IS_READY_TO_UPLOAD,CREATE_ID,UPDATE_ID,IS_CANCEL,IS_CANCEL_UPLOAD,CANCEL_SSO_ID,RESTORE_SSO_ID,IS_RESTORE,IS_RESTORE_UPLOAD,RESTORE_SSO_ID,IS_ANSWER FROM T_DMSD422_QUEST WHERE Q_ACC_MONTH_SER = '${Q_ACC_MONTH_SER}' AND WORK_DATE = '${query_date_CE}' order by WORK_DATE;  alias=dmstest

        ${output_1}=  Query    SELECT TOP 1 Q_SID,Q_DID,Q_ACC_MONTH,Q_ACC_MONTH_SER,WORK_DATE,INSPECTOR_SSO_ID,Q_VER,CNTR_NO,SEGC_NO,MAIL_NO,MAIL_TYPE,RCV_NAME,RCV_ZIP,RCV_ADDR,RCV_ADDR_CITY,RCV_ADDR_TWP,RCV_ADDR_RD,RCV_ADDR_LN,RCV_ADDR_ALY,RCV_ADDR_NO,RCV_ADDR_NO_EXT,RCV_ADDR_FL,RCV_ADDR_FL_EXT,RCV_ADDR_RM,IS_INDB_UPLOAD,IS_MODI,IS_MODI_UPLOAD,IS_REVOKE,IS_REVOKE_UPLOAD,IS_PRINTED,IS_READY_TO_UPLOAD,CREATE_ID,UPDATE_ID,IS_CANCEL,IS_CANCEL_UPLOAD,CANCEL_SSO_ID,RESTORE_SSO_ID,IS_RESTORE,IS_RESTORE_UPLOAD,RESTORE_SSO_ID,IS_ANSWER FROM T_DMSD422_QUEST WHERE Q_ACC_MONTH_SER = '${Q_ACC_MONTH_SER}' AND WORK_DATE = '${query_date_CE}' order by WORK_DATE;  alias=dmstest

        ${output_1_1}=  Query    SELECT TOP 1 Q_SID FROM T_DMSD422_QUEST WHERE Q_ACC_MONTH_SER = '${Q_ACC_MONTH_SER}' AND WORK_DATE = '${query_date_CE}' order by WORK_DATE;  alias=dmstest


        log  ${output_1}

        log  ${output_1}[0]

        log  ${output_1}[0][0]
        
        [Return]  ${output_1}[0][0]




query_output_from_database
        [Arguments]     ${query_start_date}  ${query_end_date}  ${query_stock_id}  
        [Documentation] 

        ${output}=  Query    SELECT DATE,stock_id,Trading_Volume,Trading_money,open,max,min,close,spread,Trading_turnover FROM daily_stock WHERE stock_id = ${query_stock_id} AND DATE between ${query_start_date} and ${query_end_date} order by DATE;
        log  ${output}
        [Return]  ${output}


query_output_k_from_database
        [Arguments]     ${query_start_date}  ${query_end_date}  ${query_stock_id}  
        [Documentation] 

        ${output_k}=    Query  SELECT DISTINCT today_k,DATE FROM daily_stock_kdj WHERE stock_id = ${query_stock_id} AND DATE between ${query_start_date} and ${query_end_date} order by DATE ;
        Log  ${output_k}
        [Return]  ${output_k}


query_output_d_from_database
        [Arguments]     ${query_start_date}  ${query_end_date}  ${query_stock_id}  
        [Documentation] 

        ${output_d}=    Query  SELECT DISTINCT today_d,DATE FROM daily_stock_kdj WHERE stock_id = ${query_stock_id} AND DATE between ${query_start_date} and ${query_end_date} order by DATE ;
        Log  ${output_d}
        [Return]  ${output_d}

query_strategy_in_from_database
        [Arguments]     ${query_start_date}  ${query_end_date}  ${query_stock_id}   
#        [Arguments]     ${query_start_date}  ${query_end_date}    
        [Documentation] 

        ${output_strategy_in}=    Query  SELECT DISTINCT primary_key,date,strategy_id,separate_buyin_signal,class,stock_id,strategy_in_or_out,close,number_of_share,share_amount_price,evaluate_in_strategy_ror,estimate_in_stock_ror,evaluate_in_priority_buyin_signal,estimate_in_buyin_signal,null_parent_id,evaluate_in_children_id FROM strategy_in WHERE stock_id=${query_stock_id} AND date between '${query_start_date}' and '${query_end_date}' order by DATE ;
        Log  ${output_strategy_in}
        [Return]  ${output_strategy_in}

query_evaluate_in_from_database
        [Arguments]     ${query_start_date}  ${query_end_date}  ${query_stock_id}  
#        [Arguments]     ${query_start_date}  ${query_end_date}    
        [Documentation] 

        ${output_strategy_in}=    Query  SELECT DISTINCT primary_key,date,strategy_id,separate_buyin_signal,class,stock_id,evaluate_in_or_out,close,number_of_share,share_amount_price,evaluate_in_strategy_ror,estimate_in_stock_ror,evaluate_in_priority_buyin_signal,estimate_in_buyin_signal,strategy_in_parent_id,estimate_in_children_id FROM evaluate_in WHERE stock_id=${query_stock_id} AND date between '${query_start_date}' and '${query_end_date}' order by DATE ;
        Log  ${output_strategy_in}
        [Return]  ${output_strategy_in}



query_strategy_out_from_database
#        [Arguments]     ${query_start_date}  ${query_end_date}  ${query_stock_id}  
        [Arguments]     ${query_start_date}  ${query_end_date}    
        [Documentation] 

        ${output_strategy_out}=    Query  SELECT DISTINCT primary_key,date,strategy_id,buyin_signal,class,stock_id,strategy_in_or_out,close,number_of_share,share_amount_price,evaluate_out_strategy_ror,estimate_out_stock_ror,evaluate_out_sellout_signal,estimate_out_sellout_signal,assets_in_parent_id,evaluate_out_children_id FROM strategy_in WHERE DATE between ${query_start_date} and ${query_end_date} order by DATE ;
        Log  ${output_strategy_out}
        [Return]  ${output_strategy_out}







#insert_assets_data_to_database
#        [Arguments]     ${table_name}  ${assets_i}  ${primary_key}  ${strategy_id}  ${date}    ${class}  ${stock_id}  ${assets_in_or_out}  ${number_of_share}  ${unit_price}  ${share_amount_price}
#        [Documentation] 
#
#        Append_To_list  ${assets_i}  ${primary_key}  ${strategy_id}  ${date}    ${class}  ${stock_id}  ${assets_in_or_out}  ${number_of_share}  ${unit_price}  ${share_amount_price}
#
#        ${output_sql}=  Execute Sql String  INSERT INTO ${table_name} VALUES ( ${primary_key}, ${strategy_id}, '${date}', '${class}', '${stock_id}', '${assets_in_or_out}', ${number_of_share}, ${unit_price}, ${share_amount_price} )
#
#
#
#insert_equity_data_to_database
#        [Arguments]     ${table_name}  ${equity_i}  ${primary_key}  ${strategy_id}  ${date}  ${class}  ${equity_in_or_out}  ${currency}  ${exchange_rate}  ${currency_amount_NTD}
#
#        [Documentation] 
#
#
#        Append_To_list  ${equity_i}  ${primary_key}  ${strategy_id}  ${date}  ${class}  ${equity_in_or_out}  ${currency}  ${exchange_rate}  ${currency_amount_NTD}
#
#        ${output_sql}=  Execute Sql String  INSERT INTO ${table_name} VALUES ( ${primary_key}, ${strategy_id}, '${date}', '${class}', '${equity_in_or_out}', ${currency}, ${exchange_rate}, ${currency_amount_NTD} )
#






insert_strategy_data_to_database
        [Arguments]     ${table_name}  ${primary_key}  ${date}  ${strategy_id}  ${buyin_signal}  ${class}  ${stock_id}  ${strategy_in_or_out}  ${close}  ${number_of_share}  ${share_amount_price}  ${evaluate_strategy_ror}  ${estimate_stock_ror}  ${evaluate_in_buyin_signal}  ${estimate_in_buyin_signal}  ${assets_in_parent_id}  ${evaluate_children_id} 
        [Documentation] 

#        Append_To_list   ${primary_key}  ${date}  ${strategy_id}  ${buyin_signal}  ${class}  ${stock_id}  ${evaluate_in_or_out}  ${close}  ${number_of_share}  ${share_amount_price}  ${evaluate_strategy_ror}  ${estimate_stock_ror}  ${assets_in_parent_id}  ${evaluate_children_id}


        ${output_sql}=  Execute Sql String  INSERT INTO ${table_name} VALUES ( ${primary_key}, '${date}', ${strategy_id}, ${buyin_signal}, '${class}', '${stock_id}', '${strategy_in_or_out}', ${close}, ${number_of_share}, ${share_amount_price}, ${evaluate_strategy_ror}, ${estimate_stock_ror}, ${evaluate_in_buyin_signal}, ${estimate_in_buyin_signal}, ${assets_in_parent_id}, ${evaluate_children_id} )





#insert_evaluate_in_data_to_database
insert_evaluate_data_to_database
#        [Arguments]     ${table_name}  ${primary_key}  ${date}  ${strategy_id}  ${buyin_signal}  ${class}  ${stock_id}  ${evaluate_in_or_out}  ${close}  ${number_of_share}  ${share_amount_price}  ${evaluate_in_strategy_ror}  ${evaluate_in_buyin_signal}  ${estimate_in_buyin_signal}  ${strategy_in_parent_id}  ${estimate_in_children_id} 
        [Arguments]     ${table_name}  ${primary_key}  ${date}  ${strategy_id}  ${separate_buyin_signal}  ${class}  ${stock_id}  ${evaluate_in_or_out}  ${close}  ${number_of_share}  ${share_amount_price}  ${evaluate_strategy_ror}  ${estimate_stock_ror}  ${evaluate_in_priority_buyin_signal}  ${estimate_in_buyin_signal}  ${strategy_parent_id}  ${estimate_children_id} 
        [Documentation] 

#        Append_To_list   ${primary_key}  ${date}  ${strategy_id}  ${buyin_signal}  ${class}  ${stock_id}  ${evaluate_in_or_out}  ${close}  ${number_of_share}  ${share_amount_price}  ${evaluate_in_strategy_ror}  ${strategy_in_parent_id}  ${estimate_in_children_id}


#        ${output_sql}=  Execute Sql String  INSERT INTO ${table_name} VALUES ( ${primary_key}, '${date}', ${strategy_id}, ${buyin_signal}, '${class}', '${stock_id}', '${evaluate_in_or_out}', ${close}, ${number_of_share}, ${share_amount_price}, ${evaluate_in_strategy_ror}, ${strategy_in_parent_id}, ${estimate_in_children_id} )
        ${output_sql}=  Execute Sql String  INSERT INTO ${table_name} VALUES ( ${primary_key}, '${date}', ${strategy_id}, ${separate_buyin_signal}, '${class}', '${stock_id}', '${evaluate_in_or_out}', ${close}, ${number_of_share}, ${share_amount_price}, ${evaluate_strategy_ror}, ${estimate_stock_ror}, ${evaluate_in_priority_buyin_signal}, ${estimate_in_buyin_signal}, ${strategy_parent_id}, ${estimate_children_id} )



#insert_estimate_in_data_to_database
insert_estimate_data_to_database
#        [Arguments]     ${table_name}  ${primary_key}  ${date}  ${strategy_id}  ${buyin_signal}  ${class}  ${stock_id}  ${estimatein_or_out}  ${close}  ${number_of_share}  ${share_amount_price}  ${evaluate_in_strategy_ror}  ${estimate_in_stock_ror}  ${evaluate_in_parent_id}  ${assets_children_id}  ${equity_children_id}
        [Arguments]     ${table_name}  ${primary_key}  ${date}  ${strategy_id}  ${separate_buyin_signal}  ${class}  ${stock_id}  ${estimatein_or_out}  ${close}  ${number_of_share}  ${share_amount_price}  ${evaluate_strategy_ror}  ${estimate_stock_ror}  ${evaluate_in_priority_buyin_signal}  ${estimate_in_buyin_signal}  ${evaluate_parent_id}  ${assets_children_id}  ${equity_children_id}
        [Documentation] 

#        Append_To_list   ${primary_key}  ${date}  ${strategy_id}  ${buyin_signal}  ${class}  ${stock_id}  ${estimate_in_or_out}  ${close}  ${number_of_share}  ${share_amount_price}  ${evaluate_in_strategy_ror}  ${estimate_in_stock_ror}  ${evaluate_in_parent_id}  ${assets_in_children_id}  ${equity_children_id}


#        ${output_sql}=  Execute Sql String  INSERT INTO ${table_name} VALUES ( ${primary_key}, '${date}', ${strategy_id}, ${buyin_signal}, '${class}', '${stock_id}', '${estimate_in_or_out}', ${close}, ${number_of_share}, ${share_amount_price}, ${evaluate_in_strategy_ror}, ${estimate_in_stock_ror}, ${evaluate_in_parent_id}, ${assets_children_id}, ${equity_children_id} )
        ${output_sql}=  Execute Sql String  INSERT INTO ${table_name} VALUES ( ${primary_key}, '${date}', ${strategy_id}, ${separate_buyin_signal}, '${class}', '${stock_id}', '${estimate_in_or_out}', ${close}, ${number_of_share}, ${share_amount_price}, ${evaluate_strategy_ror}, ${estimate_stock_ror}, ${evaluate_in_priority_buyin_signal}, ${estimate_in_buyin_signal}, ${evaluate_parent_id}, ${assets_children_id}, ${equity_children_id} )






insert_assets_data_to_database
        [Arguments]     ${table_name}  ${primary_key}  ${date}  ${strategy_id}  ${buyin_signal}  ${class}  ${stock_id}  ${assets_in_or_out}  ${unit_price}  ${number_of_share}  ${share_amount_price}  ${evaluate_in_strategy_ror}  ${estimate_in_stock_ror}  ${evaluate_in_buyin_signal}  ${estimate_in_buyin_signal}  ${estimate_in_parent_id}  ${strategy_out_children_id} 
        [Documentation] 

#        Append_To_list   ${primary_key}  ${date}  ${strategy_id}  ${buyin_signal}  ${class}  ${stock_id}  ${assets_in_or_out}  ${unit_price}  ${number_of_share}  ${share_amount_price}  ${evaluate_in_strategy_ror}  ${estimate_in_stock_ror}  ${estimate_in_parent_id}  ${strategy_out_children_id}  


        ${output_sql}=  Execute Sql String  INSERT INTO ${table_name} VALUES ( ${primary_key}, '${date}', ${strategy_id}, ${buyin_signal}, '${class}', '${stock_id}', '${assets_in_or_out}', ${unit_price}, ${number_of_share}, ${share_amount_price}, ${evaluate_in_strategy_ror}, ${estimate_in_stock_ror}, ${evaluate_in_buyin_signal}, ${estimate_in_buyin_signal}, ${estimate_in_parent_id}, ${strategy_out_children_id} )



insert_equity_data_to_database
        [Arguments]     ${table_name}  ${primary_key}  ${date}  ${strategy_id}  ${buyin_signal}  ${class}  ${stock_id}  ${equity_in_or_out}  ${currency}  ${exchange_rate}  ${currency_amount_NTD}  ${evaluate_in_strategy_ror}  ${estimate_in_stock_ror}  ${evaluate_in_buyin_signal}  ${estimate_in_buyin_signal}  ${estimate_in_parent_id}  ${strategy_out_children_id} 
        [Documentation] 

#        Append_To_list   ${primary_key}  ${date}  ${strategy_id}  ${buyin_signal}  ${class}  ${stock_id}  ${equity_in_or_out}  ${currency}  ${exchange_rate}  ${currency_amount_NTD}  ${evaluate_in_strategy_ror}  ${estimate_in_stock_ror}  ${estimate_in_parent_id}  ${strategy_out_children_id}  


        ${output_sql}=  Execute Sql String  INSERT INTO ${table_name} VALUES ( ${primary_key}, '${date}', ${strategy_id}, ${buyin_signal}, '${class}', '${stock_id}', '${equity_in_or_out}', ${currency}, ${exchange_rate}, ${currency_amount_NTD}, ${evaluate_in_strategy_ror}, ${estimate_in_stock_ror}, ${evaluate_in_buyin_signal}, ${estimate_in_buyin_signal}, ${estimate_in_parent_id}, ${strategy_out_children_id} )



