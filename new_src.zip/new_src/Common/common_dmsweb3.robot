*** Variables ***
${xpath_DmsFrontEnd_username}                 xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div/div[1]/div[3]/div/div/div/div[2]/div/div[2]/input
${xpath_DmsFrontEnd_selectOffice}                 xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div/div[1]/div[3]/div/div/div/div[3]/div/div[2]/div[1]/div[1]
${xpath_DmsFrontEnd_selectOfficeOption}                 xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div/div[1]/div[3]/div/div/div/div[3]/div/div[2]/div[2]/div[2]/div
${xpath_DmsFrontEnd_password}                 xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div/div[1]/div[3]/div/div/div/div[4]/div[1]/div[2]/input
${xpath_DmsFrontEnd_enterbutton}              xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div/div[1]/div[4]/div[1]/button

${xpath_DmsFrontEnd_userID}              xpath=//*[@id="__nuxt"]/div/div[2]/div[1]/div[4]
${xpath_DmsFrontEnd_userID_logout}              xpath=//*[@id="__nuxt"]/div/div[2]/div[1]/div[4]/div/div[3]/div[2]/div[2]

${xpath_DmsFrontEndMenuButton}                xpath=//*[@id="__nuxt"]/div/div[2]/div[1]/div[1]/div[1]
${xpath_DmsFrontEndMenu_ListDR}         xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[1]/div[2]/div[5]/div/div[1]
${xpath_DmsFrontEndMenu_ListDR1}         xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[1]/div[2]/div[5]/div/div[2]/div/div[1]/div/div[1]
${xpath_DmsFrontEndMenu_ListDR1_8101}         xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[1]/div[2]/div[5]/div/div[2]/div/div[1]/div/div[2]/div/a[1]/div


${xpath_DmsFrontEndMenu_ListOP}         xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[1]/div[2]/div[3]/div/div[1]
${xpath_DmsFrontEndMenu_ListOP1}         xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[1]/div[2]/div[3]/div/div[2]/div/div[1]/div/div[1]
${xpath_DmsFrontEndMenu_ListOP1_2902}         xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[1]/div[2]/div[3]/div/div[2]/div/div[1]/div/div[2]/div/a[6]/div
${xpath_DmsFrontEndMenu_ListOP1_2900}         xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[1]/div[2]/div[3]/div/div[2]/div/div[1]/div/div[2]/div/a[5]/div
${xpath_DmsFrontEndMenu_ListOP1_2301}         xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[1]/div[2]/div[3]/div/div[2]/div/div[1]/div/div[2]/div/a[3]/div
${xpath_DmsFrontEndMenu_ListOP1_2300}         xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[1]/div[2]/div[3]/div/div[2]/div/div[1]/div/div[2]/div/a[2]/div
${xpath_DmsFrontEndMenu_ListOP1_2000}         xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[1]/div[2]/div[3]/div/div[2]/div/div[1]/div/div[2]/div/a[1]
${xpath_DmsFrontEndMenu_ListMM}         xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[1]/div[2]/div[9]/div/div[1]
${xpath_DmsFrontEndMenu_ListMM1}         xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[1]/div[2]/div[9]/div/div[2]/div/div/div/div[1]
${xpath_DmsFrontEndMenu_ListMM1_a100}         xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[1]/div[2]/div[9]/div/div[2]/div/div/div/div[2]/div/a[2]

${xpath_DmsFrontEndMenu_ListMM1_a100_BSC}         xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[1]/div/div/div/div/div/div/div/div/div[1]/div[2]/div
${xpath_DmsFrontEndMenu_ListMM1_a100_BSC_20OP}         xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[1]/div/div/div/div/div/div/div/div/div[2]/div/div[1]/div/div/div[1]/div[1]/div
${xpath_DmsFrontEndMenu_ListMM1_a100_BSC_20OP_1}         xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[1]/div/div/div/div/div/div/div/div/div[2]/div/div[1]/div/div/div[2]/div/div[1]
${xpath_DmsFrontEndMenu_ListMM1_a100_BSC_20OP_3}         xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[1]/div/div/div/div/div/div/div/div/div[2]/div/div[1]/div/div/div[2]/div/div[2]

${xpath_DmsFrontEndMenu_ListMM1_a100_BSC_DATE}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[2]/div[1]/div[2]/div[2]/div/div/div/div[1]/div[2]/div/div[2]/div[1]/input

${xpath_DmsFrontEndMenu_ListMM1_a100_BSC_TOUR_NO}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[2]/div[1]/div[2]/div[2]/div/div/div/div[2]/div[2]/div[2]/input

${xpath_DmsFrontEndMenu_ListMM1_a100_BSC_today_button}         xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[2]/div[1]/div[2]/div[2]/div/div/div/div[1]/div[3]/button

${xpath_DmsFrontEndMenu_ListMM1_a100_BSC_plus_button}         xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[2]/div[1]/div[2]/div[2]/div/div/div/div[2]/div[3]/button

${xpath_DmsFrontEndMenu_ListMM1_a100_BSC_save_button}         xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[2]/div[1]/div[2]/div[2]/div/div/div/div[3]/button[2]





${xpath_DmsFrontEnd_2301_MList_letter_end_button}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[2]/div[4]/div[2]/div[2]/div/div/div/div/div/div[3]/button[2]

${xpath_DmsFrontEnd_2301_MList_letter_save_button}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[2]/div[4]/div[2]/div[2]/div/div/div/div/div/div[3]/button[1]


${xpath_DmsFrontEnd_2000_MList_letter_end_button}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[2]/div[4]/div[2]/div[2]/div/div/div/div/div/div[3]/button[2]

${xpath_DmsFrontEnd_2000_MList_letter_save_button}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[2]/div[4]/div[2]/div[2]/div/div/div/div/div/div[3]/button[1]

${xpath_DmsFrontEnd_2000_MList_letter_DST_OFFICE}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[2]/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[2]/td/div/div[1]/input


${xpath_DmsFrontEnd_2000_MList_letter_VAL_DCL_AMT}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[2]/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[1]/td[2]/div/div/input


${xpath_DmsFrontEnd_2301_MList_letter_MAIL_NO}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[2]/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr/td[1]/div/div/input


${xpath_DmsFrontEnd_2000_MList_letter_MAIL_NO}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[2]/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[1]/td[1]/div/div/input

${xpath_DmsFrontEnd_2301_MList_new_letter_button}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[2]/div[3]/div[2]/div[1]/div/button[1]

${xpath_DmsFrontEnd_2000_MList_new_letter_button}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[2]/div[3]/div[2]/div[1]/div/button



#${xpath_DmsFrontEnd_2000_MList_login_button}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[2]/td/span/button[3]

${xpath_DmsFrontEnd_2000_checkout_button}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[2]/td/span/button[4]

${xpath_DmsFrontEnd_2000MList_NO}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[2]/div[2]/div/div/div[1]/div[4]/div[2]/input



${xpath_DmsFrontEnd_2000MLIST_MESSAGE}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[4]/div[2]/div[2]/div/div/div/div/div/div[1]/span

${xpath_DmsFrontEnd_2000MLIST_STATE}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[1]/td[9]











${xpath_DmsFrontEnd_2300IN_TYPEoption1}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[1]/td[1]/div/div/div[2]/div[1]/div

${xpath_DmsFrontEnd_2300IN_TYPEoption2}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[1]/td[1]/div/div/div[2]/div[2]/div

${xpath_DmsFrontEnd_2300IN_TYPEoption3}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[1]/td[1]/div/div/div[2]/div[3]/div

${xpath_DmsFrontEnd_2300IN_TYPEoption4}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[1]/td[1]/div/div/div[2]/div[4]/div

${xpath_DmsFrontEnd_2300IN_TYPEoption5}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[1]/td[1]/div/div/div[2]/div[5]/div

${xpath_DmsFrontEnd_2300IN_TYPEoption6}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[1]/td[1]/div/div/div[2]/div[6]/div

${xpath_DmsFrontEnd_2300IN_TYPEoption7}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[1]/td[1]/div/div/div[2]/div[7]/div

${xpath_DmsFrontEnd_2300IN_TYPEoption8}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[1]/td[1]/div/div/div[2]/div[8]/div

${xpath_DmsFrontEnd_2300IN_TYPEoption9}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[1]/td[1]/div/div/div[2]/div[9]/div

${xpath_DmsFrontEnd_2300IN_TYPEoption11}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[1]/td[1]/div/div/div[2]/div[10]/div

${xpath_DmsFrontEnd_2300IN_TYPEoption11}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[1]/td[1]/div/div/div[2]/div[11]/div

${xpath_DmsFrontEnd_2300IN_TYPEoption16}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[1]/td[1]/div/div/div[2]/div[12]/div

${xpath_DmsFrontEnd_2300IN_TYPEoption168}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[1]/td[1]/div/div/div[2]/div[13]/div

${xpath_DmsFrontEnd_2300IN_TYPEoption169}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[1]/td[1]/div/div/div[2]/div[14]/div

${xpath_DmsFrontEnd_2300IN_TYPE}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[1]/td[1]/div/div/div[1]


${xpath_DmsFrontEnd_2300MLST_TYPEoption1}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[1]/td[2]/div/div/div[2]/div[1]/div

${xpath_DmsFrontEnd_2300MLST_TYPEoption0}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[1]/td[2]/div/div/div[2]/div[2]/div

${xpath_DmsFrontEnd_2300MLST_TYPE}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[1]/td[2]/div/div/div[1]/div[1]

${xpath_DmsFrontEnd_2300MLIST_NO}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[2]/td[1]/div/div/input

${xpath_DmsFrontEnd_2300ORG_OFFICE}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[2]/td[2]/div/div/input

${xpath_DmsFrontEnd_2300DST_OFFICE}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[3]/td[1]/div/div/input

${xpath_DmsFrontEnd_2300COR}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[3]/td[2]/div/div/input




${xpath_DmsFrontEnd_2000_MList_transfer_RCV_OFFICEoption2}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[2]/div[2]/div/div/div[2]/div[2]/div[2]/div[2]/div[1]/div

${xpath_DmsFrontEnd_2000_MList_transfer_RCV_OFFICEoption3}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[2]/div[2]/div/div/div[2]/div[2]/div[2]/div[2]/div[2]/div

${xpath_DmsFrontEnd_2000_MList_transfer_RCV_OFFICEoption4}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[2]/div[2]/div/div/div[2]/div[2]/div[2]/div[2]/div[3]/div

${xpath_DmsFrontEnd_2000_MList_transfer_RCV_OFFICE}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[2]/div[2]/div/div/div[2]/div[2]/div[2]/div[1]/div[1]

${xpath_DmsFrontEnd_2000_MList_transfer_ACC_DATE_from}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[2]/div[2]/div/div/div[1]/div[1]/div[2]/input

${xpath_DmsFrontEnd_2000_MList_transfer_ACC_DATE_to}        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[2]/div[2]/div/div/div[1]/div[2]/div[2]/input

${xpath_DmsFrontEnd_2000_MList_transfer_TOUR_NO_from}        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[2]/div[2]/div/div/div[1]/div[3]/div[2]/input

${xpath_DmsFrontEnd_2000_MList_transfer_TOUR_NO_to}        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[2]/div[2]/div/div/div[1]/div[4]/div[2]/input

${xpath_DmsFrontEnd_2000_MList_transfer_STAFF_NO}        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[2]/div[2]/div/div/div[2]/div[1]/div[1]/div[2]/input

${xpath_DmsFrontEnd_2000_MList_transfer_RCV_OFFICE}        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[2]/div[2]/div/div/div[2]/div[2]/div[2]/div[1]/div[1]



${xpath_DmsFrontEnd_2000ACC_DATE}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[2]/div[2]/div/div/div[1]/div[1]/div[2]/input

${xpath_DmsFrontEnd_2000TOUR_NO}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[2]/div[2]/div/div/div[1]/div[2]/div[2]/input



${xpath_DmsFrontEnd_2000STAFF_NO}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[2]/div[2]/div/div/div[1]/div[3]/div[1]/div[2]/input

${xpath_DmsFrontEnd_2000NewMListButton}         xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[1]/div/button



${xpath_DmsFrontEnd_2000_MList_transfer_FetchButton}         xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[2]/div[2]/div/div/div[4]/button[1]

${xpath_DmsFrontEnd_2000FetchButton}         xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[2]/div[2]/div/div/div[2]/button

${xpath_DmsFrontEnd_2301_F3_Button}         xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[1]/div/button[2]

${xpath_DmsFrontEnd_2000RCV_OFFICE}                  xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[2]/td[2]/div/div/div[1]/div[1]

${xpath_DmsFrontEnd_2000RCV_OFFICEoption2}                  xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[2]/td[2]/div/div/div[2]/div[1]/div

${xpath_DmsFrontEnd_2000RCV_OFFICEoption3}                  xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[2]/td[2]/div/div/div[2]/div[2]/div

${xpath_DmsFrontEnd_2000RCV_OFFICEoption4}                  xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[2]/td[2]/div/div/div[2]/div[3]/div

${xpath_DmsFrontEnd_2000MAIL_TYPE}                  xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[3]/td[1]/div/div/div[1]/div[1]

${xpath_DmsFrontEnd_2000MAIL_TYPEoption1}                  xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[3]/td[1]/div/div/div[2]/div[1]/div

${xpath_DmsFrontEnd_2000MAIL_TYPEoption2}                  xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[3]/td[1]/div/div/div[2]/div[2]/div

${xpath_DmsFrontEnd_2000MAIL_TYPEoption3}                  xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[3]/td[1]/div/div/div[2]/div[3]/div

${xpath_DmsFrontEnd_2000MAIL_TYPEoption4}                  xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[3]/td[1]/div/div/div[2]/div[4]/div


${xpath_DmsFrontEnd_2000MAIL_TYPEoptionB}                  xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[3]/td[1]/div/div/div[2]/div[5]/div

${xpath_DmsFrontEnd_2000EndButton}         xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[4]/div[2]/div[2]/div/div/div/div/div/div[3]/button[2]

${xpath_DmsFrontEnd_2000SendButton}         xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[4]/div[2]/div[2]/div/div/div/div/div/div[3]/button[1]

${xpath_DmsFrontEnd_2300EndButton}         xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[3]/button[2]


${xpath_DmsFrontEnd_2300SendButton}         xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[3]/button[1]



${xpath_DmsFrontEnd_8101NewNoneM5A0Button}         xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[3]/div[2]/div[1]/div/button[2]


${xpath_DmsFrontEnd_8120ACC_DATE}                  xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[2]/td[1]/div/div/input
${xpath_DmsFrontEnd_8120TOUR_NO}                       xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[2]/td[2]/div/div/input
${xpath_DmsFrontEnd_8120CAR_NO}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[3]/td[1]/div/div/input
${xpath_DmsFrontEnd_8120RCV_STAFF_ID}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[3]/td[2]/div/div[1]/div/input
${xpath_DmsFrontEnd_8120RCV_KIND}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[4]/td/div/div/div[1]/div[1]
${xpath_DmsFrontEnd_8120RCV_KINDoption}                               xpath=//*[@id="__nuxt"]/div/div[2]/div/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[4]/td/div/div/div[2]/div[3]/div
${xpath_DmsFrontEnd_8120CUS_PH_NO}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[6]/td[1]/div/div/input
${xpath_DmsFrontEnd_8120SND_TEL}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[6]/td[2]/div/div/input
${xpath_DmsFrontEnd_8120BNS_TYPE}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[7]/td[1]/div/div[1]/div/input
${xpath_DmsFrontEnd_8120ZIP_CODE}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[7]/td[2]/div/div[1]/div/input
${xpath_DmsFrontEnd_8120SPL_OFFICE}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[8]/td[2]/div/div[1]/div/input
${xpath_DmsFrontEnd_8120MAIL_NO}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[10]/td[1]/div/div/input
${xpath_DmsFrontEnd_8120MAIL_LENGTH}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[12]/td/table/tbody/tr/td[1]/div/div/input
${xpath_DmsFrontEnd_8120MAIL_WIDTH}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[12]/td/table/tbody/tr/td[2]/div/div/input
${xpath_DmsFrontEnd_8120MAIL_HEIGHT}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[12]/td/table/tbody/tr/td[3]/div/div/input
${xpath_DmsFrontEnd_8120MAIL_WEIGHT}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[11]/td[2]/div/div/input

${xpath_DmsFrontEnd_8120DST_NT_CODE}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[10]/td[2]/div/div[1]/div/input
${xpath_DmsFrontEnd_8120MAIL_TYPE}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[11]/td[1]/div/div/div[1]/div[1]
${xpath_DmsFrontEnd_8120MAIL_TYPEoption}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[11]/td[1]/div/div/div[2]/div[3]/div
${xpath_DmsFrontEnd_8120DSN_TYPE}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[14]/td/div/div/div[1]/div[1]
${xpath_DmsFrontEnd_8120DSN_TYPEoption1}                        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[14]/td/div/div/div[2]/div[3]/div
${xpath_DmsFrontEnd_8120DSN_TYPEoption2}                        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[14]/td/div/div/div[2]/div[4]/div
${xpath_DmsFrontEnd_8120DSN_TYPEoption3}                        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[14]/td/div/div/div[2]/div[5]/div
${xpath_DmsFrontEnd_8120DSN_TYPEoption4}                        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[14]/td/div/div/div[2]/div[6]/div
${xpath_DmsFrontEnd_8120DSN_TYPEoption5}                        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[14]/td/div/div/div[2]/div[7]/div
${xpath_DmsFrontEnd_8120DSN_TYPEoption6}                        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[14]/td/div/div/div[2]/div[8]/div
${xpath_DmsFrontEnd_8120DSN_TYPEoption7}                        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[14]/td/div/div/div[2]/div[9]/div
${xpath_DmsFrontEnd_8120DSN_TYPEoption8}                        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[14]/td/div/div/div[2]/div[10]/div
${xpath_DmsFrontEnd_8120DSN_TYPEoption9}                        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[14]/td/div/div/div[2]/div[11]/div
${xpath_DmsFrontEnd_8120DSN_TYPEoption10}                        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[14]/td/div/div/div[2]/div[12]/div
${xpath_DmsFrontEnd_8120DSN_TYPEoption11}                        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[14]/td/div/div/div[2]/div[13]/div
${xpath_DmsFrontEnd_8120DSN_TYPEoption12}                        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[14]/td/div/div/div[2]/div[14]/div
${xpath_DmsFrontEnd_8120DSN_TYPEoption13}                        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[14]/td/div/div/div[2]/div[15]/div
${xpath_DmsFrontEnd_8120DSN_TYPEoption14}                        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[14]/td/div/div/div[2]/div[16]/div


${xpath_DmsFrontEnd_8120MAIL_TYPE1}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[17]/td[1]/label/input
${xpath_DmsFrontEnd_8120ISR_CHARGE}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[17]/td[2]/div/div/input
${xpath_DmsFrontEnd_8120PAY_CASH_AMT}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[19]/td[1]/div/div/input
${xpath_DmsFrontEnd_8120PAY_POSTAL_AMT}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[19]/td[2]/div/div/input
${xpath_DmsFrontEnd_8120PAY_STMP_AMT}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[20]/td[1]/div/div/input
${xpath_DmsFrontEnd_8120MON_PAY}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[20]/td[2]/div/div/input
${xpath_DmsFrontEnd_8120CustomsFlag}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[24]/td[1]/label/input
${xpath_DmsFrontEnd_8120RCV_TEL}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[24]/td[2]/div/div/input
${xpath_DmsFrontEnd_8120TOL_POSTAL}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[25]/td/div/div/input


${xpath_DmsFrontEnd_2301_new_MList_MLST_TYPE}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[1]/td/div/div/div[1]/div[1]


${xpath_DmsFrontEnd_2301_new_MList_MLIST_NO}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[2]/td[1]/div/div/input

${xpath_DmsFrontEnd_2301_new_MList_ORG_OFFICE}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[2]/td[2]/div/div/input

${xpath_DmsFrontEnd_2301_new_MList_PCK_CNT}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[3]/td[1]/div/div/input

${xpath_DmsFrontEnd_2301_new_MList_RCL_CNT}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[3]/td[2]/div/div/input

${xpath_DmsFrontEnd_2301_new_MList_C_CNT}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[4]/td[1]/div/div/input

${xpath_DmsFrontEnd_2301_new_MList_BIDDING_CNT}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[4]/td[2]/div/div/input

${xpath_DmsFrontEnd_2301_new_MList_INCL_CNT}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[5]/td[1]/div/div/input

${xpath_DmsFrontEnd_2301_new_MList_INOP_CNT}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[5]/td[2]/div/div/input

${xpath_DmsFrontEnd_2301_new_MList_send_button}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[4]/div[2]/div[2]/div/div/div/div/div/div[3]/button[1]

${xpath_DmsFrontEnd_2301_new_MList_end_button}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[4]/div[2]/div[2]/div/div/div/div/div/div[3]/button[2]


${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPEoption1}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[1]/td/div/div/div[2]/div[1]/div

${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPEoption2}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[1]/td/div/div/div[2]/div[2]/div

${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPEoption3}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[1]/td/div/div/div[2]/div[3]/div

${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPEoption4}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[1]/td/div/div/div[2]/div[4]/div

${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPEoption5}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[1]/td/div/div/div[2]/div[5]/div

${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPEoption6}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[1]/td/div/div/div[2]/div[6]/div

${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPEoption7}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[1]/td/div/div/div[2]/div[7]/div

${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPEoption8}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[1]/td/div/div/div[2]/div[8]/div

${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPEoption9}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[1]/td/div/div/div[2]/div[9]/div

${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPEoption11}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[1]/td/div/div/div[2]/div[10]/div

${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPEoption16}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[1]/td/div/div/div[2]/div[11]/div

${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPEoption168}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[1]/td/div/div/div[2]/div[12]/div

${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPEoption169}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[1]/td/div/div/div[2]/div[13]/div


${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPE}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[1]/td/div/div/div[1]/div[1]

${xpath_DmsFrontEnd_2301_F3_new_MList_MLIST_NO}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[2]/td[1]/div/div/input

${xpath_DmsFrontEnd_2301_F3_new_MList_ORG_OFFICE}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[2]/td[2]/div/div/input

${xpath_DmsFrontEnd_2301_F3_new_MList_PCK_CNT}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[3]/td[1]/div/div/input

${xpath_DmsFrontEnd_2301_F3_new_MList_RCL_CNT}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[3]/td[2]/div/div/input

${xpath_DmsFrontEnd_2301_F3_new_MList_C_CNT}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[4]/td[1]/div/div/input

${xpath_DmsFrontEnd_2301_F3_new_MList_BIDDING_CNT}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[4]/td[2]/div/div/input

${xpath_DmsFrontEnd_2301_F3_new_MList_INCL_CNT}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[5]/td[1]/div/div/input

${xpath_DmsFrontEnd_2301_F3_new_MList_INOP_CNT}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[5]/td[2]/div/div/input

${xpath_DmsFrontEnd_2301_F3_new_MList_send_button}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[4]/div[2]/div[2]/div/div/div/div/div/div[3]/button[1]

${xpath_DmsFrontEnd_2301_F3_new_MList_end_button}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[4]/div[2]/div[2]/div/div/div/div/div/div[3]/button[2]


${xpath_DmsFrontEnd_2301_new_M120_MList_send_button}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[3]/div[4]/div[2]/div[2]/div/div/div/div/div/div[3]/button[1]

${xpath_DmsFrontEnd_2301_new_M120_MList_end_button}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[3]/div[4]/div[2]/div[2]/div/div/div/div/div/div[3]/button[2]

${xpath_DmsFrontEnd_2301_new_M120_MList_MLST_TYPE}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[3]/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[1]/td/div/div/div[1]/div[1]


${xpath_DmsFrontEnd_2301_new_M120_MList_MLST_TYPEoption0}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[3]/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[1]/td/div/div/div[2]/div[2]


${xpath_DmsFrontEnd_2301_new_M120_MList_MLST_TYPEoption1}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[3]/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[1]/td/div/div/div[2]/div[1]

${xpath_DmsFrontEnd_2301_new_M120_MList_MLIST_NO}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[3]/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[2]/td/div/div/input

${xpath_DmsFrontEnd_2301_new_M120_MList_ORG_OFFICE}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[3]/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[3]/td/div/div/input

${xpath_DmsFrontEnd_2301_new_M120_MList_DST_OFFICE}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[3]/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[4]/td/div/div/input

${xpath_DmsFrontEnd_2301_new_M120_MList_COR_MLIST}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[3]/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[5]/td/div/div/input





${select_value_TaipeiPostOffice}                   000000
${select_value_Zhongzheng_delivery}                100572














*** keywords ***



















































post_postweb2_pnsFrontEndloginFirefox
    [Arguments]     ${url}
    [Documentation]    Do bmc web login
        ${Browser_Ids}=  Browser.Get Browser Ids
        ${Page_Ids}=     Browser.Get Page Ids
        IF  ${Browser_Ids} != []
            Browser.Go To    ${url}
        ELSE
            New Browser  firefox  headless=false  args=['--allow-insecure-localhost']
#            New Browser  chromium  headless=false  args=['--allow-insecure-localhost']
            New Context  ignoreHTTPSErrors=${True}  bypassCSP=${True}
            New Page    ${url}
        END
#        Open Browser  ${url}  firefox
#        Set Browser Timeout  60s
#        New Context    viewport={'width': 1920, 'height': 1080}



dms_postweb2_pnsFrontEndloginChrome
    [Arguments]     ${url}
    [Documentation]    Do bmc web login
        ${Browser_Ids}=  Browser.Get Browser Ids
        ${Page_Ids}=     Browser.Get Page Ids
        IF  ${Browser_Ids} != []
            Browser.Go To    ${url}
        ELSE
#            New Browser  firefox  headless=false  args=['--allow-insecure-localhost']
            New Browser  chromium  headless=false  args=['--allow-insecure-localhost']
            New Context  ignoreHTTPSErrors=${True}  bypassCSP=${True}
            New Page    ${url}
        END
#        Open Browser  ${url}  firefox
#        Set Browser Timeout  60s
#        New Context    viewport={'width': 1920, 'height': 1080}




post_postweb2_pnsFrontEndloginbyExcel
    [Arguments]     ${excel_url}
    [Documentation]    Do bmc web login
        ${Browser_Ids}=  Browser.Get Browser Ids
        ${Page_Ids}=     Browser.Get Page Ids
        IF  ${Browser_Ids} != []
            Browser.Go To    https://pnstest.post.gov.tw/LI.Web/Quest.aspx?q_sid=${excel_url}
        ELSE
            New Browser  firefox  headless=false  args=['--allow-insecure-localhost']
            New Context  ignoreHTTPSErrors=${True}  bypassCSP=${True}
            New Page    https://pnstest.post.gov.tw/LI.Web/Quest.aspx?q_sid=${excel_url}
        END
#        Open Browser  ${url}  firefox
#        Set Browser Timeout  60s
#        New Context    viewport={'width': 1920, 'height': 1080}
        

dms_dmsweb2_ClickDmsFrontEndLoginUsername
    [Arguments]     ${username}
        [Documentation]
        [Tags]
        Fill Text     ${xpath_DmsFrontEnd_username}    ${username}


dms_dmsweb2_ClickDmsFrontEndLoginSelectOffice
        [Documentation]

#        Click  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndContent1_btnQuery}
        Click   ${xpath_DmsFrontEnd_selectOffice}

#        Sleep  1s

        Click   ${xpath_DmsFrontEnd_selectOfficeOption}
 
#        Sleep  1s
        Take Screenshot




dms_dmsweb2_ClickDmsFrontEndLoginPassword
    [Arguments]     ${password}
        [Documentation]
        [Tags]
        Fill Text     ${xpath_DmsFrontEnd_password}    ${password}
#        Input Password    ${xpath_DmsFrontEnd_password}    ${password}
#        Input Text    ${xpath_DmsFrontEnd_password}    ${password}


dms_dmsweb2_ClickDmsFrontEndLoginEnter
        [Documentation]
        Click     ${xpath_DmsFrontEnd_enterbutton}



dms_dmsweb2_ClickDmsFrontEnduserID_logout
        [Documentation]
        [Tags]
        Click   ${xpath_DmsFrontEnd_userID}
        Click   ${xpath_DmsFrontEnd_userID_logout}
        Set Browser Timeout    10s


dms_dmsweb2_ClickDmsFrontEndMenuButton
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndMenu_List2}
        Click     ${xpath_DmsFrontEndMenuButton}
#        Sleep  1s
#        Handle Alert


dms_dmsweb2_ClickDmsFrontEndMenu_ListDR1
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndMenu_List2Button1}
        Click     ${xpath_DmsFrontEndMenu_ListDR}
        Click     ${xpath_DmsFrontEndMenu_ListDR1}
#        Sleep  1s
#        Handle Alert

dms_dmsweb2_ClickDmsFrontEndMenu_ListOP1
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndMenu_List2Button1}
        Click     ${xpath_DmsFrontEndMenu_ListOP}
        Click     ${xpath_DmsFrontEndMenu_ListOP1}
        Set Browser Timeout    2s

#        Sleep  1s
#        Handle Alert

dms_dmsweb2_ClickDmsFrontEndMenu_ListOP1_2902
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndMenu_List2Button1}
        Click     ${xpath_DmsFrontEndMenu_ListOP1_2902}
#        Sleep  1s
#        Handle Alert

dms_dmsweb2_ClickDmsFrontEndMenu_ListOP1_2900
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndMenu_List2Button1}
        Click     ${xpath_DmsFrontEndMenu_ListOP1_2900}
#        Sleep  1s
#        Handle Alert

dms_dmsweb2_ClickDmsFrontEndMenu_ListOP1_2301
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndMenu_List2Button1}
        Click     ${xpath_DmsFrontEndMenu_ListOP1_2301}
#        Sleep  1s
#        Handle Alert


dms_dmsweb2_ClickDmsFrontEndMenu_ListOP1_2300
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndMenu_List2Button1}
        Click     ${xpath_DmsFrontEndMenu_ListOP1_2300}
#        Sleep  1s
#        Handle Alert


dms_dmsweb2_ClickDmsFrontEndMenu_ListOP1_2000
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndMenu_List2Button1}
        Click     ${xpath_DmsFrontEndMenu_ListOP1_2000}
#        Sleep  1s
#        Handle Alert


dms_dmsweb2_ClickDmsFrontEndMenu_ListMM1
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndMenu_List2Button1}
        Click     ${xpath_DmsFrontEndMenu_ListMM}
        Click     ${xpath_DmsFrontEndMenu_ListMM1}
#        Sleep  1s
#        Handle Alert

dms_dmsweb2_ClickDmsFrontEndMenu_ListMM1_a100
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndMenu_List2Button1}
        Click     ${xpath_DmsFrontEndMenu_ListMM1_a100}
#        Sleep  1s
#        Handle Alert

dms_dmsweb2_ClickDmsFrontEndMenu_ListMM1_a100_BSC
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndMenu_List2Button1}
        Click     ${xpath_DmsFrontEndMenu_ListMM1_a100_BSC}
        Take Screenshot
#        Sleep  1s
#        Handle Alert

dms_dmsweb2_ClickDmsFrontEndMenu_ListMM1_a100_BSC_20OP
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndMenu_List2Button1}
        Click     ${xpath_DmsFrontEndMenu_ListMM1_a100_BSC_20OP}
#        Sleep  1s
#        Handle Alert

dms_dmsweb2_ClickDmsFrontEndMenu_ListMM1_a100_BSC_20OP_1
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndMenu_List2Button1}
        Click     ${xpath_DmsFrontEndMenu_ListMM1_a100_BSC_20OP_1}
#        Sleep  1s
#        Handle Alert

dms_dmsweb2_ClickDmsFrontEndMenu_ListMM1_a100_BSC_20OP_3
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndMenu_List2Button1}
        Click     ${xpath_DmsFrontEndMenu_ListMM1_a100_BSC_20OP_3}
#        Sleep  1s
#        Handle Alert

dms_dmsweb2_ClickDmsFrontEndMenu_ListMM1_a100_BSC_DATE
        [Arguments]  ${BSC_DATE}
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndMenu_List2Button1}
        Fill Text   ${xpath_DmsFrontEndMenu_ListMM1_a100_BSC_DATE}   ${BSC_DATE}

#        Sleep  1s
#        Handle Alert

dms_dmsweb2_ClickDmsFrontEndMenu_ListMM1_a100_BSC_TOUR_NO
        [Arguments]  ${TOUR_NO}
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndMenu_List2Button1}
        Fill Text   ${xpath_DmsFrontEndMenu_ListMM1_a100_BSC_TOUR_NO}   ${TOUR_NO}

#        Sleep  1s
#        Handle Alert

dms_dmsweb2_ClickDmsFrontEndMenu_ListMM1_a100_BSC_today_button
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndMenu_List2Button1}
        Click     ${xpath_DmsFrontEndMenu_ListMM1_a100_BSC_today_button}
#        Sleep  1s
#        Handle Alert

dms_dmsweb2_ClickDmsFrontEndMenu_ListMM1_a100_BSC_plus_button
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndMenu_List2Button1}
        Click     ${xpath_DmsFrontEndMenu_ListMM1_a100_BSC_plus_button}
#        Sleep  1s
#        Handle Alert

dms_dmsweb2_ClickDmsFrontEndMenu_ListMM1_a100_BSC_save_button
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndMenu_List2Button1}
        Click     ${xpath_DmsFrontEndMenu_ListMM1_a100_BSC_save_button}
#        Sleep  1s
#        Handle Alert 



dms_dmsweb2_ClickDmsFrontEnd_2301_F3_new_MList_send_button
        [Documentation]
        [Tags]

        Click    ${xpath_DmsFrontEnd_2301_F3_new_MList_send_button}


dms_dmsweb2_ClickDmsFrontEnd_2301_F3_new_MList_end_button
        [Documentation]
        [Tags]

        Click    ${xpath_DmsFrontEnd_2301_F3_new_MList_end_button}

dms_dmsweb2_ClickDmsFrontEnd_2301_new_M120_MList_send_button
        [Documentation]
        [Tags]

        Click    ${xpath_DmsFrontEnd_2301_new_M120_MList_send_button}


dms_dmsweb2_ClickDmsFrontEnd_2301_new_M120_MList_end_button
        [Documentation]
        [Tags]

        Click    ${xpath_DmsFrontEnd_2301_new_M120_MList_end_button}

dms_dmsweb2_ClickDmsFrontEnd_2301_new_MList_end_button
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}
        Click    ${xpath_DmsFrontEnd_2301_new_MList_end_button}


dms_dmsweb2_ClickDmsFrontEnd_2301_MList_letter_end_button
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}
        Click    ${xpath_DmsFrontEnd_2301_MList_letter_end_button}


dms_dmsweb2_ClickDmsFrontEnd_2301_MList_letter_save_button
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}
        Click    ${xpath_DmsFrontEnd_2301_MList_letter_save_button}


dms_dmsweb2_ClickDmsFrontEnd_2000_MList_letter_end_button
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}
        Click    ${xpath_DmsFrontEnd_2000_MList_letter_end_button}


dms_dmsweb2_ClickDmsFrontEnd_2000_MList_letter_save_button
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}
        Click    ${xpath_DmsFrontEnd_2000_MList_letter_save_button}


dms_dmsweb2_ClickDmsFrontEnd_2000_MList_letter_DST_OFFICE
        [Arguments]  ${DST_OFFICE}
        [Documentation]
        [Tags]
        IF  '${DST_OFFICE}' == 'NONE'  
            Click    ${xpath_DmsFrontEnd_2000_MList_letter_DST_OFFICE}
            Keyboard Key    down     Control
            Keyboard Key    press    A
            Keyboard Key    up       Control     
            Keyboard Key    press    Delete 
        ELSE
            Fill Text   ${xpath_DmsFrontEnd_2000_MList_letter_DST_OFFICE}    ${DST_OFFICE}

        END


dms_dmsweb2_ClickDmsFrontEnd_2000_MList_letter_VAL_DCL_AMT
        [Arguments]  ${VAL_DCL_AMT}
        [Documentation]
        [Tags]
#        Fill Text   ${xpath_DmsFrontEnd_2000_MList_letter_VAL_DCL_AMT}    ${VAL_DCL_AMT}
        IF  '${VAL_DCL_AMT}' == 'None'  

        	${states}=    Get Element States    ${xpath_DmsFrontEnd_2000_MList_letter_VAL_DCL_AMT}

            ${VAL_DCL_AMT_is_enabled}=  Run Keyword And Continue On Failure    Get Element States    ${xpath_DmsFrontEnd_2000_MList_letter_VAL_DCL_AMT}  then   bool(value & enabled) 
            Log  ${VAL_DCL_AMT_is_enabled}
            IF  '${VAL_DCL_AMT_is_enabled}' == 'True' 
                Click    ${xpath_DmsFrontEnd_2000_MList_letter_VAL_DCL_AMT}
                Keyboard Key    down     Control
                Keyboard Key    press    A
                Keyboard Key    up       Control     
                Keyboard Key    press    Delete 
            ELSE
                Take Screenshot
            END
        ELSE
            Fill Text   ${xpath_DmsFrontEnd_2000_MList_letter_VAL_DCL_AMT}    ${VAL_DCL_AMT}
        END

dms_dmsweb2_ClickDmsFrontEnd_2000_MList_letter_MAIL_NO
        [Arguments]  ${MAIL_NO}
        [Documentation]
        [Tags]
#        Fill Text   ${xpath_DmsFrontEnd_2000_MList_letter_MAIL_NO}    ${MAIL_NO}
        IF  '${MAIL_NO}' == 'NONE'  
            Click    ${xpath_DmsFrontEnd_2000_MList_letter_MAIL_NO}
            Keyboard Key    down     Control
            Keyboard Key    press    A
            Keyboard Key    up       Control     
            Keyboard Key    press    Delete 
        ELSE
            Fill Text   ${xpath_DmsFrontEnd_2000_MList_letter_MAIL_NO}    ${MAIL_NO}
        END

dms_dmsweb2_ClickDmsFrontEnd_2301_MList_letter_MAIL_NO
        [Arguments]  ${MAIL_NO}
        [Documentation]
        [Tags]

        IF  '${MAIL_NO}' == 'NONE'  
            Click    ${xpath_DmsFrontEnd_2301_MList_letter_MAIL_NO}
            Keyboard Key    down     Control
            Keyboard Key    press    A
            Keyboard Key    up       Control     
            Keyboard Key    press    Delete 
        ELSE
            Fill Text   ${xpath_DmsFrontEnd_2301_MList_letter_MAIL_NO}    ${MAIL_NO}
        END

dms_dmsweb2_ClickDmsFrontEnd_2301_MList_new_letter_button
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}
        Click    ${xpath_DmsFrontEnd_2301_MList_new_letter_button}

dms_dmsweb2_ClickDmsFrontEnd_2000_MList_new_letter_button
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}
        Click    ${xpath_DmsFrontEnd_2000_MList_new_letter_button}


dms_dmsweb2_ClickDmsFrontEnd_2000_MList_checkout_button
        [Arguments]  ${i}
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}


        IF  '${i}'=='1'

            Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[1]
            Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[2]/td/span/button[4]

        ELSE

            Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]
            Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td/span/button[4]

        END


dms_dmsweb2_ClickDmsFrontEnd_2000_MList_transfer_FetchButton
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}
        Click    ${xpath_DmsFrontEnd_2000_MList_transfer_FetchButton}
#        ${MLIST_NO}=  Get_text  ${xpath_DmsFrontEnd_2000MLIST_NO}  
#        ${MLIST_STATE}=  Get_text  ${xpath_DmsFrontEnd_2000MLIST_STATE}
#        RETURN  ${MLIST_NO}  ${MLIST_STATE}


dms_dmsweb2_ClickDmsFrontEnd_2000_mail_transfer_check_button
        [Arguments]  ${i}
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}


        IF  '${i}'=='1'

            Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[1]
            Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[2]/td/span/button

        ELSE

            Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]
            Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td/span/button

        END
        Take Screenshot
        Click    xpath=//*[@id="alert-container"]/div/div/div[3]/button
        Take Screenshot

dms_dmsweb2_ClickDmsFrontEnd_2000_MList_transfer_check_button
        [Arguments]  ${i}
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}


        IF  '${i}'=='1'

            Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[1]
            Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[2]/td/span/button

        ELSE

            Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]
            Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td/span/button

        END
        Take Screenshot
        Click    xpath=//*[@id="alert-container"]/div/div/div[3]/button
        Take Screenshot

dms_dmsweb2_ClickDmsFrontEnd_2000_mail_transfer_button
        [Arguments]  ${i}
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}


        IF  '${i}'=='1'

            Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[2]/div[3]/div[2]/div[2]/table/tbody/tr[1]
            Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[2]/div[3]/div[2]/div[2]/table/tbody/tr[2]/td/span/button[4]

        ELSE

            Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[2]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]
            Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[2]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td/span/button[4]

        END
#        Handle Alert


dms_dmsweb2_ClickDmsFrontEnd_2000_MList_transfer_button
        [Arguments]  ${i}
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}


        IF  '${i}'=='1'

            Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[1]
            Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[2]/td/span/button[7]

        ELSE

            Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]
            Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td/span/button[7]

        END
#        Handle Alert





dms_dmsweb2_ClickDmsFrontEnd_2301_F3_new_MList_button
        [Arguments]  
        [Documentation]
        [Tags]

        Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[1]/div/button
        Take Screenshot
        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_2301_new_M120_MList_button
        [Arguments]  
        [Documentation]
        [Tags]

        Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[3]/div[3]/div[2]/div[1]/div/button
        Take Screenshot
        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_2301_new_MList_button
        [Arguments]  
        [Documentation]
        [Tags]

        Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[1]/div/button[1]
        Take Screenshot
        Sleep  1s

        




dms_dmsweb2_ClickDmsFrontEnd_2000_M120_MList_login_button
        [Arguments]  ${i}
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}


        IF  '${i}'=='1'

            Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[1]
            Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[2]/td/span/button[4]

        ELSE

            Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]
            Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td/span/button[4]

        END
#        Handle Alert



dms_dmsweb2_ClickDmsFrontEnd_2301_F3_MList_login_button
        [Arguments]  ${i}
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}


        IF  '${i}'=='1'

            Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[1]
            Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[2]/td/span/button[3]

        ELSE

            Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]
            Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td/span/button[3]

        END
#        Handle Alert



dms_dmsweb2_ClickDmsFrontEnd_2000_MList_login_button
        [Arguments]  ${i}
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}


        IF  '${i}'=='1'

            Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[1]
            Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[2]/td/span/button[3]

        ELSE

            Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]
            Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td/span/button[3]

        END
#        Handle Alert




dms_dmsweb2_ClickDmsFrontEnd_2000_checkout_button
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}
        Click    ${xpath_DmsFrontEnd_2000_checkout_button}



dms_dmsweb2_FetchDmsFrontEnd_2000New_MList_NO
        [Documentation]
        [Tags]
        ${MLIST_MESSAGE}=  Browser.Get text  ${xpath_DmsFrontEnd_2000MLIST_MESSAGE} 
        Log   ${MLIST_MESSAGE}
        ${MLIST_MESSAGE_split1}=    Split String    ${MLIST_MESSAGE}    ${SPACE}
        Log   ${MLIST_MESSAGE_split1}[0]
        ${MLIST_MESSAGE_split2}=    Split String    ${MLIST_MESSAGE_split1}[0]    碼
        Log   ${MLIST_MESSAGE_split2}[0]
        Log   ${MLIST_MESSAGE_split2}[1]

        RETURN  ${MLIST_MESSAGE_split2}[1]

dms_dmsweb2_ClickDmsFrontEnd_2000FetchButton
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}
        Click    ${xpath_DmsFrontEnd_2000FetchButton}
#        ${MLIST_NO}=  Get_text  ${xpath_DmsFrontEnd_2000MLIST_NO}  
#        ${MLIST_STATE}=  Get_text  ${xpath_DmsFrontEnd_2000MLIST_STATE}
#        RETURN  ${MLIST_NO}  ${MLIST_STATE}


dms_dmsweb2_ClickDmsFrontEnd_2000NewMListButton
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}
        Click    ${xpath_DmsFrontEnd_2000NewMListButton}
#        Sleep  1s
#        Handle Alert



dms_dmsweb2_ClickDmsFrontEnd_8101NewNoneM5A0Button
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}
        Click    ${xpath_DmsFrontEnd_8101NewNoneM5A0Button}
#        Sleep  1s
#        Handle Alert




dms_dmsweb2_ClickDmsFrontEnd_2300COR
        [Arguments]  ${COR}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_2300COR}  ${COR}
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_2300DST_OFFICE
        [Arguments]  ${DST_OFFICE}
        [Documentation]
        [Tags]
        IF  '${DST_OFFICE}' == 'None'  
#            Click    ${xpath_DmsFrontEnd_2300DST_OFFICE}
#            Keyboard Key    down     Control
#            Keyboard Key    press    A
#            Keyboard Key    up       Control     
#            Keyboard Key    press    Delete 
            Take Screenshot
        ELSE
            Fill Text   ${xpath_DmsFrontEnd_2300DST_OFFICE}    ${DST_OFFICE}
            Click   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[3]/th[1]
        END
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_2300ORG_OFFICE
        [Arguments]  ${ORG_OFFICE}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_2300ORG_OFFICE}  ${ORG_OFFICE}
        Click   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[2]/th[2]
#        Sleep  1s


dms_dmsweb2_ClickDmsFrontEnd_2300MLIST_NO
        [Arguments]  ${MLIST_NO}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_2300MLIST_NO}  ${MLIST_NO}
#        Sleep  1s




dms_dmsweb2_ClickDmsFrontEnd_2301_new_MList_MLIST_NO
        [Arguments]  ${MLIST_NO}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_2301_new_MList_MLIST_NO}  ${MLIST_NO}
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_2301_new_MList_ORG_OFFICE
        [Arguments]  ${ORG_OFFICE}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_2301_new_MList_ORG_OFFICE}  ${ORG_OFFICE}
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_2301_new_MList_PCK_CNT 
        [Arguments]  ${PCK_CNT}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_2301_new_MList_PCK_CNT}  ${PCK_CNT}
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_2301_new_MList_RCL_CNT
        [Arguments]  ${RCL_CNT}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_2301_new_MList_RCL_CNT}  ${RCL_CNT}
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_2301_new_MList_C_CNT
        [Arguments]  ${C_CNT}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_2301_new_MList_C_CNT}  ${C_CNT}
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_2301_new_MList_BIDDING_CNT
        [Arguments]  ${BIDDING_CNT}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_2301_new_MList_BIDDING_CNT}  ${BIDDING_CNT}
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_2301_new_MList_INCL_CNT
        [Arguments]  ${INCL_CNT}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_2301_new_MList_INCL_CNT}  ${INCL_CNT}
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_2301_new_MList_INOP_CNT
        [Arguments]  ${INOP_CNT}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_2301_new_MList_INOP_CNT}  ${INOP_CNT}
#        Sleep  1s




dms_dmsweb2_ClickDmsFrontEnd_2301_F3_new_MList_MLST_TYPE
        [Arguments]  ${MLST_TYPE}
        [Documentation]
        [Tags]
        Take Screenshot
        Click   ${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPE}
        IF  '${MLST_TYPE}' == '0'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPEoption0}     
        ELSE IF  '${MLST_TYPE}' == '1'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPEoption1}     
        ELSE IF  '${MLST_TYPE}' == '2'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPEoption2}     
        ELSE IF  '${MLST_TYPE}' == '3'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPEoption3}     
        ELSE IF  '${MLST_TYPE}' == '4'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPEoption4}     
        ELSE IF  '${MLST_TYPE}' == '5'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPEoption5}     
        ELSE IF  '${MLST_TYPE}' == '6'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPEoption6}     
        ELSE IF  '${MLST_TYPE}' == '7'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPEoption7}     
        ELSE IF  '${MLST_TYPE}' == '8'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPEoption8}     
        ELSE IF  '${MLST_TYPE}' == '9'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPEoption9}     
        ELSE IF  '${MLST_TYPE}' == '11'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPEoption11}     
        ELSE IF  '${MLST_TYPE}' == '168'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPEoption168}     
        ELSE IF  '${MLST_TYPE}' == '169'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPEoption169}     
        ELSE
                Fail 
        END
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_2301_F3_new_MList_MLIST_NO
        [Arguments]  ${MLIST_NO}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_2301_F3_new_MList_MLIST_NO}  ${MLIST_NO}
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_2301_F3_new_MList_ORG_OFFICE
        [Arguments]  ${ORG_OFFICE}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_2301_F3_new_MList_ORG_OFFICE}  ${ORG_OFFICE}
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_2301_F3_new_MList_PCK_CNT 
        [Arguments]  ${PCK_CNT}
        [Documentation]
        [Tags]
        IF  '${PCK_CNT}' != 'None'
            Fill Text   ${xpath_DmsFrontEnd_2301_F3_new_MList_PCK_CNT}  ${PCK_CNT}
        END
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_2301_F3_new_MList_RCL_CNT
        [Arguments]  ${RCL_CNT}
        [Documentation]
        [Tags]
        IF  '${RCL_CNT}' != 'None'
            Fill Text   ${xpath_DmsFrontEnd_2301_F3_new_MList_RCL_CNT}  ${RCL_CNT}
        END
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_2301_F3_new_MList_C_CNT
        [Arguments]  ${C_CNT}
        [Documentation]
        [Tags]
        IF  '${C_CNT}' != 'None'
            Fill Text   ${xpath_DmsFrontEnd_2301_F3_new_MList_C_CNT}  ${C_CNT}
        END
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_2301_F3_new_MList_BIDDING_CNT
        [Arguments]  ${BIDDING_CNT}
        [Documentation]
        [Tags]
        IF  '${BIDDING_CNT}' != 'None'
            Fill Text   ${xpath_DmsFrontEnd_2301_F3_new_MList_BIDDING_CNT}  ${BIDDING_CNT}
        END
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_2301_F3_new_MList_INCL_CNT
        [Arguments]  ${INCL_CNT}
        [Documentation]
        [Tags]
        IF  '${INCL_CNT}' != 'None'
            Fill Text   ${xpath_DmsFrontEnd_2301_F3_new_MList_INCL_CNT}  ${INCL_CNT}
        END
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_2301_F3_new_MList_INOP_CNT
        [Arguments]  ${INOP_CNT}
        [Documentation]
        [Tags]
        IF  '${INOP_CNT}' != 'None'
            Fill Text   ${xpath_DmsFrontEnd_2301_F3_new_MList_INOP_CNT}  ${INOP_CNT}
        END
#        Sleep  1s




dms_dmsweb2_ClickDmsFrontEnd_2301_new_M120_MList_MLST_TYPE
        [Arguments]  ${MLST_TYPE}
        [Documentation]
        [Tags]
        Take Screenshot
        Click   ${xpath_DmsFrontEnd_2301_new_M120_MList_MLST_TYPE}
        IF  '${MLST_TYPE}' == '0'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2301_new_M120_MList_MLST_TYPEoption0}     
        ELSE IF  '${MLST_TYPE}' == '1'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2301_new_M120_MList_MLST_TYPEoption1}
        ELSE
                Fail 
        END
#        Sleep  1s


dms_dmsweb2_ClickDmsFrontEnd_2301_new_M120_MList_MLIST_NO
        [Arguments]  ${MLIST_NO}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_2301_new_M120_MList_MLIST_NO}  ${MLIST_NO}
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_2301_new_M120_MList_ORG_OFFICE
        [Arguments]  ${ORG_OFFICE}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_2301_new_M120_MList_ORG_OFFICE}  ${ORG_OFFICE}
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_2301_new_M120_MList_DST_OFFICE
        [Arguments]  ${DST_OFFICE}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_2301_new_M120_MList_DST_OFFICE}  ${DST_OFFICE}
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_2301_new_M120_MList_COR_MLIST
        [Arguments]  ${COR_MLIST}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_2301_new_M120_MList_COR_MLIST}  ${COR_MLIST}
#        Sleep  1s









dms_dmsweb2_ClickDmsFrontEnd_2300MLST_TYPE
        [Arguments]    ${MLST_TYPE}
        [Documentation]
        [Tags]
        Log  ${MLST_TYPE}
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}
        Take Screenshot
        Click   ${xpath_DmsFrontEnd_2300MLST_TYPE}
        IF  '${MLST_TYPE}' == '0'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2300MLST_TYPEoption0}     
        ELSE IF  '${MLST_TYPE}' == '1'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2300MLST_TYPEoption1}
        ELSE
                Fail 
        END
#        Sleep  1s
#        Handle Alert

dms_dmsweb2_ClickDmsFrontEnd_2300IN_TYPE
        [Arguments]    ${IN_TYPE}
        [Documentation]
        [Tags]
        Log  ${IN_TYPE}
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}
        Take Screenshot
        Click   ${xpath_DmsFrontEnd_2300IN_TYPE}
        IF  '${IN_TYPE}' == '1'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2300IN_TYPEoption1}    
        ELSE IF  '${IN_TYPE}' == '2'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2300IN_TYPEoption2}
        ELSE IF  '${IN_TYPE}' == '3'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2300IN_TYPEoption3}
        ELSE IF  '${IN_TYPE}' == '4'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2300IN_TYPEoption4}
        ELSE IF  '${IN_TYPE}' == '5'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2300IN_TYPEoption5}
        ELSE IF  '${IN_TYPE}' == '6'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2300IN_TYPEoption6}
        ELSE IF  '${IN_TYPE}' == '7'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2300IN_TYPEoption7}
        ELSE IF  '${IN_TYPE}' == '8'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2300IN_TYPEoption8}
        ELSE IF  '${IN_TYPE}' == '9'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2300IN_TYPEoption9}
        ELSE IF  '${IN_TYPE}' == '11'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2300IN_TYPEoption11}
        ELSE IF  '${IN_TYPE}' == '16'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2300IN_TYPEoption16}
        ELSE IF  '${IN_TYPE}' == '168'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2300IN_TYPEoption168}
        ELSE IF  '${IN_TYPE}' == '169'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2300IN_TYPEoption169}
        ELSE
                Fail 
        END
#        Sleep  1s
#        Handle Alert



dms_dmsweb2_ClickDmsFrontEnd_2000_MList_transfer_RCV_OFFICE
        [Arguments]    ${RCV_OFFICE}
        [Documentation]
        [Tags]
        Log  ${RCV_OFFICE}
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}
        Take Screenshot
        Click   ${xpath_DmsFrontEnd_2000_MList_transfer_RCV_OFFICE}
        IF  '${RCV_OFFICE}' == '1'
                Fail      
        ELSE IF  '${RCV_OFFICE}' == '2'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2000_MList_transfer_RCV_OFFICEoption2}
        ELSE IF  '${RCV_OFFICE}' == '3'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2000_MList_transfer_RCV_OFFICEoption3}
        ELSE IF  '${RCV_OFFICE}' == '4'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2000_MList_transfer_RCV_OFFICEoption4}
        ELSE
                Fail 
        END
#        Sleep  1s
#        Handle Alert

dms_dmsweb2_ClickDmsFrontEnd_2000_MList_transfer_STAFF_NO
#        [Arguments]  ${STAFF_NO}
        [Documentation]
        [Tags]
        Click   ${xpath_DmsFrontEnd_2000_MList_transfer_STAFF_NO}   
#        Sleep  1s
#        Debug
        Keyboard Key    down     Control
        Keyboard Key    press    A
        Keyboard Key    up       Control  
#        Sleep  1s  
#        Debug    
        Keyboard Key    press    Delete 
        Take Screenshot  
#        Sleep  1s  
#        Debug 
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_2000_MList_transfer_TOUR_NO
        [Arguments]  ${TOUR_NO}
        [Documentation]
        [Tags]
 
        Fill Text   ${xpath_DmsFrontEnd_2000_MList_transfer_TOUR_NO_from}    ${TOUR_NO}
        Fill Text   ${xpath_DmsFrontEnd_2000_MList_transfer_TOUR_NO_to}    ${TOUR_NO}
        Take Screenshot   
#        Sleep  1s


dms_dmsweb2_ClickDmsFrontEnd_2000_MList_transfer_ACC_DATE
        [Arguments]  ${ACC_DATE}
        [Documentation]
        [Tags]
        ${matchN}  ${LOG_ACC_DATE}=  Run Keyword And Warn On Failure    Browser.Get Text      ${xpath_DmsFrontEnd_2000_MList_transfer_ACC_DATE_from}
        Log  ${matchN}
        Log  ${LOG_ACC_DATE} 
#        Fill Text   ${xpath_DmsFrontEnd_2000_MList_transfer_ACC_DATE_from}    ${ACC_DATE}
        Fill Text   ${xpath_DmsFrontEnd_2000_MList_transfer_ACC_DATE_from}    113/01/01
        Fill Text   ${xpath_DmsFrontEnd_2000_MList_transfer_ACC_DATE_to}    ${ACC_DATE}
        Take Screenshot   
#        Sleep  1s


dms_dmsweb2_ClickDmsFrontEnd_2000ACC_DATE
        [Arguments]  ${ACC_DATE}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_2000ACC_DATE}    ${ACC_DATE}
#        Fill Text   ${xpath_DmsFrontEnd_2000ACC_DATE}    114/04/01   
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_2000TOUR_NO
        [Arguments]  ${TOUR_NO}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_2000TOUR_NO}  ${TOUR_NO}   
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_2000MList_NO
        [Arguments]  ${MList_NO}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_2000MList_NO}  ${MList_NO}   
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_2000STAFF_NO
#        [Arguments]  ${STAFF_NO}
        [Documentation]
        [Tags]
        Click   ${xpath_DmsFrontEnd_2000STAFF_NO}   
#        Sleep  1s
#        Debug
        Keyboard Key    down     Control
        Keyboard Key    press    A
        Keyboard Key    up       Control  
#        Sleep  1s  
#        Debug    
        Keyboard Key    press    Delete 
#        Sleep  1s  
#        Debug 
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_2000RCV_OFFICE
        [Arguments]    ${RCV_OFFICE}
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}
        Take Screenshot
        Click   ${xpath_DmsFrontEnd_2000RCV_OFFICE}
        IF  '${RCV_OFFICE}' == '1'
                Fail      
        ELSE IF  '${RCV_OFFICE}' == '2'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2000RCV_OFFICEoption2}
        ELSE IF  '${RCV_OFFICE}' == '3'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2000RCV_OFFICEoption3}
        ELSE IF  '${RCV_OFFICE}' == '4'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2000RCV_OFFICEoption4}
        ELSE
                Fail 
        END
#        Sleep  1s
#        Handle Alert


dms_dmsweb2_ClickDmsFrontEnd_2000MAIL_TYPE
        [Arguments]    ${.MAIL_TYPE}
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}
        Take Screenshot
        Click   ${xpath_DmsFrontEnd_2000MAIL_TYPE}
        IF  '${.MAIL_TYPE}' == '1'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2000MAIL_TYPEoption1}      
        ELSE IF  '${.MAIL_TYPE}' == '2'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2000MAIL_TYPEoption2}
        ELSE IF  '${.MAIL_TYPE}' == '3'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2000MAIL_TYPEoption3}
        ELSE IF  '${.MAIL_TYPE}' == '4'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2000MAIL_TYPEoption4}
        ELSE IF  '${.MAIL_TYPE}' == 'B'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2000MAIL_TYPEoptionB}
        ELSE
                Fail 
        END
#        Sleep  1s
#        Handle Alert


dms_dmsweb2_ClickDmsFrontEnd_2000EndButton
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}
        Click    ${xpath_DmsFrontEnd_2000EndButton}
#        Sleep  1s
#        Handle Alert

dms_dmsweb2_ClickDmsFrontEnd_2000SendButton
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}
        Click    ${xpath_DmsFrontEnd_2000SendButton}
#        Sleep  1s
#        Handle Alert


dms_dmsweb2_ClickDmsFrontEnd_2300EndButton
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}
        Click    ${xpath_DmsFrontEnd_2300EndButton}
#        Sleep  1s
#        Handle Alert

dms_dmsweb2_ClickDmsFrontEnd_2300SendButton
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}
        Click    ${xpath_DmsFrontEnd_2300SendButton}
#        Sleep  1s
#        Handle Alert


dms_dmsweb2_ClickDmsFrontEnd_2301_F3_Button
        [Documentation]
        [Tags]

        Click    ${xpath_DmsFrontEnd_2301_F3_Button}



dms_dmsweb2_ClickDmsFrontEnd_8120ACC_DATE
        [Arguments]  ${ACC_DATE}
        [Documentation]
        [Tags]
#        Fill Text   ${xpath_DmsFrontEnd_8120ACC_DATE}    ${ACC_DATE}
        Fill Text   ${xpath_DmsFrontEnd_8120ACC_DATE}    114/04/01   
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_8120TOUR_NO
        [Arguments]  ${TOUR_NO}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_8120TOUR_NO}  ${TOUR_NO}   
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_8120CAR_NO
        [Arguments]  ${CAR_NO}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_8120CAR_NO}  ${CAR_NO}
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_8120RCV_STAFF_ID
        [Arguments]  ${RCV_STAFF_ID}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_8120RCV_STAFF_ID}  ${RCV_STAFF_ID}
        Take Screenshot
        Click   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[3]/th[2]
        Take Screenshot
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_8120RCV_KIND
        [Arguments]  ${RCV_KIND}
        [Documentation]
        [Tags]

        IF  '${RCV_KIND}' == '1'
                Log  1 is default setting!      
        ELSE IF  '${RCV_KIND}' == '2'


                Take Screenshot
                Click   ${xpath_DmsFrontEnd_8120RCV_KIND}
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_8120RCV_KIND}
#                Sleep  1s
                Click   ${xpath_DmsFrontEnd_8120RCV_KINDoption}
        ELSE
                Fail 
        END
 
#        Sleep  1s
        Take Screenshot
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_8120CUS_PH_NO
        [Arguments]  ${CUS_PH_NO}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_8120CUS_PH_NO}  ${CUS_PH_NO}
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_8120SND_TEL
        [Arguments]  ${SND_TEL}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_8120SND_TEL}  ${SND_TEL}
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_8120BNS_TYPE
        [Arguments]  ${BNS_TYPE}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_8120BNS_TYPE}  ${BNS_TYPE}
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_8120ZIP_CODE
        [Arguments]  ${ZIP_CODE}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_8120ZIP_CODE}  ${ZIP_CODE}
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_8120SPL_OFFICE
        [Arguments]  ${SPL_OFFICE}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_8120SPL_OFFICE}  ${SPL_OFFICE}
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_8120MAIL_NO
        [Arguments]  ${MAIL_NO}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_8120MAIL_NO}  ${MAIL_NO}

#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_8120MAIL_LENGTH
        [Arguments]  ${MAIL_LENGTH}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_8120MAIL_LENGTH}  ${MAIL_LENGTH}
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_8120MAIL_WIDTH
        [Arguments]  ${MAIL_WIDTH}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_8120MAIL_WIDTH}  ${MAIL_WIDTH}
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_8120MAIL_HEIGHT
        [Arguments]  ${MAIL_HEIGHT}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_8120MAIL_HEIGHT}  ${MAIL_HEIGHT}
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_8120MAIL_WEIGHT
        [Arguments]  ${MAIL_WEIGHT}
        [Documentation]
        [Tags]
        Log    ${MAIL_WEIGHT}
#        Sleep  1s
        Click       ${xpath_DmsFrontEnd_8120MAIL_WEIGHT}
        Take Screenshot
#        Sleep  1s
        Keyboard Input    insertText    ${MAIL_WEIGHT}
        Take Screenshot
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_8120DST_NT_CODE
        [Arguments]  ${DST_NT_CODE}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_8120DST_NT_CODE}  ${DST_NT_CODE}
        Click   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[10]/th[2]        
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_8120MAIL_TYPE
        [Arguments]  ${MAIL_TYPE}
        [Documentation]
        [Tags]
#        Fill Text   ${xpath_DmsFrontEnd_8120MAIL_TYPE}  ${MAIL_TYPE}

        IF  '${MAIL_TYPE}' == '1'
                Log  1 is default setting!      
        ELSE IF  '${MAIL_TYPE}' == '2'


                Take Screenshot
                Click   ${xpath_DmsFrontEnd_8120MAIL_TYPE}
                Take Screenshot
#                Sleep  1s
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_8120MAIL_TYPE}
                Take Screenshot
#                Sleep  1s
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_8120MAIL_TYPEoption}
                Take Screenshot
        ELSE
                Fail 
        END
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_8120DSN_TYPE
        [Arguments]  ${DSN_TYPE} 
        [Documentation]
        [Tags]
#        Fill Text   ${xpath_DmsFrontEnd_8120DSN_TYPE}  ${DSN_TYPE}

        Take Screenshot
        Click   ${xpath_DmsFrontEnd_8120DSN_TYPE}
        Take Screenshot
#        Sleep  1s
        Take Screenshot
        Click   ${xpath_DmsFrontEnd_8120DSN_TYPE}
        Take Screenshot
#        Sleep  1s
        Take Screenshot

        IF  '${DSN_TYPE}' == '0'
                Log  0 is default setting!      
        ELSE IF  '${DSN_TYPE}' == '1'
                Click   ${xpath_DmsFrontEnd_8120DSN_TYPEoption1}
                Take Screenshot
        ELSE IF  '${DSN_TYPE}' == '2'
                Click   ${xpath_DmsFrontEnd_8120DSN_TYPEoption2}
                Take Screenshot
        ELSE IF  '${DSN_TYPE}' == '3'
                Click   ${xpath_DmsFrontEnd_8120DSN_TYPEoption3}
                Take Screenshot
        ELSE IF  '${DSN_TYPE}' == '4'
                Click   ${xpath_DmsFrontEnd_8120DSN_TYPEoption4}
                Take Screenshot
        ELSE IF  '${DSN_TYPE}' == '5'
                Click   ${xpath_DmsFrontEnd_8120DSN_TYPEoption5}
                Take Screenshot
        ELSE IF  '${DSN_TYPE}' == '6'
                Click   ${xpath_DmsFrontEnd_8120DSN_TYPEoption6}
                Take Screenshot
        ELSE IF  '${DSN_TYPE}' == '7'
                Click   ${xpath_DmsFrontEnd_8120DSN_TYPEoption7}
                Take Screenshot
        ELSE IF  '${DSN_TYPE}' == '8'
                Click   ${xpath_DmsFrontEnd_8120DSN_TYPEoption8}
                Take Screenshot
        ELSE IF  '${DSN_TYPE}' == '9'
                Click   ${xpath_DmsFrontEnd_8120DSN_TYPEoption9}
                Take Screenshot
        ELSE IF  '${DSN_TYPE}' == '10'
                Click   ${xpath_DmsFrontEnd_8120DSN_TYPEoption10}
                Take Screenshot
        ELSE IF  '${DSN_TYPE}' == '11'
                Click   ${xpath_DmsFrontEnd_8120DSN_TYPEoption11}
                Take Screenshot
        ELSE IF  '${DSN_TYPE}' == '12'
                Click   ${xpath_DmsFrontEnd_8120DSN_TYPEoption12}
                Take Screenshot
        ELSE IF  '${DSN_TYPE}' == '13'
                Click   ${xpath_DmsFrontEnd_8120DSN_TYPEoption13}
                Take Screenshot
        ELSE IF  '${DSN_TYPE}' == '14'
                Click   ${xpath_DmsFrontEnd_8120DSN_TYPEoption14}
                Take Screenshot
        ELSE
                Fail 
        END
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_8120MAIL_TYPE1
        [Arguments]  ${MAIL_TYPE1}
        [Documentation]
        [Tags]
#        Fill Text   ${xpath_DmsFrontEnd_8120MAIL_TYPE1}  ${MAIL_TYPE1}
        Click  xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[17]/th[1]
        IF  '${MAIL_TYPE1}' == 'n'
                Log  N is default setting!      
        ELSE IF  '${MAIL_TYPE1}' == 'y'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_8120MAIL_TYPE1}
                Take Screenshot
        ELSE
                Fail 
        END
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_8120ISR_CHARGE
        [Arguments]  ${ISR_CHARGE}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_8120ISR_CHARGE}  ${ISR_CHARGE}
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_8120PAY_CASH_AMT
        [Arguments]  ${PAY_CASH_AMT}
        [Documentation]
        [Tags]
#        Fill Text   ${xpath_DmsFrontEnd_8120PAY_CASH_AMT}  ${PAY_CASH_AMT}
        IF  '${PAY_CASH_AMT}' == '0'
                Log  N is default setting!      
        ELSE 
                Take Screenshot
                Fill Text   ${xpath_DmsFrontEnd_8120PAY_CASH_AMT}  ${PAY_CASH_AMT}
                Take Screenshot

        END
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_8120PAY_POSTAL_AMT
        [Arguments]  ${PAY_POSTAL_AMT}
        [Documentation]
        [Tags]
#        Fill Text   ${xpath_DmsFrontEnd_8120PAY_POSTAL_AMT}  ${PAY_POSTAL_AMT}
        IF  '${PAY_POSTAL_AMT}' == '0'
                Log  0 is default setting!      
        ELSE 
                Take Screenshot
                Fill Text   ${xpath_DmsFrontEnd_8120PAY_POSTAL_AMT}  ${PAY_POSTAL_AMT}
                Take Screenshot
 
        END
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_8120PAY_STMP_AMT
        [Arguments]  ${PAY_STMP_AMT}
        [Documentation]
        [Tags]
#        Fill Text   ${xpath_DmsFrontEnd_8120PAY_STMP_AMT}  ${PAY_STMP_AMT}
        IF  '${PAY_STMP_AMT}' == '0'
                Log  0 is default setting!      
        ELSE 
                Take Screenshot
                Fill Text   ${xpath_DmsFrontEnd_8120PAY_STMP_AMT}  ${PAY_STMP_AMT}
                Take Screenshot

        END
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_8120MON_PAY
        [Arguments]  ${MON_PAY}
        [Documentation]
        [Tags]
#        Fill Text   ${xpath_DmsFrontEnd_8120MON_PAY}  ${MON_PAY}
        IF  '${MON_PAY}' == '0'
                Log  0 is default setting!      
        ELSE  
                Take Screenshot
                Fill Text   ${xpath_DmsFrontEnd_8120MON_PAY}  ${MON_PAY}
                Take Screenshot 
        END
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_8120CustomsFlag
        [Arguments]  ${CustomsFlag}
        [Documentation]
        [Tags]
#        Fill Text   ${xpath_DmsFrontEnd_8120CustomsFlag}  ${CustomsFlag}
        Click  xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[24]/th[1]
        IF  '${CustomsFlag}' == 'n'
                Log  N is default setting!      
        ELSE IF  '${CustomsFlag}' == 'y'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_8120CustomsFlag}
                Take Screenshot
        ELSE
                Fail 
        END
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_8120RCV_TEL
        [Arguments]  ${RCV_TEL}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_8120RCV_TEL}  ${RCV_TEL}
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_8120TOL_POSTAL
        [Arguments]  ${TOL_POSTAL}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_8120TOL_POSTAL}  ${TOL_POSTAL}
#        Sleep  1s



dms_dmsweb2_FetchDmsFrontEnd_2000_transfer_ACC_DATE
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${transfer_ACC_DATE}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[3] 
        RETURN    ${match}  ${transfer_ACC_DATE}


dms_dmsweb2_FetchDmsFrontEnd_2000_transfer_TOUR_NO
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${transfer_TOUR_NO}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[3] 
        RETURN    ${match}  ${transfer_TOUR_NO}

dms_dmsweb2_FetchDmsFrontEnd_2000_transfer_RCV_OFFICE
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${transfer_RCV_OFFICE}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[6] 
        RETURN    ${match}  ${transfer_RCV_OFFICE}

dms_dmsweb2_FetchDmsFrontEnd_2000_transfer_MAIL_TYPE
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${transfer_MAIL_TYPE}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[7] 
        RETURN    ${match}  ${transfer_MAIL_TYPE}

dms_dmsweb2_FetchDmsFrontEnd_2000_transfer_MLIST_STATUS
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${transfer_MLIST_STATUS}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[${i}] 
        RETURN    ${match}  ${transfer_MLIST_STATUS}




dms_dmsweb2_FetchDmsFrontEnd_2301_transfer_MAIL_TYPE
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${transfer_MAIL_TYPE}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[7]
        RETURN    ${match}  ${transfer_MAIL_TYPE}


dms_dmsweb2_FetchDmsFrontEnd_2301_transfer_RCV_OFFICE
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${transfer_RCV_OFFICE}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[6]
        RETURN    ${match}  ${transfer_RCV_OFFICE}


dms_dmsweb2_FetchDmsFrontEnd_2301_login_MLIST_STATUS
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${login_MLIST_STATUS}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[2]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]
        RETURN    ${match}  ${login_MLIST_STATUS}



dms_dmsweb2_FetchDmsFrontEnd_2301_login_MAIL_NO_SRL
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${login_MAIL_NO_SRL}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[2]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[5]
        RETURN    ${match}  ${login_MAIL_NO_SRL}


dms_dmsweb2_FetchDmsFrontEnd_2301_login_MAIL_NO
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${login_MAIL_NO}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[2]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[4]
        RETURN    ${match}  ${login_MAIL_NO}


dms_dmsweb2_FetchDmsFrontEnd_2301_MLIST_STATUS
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${MLIST_STATUS}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]
        RETURN    ${match}  ${MLIST_STATUS}



dms_dmsweb2_FetchDmsFrontEnd_2301_INOP_CNT
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${INOP_CNT}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[10]
        RETURN    ${match}  ${INOP_CNT}


dms_dmsweb2_FetchDmsFrontEnd_2301_INLP_CNT
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${INLP_CNT}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[9]
        RETURN    ${match}  ${INLP_CNT}


dms_dmsweb2_FetchDmsFrontEnd_2301_BIDDING
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${BIDDING}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[8]
        RETURN    ${match}  ${BIDDING}

dms_dmsweb2_FetchDmsFrontEnd_2301_C_CNT
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${C_CNT}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[7]
        RETURN    ${match}  ${C_CNT}


dms_dmsweb2_FetchDmsFrontEnd_2301_RCL_CNT
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${RCL_CNT}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[6]
        RETURN    ${match}  ${RCL_CNT}


dms_dmsweb2_FetchDmsFrontEnd_2301_PCK_CNT
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${PCK_CNT}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[5]
        RETURN    ${match}  ${PCK_CNT}


dms_dmsweb2_FetchDmsFrontEnd_2301_ORG_OFFICE
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${ORG_OFFICE}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[4]
        RETURN    ${match}  ${ORG_OFFICE}

dms_dmsweb2_FetchDmsFrontEnd_2301_MLIST_NO
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${MLIST_NO}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[3]
        RETURN    ${match}  ${MLIST_NO}



dms_dmsweb2_FetchDmsFrontEnd_2301_F3_IN_TYPE_CODE
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${IN_TYPE_CODE}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[3]
        RETURN    ${match}  ${IN_TYPE_CODE}

dms_dmsweb2_FetchDmsFrontEnd_2301_F3_ORG_OFFICE
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${ORG_OFFICE}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[5]
        RETURN    ${match}  ${ORG_OFFICE}

dms_dmsweb2_FetchDmsFrontEnd_2301_F3_MLIST_NO
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${MLIST_NO}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[4]
        RETURN    ${match}  ${MLIST_NO}



dms_dmsweb2_FetchDmsFrontEnd_2301_F3_MLIST_STATUS
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${MLIST_STATUS}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td
        RETURN    ${match}  ${MLIST_STATUS}



dms_dmsweb2_FetchDmsFrontEnd_2301_F3_INOP_CNT
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${INOP_CNT}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[11]
        RETURN    ${match}  ${INOP_CNT}


dms_dmsweb2_FetchDmsFrontEnd_2301_F3_INLP_CNT
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${INLP_CNT}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[10]
        RETURN    ${match}  ${INLP_CNT}


dms_dmsweb2_FetchDmsFrontEnd_2301_F3_BIDDING
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${BIDDING}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[9]
        RETURN    ${match}  ${BIDDING}

dms_dmsweb2_FetchDmsFrontEnd_2301_F3_C_CNT
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${C_CNT}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[8]
        RETURN    ${match}  ${C_CNT}


dms_dmsweb2_FetchDmsFrontEnd_2301_F3_RCL_CNT
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${RCL_CNT}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[7]
        RETURN    ${match}  ${RCL_CNT}


dms_dmsweb2_FetchDmsFrontEnd_2301_F3_PCK_CNT
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${PCK_CNT}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[6]
        RETURN    ${match}  ${PCK_CNT}






dms_dmsweb2_FetchDmsFrontEnd_2000_REC_OFFICE
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${REC_OFFICE}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[6]
        RETURN    ${match}  ${REC_OFFICE}

dms_dmsweb2_FetchDmsFrontEnd_2000_MAIL_TYPE
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${MAIL_TYPE}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[7] 	
        RETURN    ${match}  ${MAIL_TYPE}


dms_dmsweb2_FetchDmsFrontEnd_2000_MLIST_STATE
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${MLIST_STATE}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[9]	
        RETURN    ${match}  ${MLIST_STATE}



dms_dmsweb2_FetchDmsFrontEnd_2000_MLIST_STATUS
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${MLIST_STATUS}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]
        RETURN    ${match}  ${MLIST_STATUS}


dms_dmsweb2_FetchDmsFrontEnd_2000_transfer_MAIL_NO
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${transfer_MAIL_NO}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[2]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[3]
        RETURN    ${match}  ${transfer_MAIL_NO}



dms_dmsweb2_FetchDmsFrontEnd_2300_IN_TYPE
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${IN_TYPE}=  Run Keyword And Warn On Failure    Browser.Get Text           xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[3]
        RETURN    ${match}  ${IN_TYPE}


dms_dmsweb2_FetchDmsFrontEnd_2300_MLST_TYPE
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${MLST_TYPE}=  Run Keyword And Warn On Failure    Browser.Get Text           xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[4]
        RETURN    ${match}  ${MLST_TYPE}



dms_dmsweb2_FetchDmsFrontEnd_2300_MLIST_NO
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${MLIST_NO}=  Run Keyword And Warn On Failure    Browser.Get Text           xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[5]
        RETURN    ${match}  ${MLIST_NO}


dms_dmsweb2_FetchDmsFrontEnd_2300_ORG_OFFICE 
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${ORG_OFFICE}=  Run Keyword And Warn On Failure    Browser.Get Text           xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[6]
        RETURN    ${match}  ${ORG_OFFICE}



dms_dmsweb2_FetchDmsFrontEnd_2300_DST_OFFICE 
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${DST_OFFICE}=  Run Keyword And Warn On Failure    Browser.Get Text           xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[7]
        RETURN    ${match}  ${DST_OFFICE}



dms_dmsweb2_FetchDmsFrontEnd_2300_COR 
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${COR}=  Run Keyword And Warn On Failure    Browser.Get Text           xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[8]
        RETURN    ${match}  ${COR}




dms_dmsweb2_DmsFrontEnd_2000_stage1_1
        [Arguments]   ${excel_file_data}  ${string}  ${string2}
        [Documentation]
        [Tags]

        ${match2}=  set variable  False 
        ${match1}  ${REC_OFFICE}=  dms_dmsweb2_FetchDmsFrontEnd_2000_REC_OFFICE  1


	    IF	'${match1}' == 'FAIL'
		    ${result_data}=  set variable  FAIL
#		    Exit For Loop
			dms_dmsweb2_ClickDmsFrontEnd_2000NewMListButton
			IF  '${string2}' == '2900'
			    Take Screenshot
			ELSE
			    dms_dmsweb2_ClickDmsFrontEnd_2000RCV_OFFICE  ${excel_file_data}[3]
			    dms_dmsweb2_ClickDmsFrontEnd_2000MAIL_TYPE  ${excel_file_data}[4]
			END
			dms_dmsweb2_ClickDmsFrontEnd_2000SendButton
			${MList_NO}=  dms_dmsweb2_FetchDmsFrontEnd_2000New_MList_NO	
		    Take Screenshot
		    dms_dmsweb2_ClickDmsFrontEnd_2000EndButton	
			Take Screenshot
			${match1}  ${REC_OFFICE}=  dms_dmsweb2_FetchDmsFrontEnd_2000_REC_OFFICE  1

			${match2}=  set variable  True 
	    END
        Log  ${REC_OFFICE}
        Log  ${REC_OFFICE}[0]
        Log  ${excel_file_data}[3]

   	    IF	'${REC_OFFICE}[0]' == '${excel_file_data}[3]'
                ${match1}  ${MAIL_TYPE}=  dms_dmsweb2_FetchDmsFrontEnd_2000_MAIL_TYPE  1

            Log  ${MAIL_TYPE}
            Log  ${MAIL_TYPE}[0] 
            Log  ${excel_file_data}[4]  

   	    	IF	'${MAIL_TYPE}[0]' == '${excel_file_data}[4]'
   	    		${match1}  ${MLIST_STATE}=  dms_dmsweb2_FetchDmsFrontEnd_2000_MLIST_STATE  1
   	    	    IF	'${MLIST_STATE}' == 'N. 未結單'
   	    	        IF  '${string}' == 'login'
       	                dms_dmsweb2_ClickDmsFrontEnd_2000_MList_login_button  1
                    ELSE IF  '${string}' == 'checkout'
                        dms_dmsweb2_ClickDmsFrontEnd_2000_MList_checkout_button  1
                    ELSE IF  '${string}' == 'transfer'
                        dms_dmsweb2_ClickDmsFrontEnd_2000_MList_transfer_button  1
       	            ELSE
                        Fail
                    END
       	            ${match2}=  set variable  True  
#   	    	    	BREAK
   	    	    END
   	    	END
   	    END

        RETURN    ${match1}  ${match2}





dms_dmsweb2_DmsFrontEnd_2000_stage1_i
    [Arguments]  ${match2}  ${excel_file_data}  ${string}
    [Documentation]
    [Tags]

    ${match3}=  set variable   FAIL

	FOR  ${i}  IN RANGE  2  1000  1

	    IF	'${match2}' == 'True'
		    Exit For Loop
	    END

        ${match3}  ${MLIST_STATUS}=  dms_dmsweb2_FetchDmsFrontEnd_2000_MLIST_STATUS  ${i}

	    Log  ${match3}
	    Log  ${MLIST_STATUS}
	    Log  ${MLIST_STATUS}[0]
	    Take Screenshot

	    IF	'${match3}' == 'FAIL'

		    Exit For Loop
	    END

	    IF	'${MLIST_STATUS}[0]' == '刪'

		    CONTINUE FOR LOOP
	    END

                ${match3}  ${REC_OFFICE}=  dms_dmsweb2_FetchDmsFrontEnd_2000_REC_OFFICE  ${i}

                Log  ${REC_OFFICE}
                Log  ${REC_OFFICE}[0]
                Log  ${excel_file_data}[3]

	    	    IF	'${REC_OFFICE}[0]' == '${excel_file_data}[3]'
	                ${match3}  ${MAIL_TYPE}=  Run Keyword And Warn On Failure    Browser.Get Text        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[7] 	

                    Log  ${MAIL_TYPE}
                    Log  ${MAIL_TYPE}[0] 
                    Log  ${excel_file_data}[4]  

	    	    	IF	'${MAIL_TYPE}[0]' == '${excel_file_data}[4]'
	    	    		${match3}  ${MLIST_STATE}=  dms_dmsweb2_FetchDmsFrontEnd_2000_MLIST_STATE  ${i}
	    	    	    IF	'${MLIST_STATE}' == 'N. 未結單'
	    	    	       	IF  '${string}' == 'login'
       	                       	dms_dmsweb2_ClickDmsFrontEnd_2000_MList_login_button  ${i}
                            ELSE IF  '${string}' == 'checkout'
                               	dms_dmsweb2_ClickDmsFrontEnd_2000_MList_checkout_button  ${i}
                            ELSE IF  '${string}' == 'transfer'
                               	dms_dmsweb2_ClickDmsFrontEnd_2000_MList_transfer_button  ${i}
       	                    ELSE
                               	Fail
                            END
	        	            ${match2}=  set variable  True 
	    	    	    	BREAK
	    	    	    END
	    	    	END
	    	    END

		${total_column}=  set variable  ${i}
		Take Screenshot
	END

    RETURN    ${match2}  ${match3}



dms_dmsweb2_DmsFrontEnd_2000_stage1_c
        [Arguments]   ${excel_file_data}  ${string}
        [Documentation]
        [Tags]

		dms_dmsweb2_ClickDmsFrontEnd_2000NewMListButton
		IF  '${string}' == '2900'
            Take Screenshot
		ELSE
		    dms_dmsweb2_ClickDmsFrontEnd_2000RCV_OFFICE  ${excel_file_data}[3]
		    dms_dmsweb2_ClickDmsFrontEnd_2000MAIL_TYPE  ${excel_file_data}[4]
		END
		dms_dmsweb2_ClickDmsFrontEnd_2000SendButton	 
		Take Screenshot
		${MList_NO}=  dms_dmsweb2_FetchDmsFrontEnd_2000New_MList_NO	
		Take Screenshot
		dms_dmsweb2_ClickDmsFrontEnd_2000EndButton	
		Take Screenshot

		dms_dmsweb2_ClickDmsFrontEnd_2000ACC_DATE  ${excel_file_data}[1]
		dms_dmsweb2_ClickDmsFrontEnd_2000TOUR_NO   ${excel_file_data}[2]
    	dms_dmsweb2_ClickDmsFrontEnd_2000MList_NO  ${MList_NO}

		dms_dmsweb2_ClickDmsFrontEnd_2000FetchButton

		dms_dmsweb2_ClickDmsFrontEnd_2000_MList_login_button  1


dms_dmsweb2_DmsFrontEnd_2000_stage3_transfer_fetch
        [Arguments]   ${excel_file_data}
        [Documentation]
        [Tags]
        dms_dmsweb2_DmsFrontEnd_2000_stage2_transfer_fetch   ${excel_file_data}


dms_dmsweb2_DmsFrontEnd_2000_stage2_transfer_fetch
        [Arguments]   ${excel_file_data}
        [Documentation]
        [Tags]

	    dms_dmsweb2_ClickDmsFrontEnd_2000_MList_transfer_ACC_DATE  ${excel_file_data}[19]

	    dms_dmsweb2_ClickDmsFrontEnd_2000_MList_transfer_TOUR_NO  ${excel_file_data}[20]

        dms_dmsweb2_ClickDmsFrontEnd_2000_MList_transfer_STAFF_NO

        dms_dmsweb2_ClickDmsFrontEnd_2000_MList_transfer_RCV_OFFICE   ${excel_file_data}[21] 

        dms_dmsweb2_ClickDmsFrontEnd_2000_MList_transfer_FetchButton


dms_dmsweb2_DmsFrontEnd_2000_stage3_1
        [Arguments]   ${excel_file_data}
        [Documentation]
        [Tags]
        ${match1}  ${match2}=    dms_dmsweb2_DmsFrontEnd_2000_stage2_1    ${excel_file_data} 

        Log  ${match1}
        Log  ${match2}

dms_dmsweb2_DmsFrontEnd_2000_stage2_1
        [Arguments]   ${excel_file_data}
        [Documentation]
        [Tags]
        ${match2}=  set variable  False  
        ${match1}  ${transfer_ACC_DATE}=  dms_dmsweb2_FetchDmsFrontEnd_2000_transfer_ACC_DATE  1

	    IF	'${match1}' == 'FAIL'
		    ${result_data}=  set variable  FAIL

	    END
        Log  ${transfer_ACC_DATE}
        Log  ${excel_file_data}[19]

   	    IF	'${transfer_ACC_DATE}' == '${excel_file_data}[19]'
                ${match1}  ${transfer_TOUR_NO}=  dms_dmsweb2_FetchDmsFrontEnd_2000_transfer_TOUR_NO  1	

            Log  ${transfer_TOUR_NO} 
            Log  ${excel_file_data}[20]  

   	    	IF	'${transfer_TOUR_NO}' == '${excel_file_data}[20]'
   	    		${match1}  ${transfer_RCV_OFFICE}=  dms_dmsweb2_FetchDmsFrontEnd_2000_transfer_RCV_OFFICE  1

                Log  ${transfer_RCV_OFFICE}
                Log  ${transfer_RCV_OFFICE}[0] 
                Log  ${excel_file_data}[21]  

   	    	    IF	'${transfer_RCV_OFFICE}' == '${excel_file_data}[21]'

   	    	       	${match1}  ${transfer_MAIL_TYPE}=  dms_dmsweb2_FetchDmsFrontEnd_2000_transfer_MAIL_TYPE  1

                    Log  ${transfer_MAIL_TYPE}
                    Log  ${transfer_MAIL_TYPE}[0] 
                    Log  ${excel_file_data}[4]

   	    	        IF	'${transfer_MAIL_TYPE}[0]' == '${excel_file_data}[4]'

        	            dms_dmsweb2_ClickDmsFrontEnd_2000_MList_transfer_check_button  1
       	                ${match2}=  set variable  True  

                     END
   	    	    END
   	    	END
   	    END
   	    RETURN    ${match1}  ${match2}



dms_dmsweb2_DmsFrontEnd_2000_stage3_i
        [Arguments]   ${match2}    ${excel_file_data}
        [Documentation]
        [Tags]
        ${match2}  ${match3}=    dms_dmsweb2_DmsFrontEnd_2000_stage2_i  ${match2}    ${excel_file_data} 

        Log  ${match2}
        Log  ${match3}

dms_dmsweb2_DmsFrontEnd_2000_stage2_i
    [Arguments]   ${match2}  ${excel_file_data}
    [Documentation]
    [Tags]

    ${match3}=    set variable   FAIL

	FOR  ${i}  IN RANGE  2  1000  1

	    IF	'${match2}' == 'True'
		    Exit For Loop
	    END
 
        ${match3}  ${transfer_MLIST_STATUS}=  dms_dmsweb2_FetchDmsFrontEnd_2000_transfer_MLIST_STATUS  ${i}

	    Log  ${match3}
	    Log  ${transfer_MLIST_STATUS}
	    Log  ${transfer_MLIST_STATUS}[0]
	    Take Screenshot

	    IF	'${match3}' == 'FAIL'

		    Exit For Loop
	    END

	    IF	'${transfer_MLIST_STATUS}[0]' == '確'

		    CONTINUE FOR LOOP
	    END

                ${match3}  ${transfer_ACC_DATE}=  dms_dmsweb2_FetchDmsFrontEnd_2000_transfer_ACC_DATE  ${i}

                Log  ${transfer_ACC_DATE}
                Log  ${excel_file_data}[19]

	    	    IF	'${transfer_ACC_DATE}' == '${excel_file_data}[19]'
	                ${match3}  ${transfer_TOUR_NO}=  dms_dmsweb2_FetchDmsFrontEnd_2000_transfer_TOUR_NO  ${i} 	

                    Log  ${transfer_TOUR_NO}
                    Log  ${excel_file_data}[20]  

	    	    	IF	'${transfer_TOUR_NO}' == '${excel_file_data}[20]'
	    	    		${match3}  ${transfer_RCV_OFFICE}=  dms_dmsweb2_FetchDmsFrontEnd_2000_transfer_RCV_OFFICE  ${1}


                        Log  ${transfer_RCV_OFFICE}
                        Log  ${transfer_RCV_OFFICE}[0] 
                        Log  ${excel_file_data}[21]  
	    	    	    IF	'${transfer_RCV_OFFICE}[0]' == '${excel_file_data}[21]'
   	    	       	        ${match1}  ${transfer_MAIL_TYPE}=  dms_dmsweb2_FetchDmsFrontEnd_2000_transfer_MAIL_TYPE  ${i}

                            Log  ${transfer_MAIL_TYPE}
                            Log  ${transfer_MAIL_TYPE}[0] 
                            Log  ${excel_file_data}[4]

   	    	                IF	'${transfer_MAIL_TYPE}[0]' == '${excel_file_data}[4]'

        	                    dms_dmsweb2_ClickDmsFrontEnd_2000_MList_transfer_check_button  ${i} 
        	                    ${match2}=  set variable  True
                            END
	    	    	    END
	    	    	END
	    	    END

	END
	RETURN    ${match2}  ${match3}


dms_dmsweb2_DmsFrontEnd_2000_stage22_1
        [Arguments]   ${excel_file_data}
        [Documentation]
        [Tags]


        ${match2}=  set variable  False  
        ${match1}  ${transfer_MAIL_NO}=  dms_dmsweb2_FetchDmsFrontEnd_2000_transfer_MAIL_NO  1


        Log  ${transfer_MAIL_NO}
        Log  ${excel_file_data}[5]

   	    IF	'${transfer_MAIL_NO}' == '${excel_file_data}[5]'

        	dms_dmsweb2_ClickDmsFrontEnd_2000_mail_transfer_button  1
       	    ${match2}=  set variable  True
   	    END
        RETURN    ${match1}  ${match2}


dms_dmsweb2_DmsFrontEnd_2000_stage22_i
    [Arguments]   ${match2}  ${excel_file_data}
    [Documentation]
    [Tags]

    ${match3}=    set variable   FAIL

	FOR  ${i}  IN RANGE  2  1000  1

	    IF	'${match2}' == 'True'
		    Exit For Loop
	    END

        ${match3}  ${transfer_MLIST_STATUS}=   dms_dmsweb2_FetchDmsFrontEnd_2000_transfer_MLIST_STATUS   ${i}


	    Log  ${match3}
	    Log  ${transfer_MLIST_STATUS}
	    Log  ${transfer_MLIST_STATUS}[0]
	    Take Screenshot



	    IF	'${transfer_MLIST_STATUS}[0]' == '修'
		    CONTINUE FOR LOOP
	    END


                ${match3}  ${transfer_MAIL_NO}=  dms_dmsweb2_FetchDmsFrontEnd_2000_transfer_MAIL_NO  ${i} 

                Log  ${transfer_MAIL_NO}
                Log  ${excel_file_data}[5]

	    	    IF	'${transfer_MAIL_NO}' == '${excel_file_data}[5]'
	                
        	        dms_dmsweb2_ClickDmsFrontEnd_2000_mail_transfer_button  ${i} 
        	        ${match2}=  set variable  True 	

                    
	    	    END
	END

    RETURN    ${match2}  ${match3}


dms_dmsweb2_DmsFrontEnd_2300_stage1_1
        [Arguments]   ${excel_file_data}  ${string}
        [Documentation]
        [Tags]

        ${match2}=  set variable  False 
        
#        ${match1}  ${IN_TYPE}=  Run Keyword And Warn On Failure    Browser.Get Text        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[3]/div[2]/div[2]/table/tbody/tr[1]/td[3]
        ${match1}  ${IN_TYPE}=  dms_dmsweb2_FetchDmsFrontEnd_2300_IN_TYPE  1


	    IF	'${match1}' == 'FAIL'
            IF	'${string}' != 'mail'
	    	    dms_dmsweb2_DmsFrontEnd_2300_stage1_c
            END
	    	Take Screenshot

			${match2}=  set variable  True 
	    END

        Log  ${excel_file_data}[3]


        
        Log  ${IN_TYPE}
        Log  ${IN_TYPE}[0:2]
        ${IN_TYPE_num}=  evaluate  'False'
        IF  '${IN_TYPE}[0:2]' != 'Ti'
            ${IN_TYPE_num}=    Convert to Integer  ${IN_TYPE}[0:2]
        END
        Log  ${IN_TYPE_num}

        Take Screenshot

   	    IF	'${IN_TYPE_num}' == '${excel_file_data}[3]'
#                ${match1}  ${MLST_TYPE}=  Run Keyword And Warn On Failure    Browser.Get Text        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[3]/div[2]/div[2]/table/tbody/tr[1]/td[4]
                ${match1}  ${MLST_TYPE}=      dms_dmsweb2_FetchDmsFrontEnd_2300_MLST_TYPE  1 	

            
            Log  ${excel_file_data}[4]
            Log  ${MLST_TYPE}
            Log  ${MLST_TYPE}[0]  

   	    	IF	'${MLST_TYPE}[0]' == '${excel_file_data}[4]'
#   	    		${match1}  ${MLIST_NO}=  Run Keyword And Warn On Failure    Browser.Get Text        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[3]/div[2]/div[2]/table/tbody/tr[1]/td[5]
   	    		${match1}  ${MLIST_NO}=        dms_dmsweb2_FetchDmsFrontEnd_2300_MLST_NO  1 	


   	    		Log  ${MLIST_NO}
   	    		Log  ${excel_file_data}[12]

   	    	    IF	'${MLIST_NO}' == '${excel_file_data}[12]'
#   	    	        ${match1}  ${ORG_OFFICE}=  Run Keyword And Warn On Failure    Browser.Get Text        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[3]/div[2]/div[2]/table/tbody/tr[1]/td[6]
   	    	        ${match1}  ${ORG_OFFICE}=        dms_dmsweb2_FetchDmsFrontEnd_2300_ORG_OFFICE  1

   	    	        Log  ${ORG_OFFICE}
   	    	        Log  ${ORG_OFFICE}[0:6]
   	    	        Log  ${excel_file_data}[8]

   	    	        IF	'${ORG_OFFICE}[0:6]' == '${excel_file_data}[8]'
#   	    	            ${match1}  ${DST_OFFICE}=  Run Keyword And Warn On Failure    Browser.Get Text        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[3]/div[2]/div[2]/table/tbody/tr[1]/td[7]
   	    	            ${match1}  ${DST_OFFICE}=        dms_dmsweb2_FetchDmsFrontEnd_2300_DST_OFFICE  1


   	    	            Log  ${DST_OFFICE}
   	    	            Log  ${DST_OFFICE}[0:6]
   	    	            Log  ${excel_file_data}[7]
   	    	            IF  '${excel_file_data}[7]' == 'None'
   	    	                 ${excel_file_data}[7]=  evaluate  ''
   	    	            END
   	    	            Log  ${excel_file_data}[7]

   	    	            IF	'${DST_OFFICE}[0:6]' == '${excel_file_data}[7]'
#   	    	                ${match1}  ${COR}=  Run Keyword And Warn On Failure    Browser.Get Text        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[3]/div[2]/div[2]/table/tbody/tr[1]/td[8]
   	    	                ${match1}  ${COR}=        dms_dmsweb2_FetchDmsFrontEnd_2300_COR  1
   	    	                Log  ${COR}

                            IF	'${COR}' == '${excel_file_data}[9]'
#       	            dms_dmsweb2_ClickDmsFrontEnd_2000_MList_login_button  1
       	                        ${match2}=  set variable  True  
       	                    END
                        END
                    END
   	    	    END
   	    	END
   	    END

        Take Screenshot
        RETURN    ${match1}  ${match2}



dms_dmsweb2_DmsFrontEnd_2300_stage1_i
    [Arguments]   ${match2}   ${excel_file_data}  
    [Documentation]
    [Tags]


    Take Screenshot
    ${match3}=    set variable   FAIL
	FOR  ${i}  IN RANGE  2  1000  1

	    IF	'${match2}' == 'True'
		    Exit For Loop
	    END




        ${match3}  ${MLIST_STATUS}=  Run Keyword And Warn On Failure    Browser.Get Text        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]

	    Log  ${match3}
	    Log  ${MLIST_STATUS}
	    Log  ${MLIST_STATUS}[0]
	    Take Screenshot

	    IF	'${match3}' == 'FAIL'
#		    ${result_data}=  set variable  FAIL
		    Exit For Loop
	    END

	    IF	'${MLIST_STATUS}[0]' == '修'
#		    ${result_data}=  set variable  FAIL
		    CONTINUE FOR LOOP
	    END

#	    CONTINUE FOR LOOP

#			FOR  ${sensor_name}  IN  @{sensor_check_list}
#                ${match3}  ${IN_TYPE}=  Run Keyword And Warn On Failure    Browser.Get Text        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[3]/div[2]/div[2]/table/tbody/tr[1]/td[3]
                ${match3}  ${IN_TYPE}=  dms_dmsweb2_FetchDmsFrontEnd_2300_IN_TYPE  i

                Log  ${IN_TYPE}[0:2]
                ${IN_TYPE_num}=    Convert to Integer     ${IN_TYPE}[0:2]
                Log  ${IN_TYPE_num}

	    	    IF	'${IN_TYPE_num}' == '${excel_file_data}[3]'
#	                ${match3}  ${MLST_TYPE}=  Run Keyword And Warn On Failure    Browser.Get Text        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[4]
	    	    	${match3}  ${MLST_TYPE}=  Run Keyword And Warn On Failure    dms_dmsweb2_FetchDmsFrontEnd_2300_MLST_TYPE  i

                    Log  ${excel_file_data}[4]
                    Log  ${MLST_TYPE}
                    Log  ${MLST_TYPE}[0] 

	    	    	IF	'${MLST_TYPE}[0]' == '${excel_file_data}[4]'
#	    	    		${match3}  ${MLIST_NO}=  Run Keyword And Warn On Failure    Browser.Get Text        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[5]
	    	    		${match3}  ${MLIST_NO}=        dms_dmsweb2_FetchDmsFrontEnd_2300_MLST_NO  i 

                        Log  ${MLIST_NO}
                        Log  ${excel_file_data}[12]

	    	    	    IF	'${MLIST_NO}' == '${excel_file_data}[12]'
#	    	    		    ${match3}  ${ORG_OFFICE}=  Run Keyword And Warn On Failure    Browser.Get Text        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[6]
   	    	        	    ${match1}  ${ORG_OFFICE}=        dms_dmsweb2_FetchDmsFrontEnd_2300_ORG_OFFICE  i


                            Log  ${ORG_OFFICE}
                            Log  ${ORG_OFFICE}[0:6]
   	    	                Log  ${excel_file_data}[8]

	    	    	        IF	'${ORG_OFFICE}[0:6]' == '${excel_file_data}[8]'
#	    	    		        ${match3}  ${DST_OFFICE}=  Run Keyword And Warn On Failure    Browser.Get Text        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[7]
   	    	                    ${match3}  ${DST_OFFICE}=        dms_dmsweb2_FetchDmsFrontEnd_2300_DST_OFFICE  i
                                Log  ${DST_OFFICE}
   	    	                    Log  ${DST_OFFICE}[0:6]
   	    	                    Log  ${excel_file_data}[7]
   	    	                    IF  '${excel_file_data}[7]' == 'None'
   	    	                        ${excel_file_data}[7]=  evaluate  ''
   	    	                    END
   	    	                    Log  ${excel_file_data}[7]

	    	    	            IF	'${DST_OFFICE}[0:6]' == '${excel_file_data}[7]'
#	    	    		            ${match3}  ${COR}=  Run Keyword And Warn On Failure    Browser.Get Text        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[8]
   	    	                        ${match3}  ${COR}=        dms_dmsweb2_FetchDmsFrontEnd_2300_COR  i
                                    Log  ${COR}

	    	    	                IF	'${COR}' == '${excel_file_data}[9]'


#	        	            dms_dmsweb2_ClickDmsFrontEnd_2000_MList_login_button  ${i}
	        	                        ${match2}=  set variable  True 
	    	    	    	            BREAK



                                    END
                                END
	    	    	    	END
	    	    	    END
	    	    	END
	    	    END



#			END
#		Run Keyword If    '${result_data}'=='FAIL'    Exit For Loop
		${total_column}=  set variable  ${i}
		Take Screenshot
	END

    RETURN    ${match2}  ${match3}


dms_dmsweb2_DmsFrontEnd_2300_stage1_c
        [Arguments]   ${excel_file_data} 
        [Documentation]
        [Tags]

		dms_dmsweb2_ClickDmsFrontEnd_2000NewMListButton

#		Debug
		dms_dmsweb2_ClickDmsFrontEnd_2300MLST_TYPE   ${excel_file_data}[4]
		dms_dmsweb2_ClickDmsFrontEnd_2300IN_TYPE   ${excel_file_data}[3]


		dms_dmsweb2_ClickDmsFrontEnd_2300MLIST_NO   ${excel_file_data}[12]
		dms_dmsweb2_ClickDmsFrontEnd_2300ORG_OFFICE   ${excel_file_data}[8]
		dms_dmsweb2_ClickDmsFrontEnd_2300DST_OFFICE   ${excel_file_data}[7]
		dms_dmsweb2_ClickDmsFrontEnd_2300COR   ${excel_file_data}[9]

		Take Screenshot
		Sleep  1s
		Take Screenshot

		dms_dmsweb2_ClickDmsFrontEnd_2300SendButton

		Take Screenshot
		Sleep  1s
		Take Screenshot

		dms_dmsweb2_ClickDmsFrontEnd_2300EndButton

		Take Screenshot
		Sleep  1s




dms_dmsweb2_DmsFrontEnd_2301_stage1_1
        [Arguments]   ${excel_file_data}
        [Documentation]
        [Tags]

        ${match2}=  set variable  False 
        
        ${match1}  ${MLIST_NO}=  dms_dmsweb2_FetchDmsFrontEnd_2301_MLIST_NO  1


	    IF	'${match1}' == 'FAIL'
		    dms_dmsweb2_DmsFrontEnd_2301_stage1_c
            Sleep  1s
            Take Screenshot

            ${match1}  ${MLIST_NO}=  dms_dmsweb2_FetchDmsFrontEnd_2301_MLIST_NO  1 
	    END
        Log  ${MLIST_NO}
        Log  ${excel_file_data}[12]



   	    IF	'${MLIST_NO}' == '${excel_file_data}[12]'
            ${match1}  ${ORG_OFFICE}=  dms_dmsweb2_FetchDmsFrontEnd_2301_ORG_OFFICE  1         	

   	    	Log  ${ORG_OFFICE}
   	    	Log  ${ORG_OFFICE}[0:6]
   	    	Log  ${excel_file_data}[8]

   	    	IF	'${ORG_OFFICE}[0:6]' == '${excel_file_data}[8]'

   	    		${match1}  ${PCK_CNT}=  dms_dmsweb2_FetchDmsFrontEnd_2301_PCK_CNT  1

   	    	    Log  ${PCK_CNT}
   	    	    Log  ${excel_file_data}[13]

                IF  '${excel_file_data}[13]' == 'None'
                    ${excel_file_data}[13]=  evaluate  '0'
                END
   	    	    IF	'${PCK_CNT}' != '${excel_file_data}[13]'
                    Fail
   	    	    END

   	    		${match1}  ${RCL_CNT}=  dms_dmsweb2_FetchDmsFrontEnd_2301_RCL_CNT  1

   	    	    Log  ${RCL_CNT}
   	    	    Log  ${excel_file_data}[14]

                IF  '${excel_file_data}[14]' == 'None'
                    ${excel_file_data}[14]=  evaluate  '0'
                END
   	    	    IF	'${RCL_CNT}' != '${excel_file_data}[14]'
                    Fail
   	    	    END

   	    		${match1}  ${C_CNT}=  dms_dmsweb2_FetchDmsFrontEnd_2301_C_CNT  1

   	    	    Log  ${C_CNT}
   	    	    Log  ${excel_file_data}[15]

                IF  '${excel_file_data}[15]' == 'None'
                    ${excel_file_data}[15]=  evaluate  '0'
                END
   	    	    IF	'${C_CNT}' != '${excel_file_data}[15]'
                    Fail
   	    	    END

   	    		${match1}  ${BIDDING}=  dms_dmsweb2_FetchDmsFrontEnd_2301_BIDDING  1

   	    	    Log  ${BIDDING}
   	    	    Log  ${excel_file_data}[16]

                IF  '${excel_file_data}[16]' == 'None'
                    ${excel_file_data}[16]=  evaluate  '0'
                END
   	    	    IF	'${BIDDING}' != '${excel_file_data}[16]'
                    Fail
   	    	    END

   	    		${match1}  ${INLP_CNT}=  dms_dmsweb2_FetchDmsFrontEnd_2301_INLP_CNT  1

   	    	    Log  ${INLP_CNT}
   	    	    Log  ${excel_file_data}[17]

                IF  '${excel_file_data}[17]' == 'None'
                    ${excel_file_data}[17]=  evaluate  '0'
                END
   	    	    IF	'${INLP_CNT}' != '${excel_file_data}[17]'
                    Fail
   	    	    END

   	    		${match1}  ${INOP_CNT}=  dms_dmsweb2_FetchDmsFrontEnd_2301_INOP_CNT  1

   	    	    Log  ${INOP_CNT}
   	    	    Log  ${excel_file_data}[18]

                IF  '${excel_file_data}[18]' == 'None'
                    ${excel_file_data}[18]=  evaluate  '0'
                END
   	    	    IF	'${INOP_CNT}' != '${excel_file_data}[18]'
                    Fail
   	    	    END

   	    	    dms_dmsweb2_ClickDmsFrontEnd_2000_MList_login_button  1
   	    	    ${match2}=  set variable  True 
   	    	END
   	    END


        Take Screenshot
        RETURN    ${match1}  ${match2}




dms_dmsweb2_DmsFrontEnd_2301_stage1_i
    [Arguments]   ${match2}   ${excel_file_data}  
    [Documentation]
    [Tags]


    Take Screenshot
    ${match3}=    set variable   FAIL
	FOR  ${i}  IN RANGE  2  1000  1

	    IF	'${match2}' == 'True'
		    Exit For Loop
	    END




        ${match3}  ${MLIST_STATUS}=  dms_dmsweb2_FetchDmsFrontEnd_2301_MLIST_STATUS  ${i}

	    Log  ${match3}
	    Log  ${MLIST_STATUS}
	    Log  ${MLIST_STATUS}[0]
	    Take Screenshot

	    IF	'${match3}' == 'FAIL'
#		    ${result_data}=  set variable  FAIL
		    Exit For Loop
	    END

	    IF	'${MLIST_STATUS}[0]' == '修'
#		    ${result_data}=  set variable  FAIL
		    CONTINUE FOR LOOP
	    END




                ${match3}  ${MLIST_NO}=  dms_dmsweb2_FetchDmsFrontEnd_2301_MLIST_NO   ${i} 

                Log  ${MLIST_NO}
                Log  ${excel_file_data}[12]

	    	    IF	'${MLIST_NO}' == '${excel_file_data}[12]'
	                ${match3}  ${ORG_OFFICE}=  dms_dmsweb2_FetchDmsFrontEnd_2301_ORG_OFFICE   ${i} 	

                    Log  ${ORG_OFFICE}
                    Log  ${ORG_OFFICE}[0:6]
                    Log  ${excel_file_data}[8]  

	    	    	IF	'${ORG_OFFICE}[0:6]' == '${excel_file_data}[8]'
	    	    		${match3}  ${PCK_CNT}=  dms_dmsweb2_FetchDmsFrontEnd_2301_PCK_CNT  ${i}

   	    	    	    Log  ${PCK_CNT}
   	    	    	    Log  ${excel_file_data}[13]

                	    IF  '${excel_file_data}[13]' == 'None'
                	        ${excel_file_data}[13]=  evaluate  '0'
                	    END
   	    	    	    IF	'${PCK_CNT}' != '${excel_file_data}[13]'
                	        Fail
   	    	    	    END


   	    			    ${match1}  ${RCL_CNT}=  dms_dmsweb2_FetchDmsFrontEnd_2301_RCL_CNT  ${i}

   	    	    	    Log  ${RCL_CNT}
   	    	    	    Log  ${excel_file_data}[14]

                	    IF  '${excel_file_data}[14]' == 'None'
                	        ${excel_file_data}[14]=  evaluate  '0'
                	    END
   	    	    	    IF	'${RCL_CNT}' != '${excel_file_data}[14]'
                	        Fail
   	    	    	    END

   	    			    ${match1}  ${C_CNT}=  dms_dmsweb2_FetchDmsFrontEnd_2301_C_CNT  ${i}

   	    	    	    Log  ${C_CNT}
   	    	    	    Log  ${excel_file_data}[15]

                	    IF  '${excel_file_data}[15]' == 'None'
                	        ${excel_file_data}[15]=  evaluate  '0'
                	    END
   	    	    	    IF	'${C_CNT}' != '${excel_file_data}[15]'
                	        Fail
   	    	    	    END

   	    			    ${match1}  ${BIDDING}=  dms_dmsweb2_FetchDmsFrontEnd_2301_BIDDING  ${i}

   	    	    	    Log  ${BIDDING}
   	    	    	    Log  ${excel_file_data}[16]

                	    IF  '${excel_file_data}[16]' == 'None'
                	        ${excel_file_data}[16]=  evaluate  '0'
                	    END
   	    	    	    IF	'${BIDDING}' != '${excel_file_data}[16]'
                	        Fail
   	    	    	    END

   	    			    ${match1}  ${INLP_CNT}=  dms_dmsweb2_FetchDmsFrontEnd_2301_INLP_CNT  ${i}

   	    	    	    Log  ${INLP_CNT}
   	    	    	    Log  ${excel_file_data}[17]

                	    IF  '${excel_file_data}[17]' == 'None'
                	        ${excel_file_data}[17]=  evaluate  '0'
                	    END
   	    	    	    IF	'${INLP_CNT}' != '${excel_file_data}[17]'
                	        Fail
   	    	    	    END

   	    			    ${match1}  ${INOP_CNT}=  dms_dmsweb2_FetchDmsFrontEnd_2301_INOP_CNT   ${i}

   	    	    	    Log  ${INOP_CNT}
   	    	    	    Log  ${excel_file_data}[18]

                	    IF  '${excel_file_data}[18]' == 'None'
                	        ${excel_file_data}[18]=  evaluate  '0'
                	    END
   	    	    	    IF	'${INOP_CNT}' != '${excel_file_data}[18]'
                	        Fail
   	    	    	    END

   	    	    	    dms_dmsweb2_ClickDmsFrontEnd_2000_MList_login_button  ${i}
   	    	    	    ${match2}=  set variable  True 
	    	    	    
	    	    	END
	    	    END




		${total_column}=  set variable  ${i}
		Take Screenshot

	END

    RETURN    ${match2}  ${match3}






dms_dmsweb2_DmsFrontEnd_2301_stage1_c
    [Arguments]    
    [Documentation]
    [Tags]

		    dms_dmsweb2_ClickDmsFrontEnd_2301_new_MList_button
		    dms_dmsweb2_ClickDmsFrontEnd_2301_new_MList_MLIST_NO  ${excel_file_data}[12]
		    dms_dmsweb2_ClickDmsFrontEnd_2301_new_MList_ORG_OFFICE  ${excel_file_data}[8]
		    dms_dmsweb2_ClickDmsFrontEnd_2301_new_MList_PCK_CNT  ${excel_file_data}[13]
		    dms_dmsweb2_ClickDmsFrontEnd_2301_new_MList_RCL_CNT  ${excel_file_data}[14]
		    dms_dmsweb2_ClickDmsFrontEnd_2301_new_MList_C_CNT  ${excel_file_data}[15]
		    dms_dmsweb2_ClickDmsFrontEnd_2301_new_MList_BIDDING_CNT  ${excel_file_data}[16]
		    dms_dmsweb2_ClickDmsFrontEnd_2301_new_MList_INCL_CNT  ${excel_file_data}[17]
		    dms_dmsweb2_ClickDmsFrontEnd_2301_new_MList_INOP_CNT  ${excel_file_data}[18]
		    dms_dmsweb2_ClickDmsFrontEnd_2301_new_MList_send_button
		    dms_dmsweb2_ClickDmsFrontEnd_2301_new_MList_end_button

            Keyboard Key    press       F7



dms_dmsweb2_DmsFrontEnd_2301_stage2_1
        [Arguments]   ${excel_file_data}
        [Documentation]
        [Tags]

 
        ${match2}=  set variable  False 

        ${match1}  ${MLIST_NO}=  dms_dmsweb2_FetchDmsFrontEnd_2301_MLIST_NO  1


	    IF	'${match1}' == 'FAIL'
            dms_dmsweb2_DmsFrontEnd_2301_stage2_c
            Sleep  1s
            Take Screenshot

            ${match1}  ${MLIST_NO}=  dms_dmsweb2_FetchDmsFrontEnd_2301_MLIST_NO  1 
	    END
        Log  ${MLIST_NO}
        Log  ${excel_file_data}[12]

   	    IF	'${MLIST_NO}' == '${excel_file_data}[12]'
            ${match1}  ${ORG_OFFICE}=  dms_dmsweb2_FetchDmsFrontEnd_2301_ORG_OFFICE  1         	

   	    	Log  ${ORG_OFFICE}
   	    	Log  ${ORG_OFFICE}[0:6]
   	    	Log  ${excel_file_data}[8]

   	    	IF	'${ORG_OFFICE}[0:6]' == '${excel_file_data}[8]'

   	    		${match1}  ${PCK_CNT}=  dms_dmsweb2_FetchDmsFrontEnd_2301_PCK_CNT  1

   	    	    Log  ${PCK_CNT}
   	    	    Log  ${excel_file_data}[13]

                IF  '${excel_file_data}[13]' == 'None'
                    ${excel_file_data}[13]=  evaluate  '0'
                END
   	    	    IF	'${PCK_CNT}' != '${excel_file_data}[13]'
                    Fail
   	    	    END

   	    		${match1}  ${RCL_CNT}=  dms_dmsweb2_FetchDmsFrontEnd_2301_RCL_CNT  1

   	    	    Log  ${RCL_CNT}
   	    	    Log  ${excel_file_data}[14]

                IF  '${excel_file_data}[14]' == 'None'
                    ${excel_file_data}[14]=  evaluate  '0'
                END
   	    	    IF	'${RCL_CNT}' != '${excel_file_data}[14]'
                    Fail
   	    	    END

   	    		${match1}  ${C_CNT}=  dms_dmsweb2_FetchDmsFrontEnd_2301_C_CNT  1

   	    	    Log  ${C_CNT}
   	    	    Log  ${excel_file_data}[15]

                IF  '${excel_file_data}[15]' == 'None'
                    ${excel_file_data}[15]=  evaluate  '0'
                END
   	    	    IF	'${C_CNT}' != '${excel_file_data}[15]'
                    Fail
   	    	    END

   	    		${match1}  ${BIDDING}=  dms_dmsweb2_FetchDmsFrontEnd_2301_BIDDING  1

   	    	    Log  ${BIDDING}
   	    	    Log  ${excel_file_data}[16]

                IF  '${excel_file_data}[16]' == 'None'
                    ${excel_file_data}[16]=  evaluate  '0'
                END
   	    	    IF	'${BIDDING}' != '${excel_file_data}[16]'
                    Fail
   	    	    END

   	    		${match1}  ${INLP_CNT}=  dms_dmsweb2_FetchDmsFrontEnd_2301_INLP_CNT  1

   	    	    Log  ${INLP_CNT}
   	    	    Log  ${excel_file_data}[17]

                IF  '${excel_file_data}[17]' == 'None'
                    ${excel_file_data}[17]=  evaluate  '0'
                END
   	    	    IF	'${INLP_CNT}' != '${excel_file_data}[17]'
                    Fail
   	    	    END

   	    		${match1}  ${INOP_CNT}=  dms_dmsweb2_FetchDmsFrontEnd_2301_INOP_CNT  1

   	    	    Log  ${INOP_CNT}
   	    	    Log  ${excel_file_data}[18]

                IF  '${excel_file_data}[18]' == 'None'
                    ${excel_file_data}[18]=  evaluate  '0'
                END
   	    	    IF	'${INOP_CNT}' != '${excel_file_data}[18]'
                    Fail
   	    	    END

#   	    	    dms_dmsweb2_ClickDmsFrontEnd_2000_MList_login_button  1
   	    	    dms_dmsweb2_ClickDmsFrontEnd_2000_M120_MList_login_button  ${1}
   	    	    ${match2}=  set variable  True 
   	    	END
   	    END




        Take Screenshot
        RETURN    ${match1}  ${match2}







dms_dmsweb2_DmsFrontEnd_2301_stage2_i
    [Arguments]   ${match2}   ${excel_file_data}  
    [Documentation]
    [Tags]


	FOR  ${i}  IN RANGE  2  1000  1

	    IF	'${match2}' == 'True'
		    Exit For Loop
	    END




        ${match3}  ${MLIST_STATUS}=  dms_dmsweb2_FetchDmsFrontEnd_2301_MLIST_STATUS  ${i}

	    Log  ${match3}
	    Log  ${MLIST_STATUS}
	    Log  ${MLIST_STATUS}[0]
	    Take Screenshot

	    IF	'${match3}' == 'FAIL'
#		    ${result_data}=  set variable  FAIL
		    Exit For Loop
	    END

	    IF	'${MLIST_STATUS}[0]' == '修'
#		    ${result_data}=  set variable  FAIL
		    CONTINUE FOR LOOP
	    END




                ${match3}  ${MLIST_NO}=  dms_dmsweb2_FetchDmsFrontEnd_2301_MLIST_NO   ${i} 

                Log  ${MLIST_NO}
                Log  ${excel_file_data}[12]

	    	    IF	'${MLIST_NO}' == '${excel_file_data}[12]'
	                ${match3}  ${ORG_OFFICE}=  dms_dmsweb2_FetchDmsFrontEnd_2301_ORG_OFFICE   ${i} 	

                    Log  ${ORG_OFFICE}
                    Log  ${ORG_OFFICE}[0:6]
                    Log  ${excel_file_data}[8]  

	    	    	IF	'${ORG_OFFICE}[0:6]' == '${excel_file_data}[8]'
	    	    		${match3}  ${PCK_CNT}=  dms_dmsweb2_FetchDmsFrontEnd_2301_PCK_CNT  ${i}

   	    	    	    Log  ${PCK_CNT}
   	    	    	    Log  ${excel_file_data}[13]

                	    IF  '${excel_file_data}[13]' == 'None'
                	        ${excel_file_data}[13]=  evaluate  '0'
                	    END
   	    	    	    IF	'${PCK_CNT}' != '${excel_file_data}[13]'
                	        Fail
   	    	    	    END


   	    			    ${match1}  ${RCL_CNT}=  dms_dmsweb2_FetchDmsFrontEnd_2301_RCL_CNT  ${i}

   	    	    	    Log  ${RCL_CNT}
   	    	    	    Log  ${excel_file_data}[14]

                	    IF  '${excel_file_data}[14]' == 'None'
                	        ${excel_file_data}[14]=  evaluate  '0'
                	    END
   	    	    	    IF	'${RCL_CNT}' != '${excel_file_data}[14]'
                	        Fail
   	    	    	    END

   	    			    ${match1}  ${C_CNT}=  dms_dmsweb2_FetchDmsFrontEnd_2301_C_CNT  ${i}

   	    	    	    Log  ${C_CNT}
   	    	    	    Log  ${excel_file_data}[15]

                	    IF  '${excel_file_data}[15]' == 'None'
                	        ${excel_file_data}[15]=  evaluate  '0'
                	    END
   	    	    	    IF	'${C_CNT}' != '${excel_file_data}[15]'
                	        Fail
   	    	    	    END

   	    			    ${match1}  ${BIDDING}=  dms_dmsweb2_FetchDmsFrontEnd_2301_BIDDING  ${i}

   	    	    	    Log  ${BIDDING}
   	    	    	    Log  ${excel_file_data}[16]

                	    IF  '${excel_file_data}[16]' == 'None'
                	        ${excel_file_data}[16]=  evaluate  '0'
                	    END
   	    	    	    IF	'${BIDDING}' != '${excel_file_data}[16]'
                	        Fail
   	    	    	    END

   	    			    ${match1}  ${INLP_CNT}=  dms_dmsweb2_FetchDmsFrontEnd_2301_INLP_CNT  ${i}

   	    	    	    Log  ${INLP_CNT}
   	    	    	    Log  ${excel_file_data}[17]

                	    IF  '${excel_file_data}[17]' == 'None'
                	        ${excel_file_data}[17]=  evaluate  '0'
                	    END
   	    	    	    IF	'${INLP_CNT}' != '${excel_file_data}[17]'
                	        Fail
   	    	    	    END

   	    			    ${match1}  ${INOP_CNT}=  dms_dmsweb2_FetchDmsFrontEnd_2301_INOP_CNT   ${i}

   	    	    	    Log  ${INOP_CNT}
   	    	    	    Log  ${excel_file_data}[18]

                	    IF  '${excel_file_data}[18]' == 'None'
                	        ${excel_file_data}[18]=  evaluate  '0'
                	    END
   	    	    	    IF	'${INOP_CNT}' != '${excel_file_data}[18]'
                	        Fail
   	    	    	    END

#   	    	    	    dms_dmsweb2_ClickDmsFrontEnd_2000_MList_login_button  ${i}
   	    	    	    dms_dmsweb2_ClickDmsFrontEnd_2000_M120_MList_login_button  ${i}
   	    	    	    ${match2}=  set variable  True 
	    	    	    
	    	    	END
	    	    END



#			END
#		Run Keyword If    '${result_data}'=='FAIL'    Exit For Loop
		${total_column}=  set variable  ${i}
		Take Screenshot
	END

    RETURN    ${match2}  ${match3}


dms_dmsweb2_DmsFrontEnd_2301_stage2_c
    [Arguments]    
    [Documentation]
    [Tags]


		    dms_dmsweb2_ClickDmsFrontEnd_2301_new_MList_button
		    dms_dmsweb2_ClickDmsFrontEnd_2301_new_MList_MLIST_NO  ${excel_file_data}[12]
		    dms_dmsweb2_ClickDmsFrontEnd_2301_new_MList_ORG_OFFICE  ${excel_file_data}[8]
		    dms_dmsweb2_ClickDmsFrontEnd_2301_new_MList_PCK_CNT  ${excel_file_data}[13]
		    dms_dmsweb2_ClickDmsFrontEnd_2301_new_MList_RCL_CNT  ${excel_file_data}[14]
		    dms_dmsweb2_ClickDmsFrontEnd_2301_new_MList_C_CNT  ${excel_file_data}[15]
		    dms_dmsweb2_ClickDmsFrontEnd_2301_new_MList_BIDDING_CNT  ${excel_file_data}[16]
		    dms_dmsweb2_ClickDmsFrontEnd_2301_new_MList_INCL_CNT  ${excel_file_data}[17]
		    dms_dmsweb2_ClickDmsFrontEnd_2301_new_MList_INOP_CNT  ${excel_file_data}[18]
		    dms_dmsweb2_ClickDmsFrontEnd_2301_new_MList_send_button
		    dms_dmsweb2_ClickDmsFrontEnd_2301_new_MList_end_button

            Sleep  1s
            Take Screenshot
            Keyboard Key    press       F7










dms_dmsweb2_DmsFrontEnd_2301_stage22_1
        [Arguments]   ${excel_file_data}
        [Documentation]
        [Tags]


        ${match2}=  set variable  False  
        ${match1}  ${login_MAIL_NO}=  Run Keyword And Warn On Failure    Browser.Get Text        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[2]/div[3]/div[2]/div[2]/table/tbody/tr[1]/td[4]

	    IF	'${match1}' == 'FAIL'
		    dms_dmsweb2_DmsFrontEnd_2301_stage22_c
	    END
        Log  ${login_MAIL_NO}
        Log  ${excel_file_data}[5]

   	    IF	'${login_MAIL_NO}' == '${excel_file_data}[19]'
                ${match1}  ${login_MAIL_NO_SRL}=  Run Keyword And Warn On Failure    Browser.Get Text        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[2]/div[3]/div[2]/div[2]/table/tbody/tr[1]/td[5]	

            Log  ${login_MAIL_NO_SRL} 

   	    	IF	'${login_MAIL_NO_SRL}' != '0'
   	    		Fail
   	    	END          

   	    	IF	'${login_MAIL_NO_SRL}' == '0'
   	    		${match2}=  set variable  True
   	    	END
   	    END

    RETURN    ${match1}  ${match2}





dms_dmsweb2_DmsFrontEnd_2301_stage22_i
    [Arguments]   ${match2}   ${excel_file_data}  
    [Documentation]
    [Tags]


	FOR  ${i}  IN RANGE  2  1000  1

	    IF	'${match2}' == 'True'
		    Exit For Loop
	    END




        ${match3}  ${login_MLIST_STATUS}=  Run Keyword And Warn On Failure    Browser.Get Text        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[2]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]


	    Log  ${match3}
	    Log  ${login_MLIST_STATUS}
	    Log  ${login_MLIST_STATUS}[0]
	    Take Screenshot

	    IF	'${match3}' == 'FAIL'
#		    ${result_data}=  set variable  FAIL
		    Exit For Loop
	    END

	    IF	'${login_MLIST_STATUS}[0]' == '刪'
#		    ${result_data}=  set variable  FAIL
		    CONTINUE FOR LOOP
	    END

#	    CONTINUE FOR LOOP

#			FOR  ${sensor_name}  IN  @{sensor_check_list}
                ${match3}  ${login_MAIL_NO}=  Run Keyword And Warn On Failure    Browser.Get Text        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[2]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[4]	 

                Log  ${login_MAIL_NO}
                Log  ${excel_file_data}[5]

	    	    IF	'${login_MAIL_NO}' == '${excel_file_data}[5]'
	                ${match3}  ${login_MAIL_NO_SRL}=  Run Keyword And Warn On Failure    Browser.Get Text        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[2]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[6]		

                    Log  ${login_MAIL_NO_SRL}
                     

	    	    	IF	'${transfer_TOUR_NO}' == '${excel_file_data}[20]'
	    	    		${match3}  ${transfer_RCV_OFFICE}=  Run Keyword And Warn On Failure    Browser.Get Text        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[6]


                        Log  ${transfer_RCV_OFFICE}
                        Log  ${transfer_RCV_OFFICE}[0] 
                        Log  ${excel_file_data}[21]  
	    	    	    IF	'${transfer_RCV_OFFICE}[0]' == '${excel_file_data}[21]'
   	    	       	        ${match1}  ${transfer_MAIL_TYPE}=  Run Keyword And Warn On Failure    Browser.Get Text        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[7]

                            Log  ${transfer_MAIL_TYPE}
                            Log  ${transfer_MAIL_TYPE}[0] 
                            Log  ${excel_file_data}[4]

   	    	                IF	'${transfer_MAIL_TYPE}[0]' == '${excel_file_data}[4]'

        	                    dms_dmsweb2_ClickDmsFrontEnd_2000_MList_transfer_check_button  ${i} 
        	                    ${match2}=  set variable  True
                            END
	    	    	    END
	    	    	END
	    	    END



#			END
#		Run Keyword If    '${result_data}'=='FAIL'    Exit For Loop
		${total_column}=  set variable  ${i}
		Take Screenshot
	END

    RETURN    ${match2}  ${match3}


dms_dmsweb2_DmsFrontEnd_2301_stage22_c
    [Arguments]    
    [Documentation]
    [Tags]


    dms_dmsweb2_ClickDmsFrontEnd_2301_MList_new_letter_button

    dms_dmsweb2_ClickDmsFrontEnd_2000_MList_letter_MAIL_NO  ${excel_file_data}[5]

    dms_dmsweb2_ClickDmsFrontEnd_2301_MList_letter_save_button

    dms_dmsweb2_ClickDmsFrontEnd_2301_MList_letter_end_button





dms_dmsweb2_DmsFrontEnd_2301_F3_stage1_1
        [Arguments]   ${excel_file_data}
        [Documentation]
        [Tags]


        ${match2}=  set variable  False 

        ${match1}  ${MLIST_NO}=  dms_dmsweb2_FetchDmsFrontEnd_2301_F3_MLIST_NO  1


	    IF	'${match1}' == 'FAIL'

	    	dms_dmsweb2_DmsFrontEnd_2301_F3_stage1_c
            Sleep  1s
            Take Screenshot

            ${match1}  ${MLIST_NO}=  dms_dmsweb2_FetchDmsFrontEnd_2301_F3_MLIST_NO  1 
	    END
        Log  ${MLIST_NO}
        Log  ${excel_file_data}[12]

   	    IF	'${MLIST_NO}' == '${excel_file_data}[12]'
            ${match1}  ${ORG_OFFICE}=  dms_dmsweb2_FetchDmsFrontEnd_2301_F3_ORG_OFFICE  1         	

   	    	Log  ${ORG_OFFICE}
   	    	Log  ${ORG_OFFICE}[0:6]
   	    	Log  ${excel_file_data}[8]

   	    	IF	'${ORG_OFFICE}[0:6]' == '${excel_file_data}[8]'

   	    		${match1}  ${PCK_CNT}=  dms_dmsweb2_FetchDmsFrontEnd_2301_F3_PCK_CNT  1

   	    	    Log  ${PCK_CNT}
   	    	    Log  ${excel_file_data}[13]

                IF  '${excel_file_data}[13]' == 'None'
                    ${excel_file_data}[13]=  evaluate  '0'
                END
   	    	    IF	'${PCK_CNT}' != '${excel_file_data}[13]'
                    Fail
   	    	    END

   	    		${match1}  ${RCL_CNT}=  dms_dmsweb2_FetchDmsFrontEnd_2301_F3_RCL_CNT  1

   	    	    Log  ${RCL_CNT}
   	    	    Log  ${excel_file_data}[14]

                IF  '${excel_file_data}[14]' == 'None'
                    ${excel_file_data}[14]=  evaluate  '0'
                END
   	    	    IF	'${RCL_CNT}' != '${excel_file_data}[14]'
                    Fail
   	    	    END

   	    		${match1}  ${C_CNT}=  dms_dmsweb2_FetchDmsFrontEnd_2301_F3_C_CNT  1

   	    	    Log  ${C_CNT}
   	    	    Log  ${excel_file_data}[15]

                IF  '${excel_file_data}[15]' == 'None'
                    ${excel_file_data}[15]=  evaluate  '0'
                END
   	    	    IF	'${C_CNT}' != '${excel_file_data}[15]'
                    Fail
   	    	    END

   	    		${match1}  ${BIDDING}=  dms_dmsweb2_FetchDmsFrontEnd_2301_F3_BIDDING  1

   	    	    Log  ${BIDDING}
   	    	    Log  ${excel_file_data}[16]

                IF  '${excel_file_data}[16]' == 'None'
                    ${excel_file_data}[16]=  evaluate  '0'
                END
   	    	    IF	'${BIDDING}' != '${excel_file_data}[16]'
                    Fail
   	    	    END

   	    		${match1}  ${INLP_CNT}=  dms_dmsweb2_FetchDmsFrontEnd_2301_F3_INLP_CNT  1

   	    	    Log  ${INLP_CNT}
   	    	    Log  ${excel_file_data}[17]

                IF  '${excel_file_data}[17]' == 'None'
                    ${excel_file_data}[17]=  evaluate  '0'
                END
   	    	    IF	'${INLP_CNT}' != '${excel_file_data}[17]'
                    Fail
   	    	    END

   	    		${match1}  ${INOP_CNT}=  dms_dmsweb2_FetchDmsFrontEnd_2301_F3_INOP_CNT  1

   	    	    Log  ${INOP_CNT}
   	    	    Log  ${excel_file_data}[18]

                IF  '${excel_file_data}[18]' == 'None'
                    ${excel_file_data}[18]=  evaluate  '0'
                END
   	    	    IF	'${INOP_CNT}' != '${excel_file_data}[18]'
                    Fail
   	    	    END

   	    		${match1}  ${IN_TYPE_CODE}=  dms_dmsweb2_FetchDmsFrontEnd_2301_F3_IN_TYPE_CODE   1
                Log  ${IN_TYPE_CODE}
                Log  ${excel_file_data}[4]

	    	    IF	'${IN_TYPE_CODE}' == '${excel_file_data}[4]'
                	Fail
   	    	    END

   	    	    dms_dmsweb2_ClickDmsFrontEnd_2301_F3_MList_login_button  1
   	    	    ${match2}=  set variable  True 
   	    	END
   	    END



        RETURN    ${match1}  ${match2}




dms_dmsweb2_DmsFrontEnd_2301_stage1_i
    [Arguments]   ${match2}   ${excel_file_data}  
    [Documentation]
    [Tags]


	FOR  ${i}  IN RANGE  2  1000  1

	    IF	'${match2}' == 'True'
		    Exit For Loop
	    END




        ${match3}  ${MLIST_STATUS}=  dms_dmsweb2_FetchDmsFrontEnd_2301_F3_MLIST_STATUS  ${i}

	    Log  ${match3}
	    Log  ${MLIST_STATUS}
	    Log  ${MLIST_STATUS}[0]
	    Take Screenshot

	    IF	'${match3}' == 'FAIL'
#		    ${result_data}=  set variable  FAIL
		    Exit For Loop
	    END

	    IF	'${MLIST_STATUS}[0]' == '修'
#		    ${result_data}=  set variable  FAIL
		    CONTINUE FOR LOOP
	    END




                ${match3}  ${MLIST_NO}=  dms_dmsweb2_FetchDmsFrontEnd_2301_F3_MLIST_NO   ${i} 

                Log  ${MLIST_NO}
                Log  ${excel_file_data}[12]

	    	    IF	'${MLIST_NO}' == '${excel_file_data}[12]'
	                ${match3}  ${ORG_OFFICE}=  dms_dmsweb2_FetchDmsFrontEnd_2301_F3_ORG_OFFICE   ${i} 	

                    Log  ${ORG_OFFICE}
                    Log  ${ORG_OFFICE}[0:6]
                    Log  ${excel_file_data}[8]  

	    	    	IF	'${ORG_OFFICE}[0:6]' == '${excel_file_data}[8]'
	    	    		${match3}  ${PCK_CNT}=  dms_dmsweb2_FetchDmsFrontEnd_2301_F3_PCK_CNT  ${i}

   	    	    	    Log  ${PCK_CNT}
   	    	    	    Log  ${excel_file_data}[13]

                	    IF  '${excel_file_data}[13]' == 'None'
                	        ${excel_file_data}[13]=  evaluate  '0'
                	    END
   	    	    	    IF	'${PCK_CNT}' != '${excel_file_data}[13]'
                	        Fail
   	    	    	    END


   	    			    ${match1}  ${RCL_CNT}=  dms_dmsweb2_FetchDmsFrontEnd_2301_F3_RCL_CNT  ${i}

   	    	    	    Log  ${RCL_CNT}
   	    	    	    Log  ${excel_file_data}[14]

                	    IF  '${excel_file_data}[14]' == 'None'
                	        ${excel_file_data}[14]=  evaluate  '0'
                	    END
   	    	    	    IF	'${RCL_CNT}' != '${excel_file_data}[14]'
                	        Fail
   	    	    	    END

   	    			    ${match1}  ${C_CNT}=  dms_dmsweb2_FetchDmsFrontEnd_2301_F3_C_CNT  ${i}

   	    	    	    Log  ${C_CNT}
   	    	    	    Log  ${excel_file_data}[15]

                	    IF  '${excel_file_data}[15]' == 'None'
                	        ${excel_file_data}[15]=  evaluate  '0'
                	    END
   	    	    	    IF	'${C_CNT}' != '${excel_file_data}[15]'
                	        Fail
   	    	    	    END

   	    			    ${match1}  ${BIDDING}=  dms_dmsweb2_FetchDmsFrontEnd_2301_F3_BIDDING  ${i}

   	    	    	    Log  ${BIDDING}
   	    	    	    Log  ${excel_file_data}[16]

                	    IF  '${excel_file_data}[16]' == 'None'
                	        ${excel_file_data}[16]=  evaluate  '0'
                	    END
   	    	    	    IF	'${BIDDING}' != '${excel_file_data}[16]'
                	        Fail
   	    	    	    END

   	    			    ${match1}  ${INLP_CNT}=  dms_dmsweb2_FetchDmsFrontEnd_2301_F3_INLP_CNT  ${i}

   	    	    	    Log  ${INLP_CNT}
   	    	    	    Log  ${excel_file_data}[17]

                	    IF  '${excel_file_data}[17]' == 'None'
                	        ${excel_file_data}[17]=  evaluate  '0'
                	    END
   	    	    	    IF	'${INLP_CNT}' != '${excel_file_data}[17]'
                	        Fail
   	    	    	    END

   	    			    ${match1}  ${INOP_CNT}=  dms_dmsweb2_FetchDmsFrontEnd_2301_F3_INOP_CNT   ${i}

   	    	    	    Log  ${INOP_CNT}
   	    	    	    Log  ${excel_file_data}[18]

                	    IF  '${excel_file_data}[18]' == 'None'
                	        ${excel_file_data}[18]=  evaluate  '0'
                	    END
   	    	    	    IF	'${INOP_CNT}' != '${excel_file_data}[18]'
                	        Fail
   	    	    	    END

   	    			    ${match1}  ${IN_TYPE_CODE}=  dms_dmsweb2_FetchDmsFrontEnd_2301_F3_IN_TYPE_CODE   ${i}
                        Log  ${IN_TYPE_CODE}
                        Log  ${excel_file_data}[4]

	    	            IF	'${IN_TYPE_CODE}' == '${excel_file_data}[4]'
                	        Fail
   	    	    	    END

   	    	    	    dms_dmsweb2_ClickDmsFrontEnd_2301_F3_MList_login_button  ${i}
   	    	    	    ${match2}=  set variable  True 
	    	    	    
	    	    	END
	    	    END



#			END
#		Run Keyword If    '${result_data}'=='FAIL'    Exit For Loop
		${total_column}=  set variable  ${i}
		Take Screenshot
	END



    RETURN    ${match2}  ${match3}





dms_dmsweb2_DmsFrontEnd_2301_F3_stage1_c
    [Arguments]    
    [Documentation]
    [Tags]


		    dms_dmsweb2_ClickDmsFrontEnd_2301_F3_new_MList_button
		    dms_dmsweb2_ClickDmsFrontEnd_2301_F3_new_MList_MLST_TYPE  ${excel_file_data}[4]
		    dms_dmsweb2_ClickDmsFrontEnd_2301_F3_new_MList_MLIST_NO  ${excel_file_data}[12]
		    dms_dmsweb2_ClickDmsFrontEnd_2301_F3_new_MList_ORG_OFFICE  ${excel_file_data}[8]
		    dms_dmsweb2_ClickDmsFrontEnd_2301_F3_new_MList_PCK_CNT  ${excel_file_data}[13]
		    dms_dmsweb2_ClickDmsFrontEnd_2301_F3_new_MList_RCL_CNT  ${excel_file_data}[14]
		    dms_dmsweb2_ClickDmsFrontEnd_2301_F3_new_MList_C_CNT  ${excel_file_data}[15]
		    dms_dmsweb2_ClickDmsFrontEnd_2301_F3_new_MList_BIDDING_CNT  ${excel_file_data}[16]
		    dms_dmsweb2_ClickDmsFrontEnd_2301_F3_new_MList_INCL_CNT  ${excel_file_data}[17]
		    dms_dmsweb2_ClickDmsFrontEnd_2301_F3_new_MList_INOP_CNT  ${excel_file_data}[18]
		    dms_dmsweb2_ClickDmsFrontEnd_2301_F3_new_MList_send_button
		    dms_dmsweb2_ClickDmsFrontEnd_2301_F3_new_MList_end_button

            Sleep  1s
            Take Screenshot
            Keyboard Key    press       F7


