*** Keywords ***

wistron_ssh_login
    Open Connection    ${OS_HOST}
    Login    ${OS_USERNAME}    ${OS_PASSWORD}

wistron_ssh_WaitPowerOn
        [Documentation]
        [Tags]
   	Wait Until Keyword Succeeds    ${OS_WAIT_TIMEOUT}    ${OS_WAIT_RETRY_TIMEOUT}    wistron_ssh_login
    	Close All Connections

