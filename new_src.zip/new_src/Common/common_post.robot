*** Variables ***
${xpath_refresh_button}    		xpath=//*[@id="refreshPage"]
${xpath_select_Inactive_image}		xpath=//*[@id="idimage_update"]
${select_value_Both_Images}		3
${class_idpreserveAll} 			class:icheckbox_square-blue
${class_Full_Flash}			class:icheckbox_square-blue
${xpath_Full_Flash}			xpath=//*[@id="select"]
${find_log}                     ${EMPTY}
${ClearLog}				SEL_FULLNESS sensor of type event_logging_disabled logged a log area reset

*** keywords ***

post_write_variable_in_file
  [Arguments]  ${variable}  ${file_path}
#  Create File  ${EXECDIR}/file_with_variable.txt  ${variable}
  Create File  ${file_path}  ${variable}
  Append To File  ${file_path}  ${data}\n


wistron_bmcweb_login
    [Documentation]    Do bmc web login
    Launch Browser And Login GUI
    Wait Until Page Contains    Dashboard    timeout=${BROWSER_PROCESSING_TIMEOUT}
    Wait Until Element Is Not Visible    ${xpath_processing_image}    timeout=${BROWSER_PROCESSING_TIMEOUT}

wistron_bmcweb_GoAndCheckSELEventPage
    [Documentation]    1. Full SEL via ipmi command.
    ...    2. Login BMC WebUI.
    ...    3. Logs & Reports> IPMI Evnet Log.
    Go To    ${url_event_log_ipmi}
    Wait Until Element Is Not Visible    ${xpath_processing_image}    timeout=${BROWSER_PROCESSING_TIMEOUT}
#    Wait Until Page Contains Element    ${xpath_refresh_button}    timeout=30s
    sleep  1s
    Click Element    ${xpath_refresh_button}
    Wait Until Element Is Not Visible    ${xpath_processing_image}    timeout=${BROWSER_PROCESSING_TIMEOUT}



wistron_bmcweb_ExpectPowerOff
        [Documentation]
        [Tags]
    	${power_status}=    wistron_ipmi_CheckChassisPowerStatus
    	Run Keyword If    '${power_status}' == 'Chassis Power is on'    wistron_ipmi_CommandPowerOFF


wistron_bmcweb_ExpectPowerOn
        [Documentation]
        [Tags]
    	${power_status}=    wistron_ipmi_CheckChassisPowerStatus
    	Run Keyword If    '${power_status}' == 'Chassis Power is off'    wistron_ipmi_CommandPowerON
	wistron_ssh_WaitPowerOn




wistron_bmcweb_GoToPage
        [Documentation]
        [Tags]
	[Arguments] 	${url_page}
   	Go To    ${url_page}
    	Wait Until Element Is Not Visible    ${xpath_processing_image}    timeout=${BROWSER_PROCESSING_TIMEOUT}


wistron_bmcweb_ClickPowerButtonOn
        [Documentation]
        [Tags]
    	Element Should Be Enabled    ${xpath_save_button}
    	Click Element    ${xpath_power_on_radio}
    	Click Element    ${xpath_save_button}
    	Handle Alert

wistron_bmcweb_ClickPowerButtonOff
        [Documentation]
        [Tags]
    	Element Should Be Enabled    ${xpath_save_button}
    	Click Element    ${xpath_power_off_radio}
    	Click Element    ${xpath_save_button}
    	Handle Alert

wistron_bmcweb_ClickPowerButtonCycle
        [Documentation]
        [Tags]
    	Element Should Be Enabled    ${xpath_save_button}
    	Click Element    ${xpath_power_cycle_radio}
    	Click Element    ${xpath_save_button}
    	Handle Alert


wistron_bmcweb_ClickPowerButtonHardReset
        [Documentation]
        [Tags]
    	Element Should Be Enabled    ${xpath_save_button}
    	Click Element    ${xpath_power_hard_reset_radio}
    	Click Element    ${xpath_save_button}
    	Handle Alert


wistron_bmcweb_ClickPowerButtonSoftShutdown
        [Documentation]
        [Tags]
    	Element Should Be Enabled    ${xpath_save_button}
    	Click Element    ${xpath_power_ACPI_shutdown_radio}
    	Click Element    ${xpath_save_button}
    	Handle Alert











wistron_bmcweb_ExpectOemEventLog
        [Documentation]
        [Tags]
	${count} =    Get Element Count    ${xpath_IPMI_Event_Log_table_row}
    	FOR    ${row}    IN RANGE    1    ${count}
        	${irow}    set Variable    [${row}]
        	${resp} =    Get Text    ${xpath_IPMI_Event_Log_table_row}${irow}
        	${find_log}=    Run Keyword And Ignore Error    Should Contain    ${resp}    c5h 6fh a1h 01h
        	Exit For Loop If    ${find_log} == ('PASS', None)
    	END
    	Should Not Contain    ${find_log}    FAIL

wistron_bmcweb_logout
        [Documentation]
        [Tags]
    	Close All Browsers


wistron_bmcweb_ChooseBiosImage
	[Arguments] 	${bios_update_firmware_image}
	Log_To_Console   bios_update_firmware_image ${bios_update_firmware_image}
	Choose File    ${xpath_upload_firmware_image}    ${local_path}/${Image_folder_path}/${bios_update_firmware_image}
    Click Element    ${xpath_firmware_checks_button}
    Wait Until Element Is Not Visible    ${xpath_processing_image}    timeout=${BROWSER_PROCESSING_TIMEOUT}



wistron_bmcweb_ChooseBmcImage
	[Arguments] 	${bmc_update_firmware_image}
	Log_To_Console   bmc_update_firmware_image ${bmc_update_firmware_image}
	Choose File    ${xpath_upload_firmware_image}    ${local_path}/${Image_folder_path}/${bmc_update_firmware_image}
    Click Element    ${xpath_firmware_checks_button}
    Wait Until Element Is Not Visible    ${xpath_processing_image}    timeout=${BROWSER_PROCESSING_TIMEOUT}





wistron_bmcweb_ClickFirmwareUpdateButton1
	Click Element    ${xpath_start_bios_firmware_update_button}
	Log_To_Console  Click Element
    Handle Alert
	Log_To_Console  Handle Alert
    Wait Until Element Is Not Visible    ${xpath_processing_image}    timeout=${BROWSER_PROCESSING_TIMEOUT}
	Log_To_Console  Wait Until Element Is Not Visible



wistron_bmcweb_ClickFirmwareUpdateButton2
	Click Element    ${xpath_start_bios_firmware_update_button}
	Log_To_Console  Click Element 2
    Wait Until Element Is Not Visible    ${xpath_processing_image}    timeout=${BROWSER_PROCESSING_TIMEOUT}
	Log_To_Console  Wait Until Element Is Not Visible 2
    Handle Alert    timeout=${FIRMEWARE_TIMEOUT}
	Log_To_Console  Handle Alert




wistron_bmcweb_ClickFirmwareUpdateButton3
	Select From List By Value	${xpath_select_Inactive_image}   ${select_value_Both_Images}
#    Select Checkbox    ${xpath_preserve_all_configuration_checkbox}
#    	Click Element    ${xpath_preserve_all_configuration_checkbox}

    	Click Element    ${class_idpreserveAll}

#    	Mouse Down    ${xpath_preserve_all_configuration_checkbox}
#	${elem} =	Get WebElement	id:idpreserveAll
#	Log_To_Console   elem ${elem}
#	Log_To_Console   1
#	sleep  2s
#	Click Element	${elem}	


	Log_To_Console  Select Checkbox
	Click Element    ${xpath_start_bmc_firmware_update_button}
	Log_To_Console  Click Element
    Handle Alert
	Log_To_Console  Handle Alert
    Wait Until Element Is Not Visible    ${xpath_processing_image}    timeout=${BROWSER_PROCESSING_TIMEOUT}
	Log_To_Console  Wait Until Element Is Not Visible



wistron_bmcweb_ClickFirmwareUpdateButton4
	Log_To_Console  sleep 10s 2-1
	sleep  10s
	Log_To_Console  sleep 10s 2-2
	Log_To_Console  Click Element xpath_start_bmc 2-1
	Click Element    ${xpath_start_bmc_firmware_update_button}
	Log_To_Console  Click Element xpath_start_bmc 2-2
	Log_To_Console  Handle Alert 2-1
    Handle Alert    timeout=${FIRMEWARE_TIMEOUT}
	Log_To_Console  Handle Alert 2-2
	Log_To_Console  Wait Until Element Is Not Visible 2-1
    Wait Until Element Is Not Visible    ${xpath_processing_image}    timeout=${BROWSER_UPDATING_TIMEOUT}
	Log_To_Console  Wait Until Element Is Not Visible 2-2
    Wait Until Element Is Visible    ${xpath_processing_image}    timeout=${BROWSER_UPDATING_TIMEOUT}
	Log_To_Console  Wait Until Element Is Not Visible 2-3
    Handle Alert    timeout=${FIRMEWARE_TIMEOUT}
#    Wait Until Element Is Not Visible    ${xpath_processing_image}    timeout=${BROWSER_UPDATING_TIMEOUT}
	Log_To_Console  Wait Until Element Is Not Visible 2-4


wistron_bmcweb_CheckPEFpolicy
	[Arguments]  ${initial_filters}
	Wait Until Keyword Succeeds    ${FIRMEWARE_TIMEOUT}    ${FIRMEWARE_RETRY_TIMEOUT}    wistron_bmcweb_login
    GO To    ${url_event_filters}
    Wait Until Element Is Not Visible    ${xpath_processing_image}    timeout=${BROWSER_PROCESSING_TIMEOUT}
    ${firmware_filter}=    Get Text    ${xpath_event_filters_data}
    Should Be Equal As Strings    ${initial_filters}    ${firmware_filter}
    Close All Browsers
    wistron_bmcweb_logout


wistron_bmcweb_Get_initial_filters
    wistron_bmcweb_login
    GO To    ${url_event_filters}
    Wait Until Element Is Not Visible    ${xpath_processing_image}    timeout=${BROWSER_PROCESSING_TIMEOUT}
    ${output}=    Get Text    ${xpath_event_filters_data}
    Set Suite Variable    ${initial_filters}    ${output}
	Log_To_Console  initial_filters ${initial_filters}
    wistron_bmcweb_logout
    [Return]  ${initial_filters}

wistron_bmcweb_CheckLoginWebUI
	[Arguments]  ${user_id}
                Launch_Browser_And_Login_GUI    john${user_id}  johnjohnjohnjohn
                Wait_Until_Page_Contains    Dashboard    timeout=${BROWSER_CONNECTION_TIMEOUT}
                Close_All_Browsers



wistron_bmcweb_account_remove
	
	        wistron_bmcweb_login
        go to   ${url_users}
        Wait Until Element Is Not Visible    ${xpath_processing_image}    timeout=${BROWSER_PROCESSING_TIMEOUT}

        FOR  ${user_id}  IN RANGE  4  12
#       ${user_id}   set variable   4
                ${xpath_clear_user_button}  set variable   ${empty}
                ${xpath_clear_user_button}  set variable   ${xpath_clear_user}/div[${user_id}]/div/div/a/i

#               Log_To_Console    ${xpath_clear_user_button}
                Wait_Until_Element_Is_Not_Visible    ${xpath_processing_image}    timeout=${BROWSER_PROCESSING_TIMEOUT}

                ${verify1}=  Run_Keyword_And_Return_Status  Page_Should_Contain_Element   ${xpath_clear_user_button}
#               Log_To_Console    verify1 ${verify1}
                IF  '${verify1}'=='True'
                        ${verify2}=  Run_Keyword_And_Return_Status  Click_Element   ${xpath_clear_user_button}
                        IF  '${verify2}'=='True'
                                Log_To_Console    verify2 ${verify2}
                                Handle Alert
                        END
                END
        END
	wistron_bmcweb_logout


wistron_bmcweb_ClickClearLogButton
       Click_Element    ${xpath_clear_log_button}
       Handle_Alert
       Wait Until Element Is Not Visible    ${xpath_processing_image}    timeout=${BROWSER_PROCESSING_TIMEOUT}


wistron_bmcweb_ExpectClearLog
    ${irow}    set Variable    [1]
    ${resp}=    Get_Text    ${xpath_IPMI_Event_Log_1}
    Log_To_Console   resp ${resp}
    Should Contain    ${resp}     ${ClearLog}


wistron_bmcweb_CheckSensor
	[Arguments]  @{sensor_check_list}

        wistron_bmcweb_login
        GO TO    ${url_sensors}
        Wait_Until_Element_Is_Not_Visible   ${xpath_processing_image}   timeout=${BROWSER_PROCESSING_TIMEOUT}

        FOR  ${sensor_name}  IN  @{sensor_check_list}
                Log_To_Console  sensor_name ${sensor_name}
#                Log_To_Console  sensor_name_1 ${sensor_name}[1]
                Page_Should_Contain  ${sensor_name}
        END
    	wistron_bmcweb_logout

