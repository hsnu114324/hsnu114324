*** Variables ***
${SPIFlash_First_Image}	1
${SPIFlash_Both_Image}	3
${update_target_bmc}    0x1

*** Keywords ***
wistron_yafu_updatebmc
        [Arguments]     ${bmc_update_firmware_image}
#        ${output}=   OperatingSystem.Run   ${local_path}/${Utility_folder_path}/Yafuflash -nw -ip ${BMC_IP} -u ${IPMI_USERNAME} -p ${IPMI_PASSWORD} -fb -ieo -mse ${SPIFlash_First_Image} -d ${update_target_bmc} ${local_path}/${Image_folder_path}/${bmc_update_firmware_image} 2>&1 | tee log_yafu_updatebmc.txt
        ${output}=   OperatingSystem.Run   ${local_path}/${Utility_folder_path}/Yafuflash -nw -ip ${BMC_IP} -u ${IPMI_USERNAME} -p ${IPMI_PASSWORD} -fb -ieo ${local_path}/${Image_folder_path}/${bmc_update_firmware_image} 2>&1 | tee log_yafu_updatebmc.txt
        Log_To_Console  ${output}

wistron_yafu_updatebios
        [Arguments]     ${bios_update_firmware_image}
        ${output}=   OperatingSystem.Run   ${local_path}/${Script_folder_path}/marco_bios_update_yafu.sh ${local_path}/${Utility_folder_path}/Yafuflash ${BMC_IP} ${IPMI_USERNAME} ${IPMI_PASSWORD} ${local_path}/${Image_folder_path}/${bios_update_firmware_image}
        Log_To_Console  ${output}


