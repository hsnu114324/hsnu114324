*** Variables ***
${Interface_LAN}		1
${board_type_interposer}	interposer       
${board_type_fanout}		fanout       
${Re-timer_number}		0
${cpld_type_mb}			0
${cpld_type_switch}		1
${cpld_type_fanout}		2


*** Keywords ***

wistron_ipmi_CheckChassisPowerStatus
    ${output}=    Run External IPMI Standard Command    chassis power status
    [Return]    ${output}

Expect Chassis Power Status
    [Arguments]    ${expect_power_status}
    ${output}=    Run External IPMI Standard Command    chassis power status
    Should Contain    ${output}    Chassis Power is ${expect_power_status}


wistron_ipmi_PowerOn
    Run External IPMI Standard Command    chassis power on
    Wait Until Keyword Succeeds    ${POWERSTATUS_CHECK_TIMEOUT}    ${POWERSTATUS_CHECK_RETRY_TIMEOUT}    Expect Chassis Power Status    on

wistron_ipmi_PowerOff
    Run External IPMI Standard Command    chassis power off
    Wait Until Keyword Succeeds    ${POWERSTATUS_CHECK_TIMEOUT}    ${POWERSTATUS_CHECK_RETRY_TIMEOUT}    Expect Chassis Power Status    off

wistron_ipmi_PowerCycle
    Run External IPMI Standard Command    chassis power cycle  

wistron_ipmi_PowerHardReset
    Run External IPMI Standard Command    chassis power reset 

wistron_ipmi_PowerSoftShutdown
    Run External IPMI Standard Command    chassis power soft 





wistron_ipmi_WaitPowerOn
        [Documentation]
        [Tags]
        Wait Until Keyword Succeeds    ${POWERSTATUS_CHECK_TIMEOUT}    ${POWERSTATUS_CHECK_RETRY_TIMEOUT}    Expect Chassis Power Status    on


wistron_ipmi_WaitPowerOff
        [Documentation]
        [Tags]
        Wait Until Keyword Succeeds    ${POWERSTATUS_CHECK_TIMEOUT}    ${POWERSTATUS_CHECK_RETRY_TIMEOUT}    Expect Chassis Power Status    off




wistron_ipmi_FanSetManual
    Run External IPMI Raw Command    0x3c 0x73 0x1


wistron_ipmi_FanSet
	[Arguments]	${fan_target_pwm}
    Run External IPMI Raw Command    0x3c 0x74 ${fan_target_pwm}


wistron_ipmi_CheckRotorSpeed
	[Arguments]    ${inlet_rotor_minimum}    ${inlet_rotor_maximum}    ${outlet_rotor_minimum}    ${outlet_rotor_maximum}
    ${output}=    Run External IPMI Standard Command    sensor list
    ${sensor_list}=    Split String    ${output}    \n
    FOR    ${i}    IN    @{sensor_list}
        ${sensor_data}=    Split String    ${i}    |
        ${sensor_match}=    Get Regexp Matches    ${sensor_data}[0]    SPD_FAN_DUT\\d{1}_R
        IF    ${sensor_match}
		Log_To_Console   1 ==> ${outlet_rotor_minimum} ${sensor_data}[1] ${outlet_rotor_maximum}
#		Log_To_Console   1 ${i}
        	Should Be True    ${sensor_data}[1] > ${outlet_rotor_minimum}
        	Should Be True    ${sensor_data}[1] < ${outlet_rotor_maximum}

	END
	${sensor_match}=    Get Regexp Matches    ${sensor_data}[0]    SPD_FAN_DUT\\d{1}_F
    	IF    ${sensor_match}
		Log_To_Console   2 ==> ${inlet_rotor_minimum} ${sensor_data}[1] ${inlet_rotor_maximum}
#		Log_To_Console   2 ${i}
   		Should Be True    ${sensor_data}[1] > ${inlet_rotor_minimum}
    		Should Be True    ${sensor_data}[1] < ${inlet_rotor_maximum}
    	END
    END




wistron_ipmi_FanGetDuty
	[Arguments]    ${inlet_rotor_minimum}    ${inlet_rotor_maximum}    ${outlet_rotor_minimum}    ${outlet_rotor_maximum}
    Wait Until Keyword Succeeds    ${FAN_CHECK_TIMEOUT}    ${FAN_CHECK_RETRY_TIMEOUT}    wistron_ipmi_CheckRotorSpeed    ${inlet_rotor_minimum}    ${inlet_rotor_maximum}    ${outlet_rotor_minimum}    ${outlet_rotor_maximum}



wistron_ipmi_FanSetAuto
    Run External IPMI Raw Command    0x3c 0x73 0x0


wistron_ipmi_GetMBCpldVersion
	${output}=    Run External IPMI Raw Command    0x3c 0x0f 0x00
    @{split_list}=    Split String    ${output}    
	Log_To_Console   split_list 2 ${split_list}[2]
    ${cpld_version_major}	Set Variable   ${split_list}[2]	
	Log_To_Console  cpld info: ${output}
	Log_To_Console  target cpld version: ${cpld_version_major}
    [Return]	${cpld_version_major} 	


wistron_ipmi_GetFanoutCpldVersion
	${output}=    Run External IPMI Raw Command    0x3c 0x0f 0x03
    @{split_list}=    Split String    ${output}    
	Log_To_Console   split_list 2 ${split_list}[2]
    ${cpld_version_major}	Set Variable   ${split_list}[2]	
	Log_To_Console  cpld info: ${output}
	Log_To_Console  target cpld version: ${cpld_version_major}
    [Return]	${cpld_version_major} 	


wistron_ipmi_GetSwitchCpldVersion
	${output}=    Run External IPMI Raw Command    0x3c 0x0f 0x02
    @{split_list}=    Split String    ${output}    
	Log_To_Console   split_list 2 ${split_list}[2]
    ${cpld_version_major}	Set Variable   ${split_list}[2]	
	Log_To_Console  cpld info: ${output}
	Log_To_Console  target cpld version: ${cpld_version_major}
    [Return]	${cpld_version_major} 	





wistron_ipmi_GetBiosVersion
	${output}=    Run External IPMI Raw Command    0x30 0x81 0x1 0xa8 0x20 0x0 0x80
    @{split_list}=    Split String    ${output}    
	Log_To_Console   split_list 2 ${split_list}[2]
    ${bios_version_major}	Set Variable   ${split_list}[2]	
	Log_To_Console  bios info: ${output}
	Log_To_Console  target bios version: ${bios_version_major}
    [Return]	${bios_version_major} 	


wistron_ipmi_GetBmcVersion
	${output}=    Run External IPMI Standard Command    mc info
    ${split_list}=    Split String    ${output}    \n
    ${split_data1}=    Split String    ${split_list}[2]    :
    ${split_data1_list}=    Split String    ${split_data1}[1]    .
    ${split_data2}=    Split String    ${split_list}[19]   x

    ${bmc_version_major}	Set Variable   ${split_data1_list}[0]	
    ${bmc_version_minor}	Set Variable   ${split_data1_list}[1]
    ${bmc_version_patch}	Set Variable   ${split_data2}[1]
    Log_To_Console 		bmc_version_major ${bmc_version_major}
    Log_To_Console 		bmc_version_minor ${bmc_version_minor}
    Log_To_Console 		bmc_version_minor ${bmc_version_patch}
    [Return]	${bmc_version_major} 	${bmc_version_minor} 	${bmc_version_patch}

#    ${bmc_version}		Set Variable   ${bmc_version_major}.${bmc_version_minor}.${bmc_version_patch}
#    Log_To_Console 		bmc_version ${bmc_version}
#    [Return]    ${bmc_version}




wistron_ipmi_CheckNetworkInterface
	[Arguments]   ${BmcVersion_minor}
	Log_To_Console  BmcVersion ${BmcVersion_minor}
	${device_id}=    Run External IPMI Raw Command    0x06 0x01
	Log_To_Console  device_id ${device_id}
    Should Match Regexp    ${device_id}    ^\\s\\w{2}\\s\\w{2}\\s\\w{2}\\s${BmcVersion_minor}\\s\\w{2}\\s\\w{2}\\s\\w{2}\\s\\w{2}\\s\\w{2}\\s\\w{2}\\s\\w{2}\\s\\w{2}\\s\\w{2}\\s\\w{2}\\s\\w{2}    msg="reversion not match"
	

wistron_ipmi_CheckUserConfiguration
	[Arguments]  ${initial_userlist}
	Log_To_Console  initial_userlist ${initial_userlist}
    ${userlist}=    Run External IPMI Standard Command    user list
    Should Be Equal As Strings    ${initial_userlist}    ${userlist}

wistron_ipmi_updatebios
	[Arguments]     ${bios_update_firmware_image}
	${output}=   OperatingSystem.Run   ${local_path}/${Script_folder_path}/marco_bios_update_ipmi.sh ${BMC_IP} ${IPMI_USERNAME} ${IPMI_PASSWORD} ${local_path}/${Image_folder_path}/${bios_update_firmware_image}
	Log_To_Console  ${output}


wistron_ipmi_updatecpld_mb
	[Arguments]     ${cpld_update_firmware_image}
	${output}=   OperatingSystem.Run    ${local_path}/${Script_folder_path}/marco_UT20_CpldUpdate.sh -H ${BMC_IP} -U ${IPMI_USERNAME} -P ${IPMI_PASSWORD} -I ${Interface_LAN} -s ${cpld_type_mb} -f ${local_path}/${Image_folder_path}/${cpld_update_firmware_image}
	Log_To_Console  ${output}

wistron_ipmi_updatecpld_switch
	[Arguments]     ${cpld_update_firmware_image}
	${output}=   OperatingSystem.Run    ${local_path}/${Script_folder_path}/marco_UT20_CpldUpdate.sh -H ${BMC_IP} -U ${IPMI_USERNAME} -P ${IPMI_PASSWORD} -I ${Interface_LAN} -s ${cpld_type_switch} -f ${local_path}/${Image_folder_path}/${cpld_update_firmware_image}
	Log_To_Console  ${output}

wistron_ipmi_updatecpld_fanout
	[Arguments]     ${cpld_update_firmware_image}
	${output}=   OperatingSystem.Run    ${local_path}/${Script_folder_path}/marco_UT20_CpldUpdate.sh -H ${BMC_IP} -U ${IPMI_USERNAME} -P ${IPMI_PASSWORD} -I ${Interface_LAN} -s ${cpld_type_fanout} -f ${local_path}/${Image_folder_path}/${cpld_update_firmware_image}
	Log_To_Console  ${output}




wistron_ipmi_updateinterposer
	[Arguments]  ${board_type}  ${Re-timer_number}    ${interposer_update_firmware_image}
	${output}=   OperatingSystem.Run   ${local_path}/${Script_folder_path}/marco_UT20_RetimerUpdate.sh -I ${Interface_LAN} -H ${BMC_IP} -U ${IPMI_USERNAME} -P ${IPMI_PASSWORD} -s ${board_type_fanout} -n ${Re-timer_number} -f ${local_path}/${Image_folder_path}/${interposer_update_firmware_image}
	Log_To_Console  ${output}

wistron_ipmi_GetInterposerVersion
	[Arguments]  ${board_type}  ${Re-timer_number}
        IF    '${board_type}'=='${board_type_fanout}'
#		Log_To_Console   fanout 0x3${Re-timer_number}
    		${output}=  Run External IPMI Raw Command    0x3c 0x0f 0x3${Re-timer_number}
#		Log_To_Console   ${output}
	END
        IF    '${board_type}'=='${board_type_interposer}'
#		Log_To_Console   interposer 0x4${Re-timer_number}
    		${output}=  Run External IPMI Raw Command    0x3c 0x0f 0x4${Re-timer_number}
#		Log_To_Console   ${output}
	END
    	[Return]  ${output}


wistron_ipmi_ExpectInterposerVersion
	[Arguments]  ${board_type}  ${Re-timer_number}  ${interposer_version}
	Log_To_Console  expect interposer version : ${interposer_version}
	${output}=  wistron_ipmi_GetInterposerVersion	${board_type}  ${Re-timer_number}
	Log_To_Console   ${output}
	@{split_list}=    Split String    ${output}    
#	Log_To_Console   split_list 2 ${split_list}[2]
	${target_version}	Set Variable   ${split_list}[2]	
		
	Should Contain    ${target_version}    ${interposer_version}	





wistron_ipmi_Get_initial_userlist
    ${output}=    Run External IPMI Standard Command    user list
    ${initial_userlist}=  Set Variable  ${output}
	Log_To_Console  initial_userlist ${initial_userlist}
    [Return]  ${initial_userlist}


wistron_ipmi_fullsel
        FOR     ${i}    IN RANGE        3000
                ${output}=  Run External IPMI Raw Command    0xa 0x44 0x1 0x0 0x02 0x0 0x0 0x0 0x0 0x20 0x0 0x4 0x1 0x22 0x9 0x80 0x2 0xff
                Log_To_Console  ${output}
        END



















wistron_ipmi_SetUserName
	[Arguments]   ${user_id}
                ${output}=   Run_External_IPMI_Standard_Command    user set name ${user_id} john${user_id}
                Log_To_Console   1. ${output}

wistron_ipmi_SetUserPassword
	[Arguments]   ${user_id}
                ${output}=   Run_External_IPMI_Standard_Command    user set password ${user_id} johnjohnjohnjohn
                Log_To_Console   2. ${output}

wistron_ipmi_SetChannelAccess
	[Arguments]   ${user_id}
		${output}=    OperatingSystem.Run           ipmitool -I lanplus -H ${BMC_IP} -U admin -P admin channel setaccess 1 ${user_id} callin=on ipmi=on link=on privilege=4
                Log_To_Console   3. ${output}


wistron_ipmi_EnableUser
	[Arguments]   ${user_id}
                ${output}=   Run_External_IPMI_Standard_Command    user enable ${user_id}
                Log_To_Console   4. ${output}

wistron_ipmi_GetAdminPrivilege
	[Arguments]   ${user_id}
	${output}=    OperatingSystem.Run           ipmitool -I lanplus -H ${BMC_IP} -U john${user_id} -P johnjohnjohnjohn raw 0x06 0x01 -L administrator
               Log_To_Console   6. ${output}



wistron_ipmi_GetOperatorPrivilege
	[Arguments]   ${user_id}
	${output}=    OperatingSystem.Run           ipmitool -I lanplus -H ${BMC_IP} -U john${user_id} -P johnjohnjohnjohn raw 0x06 0x01 -L operator
               Log_To_Console   7. ${output}



wistron_ipmi_GetuserPrivilege
	[Arguments]   ${user_id}
	${output}=    OperatingSystem.Run           ipmitool -I lanplus -H ${BMC_IP} -U john${user_id} -P johnjohnjohnjohn raw 0x06 0x01 -L user
               Log_To_Console   8. ${output}



wistron_ipmi_CheckSensor
	[Arguments]	@{sensor_check_list}
        ${resp}=        Run External IPMI Standard Command    sdr elist all
        @{List}         Split String    ${resp}         ${\n}
    FOR    ${sensor_name}    IN    @{sensor_check_list}
        Log_To_Console  sensor_name ${sensor_name}
#        Log_To_Console  sensor_name_1 ${sensor_name}[1]
        Should Contain    ${resp}    ${sensor_name}    msg="sdr elist doesn't cotain ${sensor_name}"    values=False
    END



wistron_ipmi_CommandPowerON
    Run External IPMI Standard Command    chassis power on
    Wait Until Keyword Succeeds    ${POWERSTATUS_CHECK_TIMEOUT}    ${POWERSTATUS_CHECK_RETRY_TIMEOUT}    Expect Chassis Power Status    on

wistron_ipmi_ CommandPowerOFF
    Run External IPMI Standard Command    chassis power off
    Wait Until Keyword Succeeds    ${POWERSTATUS_CHECK_TIMEOUT}    ${POWERSTATUS_CHECK_RETRY_TIMEOUT}    Expect Chassis Power Status    off

