*** Variables ***
@{sensor_data}  @{EMPTY}
@{assign_data}  @{EMPTY}
@{result_data}  @{EMPTY}
@{excel_list}  @{EMPTY}
@{excel_list_0}  @{EMPTY}

*** Keywords ***


post_request_queryshiftscheduletime

    [Arguments]     ${schedule_type}   ${i}  


#    ${base_url}=  set variable   http://10.201.52.149
#    ${channel_url}=  set variable  /QuestWebApi4Dms/QuestGetSID/GetSID
    ${base_url}=  set variable   https://pnstest.post.gov.tw/LI.DPAPI
    ${channel_url}=  set variable  /api/QueryShiftScheduleTime

    create session  deleteemail    ${base_url}

    #Create a dynamic messageId
    ${rand_MessageID}=  generate random string  5  [NUMBERS]

#    ${SOAP_XML}=   set variable  {"QUEST_SID":[{"Q_SID":"08FBAXbGiyX"},{"Q_SID":"08FBAXbGiyY"},{"Q_SID":"08FMWPmJXkj"},{"Q_SID":"08FMWPmJXkk"}]}
#    ${SOAP_XML}=   set variable  {"ScheduleType": "WD"}   
#    ${SOAP_XML}=   set variable  {"ScheduleType": "H1"}   
    ${SOAP_XML}=   set variable  {"ScheduleType": "${schedule_type}"}   
    log  ${SOAP_XML}
    ${SOAP_XML_UTF8}=  evaluate   '${SOAP_XML}'.encode("utf-8")
    log  ${SOAP_XML_UTF8}

    ${request_header}=    create dictionary    Content-Type=application/json; charset=utf-8  X-ClientId=test  X-TxnDatetime=20240521094100  X-TxnNo=001
    ${SAVE_Response}=    Post Request    deleteemail    ${channel_url}    headers=${request_header}    data=${SOAP_XML_UTF8}

    log    ${SAVE_Response.content}



#                json_results = '[{"name": "Alice", "age": 25}, {"name": "Bob", "age": 30}]' 
 
                ${list_of_dicts}=  evaluate  json.loads('[${SAVE_Response.content}]') 
                log  ${list_of_dicts}

#                ${data_value}=  Get Dictionary Items  ${list_of_dicts[0]}
#                log  ${data_value}
#
#                ${data_value}=  Get Dictionary Items  ${list_of_dicts[0]["Data"]}
#                log  ${data_value}
#
#                ${data_value}=  Get From Dictionary  ${list_of_dicts[0]["Data"]}  QUERY_CNT  
#                log  ${data_value}
#
#                @{data_value}=  Get slice from list  ${list_of_dicts[0]["Data"]["RESPONDENT"]}
#                log  ${data_value}
#
#                ${data_value}=  Get Dictionary Items  ${list_of_dicts[0]["Data"]["RESPONDENT"][1]}
#                log  ${data_value}
#
#                ${data_value}=  Get From Dictionary  ${list_of_dicts[0]["Data"]["RESPONDENT"][1]}  Q_SID
#                log  ${data_value}
#


                ${data_value}=  Get Dictionary Items  ${list_of_dicts[0]}
                log  ${data_value}
                log  ${data_value}[0]
                log  ${data_value}[1]
                log  ${data_value}[1][0]

                ${data_value}=  Get slice from list  ${list_of_dicts[0]["ListInfo"]}
                log  ${data_value}
                log  ${data_value}[0]
                log  ${data_value}[0][OffInfo]

                ${data_value}=  Get Dictionary Items  ${list_of_dicts[0]["ListInfo"][0]}  
                log  ${data_value}

                ${data_value}=  Get slice from list   ${list_of_dicts[0]["ListInfo"][0]["OffInfo"]}  
                log  ${data_value}
                ${length_of_OffInfo}=  get length  ${data_value}

                ${i-2}=  evaluate  ${i} - 2
                    

                ${data_value}=  Get Dictionary Items  ${list_of_dicts[0]["ListInfo"][0]["OffInfo"][${i-2}]}  
                log  ${data_value}
                log  ${data_value}[0]
                log  ${data_value}[1]
                log  ${data_value}[2]
                log  ${data_value}[3]

                ${data_value}=  Get From Dictionary    ${list_of_dicts[0]["ListInfo"][0]["OffInfo"][${i-2}]}  OffNo 
                log  ${data_value}

                ${data_value}=  Get From Dictionary    ${list_of_dicts[0]["ListInfo"][0]["OffInfo"][${i-2}]}  SchInfo 
                log  ${data_value}


                ${data_value}=  Get slice from list    ${list_of_dicts[0]["ListInfo"][0]["OffInfo"][${i-2}]["SchInfo"]}
                log  ${data_value}

                ${length}=  Get length  ${data_value}

                ${data_value}=  Get Dictionary Items   ${list_of_dicts[0]["ListInfo"][0]["OffInfo"][${i-2}]["SchInfo"][0]}
                log  ${data_value}

                ${data_value}=  Get From Dictionary    ${list_of_dicts[0]["ListInfo"][0]["OffInfo"][${i-2}]["SchInfo"][0]}  ETime
                log  ${data_value}


                ${data_value2}=  Get From Dictionary   ${list_of_dicts[0]["ListInfo"][0]["OffInfo"][${i-2}]}  ZIP3
                log  ${data_value2}

                ${data_value3}=  Get From Dictionary   ${list_of_dicts[0]["ListInfo"][0]["OffInfo"][${i-2}]}  OffNo
                log  ${data_value3}


                ${data_value4_list}=  Get Slice From List    ${list_of_dicts[0]["ListInfo"][0]["OffInfo"][${i-2}]["SchInfo"]}  
                log  ${data_value4_list}
                ${length}=  Get length  ${data_value4_list}
                ${5+length}=  evaluate  5 + ${length}

#                FOR  ${j}  IN RANGE  5  ${5+length}
                FOR  ${j}  IN RANGE  5  9

                    ${j-5}=  evaluate  ${j} - 5
                    IF  ${j-5} < ${length}

                        ${data_value_${j}_S}=  Get From Dictionary    ${list_of_dicts[0]["ListInfo"][0]["OffInfo"][${i-2}]["SchInfo"][${j-5}]}  STime
                        log  ${data_value_${j}_S}

                        ${data_value_${j}_E}=  Get From Dictionary    ${list_of_dicts[0]["ListInfo"][0]["OffInfo"][${i-2}]["SchInfo"][${j-5}]}  ETime
                        log  ${data_value_${j}_E}

                    ELSE

                        ${data_value_${j}_S}=  set variable  0000
                        log  ${data_value_${j}_S}

                        ${data_value_${j}_E}=  set variable  0000
                        log  ${data_value_${j}_E}


                    END
                END

                ${data_value1}=  set variable  1
#                @{list2}=  Create List  ${data_value1}   ${data_value2}  ${data_value3}  ${data_value_5_S}  ${data_value_5_E}  ${data_value_6_S}  ${data_value_6_E}  ${data_value_7_S}  ${data_value_7_E}  ${data_value_8_S}  ${data_value8_E}  
                @{list2}=  Create List   ${data_value2}  ${data_value3}  ${data_value_5_S}  ${data_value_5_E}  ${data_value_6_S}  ${data_value_6_E}  ${data_value_7_S}  ${data_value_7_E}  ${data_value_8_S}  ${data_value8_E}  

                log  ${list2}







	[Return]  ${list2}

