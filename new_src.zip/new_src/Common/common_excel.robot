*** Variables ***
@{sensor_data}  @{EMPTY}
@{assign_data}  @{EMPTY}
@{result_data}  @{EMPTY}
@{excel_list}  @{EMPTY}
@{excel_list_0}  @{EMPTY}

*** Keywords ***

wistron_excel_getdata
    [Arguments] 	${excel_file_name}  ${sheet_name}
    [Documentation]    Load sensor list file and prepare list
    Log_To_Console   excel_file_name : ${excel_file_name}
    Log_To_Console   sheet_name : ${sheet_name}

	${new_sheet_name} =	Replace String Using Regexp	${sheet_name}	( )	\\ \  	count=1
	Log_To_Console  string ${new_sheet_name}

	${output}=   OperatingSystem.Run   python3 ${local_path}/${Script_folder_path}/excel_remove_strike.py ${local_path}/${Excel_folder_path}/${excel_file_name} ${new_sheet_name}

    Log_To_Console   excel_python_script_output : ${output}

    Open Excel Document    filename=${local_path}/${Excel_folder_path}/${excel_file_name}   doc_id=doc1
	Get Sheet   ${sheet_name}	
    ${WEB_GUI_list}=    Read Excel Column    1
    ${list_count} =    Get length    ${WEB_GUI_list}
	Log_To_Console  list_count ${list_count}

#    ${sensor_data}  Create list  ${EMPTY}
#	Log_To_Console  sensor_data ${sensor_data}

    FOR    ${i}    IN RANGE    4    ${list_count}
		${a1}=	Read Excel Cell	row_num=${i}	col_num=3

		IF  "${a1}" != "None"
		Append To List   ${sensor_data}   ${a1}
#		Log_To_Console  a1 ${a1}
		END
    END

#	Log_To_Console  sensor_data ${sensor_data}

	${sensor_check_list}=  Set Variable  ${sensor_data}
#	Log_To_Console  sensor_data ${sensor_check_list}
	[Return]  ${sensor_check_list}





wistron_excel_getdata_for_luna
    [Arguments] 	${excel_file_name}  ${sheet_name}
    [Documentation]    Load sensor list file and prepare list
    Log_To_Console   excel_file_name : ${excel_file_name}
    Log_To_Console   sheet_name : ${sheet_name}

	${new_sheet_name} =	Replace String Using Regexp	${sheet_name}	( )	\\ \  	count=1
	Log_To_Console  string ${new_sheet_name}

	${output}=   OperatingSystem.Run   python3 ${local_path}/${Script_folder_path}/excel_remove_strike.py ${local_path}/${Excel_folder_path}/${excel_file_name} ${new_sheet_name}

    Log_To_Console   excel_python_script_output : ${output}

    Open Excel Document    filename=${local_path}/${Excel_folder_path}/${excel_file_name}   doc_id=doc1
	Get Sheet   ${sheet_name}	
    ${WEB_GUI_list}=    Read Excel Column    1
    ${list_count} =    Get length    ${WEB_GUI_list}
	Log_To_Console  list_count ${list_count}

#    ${sensor_data}  Create list  ${EMPTY}
#	Log_To_Console  sensor_data ${sensor_data}

    FOR    ${i}    IN RANGE    3    ${list_count}
		${a1}=	Read Excel Cell	row_num=${i}	col_num=2

		IF  "${a1}" != "None"
		Append To List   ${sensor_data}   ${a1}
#		Log_To_Console  a1 ${a1}
		END
    END

#	Log_To_Console  sensor_data ${sensor_data}

	${sensor_check_list}=  Set Variable  ${sensor_data}
#	Log_To_Console  sensor_data ${sensor_check_list}
	[Return]  ${sensor_check_list}



post_excel_getdata_for_pns
    [Arguments] 	${excel_file_name}  ${sheet_name}
    [Documentation]    Load sensor list file and prepare list
    Log_To_Console   excel_file_name : ${excel_file_name}
    Log_To_Console   sheet_name : ${sheet_name}

	${new_sheet_name} =	Replace String Using Regexp	${sheet_name}	( )	\\ \  	count=1
	Log_To_Console  string ${new_sheet_name}

#	${output}=   OperatingSystem.Run   python3 ${local_path}/${Script_folder_path}/excel_remove_strike.py ${local_path}/${Excel_folder_path}/${excel_file_name} ${new_sheet_name}

#    Log_To_Console   excel_python_script_output : ${output}

    Open Excel Document    filename=${local_path}/${Excel_folder_path}/${excel_file_name}   doc_id=doc1
	Get Sheet   ${sheet_name}	
    ${WEB_GUI_list}=    Read Excel Column    1
    ${list_count} =    Get length    ${WEB_GUI_list}
	Log_To_Console  list_count ${list_count}

#    ${sensor_data}  Create list  ${EMPTY}
#	Log_To_Console  sensor_data ${sensor_data}

#    FOR    ${i}    IN RANGE    3    ${list_count}
#		${a1}=	Read Excel Cell	row_num=${i}	col_num=2

#		IF  "${a1}" != "None"
#		Append To List   ${sensor_data}   ${a1}
#		Log_To_Console  a1 ${a1}
#		END
#    END

#	Log_To_Console  sensor_data ${sensor_data}

	${a1}=	Read Excel Cell	row_num=2	col_num=1
	Append To List   ${sensor_data}   ${a1}

	${a1}=	Read Excel Cell	row_num=2	col_num=2
	Append To List   ${sensor_data}   ${a1}

	${a1}=	Read Excel Cell	row_num=2	col_num=3
	Append To List   ${sensor_data}   ${a1}



#	Log_To_Console  sensor_data ${sensor_data}
	[Return]  ${sensor_data}







post_excel_getdata_for_ezpost
    [Arguments] 	${excel_file_name}  ${sheet_name}
    [Documentation]    Load sensor list file and prepare list
    Log_To_Console   excel_file_name : ${excel_file_name}
    Log_To_Console   sheet_name : ${sheet_name}

	${new_sheet_name} =	Replace String Using Regexp	${sheet_name}	( )	\\ \  	count=1
	Log_To_Console  string ${new_sheet_name}

#	${output}=   OperatingSystem.Run   python3 ${local_path}/${Script_folder_path}/excel_remove_strike.py ${local_path}/${Excel_folder_path}/${excel_file_name} ${new_sheet_name}

#    Log_To_Console   excel_python_script_output : ${output}
    Log_To_Console   filename=.\\${Excel_folder_path}\\${excel_file_name}

#    Open Excel Document    filename=${local_path}/${Excel_folder_path}/${excel_file_name}   doc_id=doc1
    Open Excel Document    filename=.\\${Excel_folder_path}\\${excel_file_name}   doc_id=doc1
	Get Sheet   ${sheet_name}	
    ${WEB_GUI_list}=    Read Excel Column    1
    ${list_count} =    Get length    ${WEB_GUI_list}
	Log_To_Console  list_count ${list_count}

#    ${sensor_data}  Create list  ${EMPTY}
#	Log_To_Console  sensor_data ${sensor_data}


    FOR     ${elem}    IN    @{sensor_data}
        Remove values from list    ${sensor_data}    ${elem}
    END



    FOR    ${i}    IN RANGE    2    ${list_count}+1
		${a1}=	Read Excel Row	row_num=${i}	

		IF  "${a1}" != "None"
		Append To List   ${sensor_data}   ${a1}
		Log_To_Console  a1 ${a1}
		END
    END

    Close Current Excel Document
	Log_To_Console  sensor_data ${sensor_data}
	[Return]  ${sensor_data}








post_excel_getdata_for_state_machine
    [Arguments] 	${excel_file_name}  ${sheet_name}
    [Documentation]    Load sensor list file and prepare list
    Log    ${excel_file_name}
    Log    ${sheet_name}

	${new_sheet_name} =	Replace String Using Regexp	${sheet_name}	( )	\\ \  	count=1
	Log_To_Console  string ${new_sheet_name}

#	${output}=   OperatingSystem.Run   python3 ${local_path}/${Script_folder_path}/excel_remove_strike.py ${local_path}/${Excel_folder_path}/${excel_file_name} ${new_sheet_name}

#    Log_To_Console   excel_python_script_output : ${output}
#    Log_To_Console   filename=.\\${Excel_folder_path}\\${excel_file_name}

    Open Excel Document    filename=./${Excel_folder_path}/${excel_file_name}   doc_id=doc1
#    Open Excel Document    filename=${local_path}/${Excel_folder_path}/${excel_file_name}   doc_id=doc1
#    Open Excel Document    filename=.\\${Excel_folder_path}\\${excel_file_name}   doc_id=doc1
	Get Sheet   ${sheet_name}	
    ${WEB_GUI_list}=    Read Excel Column    1
    ${list_count} =    Get length    ${WEB_GUI_list}
	Log_To_Console  list_count ${list_count}

#    ${sensor_data}  Create list  ${EMPTY}
#	Log_To_Console  sensor_data ${sensor_data}
    FOR     ${elem}    IN    @{excel_list}
        Remove values from list    ${excel_list}    ${elem}
    END

    FOR    ${i}    IN RANGE    3    ${list_count}+1
		${a1}=	Read Excel Row	row_num=${i}	

		IF  "${a1}" != "None"
		Append To List   ${excel_list}   ${a1}
		Log             a1 ${a1}
		END
    END

    Close Current Excel Document
	Log         excel_list ${excel_list}
	[Return]  ${excel_list}








post_excel_getdata_for_state_machine_0
    [Arguments] 	${excel_file_name}  ${sheet_name}
    [Documentation]    Load sensor list file and prepare list
    Log_To_Console   excel_file_name : ${excel_file_name}
    Log_To_Console   sheet_name : ${sheet_name}

	${new_sheet_name} =	Replace String Using Regexp	${sheet_name}	( )	\\ \  	count=1
	Log_To_Console  string ${new_sheet_name}

#	${output}=   OperatingSystem.Run   python3 ${local_path}/${Script_folder_path}/excel_remove_strike.py ${local_path}/${Excel_folder_path}/${excel_file_name} ${new_sheet_name}

#    Log_To_Console   excel_python_script_output : ${output}
#    Log_To_Console   filename=.\\${Excel_folder_path}\\${excel_file_name}

    Open Excel Document    filename=./${Excel_folder_path}/${excel_file_name}   doc_id=doc1
#    Open Excel Document    filename=${local_path}/${Excel_folder_path}/${excel_file_name}   doc_id=doc1
#    Open Excel Document    filename=.\\${Excel_folder_path}\\${excel_file_name}   doc_id=doc1
	Get Sheet   ${sheet_name}	
    ${WEB_GUI_list}=    Read Excel Column    1
    ${list_count} =    Get length    ${WEB_GUI_list}
	Log_To_Console  list_count ${list_count}

#    ${excel_list_0}  Create list  ${EMPTY}
#	Log  sensor_data ${excel_list_0}
    FOR     ${elem}    IN    @{excel_list_0}
        Remove values from list    ${excel_list_0}    ${elem}
    END

#    FOR    ${i}    IN RANGE    2    ${list_count}+1
		${a1}=	Read Excel Row	row_num=2	

		IF  "${a1}" != "None"
		Append To List   ${excel_list_0}   ${a1}
		Log              a1 ${a1}
		END
#    END

    Close Current Excel Document
	Log         excel_list_0 ${excel_list_0}
	[Return]  ${excel_list_0}













































































post_excel_getdata_for_assign
    [Arguments] 	${assigner_no}  ${assign_excel_file_name}  ${sheet_name}
    [Documentation]    Load sensor list file and prepare list
    Log_To_Console   assign_excel_file_name : ${assign_excel_file_name}
    Log_To_Console   sheet_name : ${sheet_name}

	${new_sheet_name} =	Replace String Using Regexp	${sheet_name}	( )	\\ \  	count=1
	Log_To_Console  string ${new_sheet_name}

#	${output}=   OperatingSystem.Run   python3 ${local_path}/${Script_folder_path}/excel_remove_strike.py ${local_path}/${Excel_folder_path}/${excel_file_name} ${new_sheet_name}

#    Log_To_Console   excel_python_script_output : ${output}
#    Log_To_Console   filename=.\\${Excel_folder_path}\\${excel_file_name}

    Open Excel Document    filename=./${Excel_folder_path}/${assign_excel_file_name}   doc_id=doc1
#    Open Excel Document    filename=${local_path}/${Excel_folder_path}/${excel_file_name}   doc_id=doc1
#    Open Excel Document    filename=.\\${Excel_folder_path}\\${excel_file_name}   doc_id=doc1
	Get Sheet   ${sheet_name}	
    ${WEB_GUI_list}=    Read Excel Column    1
    ${list_count} =    Get length    ${WEB_GUI_list}
	Log_To_Console  list_count ${list_count}

#    ${assign_data}  Create list  ${EMPTY}
#	Log_To_Console  assign_data ${assign_data}

    FOR    ${i}    IN RANGE    2    ${list_count}+1
		${a1}=	Read Excel Row	row_num=${i}	

		Log  $a1[0] ${a1}[0]
		Log  assigner_no ${assigner_no}
		IF  ${a1}[0] == ${assigner_no}
#			Append To List   ${assign_data}  ${a1}[0] ${a1}[1] ${a1}[2] ${a1}[3]
			Append To List   ${assign_data}  ${a1}
			Log              assign_data ${assign_data}
		END
    END

    Close Current Excel Document
    Log  assign_data ${assign_data}
	Log_To_Console  assign_data ${assign_data}
	[Return]  ${assign_data}






post_excel_result2result_XO
    [Arguments] 	${result}
		Log  result ${result}
		IF  "${result}" == "PASS"
			${result_XO}=  set variable  O  
		ELSE IF  "${result}" == "FAIL"
			${result_XO}=  set variable  X
		END 
	[Return]  ${result_XO}




post_excel_CheckPnsResult
    [Arguments] 	${stage_pre}  ${stage_post}  ${result}  ${result_excel_file_name}  ${sheet_name}
    [Documentation]    Load sensor list file and prepare list
    Log   result : ${result}
    Log   result_excel_file_name : ${result_excel_file_name}
    Log   sheet_name : ${sheet_name}

	${new_sheet_name} =	Replace String Using Regexp	${sheet_name}	( )	\\ \  	count=1
	Log  new_sheet_name : ${new_sheet_name}

#	${output}=   OperatingSystem.Run   python3 ${local_path}/${Script_folder_path}/excel_remove_strike.py ${local_path}/${Excel_folder_path}/${excel_file_name} ${new_sheet_name}

#    Log_To_Console   excel_python_script_output : ${output}
#    Log_To_Console   filename=.\\${Excel_folder_path}\\${excel_file_name}

    Open Excel Document    filename=./${Excel_folder_path}/${result_excel_file_name}   doc_id=doc1
#    Open Excel Document    filename=${local_path}/${Excel_folder_path}/${excel_file_name}   doc_id=doc1
#    Open Excel Document    filename=.\\${Excel_folder_path}\\${excel_file_name}   doc_id=doc1
	Get Sheet   ${sheet_name}	
    ${WEB_GUI_list}=    Read Excel Column    1
    ${list_count} =    Get length    ${WEB_GUI_list}
	Log_To_Console  list_count ${list_count}

#    ${assign_data}  Create list  ${EMPTY}
#	Log_To_Console  assign_data ${assign_data}

	${a0}=	Read Excel Row	row_num=0
    FOR    ${i}    IN RANGE    2    ${list_count}+1
		${a1}=	Read Excel Row	row_num=${i}	

		Log  $a1[0] ${a1}[0]
		Log  stage_pre ${stage_pre}
		IF  "${a1}[0]" == "${stage_pre}"

			Log  a1 ${a1}

            ${column_count} =    Get length    ${a1}
			FOR    ${j}    IN RANGE    1    ${list_count}
			    ${value}=  set variable  ${a0}[${j}]
				Log  $a0[j] ${value}
				Log  ${a0}[${j}]
				Log  $a0[j] ${a0}[${j}]
				Log  stage_post ${stage_post}
				IF  "${a0}[${j}]" == "${stage_post}"
#					Log  result ${result}
#				    IF  "${result}" == "PASS"
#				    	${result_XO}=  set variable  O  
#				    ELSE IF  "${result}" == "FAIL"
#				        ${result_XO}=  set variable  X
#				    END 
					${result_should_be}=  set variable  ${a1}[${j}]
					Log  result_should_be ${result_should_be}
#					Log  result_XO ${result_XO}
#					IF  "${result_should_be}" == "${result_XO}"
#						${result_data}=  set variable  PASS
#					ELSE
#						${result_data}=  set variable  FAIL
#					END
				END
			END
		END
    END

	Log  result_should_be ${result_should_be}
	Log  result ${result}
	${result_XO}=  post_excel_result2result_XO  ${result}
	Log  result_XO ${result_XO}
	IF  "${result_should_be}" == "${result_XO}"
		${result_data}=  set variable  PASS
	ELSE
		${result_data}=  set variable  FAIL
	END


    Close Current Excel Document
    Log  result_data ${result_data}
	Log_To_Console  result_data ${result_data}
#	Run Keyword If    '${result_data}'=='FAIL'    FAIL    msg=${message}
	Run Keyword If    '${result_data}'=='FAIL'    FAIL    
	[Return]  ${result_data}











post_excel_compareexcel_old
#    [Arguments] 	${stage_pre}  ${stage_post}  ${result}  ${result_excel_file_name}  ${sheet_name}
    [Arguments] 	${source_excel_file}  ${source_excel_sheetname}  ${download_excel_file}  ${download_excel_sheetname}
    [Documentation]    Load sensor list file and prepare list
#    Log   result : ${result}
    Log   source_excel_file : ${source_excel_file}
    Log   source_excel_sheetname : ${source_excel_sheetname}
    Log   download_excel_file : ${download_excel_file}
    Log   download_excel_sheetname : ${download_excel_sheetname}

#	${new_sheet_name} =	Replace String Using Regexp	${sheet_name}	( )	\\ \  	count=1
#	Log  new_sheet_name : ${new_sheet_name}


    ${doc1}=  Open Excel Document    filename=./${Excel_folder_path}/${source_excel_file}   doc_id=doc1
    ${doc2}=  Open Excel Document    filename=./${Excel_folder_path}/${download_excel_file}   doc_id=doc2


	Get Sheet   ${download_excel_sheetname}	
    ${WEB_GUI_list}=    Read Excel Column    1
    ${list_count} =    Get length    ${WEB_GUI_list}
	Log_To_Console  list_count ${list_count}

        Connect To Database Using Custom Params  sqlite3  database="./test.db"

	${a0}=	Read Excel Row	row_num=0
    FOR    ${i}    IN RANGE    2    ${list_count}+1
#    FOR    ${i}    IN RANGE    2    1
                Switch Current Excel Document  ${doc1}
		${a1}=	Read Excel Row	row_num=${i}	


	        Log  a1 ${a1}
		Log  $a1[0] ${a1}[0]
		Log  $a1[1] ${a1}[1]
                IF   ${a1}[1] == None
                     BREAK
                END 

#                ${output}=    Execute Sql String    UPDATE source_schedule SET TIME_DLV_STA_1 = '${a1}[4]', TIME_DLV_END_1 = '${a1}[5]', TIME_DLV_STA_2 = '${a1}[6]', TIME_DLV_END_2 = '${a1}[7]', TIME_DLV_STA_3 = '${a1}[8]', TIME_DLV_END_3 = '${a1}[9]', TIME_DLV_STA_4 = '${a1}[10]', TIME_DLV_END_4 = '${a1}[11]' where ZIP3 = ${a1}[1]

                log  ${a1}
		${str_a1_0}=  Convert To String  ${a1}[0]
		${str_a1_1}=  Convert To String  ${a1}[1]
		${str_a1_2}=  Convert To String  ${a1}[2]


		${str_a1_4}=  Convert To String  ${a1}[4]
                ${a1_4_split}=    Split String    ${str_a1_4}    :
                ${splite_a1_4}=    Split String    ${str_a1_4}    :
		${str_a1_4}=   set variable     ${splite_a1_4}[0]${splite_a1_4}[1]

		${str_a1_5}=  Convert To String  ${a1}[5]
                ${a1_5_split}=    Split String    ${str_a1_5}    :
                ${splite_a1_5}=    Split String    ${str_a1_5}    :
		${str_a1_5}=   set variable     ${splite_a1_5}[0]${splite_a1_5}[1]

		${str_a1_6}=  Convert To String  ${a1}[6]
                ${a1_6_split}=    Split String    ${str_a1_6}    :
                ${splite_a1_6}=    Split String    ${str_a1_6}    :
		${str_a1_6}=   set variable     ${splite_a1_6}[0]${splite_a1_6}[1]

		${str_a1_7}=  Convert To String  ${a1}[7]
                ${a1_7_split}=    Split String    ${str_a1_7}    :
                ${splite_a1_7}=    Split String    ${str_a1_7}    :
		${str_a1_7}=   set variable     ${splite_a1_7}[0]${splite_a1_7}[1]

		${str_a1_8}=  Convert To String  ${a1}[8]
                ${a1_8_split}=    Split String    ${str_a1_8}    :
                ${splite_a1_8}=    Split String    ${str_a1_8}    :
		${str_a1_8}=   set variable     ${splite_a1_8}[0]${splite_a1_8}[1]


		${str_a1_9}=  Convert To String  ${a1}[9]
                ${a1_9_split}=    Split String    ${str_a1_9}    :
                ${splite_a1_9}=    Split String    ${str_a1_9}    :
		${str_a1_9}=   set variable     ${splite_a1_9}[0]${splite_a1_9}[1]

		${str_a1_10}=  Convert To String  ${a1}[10]
                ${a1_10_split}=    Split String    ${str_a1_10}    :
                ${splite_a1_10}=    Split String    ${str_a1_10}    :
		${str_a1_10}=   set variable     ${splite_a1_10}[0]${splite_a1_10}[1]

		${str_a1_11}=  Convert To String  ${a1}[11]
                ${a1_11_split}=    Split String    ${str_a1_11}    :
                ${splite_a1_11}=    Split String    ${str_a1_11}    :
		${str_a1_11}=   set variable     ${splite_a1_11}[0]${splite_a1_11}[1]



                @{list1}=  Create List  ${str_a1_0}  ${str_a1_2}  ${str_a1_1}  ${str_a1_4}  ${str_a1_5}  ${str_a1_6}  ${str_a1_7}  ${str_a1_8}  ${str_a1_9}  ${str_a1_10}  ${str_a1_11}      

                log  ${list1}


	        Log  list1 ${list1}
		Log  $list1[0] ${list1}[0]
		Log  $list1[1] ${list1}[1]
                IF   ${list1}[1] == None
                     BREAK
                END 

                ${output}=    Execute Sql String    UPDATE source_schedule SET TIME_DLV_STA_1 = '${list1}[3]', TIME_DLV_END_1 = '${list1}[4]', TIME_DLV_STA_2 = '${list1}[5]', TIME_DLV_END_2 = '${list1}[6]', TIME_DLV_STA_3 = '${list1}[7]', TIME_DLV_END_3 = '${list1}[8]', TIME_DLV_STA_4 = '${list1}[9]', TIME_DLV_END_4 = '${list1}[10]' where ZIP3 = ${list1}[2] AND BOFF_NO = ${list1}[1]



                Switch Current Excel Document  ${doc2}
                ${b1}=  Read Excel Row  row_num=${i}  

	        Log  b1 ${b1}
		Log  $b1[0] ${b1}[0]
		Log  $b1[1] ${b1}[1]
                IF   ${b1}[1] == None
                     BREAK
                END 


                log  ${b1}
		${str_b1_0}=  Convert To String  ${b1}[0]
		${str_b1_1}=  Convert To String  ${b1}[1]
		${str_b1_2}=  Convert To String  ${b1}[2]

		${str_b1_4}=  Convert To String  ${b1}[4]
		${str_b1_5}=  Convert To String  ${b1}[5]
		${str_b1_6}=  Convert To String  ${b1}[6]
		${str_b1_7}=  Convert To String  ${b1}[7]
		${str_b1_8}=  Convert To String  ${b1}[8]
		${str_b1_9}=  Convert To String  ${b1}[9]
		${str_b1_10}=  Convert To String  ${b1}[10]
		${str_b1_11}=  Convert To String  ${b1}[11]




                IF  '${str_b1_4}' == ''
                    ${str_b1_4}=  set variable  0000
                END

                IF  '${str_b1_5}' == ''
                    ${str_b1_5}=  set variable  0000
                END

                IF  '${str_b1_6}' == ''
                    ${str_b1_6}=  set variable  0000
                END

                IF  '${str_b1_7}' == ''
                    ${str_b1_7}=  set variable  0000
                END

                IF  '${str_b1_8}' == ''
                    ${str_b1_8}=  set variable  0000
                END

                IF  '${str_b1_9}' == ''
                    ${str_b1_9}=  set variable  0000
                END

                IF  '${str_b1_10}' == ''
                    ${str_b1_10}=  set variable  0000
                END

                IF  '${str_b1_11}' == ''
                    ${str_b1_11}=  set variable  0000
                END








                ${output}=    Execute Sql String    UPDATE download_schedule SET TIME_DLV_STA_1 = '${str_b1_4}', TIME_DLV_END_1 = '${str_b1_5}', TIME_DLV_STA_2 = '${str_b1_6}', TIME_DLV_END_2 = '${str_b1_7}', TIME_DLV_STA_3 = '${str_b1_8}', TIME_DLV_END_3 = '${str_b1_9}', TIME_DLV_STA_4 = '${str_b1_10}', TIME_DLV_END_4 = '${str_b1_11}' where ZIP3 = ${b1}[1] AND BOFF_NO = ${b1}[2]


#                Lists Should Be Equal  ${a1}  ${b1}

    END


    FOR    ${i}    IN RANGE    2    ${list_count}+1
		${a1}=	Read Excel Row	row_num=${i}	

	        Log  a1 ${a1}
		Log  $a1[0] ${a1}[0]
		Log  $a1[0] ${a1}[1]
                IF   ${a1}[1] == None
                     BREAK
                END 

####################################





                ${list1}=    Query    SELECT * FROM source_schedule WHERE ZIP3 = ${a1}[1] AND BOFF_NO = ${a1}[2]    
                Log  ${list1}

                ${list2}=    Query    SELECT * FROM download_schedule WHERE ZIP3 = ${a1}[1] AND BOFF_NO = ${a1}[2]    
                Log  ${list2}


                Lists Should Be Equal  ${list1}  ${list2}

    END




    Disconnect From Database

#    Close Current Excel Document
    Close All Excel Documents
    Log  result_data ${result_data}
	Log_To_Console  result_data ${result_data}
#	Run Keyword If    '${result_data}'=='FAIL'    FAIL    msg=${message}
	Run Keyword If    '${result_data}'=='FAIL'    FAIL    
	[Return]  ${result_data}












post_excel_compareexcel
#    [Arguments] 	${stage_pre}  ${stage_post}  ${result}  ${result_excel_file_name}  ${sheet_name}
    [Arguments] 	${source_excel_file}  ${source_excel_sheetname}  ${download_excel_file}  ${download_excel_sheetname}
    [Documentation]    Load sensor list file and prepare list
#    Log   result : ${result}
    Log   source_excel_file : ${source_excel_file}
    Log   source_excel_sheetname : ${source_excel_sheetname}
    Log   download_excel_file : ${download_excel_file}
    Log   download_excel_sheetname : ${download_excel_sheetname}

#	${new_sheet_name} =	Replace String Using Regexp	${sheet_name}	( )	\\ \  	count=1
#	Log  new_sheet_name : ${new_sheet_name}


    ${doc1}=  Open Excel Document    filename=./${Excel_folder_path}/${source_excel_file}   doc_id=doc1
    ${doc2}=  Open Excel Document    filename=./${Excel_folder_path}/${download_excel_file}   doc_id=doc2


	Get Sheet   ${download_excel_sheetname}	
    ${WEB_GUI_list}=    Read Excel Column    1
    ${list_count} =    Get length    ${WEB_GUI_list}
	Log_To_Console  list_count ${list_count}

        Connect To Database Using Custom Params  sqlite3  database="./test.db"

	${a0}=	Read Excel Row	row_num=0
    FOR    ${i}    IN RANGE    2    ${list_count}+1
#    FOR    ${i}    IN RANGE    2    1
                Switch Current Excel Document  ${doc1}
		${a1}=	Read Excel Row	row_num=${i}	


	        Log  a1 ${a1}
		Log  $a1[0] ${a1}[0]
		Log  $a1[1] ${a1}[1]
                IF   ${a1}[1] == None
                     BREAK
                END 

#                ${output}=    Execute Sql String    UPDATE source_schedule SET TIME_DLV_STA_1 = '${a1}[4]', TIME_DLV_END_1 = '${a1}[5]', TIME_DLV_STA_2 = '${a1}[6]', TIME_DLV_END_2 = '${a1}[7]', TIME_DLV_STA_3 = '${a1}[8]', TIME_DLV_END_3 = '${a1}[9]', TIME_DLV_STA_4 = '${a1}[10]', TIME_DLV_END_4 = '${a1}[11]' where ZIP3 = ${a1}[1]

                log  ${a1}
		${str_a1_0}=  Convert To String  ${a1}[0]
		${str_a1_1}=  Convert To String  ${a1}[1]
		${str_a1_2}=  Convert To String  ${a1}[2]


		${str_a1_4}=  Convert To String  ${a1}[4]
#                ${a1_4_split}=    Split String    ${str_a1_4}    :
#                ${splite_a1_4}=    Split String    ${str_a1_4}    :
#		${str_a1_4}=   set variable     ${splite_a1_4}[0]${splite_a1_4}[1]

		${str_a1_5}=  Convert To String  ${a1}[5]
#                ${a1_5_split}=    Split String    ${str_a1_5}    :
#                ${splite_a1_5}=    Split String    ${str_a1_5}    :
#		${str_a1_5}=   set variable     ${splite_a1_5}[0]${splite_a1_5}[1]

		${str_a1_6}=  Convert To String  ${a1}[6]
#                ${a1_6_split}=    Split String    ${str_a1_6}    :
#                ${splite_a1_6}=    Split String    ${str_a1_6}    :
#		${str_a1_6}=   set variable     ${splite_a1_6}[0]${splite_a1_6}[1]

		${str_a1_7}=  Convert To String  ${a1}[7]
#                ${a1_7_split}=    Split String    ${str_a1_7}    :
#                ${splite_a1_7}=    Split String    ${str_a1_7}    :
#		${str_a1_7}=   set variable     ${splite_a1_7}[0]${splite_a1_7}[1]

		${str_a1_8}=  Convert To String  ${a1}[8]
#                ${a1_8_split}=    Split String    ${str_a1_8}    :
#                ${splite_a1_8}=    Split String    ${str_a1_8}    :
#		${str_a1_8}=   set variable     ${splite_a1_8}[0]${splite_a1_8}[1]


		${str_a1_9}=  Convert To String  ${a1}[9]
#                ${a1_9_split}=    Split String    ${str_a1_9}    :
#                ${splite_a1_9}=    Split String    ${str_a1_9}    :
#		${str_a1_9}=   set variable     ${splite_a1_9}[0]${splite_a1_9}[1]

		${str_a1_10}=  Convert To String  ${a1}[10]
#                ${a1_10_split}=    Split String    ${str_a1_10}    :
#                ${splite_a1_10}=    Split String    ${str_a1_10}    :
#		${str_a1_10}=   set variable     ${splite_a1_10}[0]${splite_a1_10}[1]

		${str_a1_11}=  Convert To String  ${a1}[11]
#                ${a1_11_split}=    Split String    ${str_a1_11}    :
#                ${splite_a1_11}=    Split String    ${str_a1_11}    :
#		${str_a1_11}=   set variable     ${splite_a1_11}[0]${splite_a1_11}[1]



                @{list1}=  Create List  ${str_a1_0}  ${str_a1_2}  ${str_a1_1}  ${str_a1_4}  ${str_a1_5}  ${str_a1_6}  ${str_a1_7}  ${str_a1_8}  ${str_a1_9}  ${str_a1_10}  ${str_a1_11}      

                log  ${list1}


	        Log  list1 ${list1}
		Log  $list1[0] ${list1}[0]
		Log  $list1[1] ${list1}[1]
                IF   ${list1}[1] == None
                     BREAK
                END 

                ${output}=    Execute Sql String    UPDATE source_schedule SET TIME_DLV_STA_1 = '${list1}[3]', TIME_DLV_END_1 = '${list1}[4]', TIME_DLV_STA_2 = '${list1}[5]', TIME_DLV_END_2 = '${list1}[6]', TIME_DLV_STA_3 = '${list1}[7]', TIME_DLV_END_3 = '${list1}[8]', TIME_DLV_STA_4 = '${list1}[9]', TIME_DLV_END_4 = '${list1}[10]' where ZIP3 = ${list1}[2] AND BOFF_NO = ${list1}[1]



                Switch Current Excel Document  ${doc2}
                ${b1}=  Read Excel Row  row_num=${i}  

	        Log  b1 ${b1}
		Log  $b1[0] ${b1}[0]
		Log  $b1[1] ${b1}[1]
                IF   ${b1}[1] == None
                     BREAK
                END 


                log  ${b1}
		${str_b1_0}=  Convert To String  ${b1}[0]
		${str_b1_1}=  Convert To String  ${b1}[1]
		${str_b1_2}=  Convert To String  ${b1}[2]

		${str_b1_4}=  Convert To String  ${b1}[4]
		${str_b1_5}=  Convert To String  ${b1}[5]
		${str_b1_6}=  Convert To String  ${b1}[6]
		${str_b1_7}=  Convert To String  ${b1}[7]
		${str_b1_8}=  Convert To String  ${b1}[8]
		${str_b1_9}=  Convert To String  ${b1}[9]
		${str_b1_10}=  Convert To String  ${b1}[10]
		${str_b1_11}=  Convert To String  ${b1}[11]




                IF  '${str_b1_4}' == ''
                    ${str_b1_4}=  set variable  0000
                END

                IF  '${str_b1_5}' == ''
                    ${str_b1_5}=  set variable  0000
                END

                IF  '${str_b1_6}' == ''
                    ${str_b1_6}=  set variable  0000
                END

                IF  '${str_b1_7}' == ''
                    ${str_b1_7}=  set variable  0000
                END

                IF  '${str_b1_8}' == ''
                    ${str_b1_8}=  set variable  0000
                END

                IF  '${str_b1_9}' == ''
                    ${str_b1_9}=  set variable  0000
                END

                IF  '${str_b1_10}' == ''
                    ${str_b1_10}=  set variable  0000
                END

                IF  '${str_b1_11}' == ''
                    ${str_b1_11}=  set variable  0000
                END








                ${output}=    Execute Sql String    UPDATE download_schedule SET TIME_DLV_STA_1 = '${str_b1_4}', TIME_DLV_END_1 = '${str_b1_5}', TIME_DLV_STA_2 = '${str_b1_6}', TIME_DLV_END_2 = '${str_b1_7}', TIME_DLV_STA_3 = '${str_b1_8}', TIME_DLV_END_3 = '${str_b1_9}', TIME_DLV_STA_4 = '${str_b1_10}', TIME_DLV_END_4 = '${str_b1_11}' where ZIP3 = ${b1}[1] AND BOFF_NO = ${b1}[2]


#                Lists Should Be Equal  ${a1}  ${b1}

    END


    FOR    ${i}    IN RANGE    2    ${list_count}+1
		${a1}=	Read Excel Row	row_num=${i}	

	        Log  a1 ${a1}
		Log  $a1[0] ${a1}[0]
		Log  $a1[0] ${a1}[1]
                IF   ${a1}[1] == None
                     BREAK
                END 

####################################





                ${list1}=    Query    SELECT * FROM source_schedule WHERE ZIP3 = ${a1}[1] AND BOFF_NO = ${a1}[2]    
                Log  ${list1}

                ${list2}=    Query    SELECT * FROM download_schedule WHERE ZIP3 = ${a1}[1] AND BOFF_NO = ${a1}[2]    
                Log  ${list2}


                Lists Should Be Equal  ${list1}  ${list2}

    END




    Disconnect From Database

#    Close Current Excel Document
    Close All Excel Documents
    Log  result_data ${result_data}
	Log_To_Console  result_data ${result_data}
#	Run Keyword If    '${result_data}'=='FAIL'    FAIL    msg=${message}
	Run Keyword If    '${result_data}'=='FAIL'    FAIL    
	[Return]  ${result_data}





post_excel_comparejson_old
#    [Arguments] 	${stage_pre}  ${stage_post}  ${result}  ${result_excel_file_name}  ${sheet_name}
    [Arguments]        ${schedule_type}  ${source_excel_file}  ${source_excel_sheetname}
    [Documentation]    Load sensor list file and prepare list
#    Log   result : ${result}
    Log   source_excel_file : ${source_excel_file}
    Log   source_excel_sheetname : ${source_excel_sheetname}

#	${new_sheet_name} =	Replace String Using Regexp	${sheet_name}	( )	\\ \  	count=1
#	Log  new_sheet_name : ${new_sheet_name}


    ${doc1}=  Open Excel Document    filename=./${Excel_folder_path}/${source_excel_file}   doc_id=doc1

    Switch Current Excel Document  ${doc1}

#	Get Sheet   ${source_excel_sheetname}	
    ${WEB_GUI_list}=    Read Excel Column    1
    ${list_count} =    Get length    ${WEB_GUI_list}
	Log_To_Console  list_count ${list_count}

        Connect To Database Using Custom Params  sqlite3  database="./test.db"

	${a0}=	Read Excel Row	row_num=0
    FOR    ${i}    IN RANGE    2    ${list_count}+1
		${a1}=	Read Excel Row	row_num=${i}	

	        Log  a1 ${a1}
		Log  $a1[0] ${a1}[0]
		Log  $a1[0] ${a1}[1]
                IF   ${a1}[1] == None
                     BREAK
                END 


#####################################


                log  ${a1}
		${str_a1_0}=  Convert To String  ${a1}[0]
		${str_a1_1}=  Convert To String  ${a1}[1]
		${str_a1_2}=  Convert To String  ${a1}[2]


		${str_a1_4}=  Convert To String  ${a1}[4]
                ${a1_4_split}=    Split String    ${str_a1_4}    :
                ${splite_a1_4}=    Split String    ${str_a1_4}    :
		${str_a1_4}=   set variable     ${splite_a1_4}[0]${splite_a1_4}[1]

		${str_a1_5}=  Convert To String  ${a1}[5]
                ${a1_5_split}=    Split String    ${str_a1_5}    :
                ${splite_a1_5}=    Split String    ${str_a1_5}    :
		${str_a1_5}=   set variable     ${splite_a1_5}[0]${splite_a1_5}[1]

		${str_a1_6}=  Convert To String  ${a1}[6]
                ${a1_6_split}=    Split String    ${str_a1_6}    :
                ${splite_a1_6}=    Split String    ${str_a1_6}    :
		${str_a1_6}=   set variable     ${splite_a1_6}[0]${splite_a1_6}[1]

		${str_a1_7}=  Convert To String  ${a1}[7]
                ${a1_7_split}=    Split String    ${str_a1_7}    :
                ${splite_a1_7}=    Split String    ${str_a1_7}    :
		${str_a1_7}=   set variable     ${splite_a1_7}[0]${splite_a1_7}[1]

		${str_a1_8}=  Convert To String  ${a1}[8]
                ${a1_8_split}=    Split String    ${str_a1_8}    :
                ${splite_a1_8}=    Split String    ${str_a1_8}    :
		${str_a1_8}=   set variable     ${splite_a1_8}[0]${splite_a1_8}[1]


		${str_a1_9}=  Convert To String  ${a1}[9]
                ${a1_9_split}=    Split String    ${str_a1_9}    :
                ${splite_a1_9}=    Split String    ${str_a1_9}    :
		${str_a1_9}=   set variable     ${splite_a1_9}[0]${splite_a1_9}[1]

		${str_a1_10}=  Convert To String  ${a1}[10]
                ${a1_10_split}=    Split String    ${str_a1_10}    :
                ${splite_a1_10}=    Split String    ${str_a1_10}    :
		${str_a1_10}=   set variable     ${splite_a1_10}[0]${splite_a1_10}[1]

		${str_a1_11}=  Convert To String  ${a1}[11]
                ${a1_11_split}=    Split String    ${str_a1_11}    :
                ${splite_a1_11}=    Split String    ${str_a1_11}    :
		${str_a1_11}=   set variable     ${splite_a1_11}[0]${splite_a1_11}[1]



                @{list1}=  Create List  ${str_a1_0}  ${str_a1_2}  ${str_a1_1}  ${str_a1_4}  ${str_a1_5}  ${str_a1_6}  ${str_a1_7}  ${str_a1_8}  ${str_a1_9}  ${str_a1_10}  ${str_a1_11}      

                log  ${list1}


	        Log  list1 ${list1}
		Log  $list1[0] ${list1}[0]
		Log  $list1[1] ${list1}[1]
                IF   ${list1}[1] == None
                     BREAK
                END 

                ${output}=    Execute Sql String    UPDATE source_schedule SET TIME_DLV_STA_1 = '${list1}[3]', TIME_DLV_END_1 = '${list1}[4]', TIME_DLV_STA_2 = '${list1}[5]', TIME_DLV_END_2 = '${list1}[6]', TIME_DLV_STA_3 = '${list1}[7]', TIME_DLV_END_3 = '${list1}[8]', TIME_DLV_STA_4 = '${list1}[9]', TIME_DLV_END_4 = '${list1}[10]' where ZIP3 = ${list1}[1] AND BOFF_NO = ${list1}[2]



#                Lists Should Be Equal  ${list1}  ${list2}

    END

	${a0}=	Read Excel Row	row_num=0
    FOR    ${i}    IN RANGE    2    ${list_count}+1
		${a1}=	Read Excel Row	row_num=${i}	

	        Log  a1 ${a1}
		Log  $a1[0] ${a1}[0]
		Log  $a1[0] ${a1}[1]
                IF   ${a1}[1] == None
                     BREAK
                END 

####################################

                ${list2}=  post_request_queryshiftscheduletime  ${schedule_type}  ${i}

                log  ${list2}

#                ${output}=    Execute Sql String    UPDATE json_schedule SET TIME_DLV_STA_1 = '${list2}[3]', TIME_DLV_END_1 = '${list2}[4]', TIME_DLV_STA_2 = '${list2}[5]', TIME_DLV_END_2 = '${list2}[6]', TIME_DLV_STA_3 = '${list2}[7]', TIME_DLV_END_3 = '${list2}[8]', TIME_DLV_STA_4 = '${list2}[9]', TIME_DLV_END_4 = '${list2}[10]' where ZIP3 = ${list2}[1]


                ${output}=    Query    SELECT * FROM source_schedule WHERE ZIP3 = ${list2}[0] AND BOFF_NO = ${list2}[1]   
                Log  ${output}
#                ${list1}=     Get Slice From List  ${output}[0]
                ${output0}=     Get Slice From List  ${output}[0]
#                ${list1}=     Create List  ${output0}[0]  ${output0}[1]  ${output0}[2]  ${output0}[3]  ${output0}[4]  ${output0}[5]  ${output0}[6]  ${output0}[7]  ${output0}[8]  ${output0}[9]  ${output0}[10]
                ${list1}=     Create List  ${output0}[1]  ${output0}[2]  ${output0}[3]  ${output0}[4]  ${output0}[5]  ${output0}[6]  ${output0}[7]  ${output0}[8]  ${output0}[9]  ${output0}[10]

                Lists Should Be Equal  ${list1}  ${list2}

    END



    Disconnect From Database


#    Close Current Excel Document
    Close All Excel Documents
    Log  result_data ${result_data}
	Log_To_Console  result_data ${result_data}
#	Run Keyword If    '${result_data}'=='FAIL'    FAIL    msg=${message}
	Run Keyword If    '${result_data}'=='FAIL'    FAIL    
	[Return]  ${result_data}






post_excel_comparejson
#    [Arguments] 	${stage_pre}  ${stage_post}  ${result}  ${result_excel_file_name}  ${sheet_name}
    [Arguments]        ${schedule_type}  ${source_excel_file}  ${source_excel_sheetname}
    [Documentation]    Load sensor list file and prepare list
#    Log   result : ${result}
    Log   source_excel_file : ${source_excel_file}
    Log   source_excel_sheetname : ${source_excel_sheetname}

#	${new_sheet_name} =	Replace String Using Regexp	${sheet_name}	( )	\\ \  	count=1
#	Log  new_sheet_name : ${new_sheet_name}


    ${doc1}=  Open Excel Document    filename=./${Excel_folder_path}/${source_excel_file}   doc_id=doc1

    Switch Current Excel Document  ${doc1}

#	Get Sheet   ${source_excel_sheetname}	
    ${WEB_GUI_list}=    Read Excel Column    1
    ${list_count} =    Get length    ${WEB_GUI_list}
	Log_To_Console  list_count ${list_count}

        Connect To Database Using Custom Params  sqlite3  database="./test.db"

	${a0}=	Read Excel Row	row_num=0
    FOR    ${i}    IN RANGE    2    ${list_count}+1
		${a1}=	Read Excel Row	row_num=${i}	

	        Log  a1 ${a1}
		Log  $a1[0] ${a1}[0]
		Log  $a1[0] ${a1}[1]
                IF   ${a1}[1] == None
                     BREAK
                END 


#####################################


                log  ${a1}
		${str_a1_0}=  Convert To String  ${a1}[0]
		${str_a1_1}=  Convert To String  ${a1}[1]
		${str_a1_2}=  Convert To String  ${a1}[2]


		${str_a1_4}=  Convert To String  ${a1}[4]
#                ${a1_4_split}=    Split String    ${str_a1_4}    :
#                ${splite_a1_4}=    Split String    ${str_a1_4}    :
#		${str_a1_4}=   set variable     ${splite_a1_4}[0]${splite_a1_4}[1]

		${str_a1_5}=  Convert To String  ${a1}[5]
#                ${a1_5_split}=    Split String    ${str_a1_5}    :
#                ${splite_a1_5}=    Split String    ${str_a1_5}    :
#		${str_a1_5}=   set variable     ${splite_a1_5}[0]${splite_a1_5}[1]

		${str_a1_6}=  Convert To String  ${a1}[6]
#                ${a1_6_split}=    Split String    ${str_a1_6}    :
#                ${splite_a1_6}=    Split String    ${str_a1_6}    :
#		${str_a1_6}=   set variable     ${splite_a1_6}[0]${splite_a1_6}[1]

		${str_a1_7}=  Convert To String  ${a1}[7]
#                ${a1_7_split}=    Split String    ${str_a1_7}    :
#                ${splite_a1_7}=    Split String    ${str_a1_7}    :
#		${str_a1_7}=   set variable     ${splite_a1_7}[0]${splite_a1_7}[1]

		${str_a1_8}=  Convert To String  ${a1}[8]
#                ${a1_8_split}=    Split String    ${str_a1_8}    :
#                ${splite_a1_8}=    Split String    ${str_a1_8}    :
#		${str_a1_8}=   set variable     ${splite_a1_8}[0]${splite_a1_8}[1]


		${str_a1_9}=  Convert To String  ${a1}[9]
#                ${a1_9_split}=    Split String    ${str_a1_9}    :
#                ${splite_a1_9}=    Split String    ${str_a1_9}    :
#		${str_a1_9}=   set variable     ${splite_a1_9}[0]${splite_a1_9}[1]

		${str_a1_10}=  Convert To String  ${a1}[10]
#                ${a1_10_split}=    Split String    ${str_a1_10}    :
#                ${splite_a1_10}=    Split String    ${str_a1_10}    :
#		${str_a1_10}=   set variable     ${splite_a1_10}[0]${splite_a1_10}[1]

		${str_a1_11}=  Convert To String  ${a1}[11]
#                ${a1_11_split}=    Split String    ${str_a1_11}    :
#                ${splite_a1_11}=    Split String    ${str_a1_11}    :
#		${str_a1_11}=   set variable     ${splite_a1_11}[0]${splite_a1_11}[1]



                @{list1}=  Create List  ${str_a1_0}  ${str_a1_2}  ${str_a1_1}  ${str_a1_4}  ${str_a1_5}  ${str_a1_6}  ${str_a1_7}  ${str_a1_8}  ${str_a1_9}  ${str_a1_10}  ${str_a1_11}      

                log  ${list1}


	        Log  list1 ${list1}
		Log  $list1[0] ${list1}[0]
		Log  $list1[1] ${list1}[1]
                IF   ${list1}[1] == None
                     BREAK
                END 

                ${output}=    Execute Sql String    UPDATE source_schedule SET TIME_DLV_STA_1 = '${list1}[3]', TIME_DLV_END_1 = '${list1}[4]', TIME_DLV_STA_2 = '${list1}[5]', TIME_DLV_END_2 = '${list1}[6]', TIME_DLV_STA_3 = '${list1}[7]', TIME_DLV_END_3 = '${list1}[8]', TIME_DLV_STA_4 = '${list1}[9]', TIME_DLV_END_4 = '${list1}[10]' where ZIP3 = ${list1}[1] AND BOFF_NO = ${list1}[2]



#                Lists Should Be Equal  ${list1}  ${list2}

    END

	${a0}=	Read Excel Row	row_num=0
    FOR    ${i}    IN RANGE    2    ${list_count}+1
		${a1}=	Read Excel Row	row_num=${i}	

	        Log  a1 ${a1}
		Log  $a1[0] ${a1}[0]
		Log  $a1[0] ${a1}[1]
                IF   ${a1}[1] == None
                     BREAK
                END 

####################################

                ${list2}=  post_request_queryshiftscheduletime  ${schedule_type}  ${i}

                log  ${list2}

#                ${output}=    Execute Sql String    UPDATE json_schedule SET TIME_DLV_STA_1 = '${list2}[3]', TIME_DLV_END_1 = '${list2}[4]', TIME_DLV_STA_2 = '${list2}[5]', TIME_DLV_END_2 = '${list2}[6]', TIME_DLV_STA_3 = '${list2}[7]', TIME_DLV_END_3 = '${list2}[8]', TIME_DLV_STA_4 = '${list2}[9]', TIME_DLV_END_4 = '${list2}[10]' where ZIP3 = ${list2}[1]


                ${output}=    Query    SELECT * FROM source_schedule WHERE ZIP3 = ${list2}[0] AND BOFF_NO = ${list2}[1]   
                Log  ${output}
#                ${list1}=     Get Slice From List  ${output}[0]
                ${output0}=     Get Slice From List  ${output}[0]
#                ${list1}=     Create List  ${output0}[0]  ${output0}[1]  ${output0}[2]  ${output0}[3]  ${output0}[4]  ${output0}[5]  ${output0}[6]  ${output0}[7]  ${output0}[8]  ${output0}[9]  ${output0}[10]
                ${list1}=     Create List  ${output0}[1]  ${output0}[2]  ${output0}[3]  ${output0}[4]  ${output0}[5]  ${output0}[6]  ${output0}[7]  ${output0}[8]  ${output0}[9]  ${output0}[10]

                Lists Should Be Equal  ${list1}  ${list2}

    END



    Disconnect From Database


#    Close Current Excel Document
    Close All Excel Documents
    Log  result_data ${result_data}
	Log_To_Console  result_data ${result_data}
#	Run Keyword If    '${result_data}'=='FAIL'    FAIL    msg=${message}
	Run Keyword If    '${result_data}'=='FAIL'    FAIL    
	[Return]  ${result_data}








post_excel_write 
    [Arguments] 	${excel_file_name}  ${sheet_name}  ${line_num}  ${parameter0}  ${parameter1}  ${parameter2}  ${parameter3}  ${parameter4}  ${parameter5}  ${parameter6} 
    [Documentation] 

#    Log   result : ${result}
    Log   ${excel_file_name}
    Log   ${sheet_name}
    Log   ${line_num}
    Log   ${parameter0}
    Log   ${parameter1}
    Log   ${parameter2}
    Log   ${parameter3}
    Log   ${parameter4}
    Log   ${parameter5}
    Log   ${parameter6}


	${output}=   OperatingSystem.Run   python ${local_path}\\${Script_folder_path}\\excel_write_line.py ${local_path}\\${Excel_folder_path}\\${excel_file_name} ${sheet_name} ${line_num} ${parameter0} ${parameter1} ${parameter2} ${parameter3} ${parameter4} ${parameter5} ${parameter6}





post_excel_write_for_linux 
    [Arguments] 	${excel_file_name}  ${sheet_name}  ${line_num}  ${parameter0}  ${parameter1}  ${parameter2}  ${parameter3}  ${parameter4}  ${parameter5}  ${parameter6} 
    [Documentation] 

#    Log   result : ${result}
    Log   ${excel_file_name}
    Log   ${sheet_name}
    Log   ${line_num}
    Log   ${parameter0}
    Log   ${parameter1}
    Log   ${parameter2}
    Log   ${parameter3}
    Log   ${parameter4}
    Log   ${parameter5}
    Log   ${parameter6}


	${output}=   OperatingSystem.Run   python3 Script/excel_write_line.py ${excel_file_name} ${sheet_name} ${line_num} ${parameter0} ${parameter1} ${parameter2} ${parameter3} ${parameter4} ${parameter5} ${parameter6}



