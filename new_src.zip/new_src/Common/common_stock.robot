*** keywords ***

stock_higlow9_genCsv



stock_kd_rsv
    [Arguments]  ${ii}  ${path_csv}
    Log  ${ii}
    Log_To_Console  path_Csv : ${path_csv}

    ${old_csv_content}=    Get File    stock_csv/${path_csv}    encoding=UTF-8-SIG    encoding_errors=strict
    @{list_csv_before_yesterday}=  Read Csv String To List  ${old_csv_content}
    ${list_csv_by_cnt}=    Get length    ${list_csv_before_yesterday}

    FOR  ${old_j}  IN RANGE  0  ${list_csv_by_cnt}  1

        ${s1_by_array}=  get_from_list  ${list_csv_before_yesterday}  ${old_j}

                IF  '${file_exists}' == 'False'
                    Copy File  lvr_landcsv/a_lvr_land_a_header.csv  591_csv/${ii}_lvr_land_a_gps_${s1_substring}[3:6]_${s2_substring}[4:7].csv
                END



            ${csv_string}=  set variable  ${empty}
            ${str_s1_by_array}=   Evaluate  ",".join(${s1_by_array})

            ${csv_string}=  set variable  ${str_s1_by_array}\n
            log  ${csv_string}

            Append To File   stock_csv/${csv_path}  ${csv_string}


    END




stock_kd_k
    [Arguments]  ${ii}  ${path_csv}
    Log  ${ii}
    Log_To_Console  path_Csv : ${path_csv}

    ${old_csv_content}=    Get File    stock_csv/${path_csv}    encoding=UTF-8-SIG    encoding_errors=strict
    @{list_csv_before_yesterday}=  Read Csv String To List  ${old_csv_content}
    ${list_csv_by_cnt}=    Get length    ${list_csv_before_yesterday}

    FOR  ${old_j}  IN RANGE  0  ${list_csv_by_cnt}  1

        ${s1_by_array}=  get_from_list  ${list_csv_before_yesterday}  ${old_j}

                IF  '${file_exists}' == 'False'
                    Copy File  lvr_landcsv/a_lvr_land_a_header.csv  591_csv/${ii}_lvr_land_a_gps_${s1_substring}[3:6]_${s2_substring}[4:7].csv
                END



            ${csv_string}=  set variable  ${empty}
            ${str_s1_by_array}=   Evaluate  ",".join(${s1_by_array})

            ${csv_string}=  set variable  ${str_s1_by_array}\n
            log  ${csv_string}

            Append To File   stock_csv/${csv_path}  ${csv_string}


    END







stock_DynamicDateRange
    [Arguments]  ${start_date}  ${end_date}
    Log_To_Console  ${start_date}
    Log  ${start_date}
    Log_To_Console  ${end_date}
    Log  ${end_date}
    ${date_range}=   finmind_GetDateRange   ${start_date}   ${end_date}
    FOR  ${date}  IN  @{date_range}
        Log  ${date} ~ ${date}
        Log_To_Console  ${date} ~ ${date}
    END




stock_GetDateRange
    [Arguments]  ${start_date}  ${end_date}

#    ${start_date}=    Set Variable    20230227
#    ${start_date}=    Convert To Integer    ${start_date1}
#    ${end_date}=    Set Variable    20230302
#    ${end_date}=    Convert To Integer    ${end_date1}

    Log_To_Console  ${start_date}
    Log  ${start_date}
    sleep  1s
    Log_To_Console  ${end_date}
    Log  ${end_date}
    sleep  1s

    ${start_date_obj}=  Convert_Date  ${start_date}	result_format=%Y-%m-%d    date_format=%Y%m%d
#    ${start_date_obj}=  Convert_Date  ${start_date}	result_format=%Y%m%d    date_format=%Y%m%d
	Log_To_Console  ${start_date_obj}
    ${end_date_obj}=    Convert_Date  ${end_date}	result_format=%Y-%m-%d    date_format=%Y%m%d
#    ${end_date_obj}=    Convert_Date  ${end_date}	result_format=%Y%m%d    date_format=%Y%m%d
	Log_To_Console  ${end_date_obj}
    ${date_obj_range}=      Create List  ${start_date_obj}
	Log_To_Console	date_obj_range ${date_obj_range}
    ${current_date}=    Set Variable  ${start_date}
	Log_To_Console	current_date ${current_date}
    WHILE  ${current_date} < ${end_date}
        ${next_date}=  Add_Time_To_Date  ${current_date}  1days  %Y%m%d
        ${next_date_obj}=  Add_Time_To_Date  ${current_date}  1days  %Y-%m-%d
	Log_To_Console  next_date ${next_date}
	Log_To_Console  next_date_obj ${next_date_obj}
        Append_To_List  ${date_obj_range}  ${next_date_obj}
        ${current_date}=  Set Variable  ${next_date}
    END
    [Return]  ${date_obj_range}



stock_set_output_close_list_i_j    
    [Arguments]  ${i}  ${j}  ${output_date_i}  ${number}  ${output_close_list_i_j}
        
        log  ${i} ${j} ${output_date_i} ${number} ${output_close_list_i_j}

        ${output_close_${i}_${j}_${output_date_i}}=  create list  ${number}
#        append to list  ${output_close_list_${i}_${j}}  ${output_close_${i}_${j}_${output_date_i}}
        append to list  ${output_close_list_i_j}  ${output_close_${i}_${j}_${output_date_i}}

    [Return]  ${output_close_list_i_j}


stock_set_output_trading_turnover_list_i_j    
    [Arguments]  ${i}  ${j}  ${output_date_i}  ${number}  ${output_trading_turnover_list_i_j}
        
        log  ${i} ${j} ${output_date_i} ${number} ${output_trading_turnover_list_i_j}

        ${output_trading_turnover_${i}_${j}_${output_date_i}}=  create list  ${number}
#        append to list  ${output_trading_turnover_list_${i}_${j}}  ${output_trading_turnover_${i}_${j}_${output_date_i}}
        append to list  ${output_trading_turnover_list_i_j}  ${output_trading_turnover_${i}_${j}_${output_date_i}}

    [Return]  ${output_trading_turnover_list_i_j}










#stock_set_sum_output_trading_turnover_i_list    
#    [Arguments]  ${i}  ${output_date_i}  ${sum_output_trading_turnover_i_list}
#
#
#    ${status}=  Run Keyword And Return Status  Variable Should Exist  ${sum_output_trading_turnover_${i}_${output_date_i}}
#     log  ${status}
#     IF  ${status} == ${FALSE}
#         ${sum_output_trading_turnover_${i}_${output_date_i}}=  Create List  0
#
#         append_to_list  ${sum_output_trading_turnover_i_list}  ${sum_output_trading_turnover_${i}_${output_date_i}}
#         log  ${sum_output_trading_turnover_i_list}
#     END   
#
#     log  sum_output_trading_turnover_${i}_${output_date_i}
#     log  ${sum_output_trading_turnover_${i}_${output_date_i}}
#
#    [Return]  ${sum_output_trading_turnover_i_list}


