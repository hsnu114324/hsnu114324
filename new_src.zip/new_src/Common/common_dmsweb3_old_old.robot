*** Variables ***
${xpath_DmsFrontEnd_username}                 xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div/div[1]/div[3]/div/div/div/div[2]/div/div[2]/input
${xpath_DmsFrontEnd_selectOffice}                 xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div/div[1]/div[3]/div/div/div/div[3]/div/div[2]/div[1]/div[1]
${xpath_DmsFrontEnd_selectOfficeOption}                 xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div/div[1]/div[3]/div/div/div/div[3]/div/div[2]/div[2]/div[2]/div
${xpath_DmsFrontEnd_password}                 xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div/div[1]/div[3]/div/div/div/div[4]/div[1]/div[2]/input
${xpath_DmsFrontEnd_enterbutton}              xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div/div[1]/div[4]/div[1]/button

${xpath_DmsFrontEnd_userID}              xpath=//*[@id="__nuxt"]/div/div[2]/div[1]/div[4]
${xpath_DmsFrontEnd_userID_logout}              xpath=//*[@id="__nuxt"]/div/div[2]/div[1]/div[4]/div/div[3]/div[2]/div[2]

${xpath_DmsFrontEndMenuButton}                xpath=//*[@id="__nuxt"]/div/div[2]/div[1]/div[1]/div[1]
${xpath_DmsFrontEndMenu_homepage}                xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[1]/div[2]/div[1]/a/div
${xpath_DmsFrontEndMenu_ListDR}         xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[1]/div[2]/div[5]/div/div[1]
${xpath_DmsFrontEndMenu_ListDR1}         xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[1]/div[2]/div[5]/div/div[2]/div/div[1]/div/div[1]
${xpath_DmsFrontEndMenu_ListDR1_8101}         xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[1]/div[2]/div[5]/div/div[2]/div/div[1]/div/div[2]/div/a[1]/div


${xpath_DmsFrontEndMenu_ListOP}         xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[1]/div[2]/div[3]/div/div[1]
${xpath_DmsFrontEndMenu_ListOP1}         xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[1]/div[2]/div[3]/div/div[2]/div/div[1]/div/div[1]
${xpath_DmsFrontEndMenu_ListOP1_2902}         xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[1]/div[2]/div[3]/div/div[2]/div/div[1]/div/div[2]/div/a[6]/div
${xpath_DmsFrontEndMenu_ListOP1_2900}         xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[1]/div[2]/div[3]/div/div[2]/div/div[1]/div/div[2]/div/a[5]/div
${xpath_DmsFrontEndMenu_ListOP1_2301}         xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[1]/div[2]/div[3]/div/div[2]/div/div[1]/div/div[2]/div/a[3]/div
${xpath_DmsFrontEndMenu_ListOP1_2300}         xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[1]/div[2]/div[3]/div/div[2]/div/div[1]/div/div[2]/div/a[2]/div
${xpath_DmsFrontEndMenu_ListOP1_2000}         xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[1]/div[2]/div[3]/div/div[2]/div/div[1]/div/div[2]/div/a[1]
${xpath_DmsFrontEndMenu_ListMM}         xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[1]/div[2]/div[9]/div/div[1]
${xpath_DmsFrontEndMenu_ListMM1}         xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[1]/div[2]/div[9]/div/div[2]/div/div/div/div[1]
${xpath_DmsFrontEndMenu_ListMM1_a100}         xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[1]/div[2]/div[9]/div/div[2]/div/div/div/div[2]/div/a[2]


${xpath_DmsFrontEndMenu_ListMM1_a100_BSC}                        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[1]/div/div/div/div/div/div/div/div/div[1]/div[2]/div
${xpath_DmsFrontEndMenu_ListMM1_a100_BSC_20OP}                   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[1]/div/div/div/div/div/div/div/div/div[2]/div/div[1]/div/div/div[1]/div[1]/div
${xpath_DmsFrontEndMenu_ListMM1_a100_BSC_20OP_1}                 xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[1]/div/div/div/div/div/div/div/div/div[2]/div/div[1]/div/div/div[2]/div/div[1]
${xpath_DmsFrontEndMenu_ListMM1_a100_BSC_20OP_3}                 xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[1]/div/div/div/div/div/div/div/div/div[2]/div/div[1]/div/div/div[2]/div/div[2]

${xpath_DmsFrontEndMenu_ListMM1_a100_BSC_DATE}                   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[2]/div[1]/div[2]/div[2]/div/div/div/div[1]/div[2]/div/div[2]/div[1]/input

${xpath_DmsFrontEndMenu_ListMM1_a100_BSC_TOUR_NO}                xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[2]/div[1]/div[2]/div[2]/div/div/div/div[2]/div[2]/div[2]/input

${xpath_DmsFrontEndMenu_ListMM1_a100_BSC_today_button}           xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[2]/div[1]/div[2]/div[2]/div/div/div/div[1]/div[3]/button

${xpath_DmsFrontEndMenu_ListMM1_a100_BSC_plus_button}            xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[2]/div[1]/div[2]/div[2]/div/div/div/div[2]/div[3]/button

${xpath_DmsFrontEndMenu_ListMM1_a100_BSC_save_button}            xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[2]/div[1]/div[2]/div[2]/div/div/div/div[3]/button[2]

 

${variable_xpath_nuxt_replace}    /html/body/div[5]/div[2]/div[2]


${xpath_DmsFrontEnd_2000_MList_letter_end_button}               xpath=${variable_xpath_nuxt_replace}/div/div/div/div/div/div[3]/button[2]

${xpath_DmsFrontEnd_2000_MList_letter_save_button}              xpath=${variable_xpath_nuxt_replace}/div/div/div/div/div/div[3]/button[1]




${xpath_DmsFrontEnd_2000_MList_letter_DST_OFFICE}               xpath=${variable_xpath_DmsFrontEnd_2000}/tr[2]/td/div/div[1]/input

${xpath_DmsFrontEnd_2000_MList_letter_VAL_DCL_AMT}              xpath=${variable_xpath_DmsFrontEnd_2000}/tr[1]/td[2]/div/div/input

${xpath_DmsFrontEnd_2000_MList_letter_MAIL_NO}                  xpath=${variable_xpath_DmsFrontEnd_2000}/tr[1]/td[1]/div/div/input




${xpath_DmsFrontEnd_2902_MList_new_letter_button}               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[3]/div[2]/div[1]/div/button[1]

${xpath_DmsFrontEnd_2000_MList_new_letter_button}               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[2]/div[3]/div[2]/div[1]/div/button

#${xpath_DmsFrontEnd_2000_MList_login_button}                   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[2]/td/span/button[3]

${xpath_DmsFrontEnd_2000_checkout_button}                       xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[2]/td/span/button[4]

${xpath_DmsFrontEnd_2000MList_NO}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[2]/div[2]/div/div/div[1]/div[4]/div[2]/input

${xpath_DmsFrontEnd_2000MList_NO_M1A0}                               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[2]/div[2]/div/div/div[1]/div[6]/div[2]/input

${xpath_DmsFrontEnd_2000MLIST_MESSAGE}                          xpath=${variable_xpath_nuxt_replace}/div/div/div/div/div/div[1]/span

1                                                                     

${xpath_DmsFrontEnd_2000MLIST_STATE}                            xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[1]/td[9]





${xpath_DmsFrontEnd_2301_MList_letter_end_button}               xpath=${variable_xpath_nuxt_replace}/div/div/div/div/div/div[3]/button[2]

${xpath_DmsFrontEnd_2301_MList_letter_save_button}              xpath=${variable_xpath_nuxt_replace}/div/div/div/div/div/div[3]/button[1]



${xpath_DmsFrontEnd_2301_MList_letter_MAIL_NO}                  xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[2]/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr/td[1]/div/div/input


${xpath_DmsFrontEnd_2301_MList_new_letter_button}               xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[2]/div[3]/div[2]/div[1]/div/button[1]





${variable_xpath_DmsFrontEnd_2300}                     /html/body/div[5]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody

${variable_xpath_DmsFrontEnd_2300IN_TYPEoption}        ${variable_xpath_DmsFrontEnd_2300}/tr[1]/td[1]/div/div

${xpath_DmsFrontEnd_2300IN_TYPEoption1}          xpath=${variable_xpath_DmsFrontEnd_2300IN_TYPEoption}/div[2]/div[1]/div

${xpath_DmsFrontEnd_2300IN_TYPEoption2}          xpath=${variable_xpath_DmsFrontEnd_2300IN_TYPEoption}/div[2]/div[2]/div

${xpath_DmsFrontEnd_2300IN_TYPEoption3}          xpath=${variable_xpath_DmsFrontEnd_2300IN_TYPEoption}/div[2]/div[3]/div

${xpath_DmsFrontEnd_2300IN_TYPEoption4}          xpath=${variable_xpath_DmsFrontEnd_2300IN_TYPEoption}/div[2]/div[4]/div

${xpath_DmsFrontEnd_2300IN_TYPEoption5}          xpath=${variable_xpath_DmsFrontEnd_2300IN_TYPEoption}/div[2]/div[5]/div

${xpath_DmsFrontEnd_2300IN_TYPEoption6}          xpath=${variable_xpath_DmsFrontEnd_2300IN_TYPEoption}/div[2]/div[6]/div

${xpath_DmsFrontEnd_2300IN_TYPEoption7}          xpath=${variable_xpath_DmsFrontEnd_2300IN_TYPEoption}/div[2]/div[7]/div

${xpath_DmsFrontEnd_2300IN_TYPEoption8}          xpath=${variable_xpath_DmsFrontEnd_2300IN_TYPEoption}/div[2]/div[8]/div

${xpath_DmsFrontEnd_2300IN_TYPEoption9}          xpath=${variable_xpath_DmsFrontEnd_2300IN_TYPEoption}/div[2]/div[9]/div

${xpath_DmsFrontEnd_2300IN_TYPEoption11}          xpath=${variable_xpath_DmsFrontEnd_2300IN_TYPEoption}/div[2]/div[10]/div

${xpath_DmsFrontEnd_2300IN_TYPEoption11}          xpath=${variable_xpath_DmsFrontEnd_2300IN_TYPEoption}/div[2]/div[11]/div

${xpath_DmsFrontEnd_2300IN_TYPEoption16}          xpath=${variable_xpath_DmsFrontEnd_2300IN_TYPEoption}/div[2]/div[12]/div

${xpath_DmsFrontEnd_2300IN_TYPEoption168}          xpath=${variable_xpath_DmsFrontEnd_2300IN_TYPEoption}/div[2]/div[13]/div

${xpath_DmsFrontEnd_2300IN_TYPEoption169}          xpath=${variable_xpath_DmsFrontEnd_2300IN_TYPEoption}/div[2]/div[14]/div

${xpath_DmsFrontEnd_2300IN_TYPE}          xpath=${variable_xpath_DmsFrontEnd_2300IN_TYPEoption}/div[1]






${xpath_DmsFrontEnd_2300MLST_TYPEoption1}          xpath=${variable_xpath_DmsFrontEnd_2300}/tr[1]/td[2]/div/div/div[2]/div[1]/div

${xpath_DmsFrontEnd_2300MLST_TYPEoption0}          xpath=${variable_xpath_DmsFrontEnd_2300}/tr[1]/td[2]/div/div/div[2]/div[2]/div

${xpath_DmsFrontEnd_2300MLST_TYPE}                 xpath=${variable_xpath_DmsFrontEnd_2300}/tr[1]/td[2]/div/div/div[1]/div[1]

${xpath_DmsFrontEnd_2300MLIST_NO}                  xpath=${variable_xpath_DmsFrontEnd_2300}/tr[2]/td[1]/div/div/input

${xpath_DmsFrontEnd_2300ORG_OFFICE}                xpath=${variable_xpath_DmsFrontEnd_2300}/tr[2]/td[2]/div/div/input

${xpath_DmsFrontEnd_2300DST_OFFICE}                xpath=${variable_xpath_DmsFrontEnd_2300}/tr[3]/td[1]/div/div/input

${xpath_DmsFrontEnd_2300COR}                       xpath=${variable_xpath_DmsFrontEnd_2300}/tr[3]/td[2]/div/div/input




${xpath_DmsFrontEnd_2000_MList_transfer_RCV_OFFICEoption2}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[2]/div[2]/div/div/div[2]/div[2]/div[2]/div[2]/div[1]/div

${xpath_DmsFrontEnd_2000_MList_transfer_RCV_OFFICEoption3}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[2]/div[2]/div/div/div[2]/div[2]/div[2]/div[2]/div[2]/div

${xpath_DmsFrontEnd_2000_MList_transfer_RCV_OFFICEoption4}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[2]/div[2]/div/div/div[2]/div[2]/div[2]/div[2]/div[3]/div

${xpath_DmsFrontEnd_2000_MList_transfer_RCV_OFFICE}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[2]/div[2]/div/div/div[2]/div[2]/div[2]/div[1]/div[1]


                    


${xpath_DmsFrontEnd_2900_MList_transfer_ACC_DATE_from}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[3]/div[2]/div[2]/div/div/div[1]/div[1]/div[2]/div[1]/input

${xpath_DmsFrontEnd_2000_MList_transfer_ACC_DATE_from}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[2]/div[2]/div/div/div[1]/div[1]/div[2]/div[1]/input

${xpath_DmsFrontEnd_2900_MList_transfer_ACC_DATE_to}        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[3]/div[2]/div[2]/div/div/div[1]/div[2]/div[2]/div[1]/input

${xpath_DmsFrontEnd_2000_MList_transfer_ACC_DATE_to}        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[2]/div[2]/div/div/div[1]/div[2]/div[2]/div[1]/input



${xpath_DmsFrontEnd_2900_MList_transfer_TOUR_NO_from}        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[3]/div[2]/div[2]/div/div/div[1]/div[3]/div[2]/input

${xpath_DmsFrontEnd_2000_MList_transfer_TOUR_NO_from}        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[2]/div[2]/div/div/div[1]/div[4]/div[2]/input



${xpath_DmsFrontEnd_2900_MList_transfer_TOUR_NO_to}        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[3]/div[2]/div[2]/div/div/div[1]/div[4]/div[2]/input

${xpath_DmsFrontEnd_2000_MList_transfer_TOUR_NO_to}        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[2]/div[2]/div/div/div[1]/div[4]/div[2]/input



${xpath_DmsFrontEnd_2900_MList_transfer_STAFF_NO}        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[3]/div[2]/div[2]/div/div/div[2]/div[1]/div[1]/div[2]/input

${xpath_DmsFrontEnd_2000_MList_transfer_STAFF_NO}        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[2]/div[2]/div/div/div[2]/div[1]/div[1]/div[2]/input

${xpath_DmsFrontEnd_2000_MList_transfer_RCV_OFFICE}        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[2]/div[2]/div/div/div[2]/div[2]/div[2]/div[1]/div[1]



 

${xpath_DmsFrontEnd_2000ACC_DATE}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[2]/div[2]/div/div/div[1]/div[1]/div[2]/div[1]/input

${xpath_DmsFrontEnd_2000TOUR_NO}           xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[2]/div[2]/div/div/div[1]/div[2]/div[2]/input



${xpath_DmsFrontEnd_2000STAFF_NO}          xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[2]/div[2]/div/div/div[1]/div[3]/div[1]/div[2]/input

${xpath_DmsFrontEnd_2000NewMListButton}         xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[1]/div/button


${xpath_DmsFrontEnd_2900_MList_transfer_FetchButton}         xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[3]/div[2]/div[2]/div/div/div[4]/button[1]

${xpath_DmsFrontEnd_2000_MList_transfer_FetchButton}         xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[2]/div[2]/div/div/div[4]/button[1]

${xpath_DmsFrontEnd_2000FetchButton}         xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[2]/div[2]/div/div/div[2]/button

${xpath_DmsFrontEnd_2301_F3_Button}         xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[1]/div/button[2]




${variable_xpath_DmsFrontEnd_2000}                            /html/body/div[5]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody    


${xpath_DmsFrontEnd_2000RCV_OFFICE}                         xpath=${variable_xpath_DmsFrontEnd_2000}/tr[2]/td[2]/div/div/div[1]/div[1]



${xpath_DmsFrontEnd_2000RCV_OFFICEoption2}                  xpath=${variable_xpath_DmsFrontEnd_2000}/tr[2]/td[2]/div/div/div[2]/div[1]/div

${xpath_DmsFrontEnd_2000RCV_OFFICEoption3}                  xpath=${variable_xpath_DmsFrontEnd_2000}/tr[2]/td[2]/div/div/div[2]/div[2]/div

${xpath_DmsFrontEnd_2000RCV_OFFICEoption4}                  xpath=${variable_xpath_DmsFrontEnd_2000}/tr[2]/td[2]/div/div/div[2]/div[3]/div

${xpath_DmsFrontEnd_2000MAIL_TYPE}                          xpath=${variable_xpath_DmsFrontEnd_2000}/tr[3]/td[1]/div/div/div[1]/div[1]

${xpath_DmsFrontEnd_2000MAIL_TYPEoption1}                   xpath=${variable_xpath_DmsFrontEnd_2000}/tr[3]/td[1]/div/div/div[2]/div[1]/div

${xpath_DmsFrontEnd_2000MAIL_TYPEoption2}                   xpath=${variable_xpath_DmsFrontEnd_2000}/tr[3]/td[1]/div/div/div[2]/div[2]/div

${xpath_DmsFrontEnd_2000MAIL_TYPEoption3}                   xpath=${variable_xpath_DmsFrontEnd_2000}/tr[3]/td[1]/div/div/div[2]/div[3]/div

${xpath_DmsFrontEnd_2000MAIL_TYPEoption4}                   xpath=${variable_xpath_DmsFrontEnd_2000}/tr[3]/td[1]/div/div/div[2]/div[4]/div

${xpath_DmsFrontEnd_2000MAIL_TYPEoptionB}                   xpath=${variable_xpath_DmsFrontEnd_2000}/tr[3]/td[1]/div/div/div[2]/div[5]/div



${xpath_DmsFrontEnd_2000EndButton}                          xpath=${variable_xpath_nuxt_replace}/div/div/div/div/div/div[3]/button[2]

${xpath_DmsFrontEnd_2000SendButton}         xpath=${variable_xpath_nuxt_replace}/div/div/div/div/div/div[3]/button[1]

${xpath_DmsFrontEnd_2300EndButton}         xpath=${variable_xpath_nuxt_replace}/div/div/div/div/div/div[3]/button[2]


${xpath_DmsFrontEnd_2300SendButton}         xpath=${variable_xpath_nuxt_replace}/div/div/div/div/div/div[3]/button[1]



${xpath_DmsFrontEnd_8101NewNoneM5A0Button}         xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[3]/div[2]/div[1]/div/button[2]






#${variable_xpath_DmsFrontEnd_2301_new_MList}                                //*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[4]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/




${xpath_DmsFrontEnd_2301_new_MList_MLST_TYPE}                               xpath=${variable_xpath_DmsFrontEnd_2300}/tr[1]/td/div/div/div[1]/div[1]






${xpath_DmsFrontEnd_2301_new_MList_MLIST_NO}                                xpath=${variable_xpath_DmsFrontEnd_2300}/tr[1]/td[1]/div/div/input

${xpath_DmsFrontEnd_2301_new_MList_ORG_OFFICE}                              xpath=${variable_xpath_DmsFrontEnd_2300}/tr[1]/td[2]/div/div/input

${xpath_DmsFrontEnd_2301_new_MList_PCK_CNT}                                 xpath=${variable_xpath_DmsFrontEnd_2300}/tr[2]/td[1]/div/div/input

${xpath_DmsFrontEnd_2301_new_MList_RCL_CNT}                                 xpath=${variable_xpath_DmsFrontEnd_2300}/tr[2]/td[2]/div/div/input

${xpath_DmsFrontEnd_2301_new_MList_C_CNT}                                   xpath=${variable_xpath_DmsFrontEnd_2300}/tr[3]/td[1]/div/div/input

${xpath_DmsFrontEnd_2301_new_MList_BIDDING_CNT}                             xpath=${variable_xpath_DmsFrontEnd_2300}/tr[3]/td[2]/div/div/input

${xpath_DmsFrontEnd_2301_new_MList_INCL_CNT}                                xpath=${variable_xpath_DmsFrontEnd_2300}/tr[4]/td[1]/div/div/input

${xpath_DmsFrontEnd_2301_new_MList_INOP_CNT}                                xpath=${variable_xpath_DmsFrontEnd_2300}/tr[4]/td[2]/div/div/input

${xpath_DmsFrontEnd_2301_new_MList_send_button}                               xpath=${variable_xpath_nuxt_replace}/div/div/div/div/div/div[3]/button[1]

${xpath_DmsFrontEnd_2301_new_MList_end_button}                                xpath=${variable_xpath_nuxt_replace}/div/div/div/div/div/div[3]/button[2]

${xpath_DmsFrontEnd_2301_new_MList_button}                                    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[1]/div/button[1]






${variable_xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPE}                    ${variable_xpath_nuxt_replace}/div/div/div/div/div/div[2]/table/tbody/tr[1]/td/div/div

${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPEoption1}                               xpath=${variable_xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPE}/div[2]/div[1]/div

${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPEoption2}                               xpath=${variable_xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPE}/div[2]/div[2]/div

${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPEoption3}                               xpath=${variable_xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPE}/div[2]/div[3]/div

${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPEoption4}                               xpath=${variable_xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPE}/div[2]/div[4]/div

${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPEoption5}                               xpath=${variable_xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPE}/div[2]/div[5]/div

${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPEoption6}                               xpath=${variable_xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPE}/div[2]/div[6]/div

${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPEoption7}                               xpath=${variable_xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPE}/div[2]/div[7]/div

${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPEoption8}                               xpath=${variable_xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPE}/div[2]/div[8]/div

${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPEoption9}                               xpath=${variable_xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPE}/div[2]/div[9]/div

${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPEoption11}                               xpath=${variable_xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPE}/div[2]/div[10]/div

${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPEoption16}                               xpath=${variable_xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPE}/div[2]/div[11]/div

${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPEoption168}                               xpath=${variable_xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPE}/div[2]/div[12]/div

${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPEoption169}                               xpath=${variable_xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPE}/div[2]/div[13]/div


${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPE}                               xpath=${variable_xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPE}/div[1]/div[1]




${variable_xpath_DmsFrontEnd_2301_F3_new_MList}                                           ${variable_xpath_nuxt_replace}/div/div/div/div/div/div[2]/table/tbody

${xpath_DmsFrontEnd_2301_F3_new_MList_MLIST_NO}                               xpath=${variable_xpath_DmsFrontEnd_2301_F3_new_MList}/tr[2]/td[1]/div/div/input

${xpath_DmsFrontEnd_2301_F3_new_MList_ORG_OFFICE}                               xpath=${variable_xpath_DmsFrontEnd_2301_F3_new_MList}/tr[2]/td[2]/div/div/input

${xpath_DmsFrontEnd_2301_F3_new_MList_PCK_CNT}                               xpath=${variable_xpath_DmsFrontEnd_2301_F3_new_MList}/tr[3]/td[1]/div/div/input

${xpath_DmsFrontEnd_2301_F3_new_MList_RCL_CNT}                               xpath=${variable_xpath_DmsFrontEnd_2301_F3_new_MList}/tr[3]/td[2]/div/div/input

${xpath_DmsFrontEnd_2301_F3_new_MList_C_CNT}                               xpath=${variable_xpath_DmsFrontEnd_2301_F3_new_MList}/tr[4]/td[1]/div/div/input

${xpath_DmsFrontEnd_2301_F3_new_MList_BIDDING_CNT}                               xpath=${variable_xpath_DmsFrontEnd_2301_F3_new_MList}/tr[4]/td[2]/div/div/input

${xpath_DmsFrontEnd_2301_F3_new_MList_INCL_CNT}                               xpath=${variable_xpath_DmsFrontEnd_2301_F3_new_MList}/tr[5]/td[1]/div/div/input

${xpath_DmsFrontEnd_2301_F3_new_MList_INOP_CNT}                               xpath=${variable_xpath_DmsFrontEnd_2301_F3_new_MList}/tr[5]/td[2]/div/div/input

${xpath_DmsFrontEnd_2301_F3_new_MList_send_button}                               xpath=${variable_xpath_nuxt_replace}/div/div/div/div/div/div[3]/button[1]

${xpath_DmsFrontEnd_2301_F3_new_MList_end_button}                               xpath=${variable_xpath_nuxt_replace}/div/div/div/div/div/div[3]/button[2]

${xpath_DmsFrontEnd_2301_F3_new_MList_button}       xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[1]/div/button


${xpath_DmsFrontEnd_2301_new_M120_MList_send_button}                               xpath=${variable_xpath_nuxt_replace}/div/div/div/div/div/div[3]/button[1]

${xpath_DmsFrontEnd_2301_new_M120_MList_end_button}                                 xpath=${variable_xpath_nuxt_replace}/div/div/div/div/div/div[3]/button[2]


${xpath_DmsFrontEnd_2301_new_M120_MList_button}                                     xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[3]/div[3]/div[2]/div[1]/div/button


${variable_xpath_DmsFrontEnd_2301_new_M120_MList}                                ${variable_xpath_nuxt_replace}/div/div/div/div/div/div[2]/table/tbody

${xpath_DmsFrontEnd_2301_new_M120_MList_MLST_TYPE}                               xpath=${variable_xpath_DmsFrontEnd_2301_new_M120_MList}/tr[1]/td/div/div/div[1]/div[1]


${xpath_DmsFrontEnd_2301_new_M120_MList_MLST_TYPEoption0}                               xpath=${variable_xpath_DmsFrontEnd_2301_new_M120_MList}/tr[1]/td/div/div/div[2]/div[2]


${xpath_DmsFrontEnd_2301_new_M120_MList_MLST_TYPEoption1}                               xpath=${variable_xpath_DmsFrontEnd_2301_new_M120_MList}/tr[1]/td/div/div/div[2]/div[1]

${xpath_DmsFrontEnd_2301_new_M120_MList_MLIST_NO}                               xpath=${variable_xpath_DmsFrontEnd_2301_new_M120_MList}/tr[2]/td/div/div/input

${xpath_DmsFrontEnd_2301_new_M120_MList_ORG_OFFICE}                               xpath=${variable_xpath_DmsFrontEnd_2301_new_M120_MList}/tr[3]/td/div/div/input

${xpath_DmsFrontEnd_2301_new_M120_MList_DST_OFFICE}                               xpath=${variable_xpath_DmsFrontEnd_2301_new_M120_MList}/tr[4]/td/div/div/input

${xpath_DmsFrontEnd_2301_new_M120_MList_COR_MLIST}                               xpath=${variable_xpath_DmsFrontEnd_2301_new_M120_MList}/tr[5]/td/div/div/input









${select_value_TaipeiPostOffice}                   000000
${select_value_Zhongzheng_delivery}                100572














*** keywords ***



















































post_postweb2_pnsFrontEndloginFirefox
    [Arguments]     ${url}
    [Documentation]    Do bmc web login
        ${Browser_Ids}=  Browser.Get Browser Ids
        ${Page_Ids}=     Browser.Get Page Ids
        IF  ${Browser_Ids} != []
            Browser.Go To    ${url}
        ELSE
            New Browser  firefox  headless=false  args=['--allow-insecure-localhost']
#            New Browser  chromium  headless=false  args=['--allow-insecure-localhost']
            New Context  ignoreHTTPSErrors=${True}  bypassCSP=${True}
            New Page    ${url}
        END
#        Open Browser  ${url}  firefox
#        Set Browser Timeout  60s
#        New Context    viewport={'width': 1920, 'height': 1080}



dms_postweb2_pnsFrontEndloginChrome
    [Arguments]     ${url}
    [Documentation]    Do bmc web login
        ${Browser_Ids}=  Browser.Get Browser Ids
        ${Page_Ids}=     Browser.Get Page Ids
        IF  ${Browser_Ids} != []
            Browser.Go To    ${url}
        ELSE
#            New Browser  firefox  headless=false  args=['--allow-insecure-localhost']
            New Browser  chromium  headless=false  args=['--allow-insecure-localhost']
            New Context  ignoreHTTPSErrors=${True}  bypassCSP=${True}
            New Page    ${url}
        END
#        Open Browser  ${url}  firefox
#        Set Browser Timeout  60s
#        New Context    viewport={'width': 1920, 'height': 1080}




post_postweb2_pnsFrontEndloginbyExcel
    [Arguments]     ${excel_url}
    [Documentation]    Do bmc web login
        ${Browser_Ids}=  Browser.Get Browser Ids
        ${Page_Ids}=     Browser.Get Page Ids
        IF  ${Browser_Ids} != []
            Browser.Go To    https://pnstest.post.gov.tw/LI.Web/Quest.aspx?q_sid=${excel_url}
        ELSE
            New Browser  firefox  headless=false  args=['--allow-insecure-localhost']
            New Context  ignoreHTTPSErrors=${True}  bypassCSP=${True}
            New Page    https://pnstest.post.gov.tw/LI.Web/Quest.aspx?q_sid=${excel_url}
        END
#        Open Browser  ${url}  firefox
#        Set Browser Timeout  60s
#        New Context    viewport={'width': 1920, 'height': 1080}
        

dms_dmsweb2_ClickDmsFrontEndLoginUsername
    [Arguments]     ${username}
        [Documentation]
        [Tags]
        Fill Text     ${xpath_DmsFrontEnd_username}    ${username}


dms_dmsweb2_ClickDmsFrontEndLoginSelectOffice
        [Documentation]

#        Click  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndContent1_btnQuery}
        Click   ${xpath_DmsFrontEnd_selectOffice}

#        Sleep  1s

        Click   ${xpath_DmsFrontEnd_selectOfficeOption}
 
#        Sleep  1s
        Take Screenshot




dms_dmsweb2_ClickDmsFrontEndLoginPassword
    [Arguments]     ${password}
        [Documentation]
        [Tags]
        Fill Text     ${xpath_DmsFrontEnd_password}    ${password}
#        Input Password    ${xpath_DmsFrontEnd_password}    ${password}
#        Input Text    ${xpath_DmsFrontEnd_password}    ${password}


dms_dmsweb2_ClickDmsFrontEndLoginEnter
        [Documentation]
        Click     ${xpath_DmsFrontEnd_enterbutton}



dms_dmsweb2_ClickDmsFrontEnduserID_logout
        [Documentation]
        [Tags]
        Click   ${xpath_DmsFrontEnd_userID}
        Click   ${xpath_DmsFrontEnd_userID_logout}
        Set Browser Timeout    10s


dms_dmsweb2_ClickDmsFrontEndMenuButton
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndMenu_List2}
        Click     ${xpath_DmsFrontEndMenuButton}
#        Sleep  1s
#        Handle Alert

dms_dmsweb2_ClickDmsFrontEndMenu_homepage
        [Documentation]
        [Tags]

        Click     ${xpath_DmsFrontEndMenu_homepage}

#        Sleep  1s
#        Handle Alert


dms_dmsweb2_ClickDmsFrontEndMenu_ListDR1
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndMenu_List2Button1}
        Click     ${xpath_DmsFrontEndMenu_ListDR}
        Click     ${xpath_DmsFrontEndMenu_ListDR1}
#        Sleep  1s
#        Handle Alert

dms_dmsweb2_ClickDmsFrontEndMenu_ListOP1
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndMenu_List2Button1}
        Click     ${xpath_DmsFrontEndMenu_ListOP}
        Click     ${xpath_DmsFrontEndMenu_ListOP1}
        Set Browser Timeout    2s

#        Sleep  1s
#        Handle Alert

dms_dmsweb2_ClickDmsFrontEndMenu_ListOP1_2902
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndMenu_List2Button1}
        Click     ${xpath_DmsFrontEndMenu_ListOP1_2902}
#        Sleep  1s
#        Handle Alert

dms_dmsweb2_ClickDmsFrontEndMenu_ListOP1_2900
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndMenu_List2Button1}
        Click     ${xpath_DmsFrontEndMenu_ListOP1_2900}
#        Sleep  1s
#        Handle Alert

dms_dmsweb2_ClickDmsFrontEndMenu_ListOP1_2301
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndMenu_List2Button1}
        Click     ${xpath_DmsFrontEndMenu_ListOP1_2301}
#        Sleep  1s
#        Handle Alert


dms_dmsweb2_ClickDmsFrontEndMenu_ListOP1_2300
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndMenu_List2Button1}
        Click     ${xpath_DmsFrontEndMenu_ListOP1_2300}
#        Sleep  1s
#        Handle Alert


dms_dmsweb2_ClickDmsFrontEndMenu_ListOP1_2000
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndMenu_List2Button1}
        Click     ${xpath_DmsFrontEndMenu_ListOP1_2000}
#        Sleep  1s
#        Handle Alert


dms_dmsweb2_ClickDmsFrontEndMenu_ListMM1
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndMenu_List2Button1}
        Click     ${xpath_DmsFrontEndMenu_ListMM}
        Click     ${xpath_DmsFrontEndMenu_ListMM1}
#        Sleep  1s
#        Handle Alert

dms_dmsweb2_ClickDmsFrontEndMenu_ListMM1_a100
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndMenu_List2Button1}
        Click     ${xpath_DmsFrontEndMenu_ListMM1_a100}
#        Sleep  1s
#        Handle Alert

dms_dmsweb2_ClickDmsFrontEndMenu_ListMM1_a100_BSC
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndMenu_List2Button1}
        Click     ${xpath_DmsFrontEndMenu_ListMM1_a100_BSC}
        Take Screenshot
#        Sleep  1s
#        Handle Alert

dms_dmsweb2_ClickDmsFrontEndMenu_ListMM1_a100_BSC_20OP
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndMenu_List2Button1}
        Click     ${xpath_DmsFrontEndMenu_ListMM1_a100_BSC_20OP}
#        Sleep  1s
#        Handle Alert

dms_dmsweb2_ClickDmsFrontEndMenu_ListMM1_a100_BSC_20OP_1
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndMenu_List2Button1}
        Click     ${xpath_DmsFrontEndMenu_ListMM1_a100_BSC_20OP_1}
#        Sleep  1s
#        Handle Alert

dms_dmsweb2_ClickDmsFrontEndMenu_ListMM1_a100_BSC_20OP_3
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndMenu_List2Button1}
        Click     ${xpath_DmsFrontEndMenu_ListMM1_a100_BSC_20OP_3}
#        Sleep  1s
#        Handle Alert

dms_dmsweb2_ClickDmsFrontEndMenu_ListMM1_a100_BSC_DATE
        [Arguments]  ${BSC_DATE}
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndMenu_List2Button1}
        Fill Text   ${xpath_DmsFrontEndMenu_ListMM1_a100_BSC_DATE}   ${BSC_DATE}

#        Sleep  1s
#        Handle Alert

dms_dmsweb2_ClickDmsFrontEndMenu_ListMM1_a100_BSC_TOUR_NO
        [Arguments]  ${TOUR_NO}
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndMenu_List2Button1}
        Fill Text   ${xpath_DmsFrontEndMenu_ListMM1_a100_BSC_TOUR_NO}   ${TOUR_NO}

#        Sleep  1s
#        Handle Alert

dms_dmsweb2_ClickDmsFrontEndMenu_ListMM1_a100_BSC_today_button
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndMenu_List2Button1}
        Click     ${xpath_DmsFrontEndMenu_ListMM1_a100_BSC_today_button}
#        Sleep  1s
#        Handle Alert

dms_dmsweb2_ClickDmsFrontEndMenu_ListMM1_a100_BSC_plus_button
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndMenu_List2Button1}
        Click     ${xpath_DmsFrontEndMenu_ListMM1_a100_BSC_plus_button}
#        Sleep  1s
#        Handle Alert

dms_dmsweb2_ClickDmsFrontEndMenu_ListMM1_a100_BSC_save_button
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndMenu_List2Button1}
        Click     ${xpath_DmsFrontEndMenu_ListMM1_a100_BSC_save_button}
#        Sleep  1s
#        Handle Alert 



dms_dmsweb2_ClickDmsFrontEnd_2301_F3_new_MList_send_button
        [Documentation]
        [Tags]

        Click    ${xpath_DmsFrontEnd_2301_F3_new_MList_send_button}


dms_dmsweb2_ClickDmsFrontEnd_2301_F3_new_MList_end_button
        [Documentation]
        [Tags]

        Click    ${xpath_DmsFrontEnd_2301_F3_new_MList_end_button}

dms_dmsweb2_ClickDmsFrontEnd_2301_new_M120_MList_send_button
        [Documentation]
        [Tags]

        Click    ${xpath_DmsFrontEnd_2301_new_M120_MList_send_button}


dms_dmsweb2_ClickDmsFrontEnd_2301_new_M120_MList_end_button
        [Documentation]
        [Tags]

        Click    ${xpath_DmsFrontEnd_2301_new_M120_MList_end_button}


dms_dmsweb2_ClickDmsFrontEnd_2301_new_MList_send_button
        [Documentation]
        [Tags]

        Click    ${xpath_DmsFrontEnd_2301_new_MList_send_button}

dms_dmsweb2_ClickDmsFrontEnd_2301_new_MList_end_button
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}
        Click    ${xpath_DmsFrontEnd_2301_new_MList_end_button}


dms_dmsweb2_ClickDmsFrontEnd_2301_MList_letter_end_button
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}
        Click    ${xpath_DmsFrontEnd_2301_MList_letter_end_button}


dms_dmsweb2_ClickDmsFrontEnd_2301_MList_letter_save_button
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}
        Click    ${xpath_DmsFrontEnd_2301_MList_letter_save_button}


dms_dmsweb2_ClickDmsFrontEnd_2000_MList_letter_end_button
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}
        Click    ${xpath_DmsFrontEnd_2000_MList_letter_end_button}


dms_dmsweb2_ClickDmsFrontEnd_2000_MList_letter_save_button
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}
        Click    ${xpath_DmsFrontEnd_2000_MList_letter_save_button}


dms_dmsweb2_ClickDmsFrontEnd_2000_MList_letter_DST_OFFICE
        [Arguments]  ${DST_OFFICE}
        [Documentation]
        [Tags]
        IF  '${DST_OFFICE}' == 'NONE'  
            Click    ${xpath_DmsFrontEnd_2000_MList_letter_DST_OFFICE}
            Keyboard Key    down     Control
            Keyboard Key    press    A
            Keyboard Key    up       Control     
            Keyboard Key    press    Delete 
        ELSE
            Fill Text   ${xpath_DmsFrontEnd_2000_MList_letter_DST_OFFICE}    ${DST_OFFICE}

        END


dms_dmsweb2_ClickDmsFrontEnd_2000_MList_letter_VAL_DCL_AMT
        [Arguments]  ${VAL_DCL_AMT}
        [Documentation]
        [Tags]
#        Fill Text   ${xpath_DmsFrontEnd_2000_MList_letter_VAL_DCL_AMT}    ${VAL_DCL_AMT}
        IF  '${VAL_DCL_AMT}' == 'None'  

        	${states}=    Get Element States    ${xpath_DmsFrontEnd_2000_MList_letter_VAL_DCL_AMT}

            ${VAL_DCL_AMT_is_enabled}=  Run Keyword And Continue On Failure    Get Element States    ${xpath_DmsFrontEnd_2000_MList_letter_VAL_DCL_AMT}  then   bool(value & enabled) 
            Log  ${VAL_DCL_AMT_is_enabled}
            IF  '${VAL_DCL_AMT_is_enabled}' == 'True' 
                Click    ${xpath_DmsFrontEnd_2000_MList_letter_VAL_DCL_AMT}
                Keyboard Key    down     Control
                Keyboard Key    press    A
                Keyboard Key    up       Control     
                Keyboard Key    press    Delete 
            ELSE
                Take Screenshot
            END
        ELSE
            Fill Text   ${xpath_DmsFrontEnd_2000_MList_letter_VAL_DCL_AMT}    ${VAL_DCL_AMT}
        END

dms_dmsweb2_ClickDmsFrontEnd_2000_MList_letter_MAIL_NO
        [Arguments]  ${MAIL_NO}
        [Documentation]
        [Tags]
#        Fill Text   ${xpath_DmsFrontEnd_2000_MList_letter_MAIL_NO}    ${MAIL_NO}
        IF  '${MAIL_NO}' == 'NONE'  
            Click    ${xpath_DmsFrontEnd_2000_MList_letter_MAIL_NO}
            Keyboard Key    down     Control
            Keyboard Key    press    A
            Keyboard Key    up       Control     
            Keyboard Key    press    Delete 
        ELSE
            Fill Text   ${xpath_DmsFrontEnd_2000_MList_letter_MAIL_NO}    ${MAIL_NO}
        END

dms_dmsweb2_ClickDmsFrontEnd_2301_MList_letter_MAIL_NO
        [Arguments]  ${MAIL_NO}
        [Documentation]
        [Tags]

        IF  '${MAIL_NO}' == 'NONE'  
            Click    ${xpath_DmsFrontEnd_2301_MList_letter_MAIL_NO}
            Keyboard Key    down     Control
            Keyboard Key    press    A
            Keyboard Key    up       Control     
            Keyboard Key    press    Delete 
        ELSE
            Fill Text   ${xpath_DmsFrontEnd_2301_MList_letter_MAIL_NO}    ${MAIL_NO}
        END

dms_dmsweb2_ClickDmsFrontEnd_2301_MList_new_letter_button
        [Arguments]   ${excel_file_data}  
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}

        IF '${excel_file_data}[24]' == 'Y'
            Keyboard Key    press    F1
        ELSE
            Click    ${xpath_DmsFrontEnd_2301_MList_new_letter_button}
        END

dms_dmsweb2_ClickDmsFrontEnd_2000_MList_new_letter_button
        [Arguments]   ${excel_file_data}  ${string}
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}
        IF  '${excel_file_data}[24]' == 'Y'
            Keyboard Key    press    F9
        ELSE
            IF  '${string}' == '2902'
                Click    ${xpath_DmsFrontEnd_2902_MList_new_letter_button}
            ELSE  #${string}=2000,2900
                Click    ${xpath_DmsFrontEnd_2000_MList_new_letter_button}
            END
        END



dms_dmsweb2_ClickDmsFrontEnd_2000_MList_checkout_button
        [Arguments]   ${excel_file_data}  ${i}
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}

        IF  '${excel_file_data}[24]' == 'Y'
            Keyboard Key    press    F10
        ELSE
            IF  '${i}'=='1'

                Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[1]
                Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[2]/td/span/button[4]

            ELSE

                Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]
                Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td/span/button[4]

            END
        END


dms_dmsweb2_ClickDmsFrontEnd_2000_MList_transfer_FetchButton
        [Arguments]   ${excel_file_data}  ${string}
        [Documentation]
        [Tags]

        Log  ${string}
        IF  '${excel_file_data}[24]' == 'Y'
            Keyboard Key    press       F1
        ELSE
            IF  '${string}' == '2900'
                Click    ${xpath_DmsFrontEnd_2900_MList_transfer_FetchButton}
            ELSE  #${string}=  2000
                Click    ${xpath_DmsFrontEnd_2000_MList_transfer_FetchButton}
            END
        END



dms_dmsweb2_ClickDmsFrontEnd_2000_mail_transfer_check_button
        [Arguments]   ${excel_file_data}  ${i}
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}

        IF  '${excel_file_data}[24]' == 'Y'
            Keyboard Key    press       F12
        ELSE
            IF  '${i}'=='1'

                Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[1]
                Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[2]/td/span/button

            ELSE

                Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]
                Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td/span/button

            END
        END
        Take Screenshot
        Click    xpath=//*[@id="alert-container"]/div/div/div[3]/button
        Take Screenshot

dms_dmsweb2_ClickDmsFrontEnd_2000_MList_transfer_check_button
        [Arguments]   ${excel_file_data}    ${string}  ${i}
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}


        IF  '${i}'=='1'

            
            IF  '${string}' == '2900'
                Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[3]/div[3]/div[2]/div[2]/table/tbody/tr[1]
                
                IF  '${excel_file_data}[24]' == 'Y'
                    Keyboard Key    press       F12
                ELSE
                    Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[3]/div[3]/div[2]/div[2]/table/tbody/tr[2]/td/span/button
                END

            ELSE  #${string}=  2000 #2301?
                Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[1]
               
                IF  '${excel_file_data}[24]' == 'Y'
                    Keyboard Key    press       F12
                ELSE
                    Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[2]/td/span/button
                END
                
            END

        ELSE

                       
            IF  '${string}' == '2900'
                Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[3]/div[3]/div[2]/div[2]/table/tbody/tr[${i}] 
                
                IF  '${excel_file_data}[24]' == 'Y'
                    Keyboard Key    press       F12
                ELSE
                    Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[3]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td/span/button
                END

            ELSE  #${string}=  2000 #2301?
                Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[${i}] 

                IF  '${excel_file_data}[24]' == 'Y'
                    Keyboard Key    press       F12
                ELSE
                    Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td/span/button
                END

            END

        END
        Take Screenshot
        Click    xpath=//*[@id="alert-container"]/div/div/div[3]/button
        Take Screenshot

dms_dmsweb2_ClickDmsFrontEnd_2000_mail_transfer_button
        [Arguments]   ${excel_file_data}    ${string}  ${i}
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}

        Log  ${string}
        IF  '${i}'=='1'            
            Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[2]/div[3]/div[2]/div[2]/table/tbody/tr[1]

            IF  '${excel_file_data}[24]' == 'Y'
                Keyboard Key    press       F12
            ELSE
                IF  '${string}' == '2900'
                    Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[2]/div[3]/div[2]/div[2]/table/tbody/tr[2]/td/span/button[3]
                ELSE  #${string}=  2000
                    Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[2]/div[3]/div[2]/div[2]/table/tbody/tr[2]/td/span/button[4]
                END
            END
        ELSE

            Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[2]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]

            IF  '${excel_file_data}[24]' == 'Y'
                Keyboard Key    press       F12
            ELSE
                IF  '${string}' == '2900'
                    Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[2]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td/span/button[3]
                ELSE  #${string}=  2000
                    Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[2]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td/span/button[4]
                END
            END
        END
#        Handle Alert


dms_dmsweb2_ClickDmsFrontEnd_2000_MList_transfer_button
        [Arguments]   ${excel_file_data}  ${i}
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}


        IF  '${i}'=='1'

            Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[1]

            IF  '${excel_file_data}[24]' == 'Y'
                Keyboard Key    press       F12
            ELSE
                Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[2]/td/span/button[7]
            END

        ELSE

            Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]

            IF  '${excel_file_data}[24]' == 'Y'
                Keyboard Key    press       F12
            ELSE
                Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td/span/button[7]
            END
                
        END
#        Handle Alert





dms_dmsweb2_ClickDmsFrontEnd_2301_F3_new_MList_button
        [Arguments]   ${excel_file_data}  
        [Documentation]
        [Tags]

        
        IF  '${excel_file_data}[24]' == 'Y'
            Keyboard Key    press       F1
        ELSE
            Click    ${xpath_DmsFrontEnd_2301_F3_new_MList_button}  
        END  
        Take Screenshot
        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_2301_new_M120_MList_button
        [Arguments]   ${excel_file_data}  
        [Documentation]
        [Tags]
                
        IF  '${excel_file_data}[24]' == 'Y'
            Keyboard Key    press       F1
        ELSE
            Click    ${xpath_DmsFrontEnd_2301_new_M120_MList_button}
        END    
        Take Screenshot
        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_2301_new_MList_button
        [Arguments]   ${excel_file_data}  
        [Documentation]
        [Tags]
                
        IF  '${excel_file_data}[24]' == 'Y'
            Keyboard Key    press       F1
        ELSE
            Click    ${xpath_DmsFrontEnd_2301_new_MList_button}  
        END  
        Take Screenshot
        Sleep  1s

        




dms_dmsweb2_ClickDmsFrontEnd_2000_M120_MList_login_button
        [Arguments]   ${excel_file_data}  ${i}
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}


        IF  '${i}'=='1'

            Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[1]

            IF  '${excel_file_data}[24]' == 'Y'
                Keyboard Key    press       F9
            ELSE
                Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[2]/td/span/button[4]
            END


        ELSE

            Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]

            IF  '${excel_file_data}[24]' == 'Y'
                Keyboard Key    press       F9
            ELSE
                Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td/span/button[4]
            END

        END
#        Handle Alert



dms_dmsweb2_ClickDmsFrontEnd_2301_F3_MList_login_button
        [Arguments]   ${excel_file_data}  ${i}
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}


        IF  '${i}'=='1'

            Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[1]
            IF  '${excel_file_data}[24]' == 'Y'
                Keyboard Key    press       F7
            ELSE
                Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[2]/td/span/button[3]
            END

        ELSE

            Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]
            IF  '${excel_file_data}[24]' == 'Y'
                Keyboard Key    press       F7
            ELSE
                Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td/span/button[3]
            END

        END
#        Handle Alert



dms_dmsweb2_ClickDmsFrontEnd_2000_MList_login_button
        [Arguments]   ${excel_file_data}  ${i}
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}


        IF  '${i}'=='1'

            Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[1]
            IF  '${excel_file_data}[24]' == 'Y'
                Keyboard Key    press       F9
            ELSE
                Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[2]/td/span/button[3]
            END

        ELSE

            Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]
            IF  '${excel_file_data}[24]' == 'Y'
                Keyboard Key    press       F9
            ELSE
                Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td/span/button[3]
            END

        END
#        Handle Alert




dms_dmsweb2_ClickDmsFrontEnd_2000_checkout_button
        [Arguments]   ${excel_file_data}
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}
        IF  '${excel_file_data}[24]' == 'Y'
            Keyboard Key    press       F10
        ELSE
            Click    ${xpath_DmsFrontEnd_2000_checkout_button}
        END



dms_dmsweb2_FetchDmsFrontEnd_2000New_MList_NO
        [Documentation]
        [Tags]
        Sleep  1s
        Take Screenshot
        ${MLIST_MESSAGE}=  Browser.Get text  ${xpath_DmsFrontEnd_2000MLIST_MESSAGE} 
        Log   ${MLIST_MESSAGE}
        ${MLIST_MESSAGE_split1}=    Split String    ${MLIST_MESSAGE}    ${SPACE}
        Log   ${MLIST_MESSAGE_split1}[0]
        ${MLIST_MESSAGE_split2}=    Split String    ${MLIST_MESSAGE_split1}[0]    碼
        Log   ${MLIST_MESSAGE_split2}[0]
        Log   ${MLIST_MESSAGE_split2}[1]

        RETURN  ${MLIST_MESSAGE_split2}[1]

dms_dmsweb2_ClickDmsFrontEnd_2000FetchButton
        [Arguments]   ${excel_file_data}
        [Documentation]
        [Tags]

        IF  '${excel_file_data}[24]' == 'Y'
            Keyboard Key    press       F1
        ELSE
            Click    ${xpath_DmsFrontEnd_2000FetchButton}
        END



dms_dmsweb2_ClickDmsFrontEnd_2000NewMListButton
        [Arguments]   ${excel_file_data}
        [Documentation]
        [Tags]
        IF  '${excel_file_data}[24]' == 'Y'
            Keyboard Key    press       F1
        ELSE
            Click    ${xpath_DmsFrontEnd_2000NewMListButton}
        END



dms_dmsweb2_ClickDmsFrontEnd_8101NewNoneM5A0Button
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}
        Click    ${xpath_DmsFrontEnd_8101NewNoneM5A0Button}
#        Sleep  1s
#        Handle Alert




dms_dmsweb2_ClickDmsFrontEnd_2300COR
        [Arguments]  ${COR}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_2300COR}  ${COR}
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_2300DST_OFFICE
        [Arguments]  ${DST_OFFICE}
        [Documentation]
        [Tags]
        IF  '${DST_OFFICE}' == 'None'  
#            Click    ${xpath_DmsFrontEnd_2300DST_OFFICE}
#            Keyboard Key    down     Control
#            Keyboard Key    press    A
#            Keyboard Key    up       Control     
#            Keyboard Key    press    Delete 
            Take Screenshot
        ELSE
            Fill Text   ${xpath_DmsFrontEnd_2300DST_OFFICE}    ${DST_OFFICE}
            Click   xpath=${variable_xpath_DmsFrontEnd_2300}/tr[3]/th[1]
        END
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_2300ORG_OFFICE
        [Arguments]  ${ORG_OFFICE}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_2300ORG_OFFICE}  ${ORG_OFFICE}
        Click   xpath=${variable_xpath_DmsFrontEnd_2300}/tr[2]/th[2]
#        Sleep  1s


dms_dmsweb2_ClickDmsFrontEnd_2300MLIST_NO
        [Arguments]  ${MLIST_NO}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_2300MLIST_NO}  ${MLIST_NO}
#        Sleep  1s




dms_dmsweb2_ClickDmsFrontEnd_2301_new_MList_MLIST_NO
        [Arguments]  ${MLIST_NO}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_2301_new_MList_MLIST_NO}  ${MLIST_NO}
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_2301_new_MList_ORG_OFFICE
        [Arguments]  ${ORG_OFFICE}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_2301_new_MList_ORG_OFFICE}  ${ORG_OFFICE}
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_2301_new_MList_PCK_CNT 
        [Arguments]  ${PCK_CNT}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_2301_new_MList_PCK_CNT}  ${PCK_CNT}
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_2301_new_MList_RCL_CNT
        [Arguments]  ${RCL_CNT}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_2301_new_MList_RCL_CNT}  ${RCL_CNT}
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_2301_new_MList_C_CNT
        [Arguments]  ${C_CNT}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_2301_new_MList_C_CNT}  ${C_CNT}
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_2301_new_MList_BIDDING_CNT
        [Arguments]  ${BIDDING_CNT}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_2301_new_MList_BIDDING_CNT}  ${BIDDING_CNT}
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_2301_new_MList_INCL_CNT
        [Arguments]  ${INCL_CNT}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_2301_new_MList_INCL_CNT}  ${INCL_CNT}
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_2301_new_MList_INOP_CNT
        [Arguments]  ${INOP_CNT}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_2301_new_MList_INOP_CNT}  ${INOP_CNT}
#        Sleep  1s




dms_dmsweb2_ClickDmsFrontEnd_2301_F3_new_MList_MLST_TYPE
        [Arguments]  ${MLST_TYPE}
        [Documentation]
        [Tags]
        Take Screenshot
        Click   ${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPE}
        IF  '${MLST_TYPE}' == '0'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPEoption0}     
        ELSE IF  '${MLST_TYPE}' == '1'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPEoption1}     
        ELSE IF  '${MLST_TYPE}' == '2'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPEoption2}     
        ELSE IF  '${MLST_TYPE}' == '3'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPEoption3}     
        ELSE IF  '${MLST_TYPE}' == '4'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPEoption4}     
        ELSE IF  '${MLST_TYPE}' == '5'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPEoption5}     
        ELSE IF  '${MLST_TYPE}' == '6'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPEoption6}     
        ELSE IF  '${MLST_TYPE}' == '7'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPEoption7}     
        ELSE IF  '${MLST_TYPE}' == '8'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPEoption8}     
        ELSE IF  '${MLST_TYPE}' == '9'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPEoption9}     
        ELSE IF  '${MLST_TYPE}' == '11'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPEoption11}     
        ELSE IF  '${MLST_TYPE}' == '168'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPEoption168}     
        ELSE IF  '${MLST_TYPE}' == '169'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2301_F3_new_MList_MLST_TYPEoption169}     
        ELSE
                Fail 
        END
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_2301_F3_new_MList_MLIST_NO
        [Arguments]  ${MLIST_NO}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_2301_F3_new_MList_MLIST_NO}  ${MLIST_NO}
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_2301_F3_new_MList_ORG_OFFICE
        [Arguments]  ${ORG_OFFICE}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_2301_F3_new_MList_ORG_OFFICE}  ${ORG_OFFICE}
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_2301_F3_new_MList_PCK_CNT 
        [Arguments]  ${PCK_CNT}
        [Documentation]
        [Tags]
        IF  '${PCK_CNT}' != 'None'
            Fill Text   ${xpath_DmsFrontEnd_2301_F3_new_MList_PCK_CNT}  ${PCK_CNT}
        END
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_2301_F3_new_MList_RCL_CNT
        [Arguments]  ${RCL_CNT}
        [Documentation]
        [Tags]
        IF  '${RCL_CNT}' != 'None'
            Fill Text   ${xpath_DmsFrontEnd_2301_F3_new_MList_RCL_CNT}  ${RCL_CNT}
        END
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_2301_F3_new_MList_C_CNT
        [Arguments]  ${C_CNT}
        [Documentation]
        [Tags]
        IF  '${C_CNT}' != 'None'
            Fill Text   ${xpath_DmsFrontEnd_2301_F3_new_MList_C_CNT}  ${C_CNT}
        END
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_2301_F3_new_MList_BIDDING_CNT
        [Arguments]  ${BIDDING_CNT}
        [Documentation]
        [Tags]
        IF  '${BIDDING_CNT}' != 'None'
            Fill Text   ${xpath_DmsFrontEnd_2301_F3_new_MList_BIDDING_CNT}  ${BIDDING_CNT}
        END
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_2301_F3_new_MList_INCL_CNT
        [Arguments]  ${INCL_CNT}
        [Documentation]
        [Tags]
        IF  '${INCL_CNT}' != 'None'
            Fill Text   ${xpath_DmsFrontEnd_2301_F3_new_MList_INCL_CNT}  ${INCL_CNT}
        END
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_2301_F3_new_MList_INOP_CNT
        [Arguments]  ${INOP_CNT}
        [Documentation]
        [Tags]
        IF  '${INOP_CNT}' != 'None'
            Fill Text   ${xpath_DmsFrontEnd_2301_F3_new_MList_INOP_CNT}  ${INOP_CNT}
        END
#        Sleep  1s




dms_dmsweb2_ClickDmsFrontEnd_2301_new_M120_MList_MLST_TYPE
        [Arguments]  ${MLST_TYPE}
        [Documentation]
        [Tags]
        Take Screenshot
        Click   ${xpath_DmsFrontEnd_2301_new_M120_MList_MLST_TYPE}
        IF  '${MLST_TYPE}' == '0'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2301_new_M120_MList_MLST_TYPEoption0}     
        ELSE IF  '${MLST_TYPE}' == '1'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2301_new_M120_MList_MLST_TYPEoption1}
        ELSE
                Fail 
        END
#        Sleep  1s


dms_dmsweb2_ClickDmsFrontEnd_2301_new_M120_MList_MLIST_NO
        [Arguments]  ${MLIST_NO}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_2301_new_M120_MList_MLIST_NO}  ${MLIST_NO}
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_2301_new_M120_MList_ORG_OFFICE
        [Arguments]  ${ORG_OFFICE}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_2301_new_M120_MList_ORG_OFFICE}  ${ORG_OFFICE}
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_2301_new_M120_MList_DST_OFFICE
        [Arguments]  ${DST_OFFICE}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_2301_new_M120_MList_DST_OFFICE}  ${DST_OFFICE}
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_2301_new_M120_MList_COR_MLIST
        [Arguments]  ${COR_MLIST}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_2301_new_M120_MList_COR_MLIST}  ${COR_MLIST}
#        Sleep  1s









dms_dmsweb2_ClickDmsFrontEnd_2300MLST_TYPE
        [Arguments]    ${MLST_TYPE}
        [Documentation]
        [Tags]
        Log  ${MLST_TYPE}
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}
        Take Screenshot
        Click   ${xpath_DmsFrontEnd_2300MLST_TYPE}
        IF  '${MLST_TYPE}' == '0'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2300MLST_TYPEoption0}     
        ELSE IF  '${MLST_TYPE}' == '1'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2300MLST_TYPEoption1}
        ELSE
                Fail 
        END
#        Sleep  1s
#        Handle Alert

dms_dmsweb2_ClickDmsFrontEnd_2300IN_TYPE
        [Arguments]    ${IN_TYPE}
        [Documentation]
        [Tags]
        Log  ${IN_TYPE}
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}
        Take Screenshot
        Click   ${xpath_DmsFrontEnd_2300IN_TYPE}
        IF  '${IN_TYPE}' == '1'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2300IN_TYPEoption1}    
        ELSE IF  '${IN_TYPE}' == '2'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2300IN_TYPEoption2}
        ELSE IF  '${IN_TYPE}' == '3'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2300IN_TYPEoption3}
        ELSE IF  '${IN_TYPE}' == '4'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2300IN_TYPEoption4}
        ELSE IF  '${IN_TYPE}' == '5'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2300IN_TYPEoption5}
        ELSE IF  '${IN_TYPE}' == '6'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2300IN_TYPEoption6}
        ELSE IF  '${IN_TYPE}' == '7'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2300IN_TYPEoption7}
        ELSE IF  '${IN_TYPE}' == '8'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2300IN_TYPEoption8}
        ELSE IF  '${IN_TYPE}' == '9'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2300IN_TYPEoption9}
        ELSE IF  '${IN_TYPE}' == '11'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2300IN_TYPEoption11}
        ELSE IF  '${IN_TYPE}' == '16'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2300IN_TYPEoption16}
        ELSE IF  '${IN_TYPE}' == '168'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2300IN_TYPEoption168}
        ELSE IF  '${IN_TYPE}' == '169'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2300IN_TYPEoption169}
        ELSE
                Fail 
        END
#        Sleep  1s
#        Handle Alert



dms_dmsweb2_ClickDmsFrontEnd_2000_MList_transfer_RCV_OFFICE
        [Arguments]    ${RCV_OFFICE}
        [Documentation]
        [Tags]
        Log  ${RCV_OFFICE}
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}
        Take Screenshot
        Click   ${xpath_DmsFrontEnd_2000_MList_transfer_RCV_OFFICE}
        IF  '${RCV_OFFICE}' == '1'
                Fail      
        ELSE IF  '${RCV_OFFICE}' == '2'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2000_MList_transfer_RCV_OFFICEoption2}
        ELSE IF  '${RCV_OFFICE}' == '3'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2000_MList_transfer_RCV_OFFICEoption3}
        ELSE IF  '${RCV_OFFICE}' == '4'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2000_MList_transfer_RCV_OFFICEoption4}
        ELSE
                Fail 
        END
#        Sleep  1s
#        Handle Alert

dms_dmsweb2_ClickDmsFrontEnd_2000_MList_transfer_STAFF_NO
#        [Arguments]  ${STAFF_NO}
        [Arguments]  ${string}
        [Documentation]
        [Tags]
        IF  '${string}' == '2900'
            Click   ${xpath_DmsFrontEnd_2900_MList_transfer_STAFF_NO}
        ELSE  #${string}=  2000
            Click   ${xpath_DmsFrontEnd_2000_MList_transfer_STAFF_NO}
        END
#        Sleep  1s
#        Debug
        Keyboard Key    down     Control
        Keyboard Key    press    A
        Keyboard Key    up       Control  
#        Sleep  1s  
#        Debug    
        Keyboard Key    press    Delete 
        Take Screenshot  
#        Sleep  1s  
#        Debug 
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_2000_MList_transfer_TOUR_NO
        [Arguments]  ${TOUR_NO}  ${string}
        [Documentation]
        [Tags]
 
        IF  '${string}' == '2900'
            Fill Text   ${xpath_DmsFrontEnd_2900_MList_transfer_TOUR_NO_from}    ${TOUR_NO}
            Fill Text   ${xpath_DmsFrontEnd_2900_MList_transfer_TOUR_NO_to}    ${TOUR_NO}
        ELSE  #${string}=  2000
            Fill Text   ${xpath_DmsFrontEnd_2000_MList_transfer_TOUR_NO_from}    ${TOUR_NO}
            Fill Text   ${xpath_DmsFrontEnd_2000_MList_transfer_TOUR_NO_to}    ${TOUR_NO}
        END

        Take Screenshot   
#        Sleep  1s


dms_dmsweb2_ClickDmsFrontEnd_2000_MList_transfer_ACC_DATE
        [Arguments]  ${ACC_DATE}  ${string}
        [Documentation]
        [Tags]

        Log  ${string}
        IF  '${string}' == '2900'
#            ${matchN}  ${LOG_ACC_DATE}=  Run Keyword And Warn On Failure    Browser.Get Text      ${xpath_DmsFrontEnd_2900_MList_transfer_ACC_DATE_from}

            ${matchN}  ${LOG_ACC_DATE}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[3]/div[2]/div[2]/div/div/div[1]/div[1]/div[2]/div[1]/input

            Log  ${matchN}
            Log  ${LOG_ACC_DATE} 
            Fill Text   ${xpath_DmsFrontEnd_2900_MList_transfer_ACC_DATE_from}    113/01/01
            Fill Text   ${xpath_DmsFrontEnd_2900_MList_transfer_ACC_DATE_to}    ${ACC_DATE}

        ELSE  #${string}=  2000
            ${matchN}  ${LOG_ACC_DATE}=  Run Keyword And Warn On Failure    Browser.Get Text      ${xpath_DmsFrontEnd_2000_MList_transfer_ACC_DATE_from}

            Log  ${matchN}
            Log  ${LOG_ACC_DATE} 
            Fill Text   ${xpath_DmsFrontEnd_2000_MList_transfer_ACC_DATE_from}    113/01/01
            Fill Text   ${xpath_DmsFrontEnd_2000_MList_transfer_ACC_DATE_to}    ${ACC_DATE}

        END



        Take Screenshot   
#        Sleep  1s


dms_dmsweb2_ClickDmsFrontEnd_2000ACC_DATE
        [Arguments]  ${ACC_DATE}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_2000ACC_DATE}    ${ACC_DATE}
#        Fill Text   ${xpath_DmsFrontEnd_2000ACC_DATE}    114/04/01   
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_2000TOUR_NO
        [Arguments]  ${TOUR_NO}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_2000TOUR_NO}  ${TOUR_NO}   
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_2000MList_NO
        [Arguments]  ${MList_NO}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_2000MList_NO}  ${MList_NO}   
#        Sleep  1s


dms_dmsweb2_ClickDmsFrontEnd_2000MLIST_NO_M1A0
        [Arguments]  ${MLIST_NO_M1A0}
        [Documentation]
        [Tags]
        Fill Text   ${xpath_DmsFrontEnd_2000MLIST_NO_M1A0}  ${MLIST_NO_M1A0}   
#        Sleep  1s


dms_dmsweb2_ClickDmsFrontEnd_2000STAFF_NO
#        [Arguments]  ${STAFF_NO}
        [Documentation]
        [Tags]
        Click   ${xpath_DmsFrontEnd_2000STAFF_NO}   
#        Sleep  1s
#        Debug
        Keyboard Key    down     Control
        Keyboard Key    press    A
        Keyboard Key    up       Control  
#        Sleep  1s  
#        Debug    
        Keyboard Key    press    Delete 
#        Sleep  1s  
#        Debug 
#        Sleep  1s

dms_dmsweb2_ClickDmsFrontEnd_2000RCV_OFFICE
        [Arguments]    ${RCV_OFFICE}
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}
        Take Screenshot
        Sleep  1s
        Take Screenshot
        Click   ${xpath_DmsFrontEnd_2000RCV_OFFICE}
        IF  '${RCV_OFFICE}' == '1'
                Fail      
        ELSE IF  '${RCV_OFFICE}' == '2'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2000RCV_OFFICEoption2}
        ELSE IF  '${RCV_OFFICE}' == '3'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2000RCV_OFFICEoption3}
        ELSE IF  '${RCV_OFFICE}' == '4'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2000RCV_OFFICEoption4}
        ELSE
                Fail 
        END
#        Sleep  1s
#        Handle Alert


dms_dmsweb2_ClickDmsFrontEnd_2000MAIL_TYPE
        [Arguments]    ${.MAIL_TYPE}
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}
        Take Screenshot
        Click   ${xpath_DmsFrontEnd_2000MAIL_TYPE}
        IF  '${.MAIL_TYPE}' == '1'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2000MAIL_TYPEoption1}      
        ELSE IF  '${.MAIL_TYPE}' == '2'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2000MAIL_TYPEoption2}
        ELSE IF  '${.MAIL_TYPE}' == '3'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2000MAIL_TYPEoption3}
        ELSE IF  '${.MAIL_TYPE}' == '4'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2000MAIL_TYPEoption4}
        ELSE IF  '${.MAIL_TYPE}' == 'B'
                Take Screenshot
                Click   ${xpath_DmsFrontEnd_2000MAIL_TYPEoptionB}
        ELSE
                Fail 
        END
#        Sleep  1s
#        Handle Alert


dms_dmsweb2_ClickDmsFrontEnd_2000EndButton
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}
        Click    ${xpath_DmsFrontEnd_2000EndButton}
#        Sleep  1s
#        Handle Alert

dms_dmsweb2_ClickDmsFrontEnd_2000SendButton
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}
        Click    ${xpath_DmsFrontEnd_2000SendButton}
#        Sleep  1s
#        Handle Alert


dms_dmsweb2_ClickDmsFrontEnd_2300EndButton
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}
        Click    ${xpath_DmsFrontEnd_2300EndButton}
#        Sleep  1s
#        Handle Alert

dms_dmsweb2_ClickDmsFrontEnd_2300SendButton
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}
        Click    ${xpath_DmsFrontEnd_2300SendButton}
#        Sleep  1s
#        Handle Alert


dms_dmsweb2_ClickDmsFrontEnd_2301_F3_Button
        [Documentation]
        [Tags]

        Click    ${xpath_DmsFrontEnd_2301_F3_Button}






dms_dmsweb2_FetchDmsFrontEnd_2000_transfer_ACC_DATE
        [Arguments]   ${string}  ${i}
        [Documentation]
        [Tags]

        Log  ${string}
        IF  '${string}' == '2900'
            ${match}  ${transfer_ACC_DATE}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[3]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[3]  
            
        ELSE  #${string}=  2000 
            ${match}  ${transfer_ACC_DATE}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[3] 
        END

        RETURN    ${match}  ${transfer_ACC_DATE}


dms_dmsweb2_FetchDmsFrontEnd_2000_transfer_TOUR_NO
        [Arguments]    ${string}  ${i}
        [Documentation]
        [Tags]
        

        Log  ${string}
        IF  '${string}' == '2900'
            ${match}  ${transfer_TOUR_NO}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[3]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[4]   
            
        ELSE  #${string}=  2000 
            ${match}  ${transfer_TOUR_NO}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[4]  
        END

        RETURN    ${match}  ${transfer_TOUR_NO}

dms_dmsweb2_FetchDmsFrontEnd_2000_transfer_RCV_OFFICE
        [Arguments]    ${string}  ${i}
        [Documentation]
        [Tags]

       
        Log  ${string}
        IF  '${string}' == '2900'
            ${match}  ${transfer_RCV_OFFICE}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[3]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[6]   
           
        ELSE  #${string}=  2000 
            ${match}  ${transfer_RCV_OFFICE}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[6]  
        END

        RETURN    ${match}  ${transfer_RCV_OFFICE}

dms_dmsweb2_FetchDmsFrontEnd_2000_transfer_MAIL_TYPE
        [Arguments]   ${string}  ${i}
        [Documentation]
        [Tags]
         

        Log  ${string}
        IF  '${string}' == '2900'
            ${match}  ${transfer_MAIL_TYPE}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[3]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[7]   
           
        ELSE  #${string}=  2000 
            ${match}  ${transfer_MAIL_TYPE}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[7]  
        END


        RETURN    ${match}  ${transfer_MAIL_TYPE}



dms_dmsweb2_FetchDmsFrontEnd_2000_transfer_MAIL_STATUS
        [Arguments]   ${string}  ${i}
        [Documentation]
        [Tags]

        Log  ${string}

        IF  '${string}' == '2902'
            ${match}  ${transfer_MAIL_STATUS}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[3]/div[2]/div[2]/table/tbody/tr[${i}] 
        ELSE  #${string}= 2000,2900
            ${match}  ${transfer_MAIL_STATUS}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[2]/div[3]/div[2]/div[2]/table/tbody/tr[${i}] 
        END        


        RETURN    ${match}  ${transfer_MAIL_STATUS}


dms_dmsweb2_FetchDmsFrontEnd_2000_transfer_MLIST_STATUS
        [Arguments]  ${string}   ${i}
        [Documentation]
        [Tags]

        IF  '${string}' == '2900'
            ${match}  ${transfer_MLIST_STATUS}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[3]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]
        ELSE  #${string}= 2000
            ${match}  ${transfer_MLIST_STATUS}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]  
        END   

        


        RETURN    ${match}  ${transfer_MLIST_STATUS}




dms_dmsweb2_FetchDmsFrontEnd_2301_transfer_MAIL_TYPE
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${transfer_MAIL_TYPE}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[7]
        RETURN    ${match}  ${transfer_MAIL_TYPE}


dms_dmsweb2_FetchDmsFrontEnd_2301_transfer_RCV_OFFICE
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${transfer_RCV_OFFICE}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[6]
        RETURN    ${match}  ${transfer_RCV_OFFICE}


dms_dmsweb2_FetchDmsFrontEnd_2301_login_MLIST_STATUS
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${login_MLIST_STATUS}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[2]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]
        RETURN    ${match}  ${login_MLIST_STATUS}



dms_dmsweb2_FetchDmsFrontEnd_2301_login_MAIL_NO_SRL
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${login_MAIL_NO_SRL}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[2]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[5]
        RETURN    ${match}  ${login_MAIL_NO_SRL}


dms_dmsweb2_FetchDmsFrontEnd_2301_login_MAIL_NO
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${login_MAIL_NO}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[2]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[4]
        RETURN    ${match}  ${login_MAIL_NO}


dms_dmsweb2_FetchDmsFrontEnd_2301_MLIST_NO_M120
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${MLIST_NO_M120}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[3]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[4]
        RETURN    ${match}  ${MLIST_NO_M120}




dms_dmsweb2_FetchDmsFrontEnd_2301_MLIST_STATUS
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${MLIST_STATUS}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]
        RETURN    ${match}  ${MLIST_STATUS}



dms_dmsweb2_FetchDmsFrontEnd_2301_INOP_CNT
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${INOP_CNT}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[10]
        RETURN    ${match}  ${INOP_CNT}


dms_dmsweb2_FetchDmsFrontEnd_2301_INLP_CNT
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${INLP_CNT}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[9]
        RETURN    ${match}  ${INLP_CNT}


dms_dmsweb2_FetchDmsFrontEnd_2301_BIDDING
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${BIDDING}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[8]
        RETURN    ${match}  ${BIDDING}

dms_dmsweb2_FetchDmsFrontEnd_2301_C_CNT
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${C_CNT}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[7]
        RETURN    ${match}  ${C_CNT}


dms_dmsweb2_FetchDmsFrontEnd_2301_RCL_CNT
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${RCL_CNT}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[6]
        RETURN    ${match}  ${RCL_CNT}


dms_dmsweb2_FetchDmsFrontEnd_2301_PCK_CNT
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${PCK_CNT}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[5]
        RETURN    ${match}  ${PCK_CNT}


dms_dmsweb2_FetchDmsFrontEnd_2301_ORG_OFFICE
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${ORG_OFFICE}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[4]
        RETURN    ${match}  ${ORG_OFFICE}

dms_dmsweb2_FetchDmsFrontEnd_2301_ORG_OFFICE_M120
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${ORG_OFFICE_M120}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[3]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[5]
        RETURN    ${match}  ${ORG_OFFICE_M120}


dms_dmsweb2_FetchDmsFrontEnd_2301_COR_MLIST
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${COR_MLIST}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[3]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[7]
        RETURN    ${match}  ${COR_MLIST}


dms_dmsweb2_FetchDmsFrontEnd_2301_MLIST_NO
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${MLIST_NO}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[3]
        RETURN    ${match}  ${MLIST_NO}



dms_dmsweb2_FetchDmsFrontEnd_2301_F3_IN_TYPE_CODE
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${IN_TYPE_CODE}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[3]
        RETURN    ${match}  ${IN_TYPE_CODE}

dms_dmsweb2_FetchDmsFrontEnd_2301_F3_ORG_OFFICE
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${ORG_OFFICE}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[5]
        RETURN    ${match}  ${ORG_OFFICE}

dms_dmsweb2_FetchDmsFrontEnd_2301_F3_MLIST_NO
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${MLIST_NO}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[4]
        RETURN    ${match}  ${MLIST_NO}



dms_dmsweb2_FetchDmsFrontEnd_2301_F3_MLIST_STATUS
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${MLIST_STATUS}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td
        RETURN    ${match}  ${MLIST_STATUS}



dms_dmsweb2_FetchDmsFrontEnd_2301_F3_INOP_CNT
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${INOP_CNT}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[11]
        RETURN    ${match}  ${INOP_CNT}


dms_dmsweb2_FetchDmsFrontEnd_2301_F3_INLP_CNT
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${INLP_CNT}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[10]
        RETURN    ${match}  ${INLP_CNT}


dms_dmsweb2_FetchDmsFrontEnd_2301_F3_BIDDING
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${BIDDING}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[9]
        RETURN    ${match}  ${BIDDING}

dms_dmsweb2_FetchDmsFrontEnd_2301_F3_C_CNT
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${C_CNT}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[8]
        RETURN    ${match}  ${C_CNT}


dms_dmsweb2_FetchDmsFrontEnd_2301_F3_RCL_CNT
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${RCL_CNT}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[7]
        RETURN    ${match}  ${RCL_CNT}


dms_dmsweb2_FetchDmsFrontEnd_2301_F3_PCK_CNT
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${PCK_CNT}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[6]
        RETURN    ${match}  ${PCK_CNT}






dms_dmsweb2_FetchDmsFrontEnd_2000_REC_OFFICE
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${REC_OFFICE}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[6]
        RETURN    ${match}  ${REC_OFFICE}

dms_dmsweb2_FetchDmsFrontEnd_2000_MAIL_TYPE
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${MAIL_TYPE}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[7] 	
        RETURN    ${match}  ${MAIL_TYPE}

dms_dmsweb2_FetchDmsFrontEnd_2000_MLIST_NO_M1A0
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${MLIST_NO_M1A0}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[8]	
#        RETURN    ${match}  ${MLIST_NO_M1A0}
        RETURN    ${MLIST_NO_M1A0}


dms_dmsweb2_FetchDmsFrontEnd_2000_MLIST_STATE
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${MLIST_STATE}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[9]	
        RETURN    ${match}  ${MLIST_STATE}



dms_dmsweb2_FetchDmsFrontEnd_2000_MLIST_STATUS
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${MLIST_STATUS}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]
        RETURN    ${match}  ${MLIST_STATUS}


dms_dmsweb2_FetchDmsFrontEnd_2000_transfer_MAIL_NO
        [Arguments]   ${string}  ${i}  
        [Documentation]
        [Tags]
        Log  ${string} 
        IF  '${string}' == '2902'
            ${match}  ${transfer_MAIL_NO}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[3]
        ELSE  #${sting}= 2000,2900
            ${match}  ${transfer_MAIL_NO}=  Run Keyword And Warn On Failure    Browser.Get Text   xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[2]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[3]

        END

        RETURN    ${match}  ${transfer_MAIL_NO}



dms_dmsweb2_FetchDmsFrontEnd_2300_IN_TYPE
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${IN_TYPE}=  Run Keyword And Warn On Failure    Browser.Get Text           xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[3]
        RETURN    ${match}  ${IN_TYPE}




dms_dmsweb2_FetchDmsFrontEnd_2300_MLST_TYPE
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${MLST_TYPE}=  Run Keyword And Warn On Failure    Browser.Get Text           xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[4]
        RETURN    ${match}  ${MLST_TYPE}



dms_dmsweb2_FetchDmsFrontEnd_2300_MLIST_NO
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${MLIST_NO}=  Run Keyword And Warn On Failure    Browser.Get Text           xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[5]
        RETURN    ${match}  ${MLIST_NO}


dms_dmsweb2_FetchDmsFrontEnd_2300_ORG_OFFICE 
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${ORG_OFFICE}=  Run Keyword And Warn On Failure    Browser.Get Text           xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[6]
        RETURN    ${match}  ${ORG_OFFICE}



dms_dmsweb2_FetchDmsFrontEnd_2300_DST_OFFICE 
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${DST_OFFICE}=  Run Keyword And Warn On Failure    Browser.Get Text           xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[7]
        RETURN    ${match}  ${DST_OFFICE}



dms_dmsweb2_FetchDmsFrontEnd_2300_COR 
        [Arguments]   ${i}
        [Documentation]
        [Tags]
        ${match}  ${COR}=  Run Keyword And Warn On Failure    Browser.Get Text           xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[8]
        RETURN    ${match}  ${COR}




dms_dmsweb2_DmsFrontEnd_2000_stage1_1
        [Arguments]   ${excel_file_data}  ${string}  ${string2}
        [Documentation]
        [Tags]
        Take Screenshot

        ${match2}=  set variable  False 
        ${match1}  ${REC_OFFICE}=  dms_dmsweb2_FetchDmsFrontEnd_2000_REC_OFFICE  1


	    IF	'${match1}' == 'FAIL'

                        dms_dmsweb2_DmsFrontEnd_2000_stage1_c   ${excel_file_data}  ${string2}

			
			Take Screenshot
			Sleep  1s
			Take Screenshot
			${match1}  ${REC_OFFICE}=  dms_dmsweb2_FetchDmsFrontEnd_2000_REC_OFFICE  1

			${match2}=  set variable  True 
	    END
        Log  ${REC_OFFICE}
        Log  ${REC_OFFICE}[0]
        Log  ${excel_file_data}[3]

   	    IF	'${REC_OFFICE}[0]' == '${excel_file_data}[3]'
                ${match1}  ${MAIL_TYPE}=  dms_dmsweb2_FetchDmsFrontEnd_2000_MAIL_TYPE  1

            Log  ${MAIL_TYPE}
            Log  ${MAIL_TYPE}[0] 
            Log  ${excel_file_data}[4]  

   	    	IF	'${MAIL_TYPE}[0]' == '${excel_file_data}[4]'
   	    		${match1}  ${MLIST_STATE}=  dms_dmsweb2_FetchDmsFrontEnd_2000_MLIST_STATE  1
   	    	    IF	'${MLIST_STATE}' == 'N. 未結單'
   	    	        IF  '${string}' == 'login'
   	    	            ${match1}=    dms_dmsweb2_FetchDmsFrontEnd_2000_MLIST_NO_M1A0  1
       	                dms_dmsweb2_ClickDmsFrontEnd_2000_MList_login_button   ${excel_file_data}   1
                    ELSE IF  '${string}' == 'checkout'
                        dms_dmsweb2_ClickDmsFrontEnd_2000_MList_checkout_button   ${excel_file_data}   1
                    ELSE IF  '${string}' == 'transfer'
                        dms_dmsweb2_ClickDmsFrontEnd_2000_MList_transfer_button   ${excel_file_data}   1
       	            ELSE
                        Fail
                    END
       	            ${match2}=  set variable  True  
#   	    	    	BREAK
   	    	    END
   	    	END
   	    END

        RETURN    ${match1}  ${match2}





dms_dmsweb2_DmsFrontEnd_2000_stage1_i
    [Arguments]  ${match2}  ${excel_file_data}  ${string}
    [Documentation]
    [Tags]
    Take Screenshot

    ${match3}=  set variable   FAIL

	FOR  ${i}  IN RANGE  2  1000  1

	    IF	'${match2}' == 'True'
		    Exit For Loop
	    END

        ${match3}  ${MLIST_STATUS}=  dms_dmsweb2_FetchDmsFrontEnd_2000_MLIST_STATUS  ${i}

	    Log  ${match3}
	    Log  ${MLIST_STATUS}
	    Log  ${MLIST_STATUS}[0]
	    Take Screenshot

	    IF	'${match3}' == 'FAIL'

		    Exit For Loop
	    END

	    IF	'${MLIST_STATUS}[0]' == '刪'

		    CONTINUE FOR LOOP
	    END

                ${match3}  ${REC_OFFICE}=  dms_dmsweb2_FetchDmsFrontEnd_2000_REC_OFFICE  ${i}

                Log  ${REC_OFFICE}
                Log  ${REC_OFFICE}[0]
                Log  ${excel_file_data}[3]

	    	    IF	'${REC_OFFICE}[0]' == '${excel_file_data}[3]'
	                ${match3}  ${MAIL_TYPE}=  Run Keyword And Warn On Failure    Browser.Get Text        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[7] 	

                    Log  ${MAIL_TYPE}
                    Log  ${MAIL_TYPE}[0] 
                    Log  ${excel_file_data}[4]  

	    	    	IF	'${MAIL_TYPE}[0]' == '${excel_file_data}[4]'
	    	    		${match3}  ${MLIST_STATE}=  dms_dmsweb2_FetchDmsFrontEnd_2000_MLIST_STATE  ${i}
	    	    	    IF	'${MLIST_STATE}' == 'N. 未結單'
	    	    	       	IF  '${string}' == 'login'
	    	    	       	    ${match3}=    dms_dmsweb2_FetchDmsFrontEnd_2000_MLIST_NO_M1A0  ${i}
       	                       	dms_dmsweb2_ClickDmsFrontEnd_2000_MList_login_button   ${excel_file_data}   ${i}
                            ELSE IF  '${string}' == 'checkout'
                               	dms_dmsweb2_ClickDmsFrontEnd_2000_MList_checkout_button   ${excel_file_data}   ${i}
                            ELSE IF  '${string}' == 'transfer'
                               	dms_dmsweb2_ClickDmsFrontEnd_2000_MList_transfer_button   ${excel_file_data}   ${i}
       	                    ELSE
                               	Fail
                            END
	        	            ${match2}=  set variable  True 
	    	    	    	BREAK
	    	    	    END
	    	    	END
	    	    END

		${total_column}=  set variable  ${i}
		Take Screenshot
	END

    RETURN    ${match2}  ${match3}



dms_dmsweb2_DmsFrontEnd_2000_stage1_c
        [Arguments]   ${excel_file_data}  ${string}
        [Documentation]
        [Tags]
        Take Screenshot

		dms_dmsweb2_ClickDmsFrontEnd_2000NewMListButton   ${excel_file_data}   ${excel_file_data}
		IF  '${string}' == '2900'
            Take Screenshot
		ELSE
		    dms_dmsweb2_ClickDmsFrontEnd_2000RCV_OFFICE  ${excel_file_data}[3]
		    dms_dmsweb2_ClickDmsFrontEnd_2000MAIL_TYPE  ${excel_file_data}[4]
		END
		dms_dmsweb2_ClickDmsFrontEnd_2000SendButton	 
		Take Screenshot
		${MList_NO}=  dms_dmsweb2_FetchDmsFrontEnd_2000New_MList_NO	
		Take Screenshot
		dms_dmsweb2_ClickDmsFrontEnd_2000EndButton	
		Take Screenshot

#        IF  '${string}' == '2900'
		    Sleep  1s
            Take Screenshot
            #Keyboard Key    press       F7
            Keyboard Key    press       F9
#        END

#		dms_dmsweb2_ClickDmsFrontEnd_2000ACC_DATE  ${excel_file_data}[1]
#		dms_dmsweb2_ClickDmsFrontEnd_2000TOUR_NO   ${excel_file_data}[2]
#    	dms_dmsweb2_ClickDmsFrontEnd_2000MList_NO  ${MList_NO}

#		dms_dmsweb2_ClickDmsFrontEnd_2000FetchButton

#		dms_dmsweb2_ClickDmsFrontEnd_2000_MList_login_button  1


dms_dmsweb2_DmsFrontEnd_2000_stage3_transfer_fetch
        [Arguments]   ${excel_file_data}  ${string}
        [Documentation]
        [Tags]
        Take Screenshot
        dms_dmsweb2_DmsFrontEnd_2000_stage2_transfer_fetch   ${excel_file_data}  ${string}


dms_dmsweb2_DmsFrontEnd_2000_stage2_transfer_fetch
        [Arguments]   ${excel_file_data}  ${string}
        [Documentation]
        [Tags]
        Take Screenshot

	    dms_dmsweb2_ClickDmsFrontEnd_2000_MList_transfer_ACC_DATE  ${excel_file_data}[19]  ${string}

	    dms_dmsweb2_ClickDmsFrontEnd_2000_MList_transfer_TOUR_NO  ${excel_file_data}[20]  ${string}

        dms_dmsweb2_ClickDmsFrontEnd_2000_MList_transfer_STAFF_NO  ${string}

        IF  '${string}' == 2000
            dms_dmsweb2_ClickDmsFrontEnd_2000_MList_transfer_RCV_OFFICE   ${excel_file_data}[21] 
        ELSE  #${string}=  2900
            Take Screenshot
        END

        dms_dmsweb2_ClickDmsFrontEnd_2000_MList_transfer_FetchButton   ${excel_file_data}  ${string}


dms_dmsweb2_DmsFrontEnd_2000_stage3_1
        [Arguments]   ${excel_file_data}  ${string}
        [Documentation]
        [Tags]
        Take Screenshot
        ${match1}  ${match2}=    dms_dmsweb2_DmsFrontEnd_2000_stage2_1    ${excel_file_data}  ${string} 

        Log  ${match1}
        Log  ${match2}

dms_dmsweb2_DmsFrontEnd_2000_stage2_1
        [Arguments]   ${excel_file_data}  ${string}
        [Documentation]
        [Tags]
        Take Screenshot

        ${match2}=  set variable  False  
        ${match1}  ${transfer_ACC_DATE}=  dms_dmsweb2_FetchDmsFrontEnd_2000_transfer_ACC_DATE  ${string}  1

	    IF	'${match1}' == 'FAIL'
		    ${result_data}=  set variable  FAIL

	    END
        Log  ${transfer_ACC_DATE}
        Log  ${excel_file_data}[19]

   	    IF	'${transfer_ACC_DATE}' == '${excel_file_data}[19]'
                ${match1}  ${transfer_TOUR_NO}=  dms_dmsweb2_FetchDmsFrontEnd_2000_transfer_TOUR_NO  ${string}  1	

            Log  ${transfer_TOUR_NO} 
            Log  ${excel_file_data}[20]  

   	    	IF	'${transfer_TOUR_NO}' == '${excel_file_data}[20]'
   	    		${match1}  ${transfer_RCV_OFFICE}=  dms_dmsweb2_FetchDmsFrontEnd_2000_transfer_RCV_OFFICE  ${string}  1

                Log  ${transfer_RCV_OFFICE}
                Log  ${transfer_RCV_OFFICE}[0] 
                Log  ${excel_file_data}[21]  

   	    	    IF	'${transfer_RCV_OFFICE}' == '${excel_file_data}[21]'

   	    	       	${match1}  ${transfer_MAIL_TYPE}=  dms_dmsweb2_FetchDmsFrontEnd_2000_transfer_MAIL_TYPE  ${string}  1

                    Log  ${transfer_MAIL_TYPE}
                    Log  ${transfer_MAIL_TYPE}[0] 
                    Log  ${excel_file_data}[4]

   	    	        IF	'${transfer_MAIL_TYPE}[0]' == '${excel_file_data}[4]'

        	            dms_dmsweb2_ClickDmsFrontEnd_2000_MList_transfer_check_button   ${excel_file_data}   ${string}  1
       	                ${match2}=  set variable  True  

                     END
   	    	    END
   	    	END
   	    END
   	    RETURN    ${match1}  ${match2}



dms_dmsweb2_DmsFrontEnd_2000_stage3_i
        [Arguments]   ${match2}    ${excel_file_data}  ${string}
        [Documentation]
        [Tags]
        Take Screenshot

        ${match2}  ${match3}=    dms_dmsweb2_DmsFrontEnd_2000_stage2_i  ${match2}    ${excel_file_data}  ${string}

        Log  ${match2}
        Log  ${match3}

dms_dmsweb2_DmsFrontEnd_2000_stage2_i
    [Arguments]   ${match2}  ${excel_file_data}  ${string}
    [Documentation]
    [Tags]
    Take Screenshot

    ${match3}=    set variable   FAIL

	FOR  ${i}  IN RANGE  2  1000  1

	    IF	'${match2}' == 'True'
		    Exit For Loop
	    END
 
        ${match3}  ${transfer_MLIST_STATUS}=  dms_dmsweb2_FetchDmsFrontEnd_2000_transfer_MLIST_STATUS  ${string}  ${i}

	    Log  ${match3}
	    Log  ${transfer_MLIST_STATUS}
	    Log  ${transfer_MLIST_STATUS}[0]
	    Take Screenshot

	    IF	'${match3}' == 'FAIL'

		    Exit For Loop
	    END

	    IF	'${transfer_MLIST_STATUS}[0]' == '確'

		    CONTINUE FOR LOOP
	    END

                ${match3}  ${transfer_ACC_DATE}=  dms_dmsweb2_FetchDmsFrontEnd_2000_transfer_ACC_DATE  ${string}  ${i}

                Log  ${transfer_ACC_DATE}
                Log  ${excel_file_data}[19]

	    	    IF	'${transfer_ACC_DATE}' == '${excel_file_data}[19]'
	                ${match3}  ${transfer_TOUR_NO}=  dms_dmsweb2_FetchDmsFrontEnd_2000_transfer_TOUR_NO    ${string}  ${i} 	

                    Log  ${transfer_TOUR_NO}
                    Log  ${excel_file_data}[20]  

	    	    	IF	'${transfer_TOUR_NO}' == '${excel_file_data}[20]'
	    	    		${match3}  ${transfer_RCV_OFFICE}=  dms_dmsweb2_FetchDmsFrontEnd_2000_transfer_RCV_OFFICE  ${string}  ${1}


                        Log  ${transfer_RCV_OFFICE}
                        Log  ${transfer_RCV_OFFICE}[0] 
                        Log  ${excel_file_data}[21]  
	    	    	    IF	'${transfer_RCV_OFFICE}[0]' == '${excel_file_data}[21]'
   	    	       	        ${match1}  ${transfer_MAIL_TYPE}=  dms_dmsweb2_FetchDmsFrontEnd_2000_transfer_MAIL_TYPE  ${string}  ${i}

                            Log  ${transfer_MAIL_TYPE}
                            Log  ${transfer_MAIL_TYPE}[0] 
                            Log  ${excel_file_data}[4]

   	    	                IF	'${transfer_MAIL_TYPE}[0]' == '${excel_file_data}[4]'

        	                    dms_dmsweb2_ClickDmsFrontEnd_2000_MList_transfer_check_button   ${excel_file_data}   ${string}  ${i} 
        	                    ${match2}=  set variable  True
                            END
	    	    	    END
	    	    	END
	    	    END

	END
	RETURN    ${match2}  ${match3}


dms_dmsweb2_DmsFrontEnd_2000_stage22_1
        [Arguments]   ${excel_file_data}  ${string}  ${string2}
        [Documentation]
        [Tags]
        Take Screenshot


        ${match2}=  set variable  False  
        ${match1}  ${transfer_MAIL_NO}=  dms_dmsweb2_FetchDmsFrontEnd_2000_transfer_MAIL_NO  ${string2}  1  

	    IF	'${match1}' == 'FAIL'
#            IF    '${string}' == 'login'
                dms_dmsweb2_DmsFrontEnd_2000_stage22_c   ${excel_file_data}  ${string2}
#            END
			
			Take Screenshot
			${match1}  ${transfer_MAIL_NO}=  dms_dmsweb2_FetchDmsFrontEnd_2000_transfer_MAIL_NO  ${string2}  1

#			${match2}=  set variable  True 
	    END

        Log  ${transfer_MAIL_NO}
        Log  ${excel_file_data}[5]

   	    IF	'${transfer_MAIL_NO}' == '${excel_file_data}[5]'
            IF    '${string}' == 'transfer'
        	    dms_dmsweb2_ClickDmsFrontEnd_2000_mail_transfer_button   ${excel_file_data}   ${string2}  1
        	END
       	    ${match2}=  set variable  True
   	    END
        RETURN    ${match1}  ${match2}


dms_dmsweb2_DmsFrontEnd_2000_stage22_i
    [Arguments]   ${match2}  ${excel_file_data}  ${string}  ${string2}
    [Documentation]
    [Tags]
    Take Screenshot

    ${match3}=    set variable   FAIL

	FOR  ${i}  IN RANGE  2  1000  1

	    IF	'${match2}' == 'True'
		    Exit For Loop
	    END

#        ${match3}  ${transfer_MLIST_STATUS}=   dms_dmsweb2_FetchDmsFrontEnd_2000_transfer_MLIST_STATUS   ${i}
        Log  ${string}
        Log  ${string2}
        ${match3}  ${transfer_MAIL_STATUS}=         dms_dmsweb2_FetchDmsFrontEnd_2000_transfer_MAIL_STATUS  ${string2}  ${i}


	    Log  ${match3}
	    Log  ${transfer_MAIL_STATUS}
	    Log  ${transfer_MAIL_STATUS}[0]
	    Take Screenshot

	    IF	'${match3}' == 'FAIL'

		    Exit For Loop
	    END

#        IF  '${string2}' == '2902'
        	IF	'${transfer_MAIL_STATUS}[0]' == '刪'
		        CONTINUE FOR LOOP
	        END
#        ELSE  #${string2}= 2000,2900 
	        IF	'${transfer_MAIL_STATUS}[0]' == '修'
		        CONTINUE FOR LOOP
	        END
#        END

                ${match3}  ${transfer_MAIL_NO}=  dms_dmsweb2_FetchDmsFrontEnd_2000_transfer_MAIL_NO  ${string2}  ${i} 

                Log  ${transfer_MAIL_NO}
                Log  ${excel_file_data}[5]

	    	    IF	'${transfer_MAIL_NO}' == '${excel_file_data}[5]'
	                IF    '${string}' == 'transfer'
        	            dms_dmsweb2_ClickDmsFrontEnd_2000_mail_transfer_button   ${excel_file_data}   ${string2}  ${i} 
        	        END
        	        ${match2}=  set variable  True 	

                    
	    	    END
	END

    RETURN    ${match2}  ${match3}


dms_dmsweb2_DmsFrontEnd_2300_stage1_1
#        [Arguments]   ${excel_file_data}  ${string}
        [Arguments]   ${excel_file_data}
        [Documentation]
        [Tags]
        Take Screenshot

        ${match2}=  set variable  False 
        
#        ${match1}  ${IN_TYPE}=  Run Keyword And Warn On Failure    Browser.Get Text        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[3]/div[2]/div[2]/table/tbody/tr[1]/td[3]
        ${match1}  ${IN_TYPE}=  dms_dmsweb2_FetchDmsFrontEnd_2300_IN_TYPE  1


	    IF	'${match1}' == 'FAIL'
#            IF	'${string}' != 'mail'
	    	    dms_dmsweb2_DmsFrontEnd_2300_stage1_c       ${excel_file_data}
#            END
	    	Take Screenshot

			${match2}=  set variable  True 
	    END

        Log  ${excel_file_data}[3]


        
        Log  ${IN_TYPE}
        Log  ${IN_TYPE}[0:2]
        ${IN_TYPE_num}=  evaluate  'False'
        IF  '${IN_TYPE}[0:2]' != 'Ti'
            ${IN_TYPE_num}=    Convert to Integer  ${IN_TYPE}[0:2]
        END
        Log  ${IN_TYPE_num}

        Take Screenshot

   	    IF	'${IN_TYPE_num}' == '${excel_file_data}[3]'
#                ${match1}  ${MLST_TYPE}=  Run Keyword And Warn On Failure    Browser.Get Text        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[3]/div[2]/div[2]/table/tbody/tr[1]/td[4]
                ${match1}  ${MLST_TYPE}=      dms_dmsweb2_FetchDmsFrontEnd_2300_MLST_TYPE  1 	

            
            Log  ${excel_file_data}[4]
            Log  ${MLST_TYPE}
            Log  ${MLST_TYPE}[0]  

   	    	IF	'${MLST_TYPE}[0]' == '${excel_file_data}[4]'
#   	    		${match1}  ${MLIST_NO}=  Run Keyword And Warn On Failure    Browser.Get Text        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[3]/div[2]/div[2]/table/tbody/tr[1]/td[5]
   	    		${match1}  ${MLIST_NO}=        dms_dmsweb2_FetchDmsFrontEnd_2300_MLIST_NO  1 	


   	    		Log  ${MLIST_NO}
   	    		Log  ${excel_file_data}[12]

   	    	    IF	'${MLIST_NO}' == '${excel_file_data}[12]'
#   	    	        ${match1}  ${ORG_OFFICE}=  Run Keyword And Warn On Failure    Browser.Get Text        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[3]/div[2]/div[2]/table/tbody/tr[1]/td[6]
   	    	        ${match1}  ${ORG_OFFICE}=        dms_dmsweb2_FetchDmsFrontEnd_2300_ORG_OFFICE  1

   	    	        Log  ${ORG_OFFICE}
   	    	        Log  ${ORG_OFFICE}[0:6]
   	    	        Log  ${excel_file_data}[8]

   	    	        IF	'${ORG_OFFICE}[0:6]' == '${excel_file_data}[8]'
#   	    	            ${match1}  ${DST_OFFICE}=  Run Keyword And Warn On Failure    Browser.Get Text        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[3]/div[2]/div[2]/table/tbody/tr[1]/td[7]
   	    	            ${match1}  ${DST_OFFICE}=        dms_dmsweb2_FetchDmsFrontEnd_2300_DST_OFFICE  1


   	    	            Log  ${DST_OFFICE}
   	    	            Log  ${DST_OFFICE}[0:6]
   	    	            Log  ${excel_file_data}[7]
   	    	            IF  '${excel_file_data}[7]' == 'None'
   	    	                 ${excel_file_data}[7]=  evaluate  ''
   	    	            END
   	    	            Log  ${excel_file_data}[7]

   	    	            IF	'${DST_OFFICE}[0:6]' == '${excel_file_data}[7]'
#   	    	                ${match1}  ${COR}=  Run Keyword And Warn On Failure    Browser.Get Text        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[3]/div[2]/div[2]/table/tbody/tr[1]/td[8]
   	    	                ${match1}  ${COR}=        dms_dmsweb2_FetchDmsFrontEnd_2300_COR  1
   	    	                Log  ${COR}

                            IF	'${COR}' == '${excel_file_data}[9]'
#       	            dms_dmsweb2_ClickDmsFrontEnd_2000_MList_login_button   ${excel_file_data}   1
       	                        ${match2}=  set variable  True  
       	                    END
                        END
                    END
   	    	    END
   	    	END
   	    END

        Take Screenshot
        RETURN    ${match1}  ${match2}



dms_dmsweb2_DmsFrontEnd_2300_stage1_i
    [Arguments]   ${match2}   ${excel_file_data}  
    [Documentation]
    [Tags]
    Take Screenshot


    ${match3}=    set variable   FAIL
	FOR  ${i}  IN RANGE  2  1000  1

	    IF	'${match2}' == 'True'
		    Exit For Loop
	    END




        ${match3}  ${MLIST_STATUS}=  Run Keyword And Warn On Failure    Browser.Get Text        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]

	    Log  ${match3}
	    Log  ${MLIST_STATUS}
	    Log  ${MLIST_STATUS}[0]
	    Take Screenshot

	    IF	'${match3}' == 'FAIL'
#		    ${result_data}=  set variable  FAIL
		    Exit For Loop
	    END

	    IF	'${MLIST_STATUS}[0]' == '修'
#		    ${result_data}=  set variable  FAIL
		    CONTINUE FOR LOOP
	    END

#	    CONTINUE FOR LOOP

#			FOR  ${sensor_name}  IN  @{sensor_check_list}
#                ${match3}  ${IN_TYPE}=  Run Keyword And Warn On Failure    Browser.Get Text        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[3]/div[2]/div[2]/table/tbody/tr[1]/td[3]
                ${match3}  ${IN_TYPE}=  dms_dmsweb2_FetchDmsFrontEnd_2300_IN_TYPE  ${i}

                Log  ${IN_TYPE}
                Log  ${IN_TYPE}[0:2]
                ${IN_TYPE_num}=  evaluate  'False'
                IF  '${IN_TYPE}[0:2]' != 'Ti'
                    ${IN_TYPE_num}=    Convert to Integer     ${IN_TYPE}[0:2]
                END
                Log  ${IN_TYPE_num}

	    	    IF	'${IN_TYPE_num}' == '${excel_file_data}[3]'
#	                ${match3}  ${MLST_TYPE}=  Run Keyword And Warn On Failure    Browser.Get Text        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[4]
	    	    	${match3}  ${MLST_TYPE}=  Run Keyword And Warn On Failure    dms_dmsweb2_FetchDmsFrontEnd_2300_MLST_TYPE  ${i}

                    Log  ${excel_file_data}[4]
                    Log  ${MLST_TYPE}
                    Log  ${MLST_TYPE}[0] 
                    Log  ${MLST_TYPE}[1]
                    Log  ${MLST_TYPE}[1][0]
                    Log_To_Console  ${MLST_TYPE}[1][0]
#                    Debug

#	    	    	IF	'${MLST_TYPE}[0]' == '${excel_file_data}[4]'
	    	    	IF	'${MLST_TYPE}[1][0]' == '${excel_file_data}[4]'
#	    	    		${match3}  ${MLIST_NO}=  Run Keyword And Warn On Failure    Browser.Get Text        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[5]
	    	    		${match3}  ${MLIST_NO}=        dms_dmsweb2_FetchDmsFrontEnd_2300_MLIST_NO  ${i} 

                        Log  ${MLIST_NO}
                        Log  ${excel_file_data}[12]

	    	    	    IF	'${MLIST_NO}' == '${excel_file_data}[12]'
#	    	    		    ${match3}  ${ORG_OFFICE}=  Run Keyword And Warn On Failure    Browser.Get Text        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[6]
   	    	        	    ${match1}  ${ORG_OFFICE}=        dms_dmsweb2_FetchDmsFrontEnd_2300_ORG_OFFICE  ${i}


                            Log  ${ORG_OFFICE}
                            Log  ${ORG_OFFICE}[0:6]
   	    	                Log  ${excel_file_data}[8]

	    	    	        IF	'${ORG_OFFICE}[0:6]' == '${excel_file_data}[8]'
#	    	    		        ${match3}  ${DST_OFFICE}=  Run Keyword And Warn On Failure    Browser.Get Text        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]/td[7]
   	    	                    ${match3}  ${DST_OFFICE}=        dms_dmsweb2_FetchDmsFrontEnd_2300_DST_OFFICE  ${i}
                                Log  ${DST_OFFICE}
   	    	                    Log  ${DST_OFFICE}[0:6]
   	    	                    Log  ${excel_file_data}[7]
   	    	                    IF  '${excel_file_data}[7]' == 'None'
   	    	                        ${excel_file_data}[7]=  evaluate  ''
   	    	                    END
   	    	                    Log  ${excel_file_data}[7]

#	    	    	            IF	'${DST_OFFICE}[0:6]' == '${excel_file_data}[7]'

   	    	                        ${match3}  ${COR}=        dms_dmsweb2_FetchDmsFrontEnd_2300_COR  ${i}
                                    Log  ${COR}

	    	    	                IF	'${COR}' == '${excel_file_data}[9]'


#	        	            dms_dmsweb2_ClickDmsFrontEnd_2000_MList_login_button   ${excel_file_data}   ${i}
	        	                        ${match2}=  set variable  True 
	    	    	    	            BREAK



                                    END
#                                END
	    	    	    	END
	    	    	    END
	    	    	END
	    	    END



#			END
#		Run Keyword If    '${result_data}'=='FAIL'    Exit For Loop
		${total_column}=  set variable  ${i}
		Take Screenshot
	END

    RETURN    ${match2}  ${match3}


dms_dmsweb2_DmsFrontEnd_2300_stage1_c
        [Arguments]   ${excel_file_data}  
        [Documentation]
        [Tags]
        Take Screenshot

		dms_dmsweb2_ClickDmsFrontEnd_2000NewMListButton   ${excel_file_data} 

#		Debug
		dms_dmsweb2_ClickDmsFrontEnd_2300MLST_TYPE   ${excel_file_data}[4]
		dms_dmsweb2_ClickDmsFrontEnd_2300IN_TYPE   ${excel_file_data}[3]


		dms_dmsweb2_ClickDmsFrontEnd_2300MLIST_NO   ${excel_file_data}[12]
		dms_dmsweb2_ClickDmsFrontEnd_2300ORG_OFFICE   ${excel_file_data}[8]
        IF  '${excel_file_data}[4]' == '0'
		    dms_dmsweb2_ClickDmsFrontEnd_2300DST_OFFICE   ${excel_file_data}[7]
        END
		dms_dmsweb2_ClickDmsFrontEnd_2300COR   ${excel_file_data}[9]

		Take Screenshot
		Sleep  1s
		Take Screenshot

		dms_dmsweb2_ClickDmsFrontEnd_2300SendButton

		Take Screenshot
		Sleep  1s
		Take Screenshot

		dms_dmsweb2_ClickDmsFrontEnd_2300EndButton

		Take Screenshot
		Sleep  1s




dms_dmsweb2_DmsFrontEnd_2301_stage1_1
        [Arguments]   ${excel_file_data}  ${string}  
        [Documentation]
        [Tags]
        Take Screenshot

        Log  ${excel_file_data}
        Take Screenshot
        ${match2}=  set variable  False 
        
        ${match1}  ${MLIST_NO}=  dms_dmsweb2_FetchDmsFrontEnd_2301_MLIST_NO  1


	    IF	'${match1}' == 'FAIL'
	        IF	'${string}' == 'MList'
		        dms_dmsweb2_DmsFrontEnd_2301_stage1_c       ${excel_file_data}
		    END  
            Sleep  1s
            Take Screenshot

            ${match1}  ${MLIST_NO}=  dms_dmsweb2_FetchDmsFrontEnd_2301_MLIST_NO  1 
	    END
        Log  ${MLIST_NO}
        Log  ${excel_file_data}[12]



   	    IF	'${MLIST_NO}' == '${excel_file_data}[12]'

	        IF	'${string}' == 'mail' 
	    	    dms_dmsweb2_ClickDmsFrontEnd_2000_MList_login_button   ${excel_file_data}   1
   	    	    ${match2}=  set variable  True 
   	    	    RETURN    ${match1}  ${match2}
   	    	ELSE IF  '${string}' == 'M120'
   	    		dms_dmsweb2_ClickDmsFrontEnd_2000_M120_MList_login_button   ${excel_file_data}   1
   	    	    ${match2}=  set variable  True
   	    	    RETURN    ${match1}  ${match2}
	    	END

            ${match1}  ${ORG_OFFICE}=  dms_dmsweb2_FetchDmsFrontEnd_2301_ORG_OFFICE  1   

   	    	Log  ${ORG_OFFICE}
   	    	Log  ${ORG_OFFICE}[0:6]
   	    	Log  ${excel_file_data}[8]

   	    	IF	'${ORG_OFFICE}[0:6]' == '${excel_file_data}[8]'

   	    		${match1}  ${PCK_CNT}=  dms_dmsweb2_FetchDmsFrontEnd_2301_PCK_CNT  1

   	    	    Log  ${PCK_CNT}
   	    	    Log  ${excel_file_data}[13]

                IF  '${excel_file_data}[13]' == 'None'
                    ${excel_file_data}[13]=  evaluate  '0'
                END
   	    	    IF	'${PCK_CNT}' != '${excel_file_data}[13]'
                    Fail
   	    	    END

   	    		${match1}  ${RCL_CNT}=  dms_dmsweb2_FetchDmsFrontEnd_2301_RCL_CNT  1

   	    	    Log  ${RCL_CNT}
   	    	    Log  ${excel_file_data}[14]

                IF  '${excel_file_data}[14]' == 'None'
                    ${excel_file_data}[14]=  evaluate  '0'
                END
   	    	    IF	'${RCL_CNT}' != '${excel_file_data}[14]'
                    Fail
   	    	    END

   	    		${match1}  ${C_CNT}=  dms_dmsweb2_FetchDmsFrontEnd_2301_C_CNT  1

   	    	    Log  ${C_CNT}
   	    	    Log  ${excel_file_data}[15]

                IF  '${excel_file_data}[15]' == 'None'
                    ${excel_file_data}[15]=  evaluate  '0'
                END
   	    	    IF	'${C_CNT}' != '${excel_file_data}[15]'
                    Fail
   	    	    END

   	    		${match1}  ${BIDDING}=  dms_dmsweb2_FetchDmsFrontEnd_2301_BIDDING  1

   	    	    Log  ${BIDDING}
   	    	    Log  ${excel_file_data}[16]

                IF  '${excel_file_data}[16]' == 'None'
                    ${excel_file_data}[16]=  evaluate  '0'
                END
   	    	    IF	'${BIDDING}' != '${excel_file_data}[16]'
                    Fail
   	    	    END

   	    		${match1}  ${INLP_CNT}=  dms_dmsweb2_FetchDmsFrontEnd_2301_INLP_CNT  1

   	    	    Log  ${INLP_CNT}
   	    	    Log  ${excel_file_data}[17]

                IF  '${excel_file_data}[17]' == 'None'
                    ${excel_file_data}[17]=  evaluate  '0'
                END
   	    	    IF	'${INLP_CNT}' != '${excel_file_data}[17]'
                    Fail
   	    	    END

   	    		${match1}  ${INOP_CNT}=  dms_dmsweb2_FetchDmsFrontEnd_2301_INOP_CNT  1

   	    	    Log  ${INOP_CNT}
   	    	    Log  ${excel_file_data}[18]

                IF  '${excel_file_data}[18]' == 'None'
                    ${excel_file_data}[18]=  evaluate  '0'
                END
   	    	    IF	'${INOP_CNT}' != '${excel_file_data}[18]'
                    Fail
   	    	    END

                
   	    	    dms_dmsweb2_ClickDmsFrontEnd_2000_MList_login_button   ${excel_file_data}   1
   	    	    ${match2}=  set variable  True 
   	    	END
   	    END


        Take Screenshot
        RETURN    ${match1}  ${match2}




dms_dmsweb2_DmsFrontEnd_2301_stage1_i
    [Arguments]   ${match2}   ${excel_file_data}   ${string}  
    [Documentation]
    [Tags]
    Take Screenshot


    ${match3}=    set variable   FAIL
	FOR  ${i}  IN RANGE  2  1000  1

	    IF	'${match2}' == 'True'
		    Exit For Loop
	    END




        ${match3}  ${MLIST_STATUS}=  dms_dmsweb2_FetchDmsFrontEnd_2301_MLIST_STATUS  ${i}

	    Log  ${match3}
	    Log  ${MLIST_STATUS}
	    Log  ${MLIST_STATUS}[0]
	    Take Screenshot

	    IF	'${match3}' == 'FAIL'
#		    ${result_data}=  set variable  FAIL
		    Exit For Loop
	    END

	    IF	'${MLIST_STATUS}[0]' == '修'
#		    ${result_data}=  set variable  FAIL
		    CONTINUE FOR LOOP
	    END




                ${match3}  ${MLIST_NO}=  dms_dmsweb2_FetchDmsFrontEnd_2301_MLIST_NO   ${i} 

                Log  ${MLIST_NO}
                Log  ${excel_file_data}[12]

	    	    IF	'${MLIST_NO}' == '${excel_file_data}[12]'

	                IF	'${string}' == 'mail'
	    	            dms_dmsweb2_ClickDmsFrontEnd_2000_MList_login_button   ${excel_file_data}   ${i}
   	    	            ${match2}=  set variable  True  
	                ELSE IF  '${string}' == 'M120'
   	    		        dms_dmsweb2_ClickDmsFrontEnd_2000_M120_MList_login_button   ${excel_file_data}   ${i}
   	    	            ${match2}=  set variable  True
	    	        END

	                ${match3}  ${ORG_OFFICE}=  dms_dmsweb2_FetchDmsFrontEnd_2301_ORG_OFFICE   ${i} 	

                    Log  ${ORG_OFFICE}
                    Log  ${ORG_OFFICE}[0:6]
                    Log  ${excel_file_data}[8]  

	    	    	IF	'${ORG_OFFICE}[0:6]' == '${excel_file_data}[8]'
	    	    		${match3}  ${PCK_CNT}=  dms_dmsweb2_FetchDmsFrontEnd_2301_PCK_CNT  ${i}

   	    	    	    Log  ${PCK_CNT}
   	    	    	    Log  ${excel_file_data}[13]

                	    IF  '${excel_file_data}[13]' == 'None'
                	        ${excel_file_data}[13]=  evaluate  '0'
                	    END
   	    	    	    IF	'${PCK_CNT}' != '${excel_file_data}[13]'
                	        Fail
   	    	    	    END


   	    			    ${match1}  ${RCL_CNT}=  dms_dmsweb2_FetchDmsFrontEnd_2301_RCL_CNT  ${i}

   	    	    	    Log  ${RCL_CNT}
   	    	    	    Log  ${excel_file_data}[14]

                	    IF  '${excel_file_data}[14]' == 'None'
                	        ${excel_file_data}[14]=  evaluate  '0'
                	    END
   	    	    	    IF	'${RCL_CNT}' != '${excel_file_data}[14]'
                	        Fail
   	    	    	    END

   	    			    ${match1}  ${C_CNT}=  dms_dmsweb2_FetchDmsFrontEnd_2301_C_CNT  ${i}

   	    	    	    Log  ${C_CNT}
   	    	    	    Log  ${excel_file_data}[15]

                	    IF  '${excel_file_data}[15]' == 'None'
                	        ${excel_file_data}[15]=  evaluate  '0'
                	    END
   	    	    	    IF	'${C_CNT}' != '${excel_file_data}[15]'
                	        Fail
   	    	    	    END

   	    			    ${match1}  ${BIDDING}=  dms_dmsweb2_FetchDmsFrontEnd_2301_BIDDING  ${i}

   	    	    	    Log  ${BIDDING}
   	    	    	    Log  ${excel_file_data}[16]

                	    IF  '${excel_file_data}[16]' == 'None'
                	        ${excel_file_data}[16]=  evaluate  '0'
                	    END
   	    	    	    IF	'${BIDDING}' != '${excel_file_data}[16]'
                	        Fail
   	    	    	    END

   	    			    ${match1}  ${INLP_CNT}=  dms_dmsweb2_FetchDmsFrontEnd_2301_INLP_CNT  ${i}

   	    	    	    Log  ${INLP_CNT}
   	    	    	    Log  ${excel_file_data}[17]

                	    IF  '${excel_file_data}[17]' == 'None'
                	        ${excel_file_data}[17]=  evaluate  '0'
                	    END
   	    	    	    IF	'${INLP_CNT}' != '${excel_file_data}[17]'
                	        Fail
   	    	    	    END

   	    			    ${match1}  ${INOP_CNT}=  dms_dmsweb2_FetchDmsFrontEnd_2301_INOP_CNT   ${i}

   	    	    	    Log  ${INOP_CNT}
   	    	    	    Log  ${excel_file_data}[18]

                	    IF  '${excel_file_data}[18]' == 'None'
                	        ${excel_file_data}[18]=  evaluate  '0'
                	    END
   	    	    	    IF	'${INOP_CNT}' != '${excel_file_data}[18]'
                	        Fail
   	    	    	    END

   	    	    	    dms_dmsweb2_ClickDmsFrontEnd_2000_MList_login_button   ${excel_file_data}   ${i}
   	    	    	    ${match2}=  set variable  True 
	    	    	    
	    	    	END
	    	    END




		${total_column}=  set variable  ${i}
		Take Screenshot

	END

    RETURN    ${match2}  ${match3}






dms_dmsweb2_DmsFrontEnd_2301_stage1_c
    [Arguments]           ${excel_file_data} 
    [Documentation]
    [Tags]
    Take Screenshot

		    dms_dmsweb2_ClickDmsFrontEnd_2301_new_MList_button   ${excel_file_data} 
		    dms_dmsweb2_ClickDmsFrontEnd_2301_new_MList_MLIST_NO  ${excel_file_data}[12]
		    dms_dmsweb2_ClickDmsFrontEnd_2301_new_MList_ORG_OFFICE  ${excel_file_data}[8]
		    dms_dmsweb2_ClickDmsFrontEnd_2301_new_MList_PCK_CNT  ${excel_file_data}[13]
		    dms_dmsweb2_ClickDmsFrontEnd_2301_new_MList_RCL_CNT  ${excel_file_data}[14]
		    dms_dmsweb2_ClickDmsFrontEnd_2301_new_MList_C_CNT  ${excel_file_data}[15]
		    dms_dmsweb2_ClickDmsFrontEnd_2301_new_MList_BIDDING_CNT  ${excel_file_data}[16]
		    dms_dmsweb2_ClickDmsFrontEnd_2301_new_MList_INCL_CNT  ${excel_file_data}[17]
		    dms_dmsweb2_ClickDmsFrontEnd_2301_new_MList_INOP_CNT  ${excel_file_data}[18]
		    Debug
		    dms_dmsweb2_ClickDmsFrontEnd_2301_new_MList_send_button
		    dms_dmsweb2_ClickDmsFrontEnd_2301_new_MList_end_button

            Keyboard Key    press       F7



dms_dmsweb2_DmsFrontEnd_2301_stage2_1
        [Arguments]   ${excel_file_data}
        [Documentation]
        [Tags]
        Take Screenshot

 
        ${match2}=  set variable  False 

        ${match1}  ${MLIST_NO_M120}=  dms_dmsweb2_FetchDmsFrontEnd_2301_MLIST_NO_M120  1


	    IF	'${match1}' == 'FAIL'
            dms_dmsweb2_DmsFrontEnd_2301_stage2_c   ${excel_file_data}
            Sleep  1s
            Take Screenshot

            ${match1}  ${MLIST_NO_M120}=  dms_dmsweb2_FetchDmsFrontEnd_2301_MLIST_NO_M120  1 
	    END
        Log  ${MLIST_NO_M120}
        Log  ${excel_file_data}[12]

   	    IF	'${MLIST_NO_M120}' == '${excel_file_data}[12]'
            ${match1}  ${ORG_OFFICE_M120}=  dms_dmsweb2_FetchDmsFrontEnd_2301_ORG_OFFICE_M120  1         	

   	    	Log  ${ORG_OFFICE_M120}
   	    	Log  ${ORG_OFFICE_M120}[0:6]
   	    	Log  ${excel_file_data}[8]

   	    	IF	'${ORG_OFFICE_M120}[0:6]' == '${excel_file_data}[8]'

   	    		${match1}  ${COR_MLIST}=  dms_dmsweb2_FetchDmsFrontEnd_2301_COR_MLIST  1

   	    	    Log  ${COR_MLIST}
   	    	    Log  ${excel_file_data}[9]

                IF  '${excel_file_data}[9]' == 'None'
                    ${excel_file_data}[9]=  evaluate  '0'
                END
   	    	    IF	'${COR_MLIST}' != '${excel_file_data}[9]'
                    Fail
   	    	    END

#   	    	    dms_dmsweb2_ClickDmsFrontEnd_2000_M120_MList_login_button   ${excel_file_data}   1
   	    	    ${match2}=  set variable  True 
   	    	END
   	    END


        Take Screenshot
        RETURN    ${match1}  ${match2}







dms_dmsweb2_DmsFrontEnd_2301_stage2_i
    [Arguments]   ${match2}   ${excel_file_data}
    [Documentation]
    [Tags]
    Take Screenshot

    
    ${match3}=    set variable   FAIL
	FOR  ${i}  IN RANGE  2  1000  1

	    IF	'${match2}' == 'True'
		    Exit For Loop
	    END

        ${match3}  ${MLIST_STATUS}=  dms_dmsweb2_FetchDmsFrontEnd_2301_MLIST_STATUS  ${i}

	    Log  ${match3}
	    Log  ${MLIST_STATUS}
	    Log  ${MLIST_STATUS}[0]
	    Take Screenshot

	    IF	'${match3}' == 'FAIL'

		    Exit For Loop
	    END

	    IF	'${MLIST_STATUS}[0]' == '修'

		    CONTINUE FOR LOOP
	    END

                ${match3}  ${MLIST_NO_M120}=  dms_dmsweb2_FetchDmsFrontEnd_2301_MLIST_NO_M120   ${i} 

                Log  ${MLIST_NO_M120}
                Log  ${excel_file_data}[12]

	    	    IF	'${MLIST_NO_M120}' == '${excel_file_data}[12]'        	
                    ${match1}  ${ORG_OFFICE_M120}=  dms_dmsweb2_FetchDmsFrontEnd_2301_ORG_OFFICE_M120  ${i}         	

   	    	        Log  ${ORG_OFFICE_M120}
   	    	        Log  ${ORG_OFFICE_M120}[0:6]
   	    	        Log  ${excel_file_data}[8]

   	    	        IF	'${ORG_OFFICE_M120}[0:6]' == '${excel_file_data}[8]'

   	    		        ${match1}  ${COR_MLIST}=  dms_dmsweb2_FetchDmsFrontEnd_2301_COR_MLIST  ${i}

   	    	            Log  ${COR_MLIST}
   	    	            Log  ${excel_file_data}[9]

                        IF  '${excel_file_data}[9]' == 'None'
                            ${excel_file_data}[9]=  evaluate  '0'
                        END
   	    	            IF	'${COR_MLIST}' != '${excel_file_data}[9]'
                            Fail
   	    	            END
   	    	            ${match2}=  set variable  True
   	    	        END  	     
   	    	    END  	    	        
   	    	
		${total_column}=  set variable  ${i}
		Take Screenshot
	END

    RETURN    ${match2}  ${match3}


dms_dmsweb2_DmsFrontEnd_2301_stage2_c
    [Arguments]    ${excel_file_data}
    [Documentation]
    [Tags]
    Take Screenshot


		    dms_dmsweb2_ClickDmsFrontEnd_2301_new_M120_MList_button   ${excel_file_data} 
		    dms_dmsweb2_ClickDmsFrontEnd_2301_new_M120_MList_MLST_TYPE  ${excel_file_data}[4]
		    dms_dmsweb2_ClickDmsFrontEnd_2301_new_M120_MList_MLIST_NO  ${excel_file_data}[11]
		    dms_dmsweb2_ClickDmsFrontEnd_2301_new_M120_MList_ORG_OFFICE  ${excel_file_data}[8] 
		    Log   ${excel_file_data}[7]
		    IF  '${excel_file_data}[7]' != 'None'
                dms_dmsweb2_ClickDmsFrontEnd_2301_new_M120_MList_DST_OFFICE  ${excel_file_data}[7]
            END
		    dms_dmsweb2_ClickDmsFrontEnd_2301_new_M120_MList_COR_MLIST  ${excel_file_data}[9]
		    Debug
		    dms_dmsweb2_ClickDmsFrontEnd_2301_new_M120_MList_send_button
		    dms_dmsweb2_ClickDmsFrontEnd_2301_new_M120_MList_end_button

            Sleep  1s
            Take Screenshot










dms_dmsweb2_DmsFrontEnd_2301_stage22_1
        [Arguments]   ${excel_file_data}
        [Documentation]
        [Tags]
        Take Screenshot

        Log   ${excel_file_data}
        ${match2}=  set variable  False  

        ${match1}  ${login_MAIL_NO}=  dms_dmsweb2_FetchDmsFrontEnd_2301_login_MAIL_NO   1

	    IF	'${match1}' == 'FAIL'
		    dms_dmsweb2_DmsFrontEnd_2301_stage22_c   ${excel_file_data}
		    Take Screenshot
		    ${match1}  ${login_MAIL_NO}=  dms_dmsweb2_FetchDmsFrontEnd_2301_login_MAIL_NO   1 
		    Take Screenshot
	    END
        Log  ${login_MAIL_NO}
        Log  ${excel_file_data}[5]

   	    IF	'${login_MAIL_NO}' == '${excel_file_data}[5]'


            ${match1}  ${login_MAIL_NO_SRL}=  dms_dmsweb2_FetchDmsFrontEnd_2301_login_MAIL_NO_SRL   1

            Log  ${login_MAIL_NO_SRL} 

   	    	IF	'${login_MAIL_NO_SRL}' != '0'
   	    		Fail
   	    	END          

   	    	IF	'${login_MAIL_NO_SRL}' == '0'
   	    	    #dms_dmsweb2_ClickDmsFrontEnd_2000_MList_transfer_check_button   ${excel_file_data}   2301  1
   	    	    Take Screenshot
   	    		${match2}=  set variable  True
   	    	END
   	    END
    Take Screenshot
    RETURN    ${match1}  ${match2}





dms_dmsweb2_DmsFrontEnd_2301_stage22_i
    [Arguments]   ${match2}   ${excel_file_data}  
    [Documentation]
    [Tags]
    Take Screenshot

    ${match3}=    set variable   FAIL
	FOR  ${i}  IN RANGE  2  1000  1

	    IF	'${match2}' == 'True'
		    Exit For Loop
	    END




        ${match3}  ${login_MLIST_STATUS}=  Run Keyword And Warn On Failure    Browser.Get Text        xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[2]/div[3]/div[2]/div[2]/table/tbody/tr[${i}]


	    Log  ${match3}
	    Log  ${login_MLIST_STATUS}
	    Log  ${login_MLIST_STATUS}[0]
	    Take Screenshot

	    IF	'${match3}' == 'FAIL'
#		    ${result_data}=  set variable  FAIL
		    Exit For Loop
	    END

	    IF	'${login_MLIST_STATUS}[0]' == '刪'
#		    ${result_data}=  set variable  FAIL
		    CONTINUE FOR LOOP
	    END

#	    CONTINUE FOR LOOP

#			FOR  ${sensor_name}  IN  @{sensor_check_list}
	 

                ${match3}  ${login_MAIL_NO}=  dms_dmsweb2_FetchDmsFrontEnd_2301_login_MAIL_NO   ${i}

                Log  ${login_MAIL_NO}
                Log  ${excel_file_data}[5]

	    	    IF	'${login_MAIL_NO}' == '${excel_file_data}[5]'
	

                    ${match3}  ${login_MAIL_NO_SRL}=  dms_dmsweb2_FetchDmsFrontEnd_2301_login_MAIL_NO_SRL   ${i}	

                    Log  ${login_MAIL_NO_SRL}
                     

	    	    	IF	'${transfer_TOUR_NO}' == '${excel_file_data}[20]'

                        ${match3}  ${transfer_RCV_OFFICE}=  dms_dmsweb2_FetchDmsFrontEnd_2301_transfer_RCV_OFFICE  ${i}

                        Log  ${transfer_RCV_OFFICE}
                        Log  ${transfer_RCV_OFFICE}[0] 
                        Log  ${excel_file_data}[21]  
	    	    	    IF	'${transfer_RCV_OFFICE}[0]' == '${excel_file_data}[21]'

   	    	       	        ${match1}  ${transfer_MAIL_TYPE}=    dms_dmsweb2_FetchDmsFrontEnd_2301_transfer_MAIL_TYPE  ${i}

                            Log  ${transfer_MAIL_TYPE}
                            Log  ${transfer_MAIL_TYPE}[0] 
                            Log  ${excel_file_data}[4]

   	    	                IF	'${transfer_MAIL_TYPE}[0]' == '${excel_file_data}[4]'

        	                    dms_dmsweb2_ClickDmsFrontEnd_2000_MList_transfer_check_button   ${excel_file_data}   2301  ${i} 
        	                    ${match2}=  set variable  True
                            END
	    	    	    END
	    	    	END
	    	    END



#			END
#		Run Keyword If    '${result_data}'=='FAIL'    Exit For Loop
		${total_column}=  set variable  ${i}
		Take Screenshot
	END
    Take Screenshot
    RETURN    ${match2}  ${match3}




dms_dmsweb2_DmsFrontEnd_2301_stage22_c
    [Arguments]      ${excel_file_data}
    [Documentation]
    [Tags]
    Take Screenshot


    dms_dmsweb2_ClickDmsFrontEnd_2301_MList_new_letter_button   ${excel_file_data} 

    dms_dmsweb2_ClickDmsFrontEnd_2000_MList_letter_MAIL_NO  ${excel_file_data}[5]
    Sleep  1s
    dms_dmsweb2_ClickDmsFrontEnd_2301_MList_letter_save_button
    Sleep  1s
    Take Screenshot
    dms_dmsweb2_ClickDmsFrontEnd_2301_MList_letter_save_button
    Sleep  1s
    Take Screenshot
    dms_dmsweb2_ClickDmsFrontEnd_2301_MList_letter_end_button
    Debug


dms_dmsweb2_DmsFrontEnd_2000_stage22_c
    [Arguments]      ${excel_file_data}  ${string}
    [Documentation]
    [Tags]
    Take Screenshot


    dms_dmsweb2_ClickDmsFrontEnd_2000_MList_new_letter_button   ${excel_file_data}   ${string}
	 Sleep  1s
    
    dms_dmsweb2_ClickDmsFrontEnd_2000_MList_letter_MAIL_NO  ${excel_file_data}[5]
	Sleep  1s
	Log  ${excel_file_data}[4]
	IF  '${excel_file_data}[4]' == '1'
      dms_dmsweb2_ClickDmsFrontEnd_2000_MList_letter_VAL_DCL_AMT  ${excel_file_data}[6]
    END
	Sleep  1s
#    dms_dmsweb2_ClickDmsFrontEnd_2000_MList_letter_DST_OFFICE  ${excel_file_data}[7]
	Sleep  1s
    dms_dmsweb2_ClickDmsFrontEnd_2000_MList_letter_save_button
	Sleep  1s

    Take Screenshot

    dms_dmsweb2_ClickDmsFrontEnd_2000_MList_letter_end_button
	Sleep  1s
    Debug



dms_dmsweb2_DmsFrontEnd_2301_F3_stage1_1
        [Arguments]   ${excel_file_data}   ${string}
        [Documentation]
        [Tags]
        Take Screenshot

        ${match2}=  set variable  False 

        ${match1}  ${MLIST_NO}=  dms_dmsweb2_FetchDmsFrontEnd_2301_F3_MLIST_NO  1


	    IF	'${match1}' == 'FAIL'

	        IF	'${string}' != 'mail'
	    	    dms_dmsweb2_DmsFrontEnd_2301_F3_stage1_c       ${excel_file_data}  
	    	END 
            Sleep  1s
            Take Screenshot

            ${match1}  ${MLIST_NO}=  dms_dmsweb2_FetchDmsFrontEnd_2301_F3_MLIST_NO  1 
	    END
        Log  ${MLIST_NO}
        Log  ${excel_file_data}[12]

   	    IF	'${MLIST_NO}' == '${excel_file_data}[12]'

	        IF	'${string}' == 'mail'
	    	    dms_dmsweb2_ClickDmsFrontEnd_2301_F3_MList_login_button   ${excel_file_data}   1
   	    	    ${match2}=  set variable  True  
	    	END

            ${match1}  ${ORG_OFFICE}=  dms_dmsweb2_FetchDmsFrontEnd_2301_F3_ORG_OFFICE  1         	

   	    	Log  ${ORG_OFFICE}
   	    	Log  ${ORG_OFFICE}[0:6]
   	    	Log  ${excel_file_data}[8]

   	    	IF	'${ORG_OFFICE}[0:6]' == '${excel_file_data}[8]'

   	    		${match1}  ${PCK_CNT}=  dms_dmsweb2_FetchDmsFrontEnd_2301_F3_PCK_CNT  1

   	    	    Log  ${PCK_CNT}
   	    	    Log  ${excel_file_data}[13]

                IF  '${excel_file_data}[13]' == 'None'
                    ${excel_file_data}[13]=  evaluate  '0'
                END
   	    	    IF	'${PCK_CNT}' != '${excel_file_data}[13]'
                    Fail
   	    	    END

   	    		${match1}  ${RCL_CNT}=  dms_dmsweb2_FetchDmsFrontEnd_2301_F3_RCL_CNT  1

   	    	    Log  ${RCL_CNT}
   	    	    Log  ${excel_file_data}[14]

                IF  '${excel_file_data}[14]' == 'None'
                    ${excel_file_data}[14]=  evaluate  '0'
                END
   	    	    IF	'${RCL_CNT}' != '${excel_file_data}[14]'
                    Fail
   	    	    END

   	    		${match1}  ${C_CNT}=  dms_dmsweb2_FetchDmsFrontEnd_2301_F3_C_CNT  1

   	    	    Log  ${C_CNT}
   	    	    Log  ${excel_file_data}[15]

                IF  '${excel_file_data}[15]' == 'None'
                    ${excel_file_data}[15]=  evaluate  '0'
                END
   	    	    IF	'${C_CNT}' != '${excel_file_data}[15]'
                    Fail
   	    	    END

   	    		${match1}  ${BIDDING}=  dms_dmsweb2_FetchDmsFrontEnd_2301_F3_BIDDING  1

   	    	    Log  ${BIDDING}
   	    	    Log  ${excel_file_data}[16]

                IF  '${excel_file_data}[16]' == 'None'
                    ${excel_file_data}[16]=  evaluate  '0'
                END
   	    	    IF	'${BIDDING}' != '${excel_file_data}[16]'
                    Fail
   	    	    END

   	    		${match1}  ${INLP_CNT}=  dms_dmsweb2_FetchDmsFrontEnd_2301_F3_INLP_CNT  1

   	    	    Log  ${INLP_CNT}
   	    	    Log  ${excel_file_data}[17]

                IF  '${excel_file_data}[17]' == 'None'
                    ${excel_file_data}[17]=  evaluate  '0'
                END
   	    	    IF	'${INLP_CNT}' != '${excel_file_data}[17]'
                    Fail
   	    	    END

   	    		${match1}  ${INOP_CNT}=  dms_dmsweb2_FetchDmsFrontEnd_2301_F3_INOP_CNT  1

   	    	    Log  ${INOP_CNT}
   	    	    Log  ${excel_file_data}[18]

                IF  '${excel_file_data}[18]' == 'None'
                    ${excel_file_data}[18]=  evaluate  '0'
                END
   	    	    IF	'${INOP_CNT}' != '${excel_file_data}[18]'
                    Fail
   	    	    END

   	    		${match1}  ${IN_TYPE_CODE}=  dms_dmsweb2_FetchDmsFrontEnd_2301_F3_IN_TYPE_CODE   1
                Log  ${IN_TYPE_CODE}
                Log  ${excel_file_data}[4]

	    	    IF	'${IN_TYPE_CODE}' == '${excel_file_data}[4]'
                	Fail
   	    	    END

   	    	    dms_dmsweb2_ClickDmsFrontEnd_2301_F3_MList_login_button   ${excel_file_data}   1
   	    	    ${match2}=  set variable  True 
   	    	END
   	    END


        Take Screenshot
        RETURN    ${match1}  ${match2}




dms_dmsweb2_DmsFrontEnd_2301_F3_stage1_i
    [Arguments]   ${match2}   ${excel_file_data}  
    [Documentation]
    [Tags]
    Take Screenshot

    ${match3}=    set variable   FAIL
	FOR  ${i}  IN RANGE  2  1000  1

	    IF	'${match2}' == 'True'
		    Exit For Loop
	    END




        ${match3}  ${MLIST_STATUS}=  dms_dmsweb2_FetchDmsFrontEnd_2301_F3_MLIST_STATUS  ${i}

	    Log  ${match3}
	    Log  ${MLIST_STATUS}
	    Log  ${MLIST_STATUS}[0]
	    Take Screenshot

	    IF	'${match3}' == 'FAIL'
#		    ${result_data}=  set variable  FAIL
		    Exit For Loop
	    END

	    IF	'${MLIST_STATUS}[0]' == '修'
#		    ${result_data}=  set variable  FAIL
		    CONTINUE FOR LOOP
	    END




                ${match3}  ${MLIST_NO}=  dms_dmsweb2_FetchDmsFrontEnd_2301_F3_MLIST_NO   ${i} 

                Log  ${MLIST_NO}
                Log  ${excel_file_data}[12]

	    	    IF	'${MLIST_NO}' == '${excel_file_data}[12]'

	                IF	'${string}' == 'mail'
	    	            dms_dmsweb2_ClickDmsFrontEnd_2301_F3_MList_login_button   ${excel_file_data}   ${i}
   	    	            ${match2}=  set variable  True  
	    	        END

	                ${match3}  ${ORG_OFFICE}=  dms_dmsweb2_FetchDmsFrontEnd_2301_F3_ORG_OFFICE   ${i} 	

                    Log  ${ORG_OFFICE}
                    Log  ${ORG_OFFICE}[0:6]
                    Log  ${excel_file_data}[8]  

	    	    	IF	'${ORG_OFFICE}[0:6]' == '${excel_file_data}[8]'
	    	    		${match3}  ${PCK_CNT}=  dms_dmsweb2_FetchDmsFrontEnd_2301_F3_PCK_CNT  ${i}

   	    	    	    Log  ${PCK_CNT}
   	    	    	    Log  ${excel_file_data}[13]

                	    IF  '${excel_file_data}[13]' == 'None'
                	        ${excel_file_data}[13]=  evaluate  '0'
                	    END
   	    	    	    IF	'${PCK_CNT}' != '${excel_file_data}[13]'
                	        Fail
   	    	    	    END


   	    			    ${match1}  ${RCL_CNT}=  dms_dmsweb2_FetchDmsFrontEnd_2301_F3_RCL_CNT  ${i}

   	    	    	    Log  ${RCL_CNT}
   	    	    	    Log  ${excel_file_data}[14]

                	    IF  '${excel_file_data}[14]' == 'None'
                	        ${excel_file_data}[14]=  evaluate  '0'
                	    END
   	    	    	    IF	'${RCL_CNT}' != '${excel_file_data}[14]'
                	        Fail
   	    	    	    END

   	    			    ${match1}  ${C_CNT}=  dms_dmsweb2_FetchDmsFrontEnd_2301_F3_C_CNT  ${i}

   	    	    	    Log  ${C_CNT}
   	    	    	    Log  ${excel_file_data}[15]

                	    IF  '${excel_file_data}[15]' == 'None'
                	        ${excel_file_data}[15]=  evaluate  '0'
                	    END
   	    	    	    IF	'${C_CNT}' != '${excel_file_data}[15]'
                	        Fail
   	    	    	    END

   	    			    ${match1}  ${BIDDING}=  dms_dmsweb2_FetchDmsFrontEnd_2301_F3_BIDDING  ${i}

   	    	    	    Log  ${BIDDING}
   	    	    	    Log  ${excel_file_data}[16]

                	    IF  '${excel_file_data}[16]' == 'None'
                	        ${excel_file_data}[16]=  evaluate  '0'
                	    END
   	    	    	    IF	'${BIDDING}' != '${excel_file_data}[16]'
                	        Fail
   	    	    	    END

   	    			    ${match1}  ${INLP_CNT}=  dms_dmsweb2_FetchDmsFrontEnd_2301_F3_INLP_CNT  ${i}

   	    	    	    Log  ${INLP_CNT}
   	    	    	    Log  ${excel_file_data}[17]

                	    IF  '${excel_file_data}[17]' == 'None'
                	        ${excel_file_data}[17]=  evaluate  '0'
                	    END
   	    	    	    IF	'${INLP_CNT}' != '${excel_file_data}[17]'
                	        Fail
   	    	    	    END

   	    			    ${match1}  ${INOP_CNT}=  dms_dmsweb2_FetchDmsFrontEnd_2301_F3_INOP_CNT   ${i}

   	    	    	    Log  ${INOP_CNT}
   	    	    	    Log  ${excel_file_data}[18]

                	    IF  '${excel_file_data}[18]' == 'None'
                	        ${excel_file_data}[18]=  evaluate  '0'
                	    END
   	    	    	    IF	'${INOP_CNT}' != '${excel_file_data}[18]'
                	        Fail
   	    	    	    END

   	    			    ${match1}  ${IN_TYPE_CODE}=  dms_dmsweb2_FetchDmsFrontEnd_2301_F3_IN_TYPE_CODE   ${i}
                        Log  ${IN_TYPE_CODE}
                        Log  ${excel_file_data}[4]

	    	            IF	'${IN_TYPE_CODE}' == '${excel_file_data}[4]'
                	        Fail
   	    	    	    END

   	    	    	    dms_dmsweb2_ClickDmsFrontEnd_2301_F3_MList_login_button   ${excel_file_data}   ${i}
   	    	    	    ${match2}=  set variable  True 
	    	    	    
	    	    	END
	    	    END



#			END
#		Run Keyword If    '${result_data}'=='FAIL'    Exit For Loop
		${total_column}=  set variable  ${i}
		Take Screenshot
	END



    RETURN    ${match2}  ${match3}





dms_dmsweb2_DmsFrontEnd_2301_F3_stage1_c
    [Arguments]           ${excel_file_data}  
    [Documentation]
    [Tags]
    Take Screenshot


		    dms_dmsweb2_ClickDmsFrontEnd_2301_F3_new_MList_button   ${excel_file_data} 
		    dms_dmsweb2_ClickDmsFrontEnd_2301_F3_new_MList_MLST_TYPE  ${excel_file_data}[4]
		    dms_dmsweb2_ClickDmsFrontEnd_2301_F3_new_MList_MLIST_NO  ${excel_file_data}[12]
		    dms_dmsweb2_ClickDmsFrontEnd_2301_F3_new_MList_ORG_OFFICE  ${excel_file_data}[8]
		    dms_dmsweb2_ClickDmsFrontEnd_2301_F3_new_MList_PCK_CNT  ${excel_file_data}[13]
		    dms_dmsweb2_ClickDmsFrontEnd_2301_F3_new_MList_RCL_CNT  ${excel_file_data}[14]
		    dms_dmsweb2_ClickDmsFrontEnd_2301_F3_new_MList_C_CNT  ${excel_file_data}[15]
		    dms_dmsweb2_ClickDmsFrontEnd_2301_F3_new_MList_BIDDING_CNT  ${excel_file_data}[16]
		    dms_dmsweb2_ClickDmsFrontEnd_2301_F3_new_MList_INCL_CNT  ${excel_file_data}[17]
		    dms_dmsweb2_ClickDmsFrontEnd_2301_F3_new_MList_INOP_CNT  ${excel_file_data}[18]
		    dms_dmsweb2_ClickDmsFrontEnd_2301_F3_new_MList_send_button
		    dms_dmsweb2_ClickDmsFrontEnd_2301_F3_new_MList_end_button

            Sleep  1s
            Take Screenshot
            Keyboard Key    press       F7


