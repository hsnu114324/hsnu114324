*** Variables ***
${xpath_pnsFrontEnd_username}                 xpath=//*[@id="txtUserId"]
${xpath_pnsFrontEnd_password}                 xpath=//*[@id="txtInfo"]
${xpath_pnsFrontEnd_enterbutton}              xpath=//*[@id="btnLogin"]


${xpath_PnsFrontEndMenu_List2}                xpath=//*[@id="MenuList"]/li/a[2]/span[1]
${xpath_PnsFrontEndMenu_List2Button1}         xpath=//*[@id="MenuList"]/li/ul[2]/li[1]/a 
${xpath_PnsFrontEndbtnQuery}                  xpath=//*[@id="BodyMainContent_btnQuery"]
${xpath_PnsFrontEndlbtnReqNo_0}               xpath=//*[@id="BodyMainContent_gvList_lbtnReqNo_0"]
${xpath_PnsFrontEndbtnEditInfo_0}             xpath=//*[@id="BodyMainContent_gvList_btnEditInfo_0"]
${xpath_PnsFrontEndCancelbtnSave}             xpath=//*[@id="BodyMainContent_fvw_btnSave"]



${xpath_PnsFrontEndMenu_List1}    		      xpath=//*[@id="MenuList"]/li/a[1]/span[1]
${xpath_PnsFrontEndMenu_List1Button1}		  xpath=//*[@id="MenuList"]/li/ul[1]/li[1]/a
${xpath_PnsFrontEndMenu_List1Button2}             xpath=//*[@id="MenuList"]/li/ul[1]/li[2]/a
${xpath_PnsFrontEndMenu_List1Button3}             xpath=//*[@id="MenuList"]/li/ul[1]/li[3]/a
${xpath_PnsFrontEndMenu_List1Button4}             xpath=//*[@id="MenuList"]/li/ul[1]/li[4]/a
${xpath_PnsFrontEndcbConfirm}                 xpath=//*[@id="BodyMainContent_cbConfirm"]
${xpath_PnsFrontEndbtnConfirm}                xpath=//*[@id="BodyMainContent_btnConfirm"]
${xpath_PnsddlNewCity_ddl1}                   xpath=//*[@id="BodyMainContent_ddlNewCity_ddl1"]
${select_value_TaipeiCity}                    臺北市
${xpath_PnsddlNewArea_ddl1}                   xpath=//*[@id="BodyMainContent_ddlNewArea_ddl1"]
${select_value_ZhongzhengDistrict}            中正區
${select_value_100ZhongzhengDistrict}            100中正區
${xpath_PnsddlNewRoad_ddl1}                   xpath=//*[@id="BodyMainContent_ddlNewRoad_ddl1"]
${select_value_SectionOneOfBadeRoad}          八德路１段
${xpath_PnstxtNewNumber}                      xpath=//*[@id="BodyMainContent_txtNewNumber"]

${xpath_PnsddlOldCity_ddl1}                   xpath=//*[@id="BodyMainContent_ddlOldCity_ddl1"]
${select_value_TaipeiCity}                    臺北市
${xpath_PnsddlOldArea_ddl1}                   xpath=//*[@id="BodyMainContent_ddlOldArea_ddl1"]
${select_value_ZhongzhengDistrict}            中正區
${xpath_PnsddlOldRoad_ddl1}                   xpath=//*[@id="BodyMainContent_ddlOldRoad_ddl1"]
${select_value_SanyuanStreet}                 三元街
${xpath_PnstxtOldNumber}                      xpath=//*[@id="BodyMainContent_txtOldNumber"]


${xpath_PnsddlCity_ddl1}                   xpath=//*[@id="ContentPlaceHolder1_ddlCity_ddl1"]
${select_value_TaipeiCity}                    臺北市
${xpath_PnsddlArea_ddl1}                   xpath=//*[@id="ContentPlaceHolder1_ddlArea_ddl1"]
${select_value_ZhongzhengDistrict}            中正區
${select_value_100ZhongzhengDistrict}            100中正區
${xpath_PnsddlRoad_ddl1}                   xpath=//*[@id="ContentPlaceHolder1_ddlRoad_ddl1"]
${select_value_SectionOneOfBadeRoad}          八德路１段
${xpath_PnstxtNumber}                      xpath=//*[@id="ContentPlaceHolder1_txtNumber"]

${xpath_PnsddlCity_old_ddl1}                   xpath=//*[@id="ContentPlaceHolder1_ddlCity_old_ddl1"]
${select_value_TaipeiCity}                    臺北市
${xpath_PnsddlArea_old_ddl1}                   xpath=//*[@id="ContentPlaceHolder1_ddlArea_old_ddl1"]
${select_value_ZhongzhengDistrict}            中正區
${xpath_PnsddlRoad_old_ddl1}                   xpath=//*[@id="ContentPlaceHolder1_ddlRoad_old_ddl1"]
${select_value_SanyuanStreet}                 三元街
${xpath_PnstxtNumber_old}                      xpath=//*[@id="ContentPlaceHolder1_txtNumber_old"]


${xpath_PnschkNewRoad}                      xpath=//*[@id="BodyMainContent_chkNewRoad"]
${xpath_PnstxtNewRoad}                      xpath=//*[@id="BodyMainContent_txtNewRoad"]
${xpath_PnschkOldRoad}                      xpath=//*[@id="BodyMainContent_chkOldRoad"]
${xpath_PnstxtOldRoad}                      xpath=//*[@id="BodyMainContent_txtOldRoad"]

${xpath_PnschkNewRoad_Backend}                      xpath=//*[@id="ContentPlaceHolder1_chkNewRoad"]
${xpath_PnstxtNewRoad_Backend}                      xpath=//*[@id="ContentPlaceHolder1_txtNewRoad"]
${xpath_PnschkOldRoad_Backend}                      xpath=//*[@id="ContentPlaceHolder1_chkOldRoad"]
${xpath_PnstxtOldRoad_Backend}                      xpath=//*[@id="ContentPlaceHolder1_txtOldRoad"]

${xpath_PnstxtRemark_Backend}                      xpath=//*[@id="ContentPlaceHolder1_txtNewRemark"]
${xpath_PnstxtVerificationDate_Backend}                      xpath=//*[@id="ContentPlaceHolder1_txtVerificationDate_CalTextBox"]
${xpath_PnstxtEffectiveStartDate_Backend}                      xpath=//*[@id="ContentPlaceHolder1_txtEffectiveStartDate_CalTextBox"]
${xpath_PnstxtEffectiveEndDate_Backend}                      xpath=//*[@id="ContentPlaceHolder1_txtEffectiveEndDate_CalTextBox"]

${xpath_PnstxtNewRemark}                      xpath=//*[@id="BodyMainContent_txtNewRemark"]
${xpath_PnstxtVerificationDate}                      xpath=//*[@id="BodyMainContent_txtVerificationDate_CalTextBox"]
${xpath_PnstxtEffectiveStartDate}                      xpath=//*[@id="BodyMainContent_txtEffectiveStartDate_CalTextBox"]
${xpath_PnstxtEffectiveEndDate}                      xpath=//*[@id="BodyMainContent_txtEffectiveEndDate_CalTextBox"]


${xpath_PnsTextBox1}                   xpath=//*[@id="BodyMainContent_TextBox1"]
${xpath_PnsTextBox2}                    xpath=//*[@id="BodyMainContent_TextBox2"]
${xpath_PnsTextBox3}                    xpath=//*[@id="BodyMainContent_TextBox3"]
${xpath_PnsTextBox4}                    xpath=//*[@id="BodyMainContent_TextBox4"]
${xpath_PnsTextBox5}                    xpath=//*[@id="BodyMainContent_TextBox5"]
${xpath_PnsTextBox6}                    xpath=//*[@id="BodyMainContent_TextBox6"]
${xpath_PnsTextBox7}                    xpath=//*[@id="BodyMainContent_TextBox7"]
${xpath_PnsTextBox8}                    xpath=//*[@id="BodyMainContent_TextBox8"]
${xpath_PnsTextBox9}                    xpath=//*[@id="BodyMainContent_TextBox9"]
${xpath_PnsTextBox10}                    xpath=//*[@id="BodyMainContent_TextBox10"]

${xpath_PnsTextBox1_Backend}                   xpath=//*[@id="ContentPlaceHolder1_TextBox1"]
${xpath_PnsTextBox2_Backend}                    xpath=//*[@id="ContentPlaceHolder1_TextBox2"]
${xpath_PnsTextBox3_Backend}                    xpath=//*[@id="ContentPlaceHolder1_TextBox3"]
${xpath_PnsTextBox4_Backend}                    xpath=//*[@id="ContentPlaceHolder1_TextBox4"]
${xpath_PnsTextBox5_Backend}                    xpath=//*[@id="ContentPlaceHolder1_TextBox5"]
${xpath_PnsTextBox6_Backend}                    xpath=//*[@id="ContentPlaceHolder1_TextBox6"]
${xpath_PnsTextBox7_Backend}                    xpath=//*[@id="ContentPlaceHolder1_TextBox7"]
${xpath_PnsTextBox8_Backend}                    xpath=//*[@id="ContentPlaceHolder1_TextBox8"]
${xpath_PnsTextBox9_Backend}                    xpath=//*[@id="ContentPlaceHolder1_TextBox9"]
${xpath_PnsTextBox10_Backend}                    xpath=//*[@id="ContentPlaceHolder1_TextBox10"]

${xpath_PnsbtnP1}                    xpath=//*[@id="btnP1"]


${xpath_PnstxtCellPhone}                      xpath=//*[@id="BodyMainContent_txtCellPhone"]
${xpath_PnstxtTelePhone}                      xpath=//*[@id="BodyMainContent_txtTelePhone"]
${xpath_PnsbtnSend}                           xpath=//*[@id="BodyMainContent_btnSend"]

${xpath_PnstxtEmail}                      xpath=//*[@id="ContentPlaceHolder1_txtEmail"]
${xpath_PnstxtUserName_Backend}                      xpath=//*[@id="ContentPlaceHolder1_txtUserName"]
${xpath_PnstxtCellPhone_Backend}                      xpath=//*[@id="ContentPlaceHolder1_txtCellPhone"]
${xpath_PnstxtTelePhone_Backend}                      xpath=//*[@id="ContentPlaceHolder1_txtTelePhone"]
${xpath_PnsbtnSave}                           xpath=//*[@id="ContentPlaceHolder1_btnSave"]

${xpath_pnsBackEnd_username}                  xpath=//*[@id="txtUserID"]
${xpath_pnsBackEnd_enterbutton}               xpath=//*[@id="btnLogin"]
${xpath_pnsBackEndSelectFrame1}               xpath=//*[@id="frameName"]/frame[1]
${xpath_pnsBackEndSelectFrame2}               xpath=//*[@id="frameName"]/frame[2]
${xpath_pnsBackEndtvFunctionn0Nodes}          xpath=//*[@id="tvFunctionn0Nodes"]
${xpath_pnsBackEndtvFunctiont1}               xpath=//*[@id="tvFunctiont1"]
${xpath_pnsBackEndtvFunctiont1i}              xpath=//*[@id="tvFunctiont1i"]
${xpath_pnsBackEndtvFunctiont2}               xpath=//*[@id="tvFunctiont2"]
${xpath_pnsBackEndtvFunctiont3}               xpath=//*[@id="tvFunctiont3"]
${xpath_pnsBackEndtvFunctiont4}               xpath=//*[@id="tvFunctiont4"]
${xpath_pnsBackEndtvFunctiont20}              xpath=//*[@id="tvFunctiont20"]
${xpath_pnsBackEndtvFunctiont21}              xpath=//*[@id="tvFunctiont21"]
${xpath_pnsBackEndtvFunctiont22}              xpath=//*[@id="tvFunctiont22"]
${xpath_pnsBackEndtvFunctiont23}              xpath=//*[@id="tvFunctiont23"]
${xpath_pnsBackEndtvFunctiont24}              xpath=//*[@id="tvFunctiont24"]
${xpath_pnsBackEndtvFunctiont25}              xpath=//*[@id="tvFunctiont25"]
${xpath_pnsBackEndtvFunctiont26}              xpath=//*[@id="tvFunctiont26"]
${xpath_pnsBackEndtvFunctiont27}              xpath=//*[@id="tvFunctiont27"]
${xpath_pnsBackEndtvFunctiont28}              xpath=//*[@id="tvFunctiont28"]
${xpath_pnsBackEndtvFunctiont29}              xpath=//*[@id="tvFunctiont29"]

${xpath_pnsBackEndDateStart_Upload_CalTextBox}    xpath=//*[@id="ContentPlaceHolder1_txtUploadDateStart_Cond_CalTextBox"]
${xpath_pnsBackEndDateEnd_Upload_CalTextBox}      xpath=//*[@id="ContentPlaceHolder1_txtUploadDateEnd_Cond_CalTextBox"]
${xpath_pnsBackEndDateStart_Send_CalTextBox}      xpath=//*[@id="ContentPlaceHolder1_txtSendDateStart_Cond_CalTextBox"]
${xpath_pnsBackEndDateEnd_Send_CalTextBox}        xpath=//*[@id="ContentPlaceHolder1_txtSendDateEnd_Cond_CalTextBox"]
${xpath_pnsBackEndDateStart_CalTextBox}           xpath=//*[@id="ContentPlaceHolder1_txtUploadDateStart_CalTextBox"]
${xpath_pnsBackEndtxtDid}                 xpath=//*[@id="ContentPlaceHolder1_txtDid_Cond"]
${xpath_pnsBackEndtxtUploaderID}          xpath=//*[@id="ContentPlaceHolder1_txtUploaderID_Cond"]
${xpath_pnsBackEndtxtFirstInspectorID}          xpath=//*[@id="ContentPlaceHolder1_txtFirstInspectorID_Cond"]
${xpath_pnsBackEndtxtSecondInspectorID}          xpath=//*[@id="ContentPlaceHolder1_txtSecondInspectorID_Cond"]
${xpath_pnsBackEndrblTyperbl1_0}          xpath=//*[@id="ContentPlaceHolder1_rblType_Cond_rbl1_0"]
${xpath_pnsBackEndrblTyperbl1_1}          xpath=//*[@id="ContentPlaceHolder1_rblType_Cond_rbl1_1"]
${xpath_pnsBackEndddlStatusddl1}          xpath=//*[@id="ContentPlaceHolder1_ddlStatus_Cond_ddl1"]
${xpath_pnsBackEndddlCommentTypeddl1}          xpath=//*[@id="ContentPlaceHolder1_ddlCommentType_Cond_ddl1"]
${xpath_pnsBackEndddlScheduleType_ddl1}        xpath=//*[@id="ContentPlaceHolder1_ddlScheduleType_ddl1"]

${xpath_pnstxtNewLane}                xpath=//*[@id="BodyMainContent_txtNewLane"]
${xpath_pnstxtNewAlley}                xpath=//*[@id="BodyMainContent_txtNewAlley"]
${xpath_pnstxtNewSubNumber}        xpath=//*[@id="BodyMainContent_txtNewSubNumber"]
${xpath_pnstxtNewFloor}                xpath=//*[@id="BodyMainContent_txtNewFloor"]
${xpath_pnstxtNewSubFloor}        xpath=//*[@id="BodyMainContent_txtNewSubFloor"]
${xpath_pnstxtNewRoom}                xpath=//*[@id="BodyMainContent_txtNewRoom"]

${xpath_pnstxtLane}                                xpath=//*[@id="ContentPlaceHolder1_txtLane"]
${xpath_pnstxtAlley}                                xpath=//*[@id="ContentPlaceHolder1_txtAlley"]
${xpath_pnstxtSubNumber}                        xpath=//*[@id="ContentPlaceHolder1_txtSubNumber"]
${xpath_pnstxtFloor}                                xpath=//*[@id="ContentPlaceHolder1_txtFloor"]
${xpath_pnstxtSubFloor}                        xpath=//*[@id="ContentPlaceHolder1_txtSubFloor"]
${xpath_pnstxtRoom}                                xpath=//*[@id="ContentPlaceHolder1_txtRoom"]


${xpath_pnstxtLane_old}                                xpath=//*[@id="ContentPlaceHolder1_txtLane_old"]
${xpath_pnstxtAlley_old}                                xpath=//*[@id="ContentPlaceHolder1_txtAlley_old"]
${xpath_pnstxtSubNumber_old}                        xpath=//*[@id="ContentPlaceHolder1_txtSubNumber_old"]
${xpath_pnstxtFloor_old}                                xpath=//*[@id="ContentPlaceHolder1_txtFloor_old"]
${xpath_pnstxtSubFloor_old}                        xpath=//*[@id="ContentPlaceHolder1_txtSubFloor_old"]
${xpath_pnstxtRoom_old}                                xpath=//*[@id="ContentPlaceHolder1_txtRoom_old"]

${xpath_pnstxtOldLane}                xpath=//*[@id="BodyMainContent_txtOldLane"]
${xpath_pnstxtOldAlley}                xpath=//*[@id="BodyMainContent_txtOldAlley"]
${xpath_pnstxtOldSubNumber}        xpath=//*[@id="BodyMainContent_txtOldSubNumber"]
${xpath_pnstxtOldFloor}                xpath=//*[@id="BodyMainContent_txtOldFloor"]
${xpath_pnstxtOldSubFloor}        xpath=//*[@id="BodyMainContent_txtOldSubFloor"]
${xpath_pnstxtOldRoom}                xpath=//*[@id="BodyMainContent_txtOldRoom"]

${xpath_pnsBackEndContent1_btnQuery}          xpath=//*[@id="ContentPlaceHolder1_btnQuery"]
${xpath_pnsBackEndContent1_btnSend}          xpath=//*[@id="ContentPlaceHolder1_btnSend"]
${xpath_pnsBackEndContent1_wucUpload}          xpath=//*[@id="ContentPlaceHolder1_wucUpload"]
${xpath_pnsBackEndContent1_btnDownload}          xpath=//*[@id="ContentPlaceHolder1_btnDownload"]
${xpath_pnsBackEndContent1_ddlVerificationOffice_ddl1}          xpath=//*[@id="ContentPlaceHolder1_ddlVerificationOffice_ddl1"]
${xpath_pnsBackEndContent1_gvList_LinkButton_0}               xpath=//*[@id="ContentPlaceHolder1_gvList_LinkButton_0"]
${xpath_pnsBackEndContent1_gvList_LinkButton_1}               xpath=//*[@id="ContentPlaceHolder1_gvList_LinkButton_1"]
${xpath_pnsBackEndContent1_gvList_LinkButton_2}               xpath=//*[@id="ContentPlaceHolder1_gvList_LinkButton_2"]
${xpath_pnsBackEndContent1_gvList_LinkButton_3}               xpath=//*[@id="ContentPlaceHolder1_gvList_LinkButton_3"]
${xpath_pnsBackEndContent1_gvList_LinkButton_4}               xpath=//*[@id="ContentPlaceHolder1_gvList_LinkButton_4"]
${xpath_pnsBackEndContent1_gvList_LinkButton_5}               xpath=//*[@id="ContentPlaceHolder1_gvList_LinkButton_5"]
${xpath_pnsBackEndContent1_gvList_LinkButton_6}               xpath=//*[@id="ContentPlaceHolder1_gvList_LinkButton_6"]
${xpath_pnsBackEndContent1_gvList_LinkButton_7}               xpath=//*[@id="ContentPlaceHolder1_gvList_LinkButton_7"]
${xpath_pnsBackEndContent1_gvList_LinkButton_8}               xpath=//*[@id="ContentPlaceHolder1_gvList_LinkButton_8"]
${xpath_pnsBackEndContent1_gvList_LinkButton_9}               xpath=//*[@id="ContentPlaceHolder1_gvList_LinkButton_9"]
${xpath_pnsBackEndContent1_fvw1_btnFvwPrint_btnPrint}          xpath=//*[@id="ContentPlaceHolder1_fvw1_btnFvwPrint_btnPrint"]

${xpath_pnsBackEndContent1_fvw2_btnFvwPrint_btnPrint}          xpath=//*[@id="ContentPlaceHolder1_fvw2_btnFvwPrint_btnPrint"]

${xpath_pnsBackEndContent1_fvw1_btnFvwChange}         xpath=//*[@id="ContentPlaceHolder1_fvw1_btnFvwChange"]
${xpath_pnsBackEndContent1_fvw2_btnFvwChange}         xpath=//*[@id="ContentPlaceHolder1_fvw2_btnFvwChange"]
${xpath_pnsBackEndContent1_fvw3_btnFvwChange}         xpath=//*[@id="ContentPlaceHolder1_fvw3_btnFvwChange"]
${xpath_pnsBackEndContent1_btnFvwSave}        xpath=//*[@id="ContentPlaceHolder1_btnFvwSave"]



${xpath_pnsBackEndContent1_fvw1_ddlResult_ddl1}    xpath=//*[@id="ContentPlaceHolder1_fvw1_ddlResult_ddl1"]
${select_value_30success}                      30
${select_value_31fail}                         31
${xpath_pnsBackEndContent1_fvw1_txtVerificationNote}        xpath=//*[@id="ContentPlaceHolder1_fvw1_txtVerificationNote"]
${xpath_pnsBackEndContent1_fvw2_txtVerificationNote}        xpath=//*[@id="ContentPlaceHolder1_fvw2_txtVerificationNote"]
${xpath_pnsBackEndContent1_fvw3_txtVerificationNote}        xpath=//*[@id="ContentPlaceHolder1_fvw3_verificationNote"]
${xpath_pnsBackEnduploadfile}        xpath=//*[@id="ContentPlaceHolder1_fileUpload"]
${xpath_pnsBackEnduploadVerifyPicture}        xpath=//*[@id="ContentPlaceHolder1_fvw1_FileUpload1"]
${xpath_pnsBackEnd_fvw2_uploadVerifyPicture}        xpath=//*[@id="ContentPlaceHolder1_fvw2_FileUpload1"]

${xpath_pnsBackEndContent1_fvw1_btnUpload}                        xpath=//*[@id="ContentPlaceHolder1_fvw1_btnUpload"]

${xpath_pnsBackEndContent1_fvw2_btnUpload}                        xpath=//*[@id="ContentPlaceHolder1_fvw2_btnUpload"]

${xpath_pnsBackEndContent1_fvw1_lbtnFile}     xpath=//*[@id="ContentPlaceHolder1_fvw1_lbtnFile"]
${xpath_pnsBackEndContent1_fvw2_lbtnFile}     xpath=//*[@id="ContentPlaceHolder1_fvw2_lbtnFile"]
${xpath_pnsBackEndContent1_fvw2_ddlResult_ddl1}    xpath=//*[@id="ContentPlaceHolder1_fvw2_ddlResult_ddl1"]
${xpath_pnsBackEndContent1_fvw3_ddlResult_ddl1}    xpath=//*[@id="ContentPlaceHolder1_fvw3_ddlResult_ddl1"]
${xpath_pnsBackEndContent1_btnFvw2Save}        xpath=//*[@id="ContentPlaceHolder1_btnFvw2Save"]

${xpath_pnsBackEndContent1_btnFvw1Save}        xpath=//*[@id="ContentPlaceHolder1_btnFvw1Save"]

${xpath_pnsBackEndContent1_fvw_btnSave}        xpath=//*[@id="ContentPlaceHolder1_fvw_btnSave"]
${xpath_pnsBackEndContent1_fvw_ddl1_ddl1}      xpath=//*[@id="ContentPlaceHolder1_fvw_ddl1_ddl1"]
${xpath_pnsBackEndContent1_fvw_ddl2_ddl1}      xpath=//*[@id="ContentPlaceHolder1_fvw_ddl2_ddl1"]
${xpath_pnsBackEndContent1_fvw_ddlCommentType_ddl1}          xpath=//*[@id="ContentPlaceHolder1_fvw_ddlCommentType_ddl1"]
${xpath_pnsBackEndContent1_fvw_ddlStatus_ddl1}          xpath=//*[@id="ContentPlaceHolder1_fvw_ddlStatus_ddl1"]
${xpath_pnsBackEndContent1_fvw_ddlInspector_ddl1}          xpath=//*[@id="ContentPlaceHolder1_fvw_ddlInspector_ddl1"]
${xpath_pnsBackEndContent1_fvw_txtFirstInspectDesc}          xpath=//*[@id="ContentPlaceHolder1_fvw_txtFirstInspectDesc"]
${xpath_pnsBackEndContent1_fvw_txtSecondInspectDesc}          xpath=//*[@id="ContentPlaceHolder1_fvw_txtSecondInspectDesc"]

${xpath_pnsBackEndLinkButton_0}    xpath=//*[@id="ContentPlaceHolder1_gvList_LinkButton_0"]



${xpath_pnsrblNewPostType}    xpath=//*[@id="BodyMainContent_rblNewPostType_rbl1_1"]
${xpath_pnsrblOldPostType}    xpath=//*[@id="BodyMainContent_rblOldPostType_rbl1_1"]
${xpath_pnsddlNewOrangePost1}    xpath=//*[@id="BodyMainContent_ddlNewOrangePost1_ddl1"]
${xpath_pnsddlNewOrangePost2}    xpath=//*[@id="BodyMainContent_ddlNewOrangePost2_ddl1"]
${xpath_pnsddlNewOrangePost3}    xpath=//*[@id="BodyMainContent_ddlNewOrangePost3_ddl1"]
${xpath_pnsddlOldOrangePost1}    xpath=//*[@id="BodyMainContent_ddlOldOrangePost1_ddl1"]
${xpath_pnsddlOldOrangePost2}    xpath=//*[@id="BodyMainContent_ddlOldOrangePost2_ddl1"]
${xpath_pnsddlOldOrangePost3}    xpath=//*[@id="BodyMainContent_ddlOldOrangePost3_ddl1"]

${xpath_pnstxtNewPostNumber}    xpath=//*[@id="BodyMainContent_txtNewPostNumber"]
${xpath_pnstxtOldPostNumber}    xpath=//*[@id="BodyMainContent_txtOldPostNumber"]


${xpath_pnsrblNewPostType_Backend}    xpath=//*[@id="ContentPlaceHolder1_rblNewPostType_rbl1_1"]
${xpath_pnsrblOldPostType_Backend}    xpath=//*[@id="ContentPlaceHolder1_rblOldPostType_rbl1_1"]
${xpath_pnsddlNewOrangePost1_Backend}    xpath=//*[@id="ContentPlaceHolder1_ddlNewOrangePost1_ddl1"]
${xpath_pnsddlNewOrangePost2_Backend}    xpath=//*[@id="ContentPlaceHolder1_ddlNewOrangePost2_ddl1"]
${xpath_pnsddlNewOrangePost3_Backend}    xpath=//*[@id="ContentPlaceHolder1_ddlNewOrangePost3_ddl1"]
${xpath_pnsddlOldOrangePost1_Backend}    xpath=//*[@id="ContentPlaceHolder1_ddlOldOrangePost1_ddl1"]
${xpath_pnsddlOldOrangePost2_Backend}    xpath=//*[@id="ContentPlaceHolder1_ddlOldOrangePost2_ddl1"]
${xpath_pnsddlOldOrangePost3_Backend}    xpath=//*[@id="ContentPlaceHolder1_ddlOldOrangePost3_ddl1"]

${xpath_pnstxtNewPostNumber_Backend}    xpath=//*[@id="ContentPlaceHolder1_txtNewPostNumber"]
${xpath_pnstxtOldPostNumber_Backend}    xpath=//*[@id="ContentPlaceHolder1_txtOldPostNumber"]

${select_value_TaipeiPostOffice}                   000000
${select_value_Zhongzheng_delivery}                100572









${xpath_pnstestmailFrontEnd_enterbutton}              xpath=//*[@id="Start"]

${xpath_pnstestmailFrontEnd_Q2_3_1_2_3}   xpath=//*[@id="A_3_1_2_3_Check"]
${xpath_pnstestmailFrontEnd_Q2_4_1_2_3_1}   xpath=//*[@id="A_4_1_2_3_1"]
${xpath_pnstestmailFrontEnd_Q3_11_1_3_1}   xpath=//*[@id="A_11_1_3__1"]
${xpath_pnstestmailFrontEnd_Q4_12_0_4}   xpath=//*[@id="A_12_0_4_"]
${xpath_pnstestmailFrontEnd_Q5_13_0_5}   xpath=//*[@id="A_13_0_5_"]
${xpath_pnstestmailFrontEnd_Q6_14_1_6_1}   xpath=//*[@id="A_14_1_6__1"]
${xpath_pnstestmailFrontEnd_Q7_15_1_7_1}   xpath=//*[@id="A_15_1_7__1"]
${xpath_pnstestmailFrontEnd_Q8_16_0_8_16}   xpath=//*[@id="A_16_0_8_16"]
${xpath_pnstestmailFrontEnd_Q8_17_0_8_16}   xpath=//*[@id="A_17_0_8_16"]
${xpath_pnstestmailFrontEnd_Q8_18_0_8_16}   xpath=//*[@id="A_18_0_8_16"]

${xpath_pnstestmailFrontEnd_Q9_20_1_9_1}   xpath=//*[@id="A_20_1_9__1"]


${xpath_pnstestmailFrontEnd_Q2_B_30_1_2_9_3}    xpath=//*[@id="B_30_1_2_9_3"]

${xpath_pnstestmailFrontEnd_Q3_B_31_1_3__3}    xpath=//*[@id="B_31_1_3__3"]

${xpath_pnstestmailFrontEnd_Q4_B_32_0_4_}    xpath=//*[@id="B_32_0_4_"] 

${xpath_pnstestmailFrontEnd_Q5_B_33_0_5_}    xpath=//*[@id="B_33_0_5_"]

${xpath_pnstestmailFrontEnd_Q6_B_34_1_6__1}    xpath=//*[@id="B_34_1_6__1"] 

${xpath_pnstestmailFrontEnd_Q7_B_35_1_7__1}    xpath=//*[@id="B_35_1_7__1"]

${xpath_pnstestmailFrontEnd_Q8_B_36_0_8_16}    xpath=//*[@id="B_36_0_8_16"] 

${xpath_pnstestmailFrontEnd_Q8_B_37_0_8_16}    xpath=//*[@id="B_37_0_8_16"] 

${xpath_pnstestmailFrontEnd_Q8_B_38_0_8_16}    xpath=//*[@id="B_38_0_8_16"]



${xpath_pnstestmailFrontEnd_cbTreatyConfirm}   xpath=//*[@id="cbTreatyConfirm"]
${xpath_pnstestmailFrontEnd_Submit}   xpath=//*[@id="Submit"]


${xpath_bulkusername}   xpath=//*[@id="USERID"]
${xpath_bulkpassword}   xpath=//*[@id="USERPASSWORD"]
${xpath_bulkenterbutton}   xpath=//*[@id="doLogin"]
${xpath_bulkadminenterbutton}   xpath=//*[@id="_confirm"]

${xpath_bulkSY000}   xpath=//*[@id="SY000"]
${xpath_bulkSY000List3}   xpath=//*[@id="SY000"]/ul/li[3]/a
${xpath_bulkSY000List3bean_search}   xpath=//*[@id="bean_search"]

${xpath_bulkBU000}   xpath=//*[@id="BU000"]
${xpath_bulkBU000List2}   xpath=//*[@id="BU000"]/ul/li[2]/a
${xpath_bulkBU000List2bean_search}   xpath=//*[@id="bean_search"]
${xpath_bulkBU000List2erste}    xpath=//html/body/div[2]/div[3]/div/div[3]/div[3]/div/table/tbody/tr[2]/td[15]/input
${xpath_bulkBU000List2ersteS1}            xpath=//*[@id="panel_S1"]
${xpath_bulkBU000List2ersteS1log_name}    xpath=//*[@id="folder_S1_body"]/p[2]
${xpath_bulkBU000List2ersteS1_log}        xpath=//*[@id="folder_S1_body"]/p[1]/a 
${xpath_bulkBU000List2ersteS2}            xpath=//*[@id="panel_S2"]
${xpath_bulkBU000List2ersteS2log_name}    xpath=//*[@id="folder_S2_body"]/p[2]
${xpath_bulkBU000List2ersteS2_log}        xpath=//*[@id="folder_S2_body"]/p[1]/a
${xpath_bulkBU000List2ersteS3}            xpath=//*[@id="panel_S3"]
${xpath_bulkBU000List2ersteS3log_name}    xpath=//*[@id="folder_S3_body"]/p[2]
${xpath_bulkBU000List2ersteS3_log}        xpath=//*[@id="folder_S3_body"]/p[1]/a


${xpath_pnsSSOlogin}   xpath=//*[@id="btnLoginS"]
${xpath_pnsSSOsignup_1}   xpath=//*[@id="lnkEzPost_Click"]
${xpath_pnsSSOsignup_2}    xpath=//*[@id="RegisterLink"]
${xpath_pnsSSOFrontEnd_username}   xpath=//*[@id="inputEmail"]
${xpath_pnsSSOFrontEnd_password}   xpath=//*[@id="inputPd"]
${xpath_pnsSSOFrontEnd_enterbutton}   xpath=//*[@id="form-login"]/div/div/div/div[2]/div[4]/div[2]/div/button
${xpath_pnsSSOold_nexttime}    xpath=//*[@id="UpgradeConfirmBtn"]
${xpath_pnsSSOnew_nexttime}    xpath=//*[@id="alertModal"]/div/div/div[3]/div/button[1]
${xpath_pnsSSOnew_binding}    xpath=//*[@id="alertModal"]/div/div/div[3]/div/button[2]
${xpath_pnsSSOFrontEndregister_phone}   xpath=//*[@id="fake-legend"]
${xpath_pnsSSOFrontEndinput_phone}   xpath=//*[@id="inputEmail"]
${xpath_pnsSSOregister_phone}        xpath=//*[@id="root"]/div[2]/div/div/div/button[2]
${xpath_pnsSSOverification_code}        xpath=//*[@id="root"]/div[2]/div/div/div/button[2]
${xpath_pnsSSOpassword_1}    xpath=//*[@id="form-2a-pass-toggle-1"]
${xpath_pnsSSOpassword_2}    xpath=//*[@id="form-2a-pass-toggle-2"]
${xpath_pnsSSObirthday}    xpath=//*[@id="root"]/div[2]/div/div/form/div[5]/div/div/div/input
${xpath_pnsSSOinformation_checkbox}    xpath=//*[@id="root"]/div[2]/div/div/form/div[7]/label/input
${mask_below_1}    xpath=//*[@id="mask_below"]
${mask_below_2}    xpath=//*[@id="mask_below"]/div
${mask_below_3}    xpath=//*[@id="mask_below"]/div/div[1]
${mask_below_4}    xpath=//*[@id="mask_below"]/div/div[1]/div
${mask_below_5}    xpath=//*[@id="mask_below"]/div/div[1]/div/div
${mask_below_6}    xpath=//*[@id="mask_below"]/div/div[1]/div/div/p[1]

${termsContainer}    xpath=//*[@id="termsContainer"]
${xpath_pnsSSOnew_binding2_submitButton}    xpath=//*[@id="submitButton"]

${xpath_pnsSSOinformation_mask_below_button}    xpath=//*[@id="mask_below"]/div/div[2]/button
${xpath_pnsSSOinformation_primary_button}    xpath=//*[@id="root"]/div[2]/div/div/form/div[8]/button
${xpath_pnsSSOforget}    xpath=//*[@id="form-login"]/div/div/div/div[2]/div[5]/div[1]/a
${xpath_pnsSSOsend_forget_password_button}    xpath=//*[@id="form-ForgotPd"]/div[1]/div/div/div[5]/div[2]/div/button
${xpath_pnsSSOUpgrade}    xpath=//*[@id="UpgradeCencelBtn"]
${xpath_pnsSSOreturn_button}    xpath=//*[@id="root"]/div[2]/div/div/div[2]/button
${xpath_pnsSSOforget_birthday}    xpath=//*[@id="form-3-date-picker-1"]
${xpath_pnsSSOforget_birthday_sendbutton}    xpath=//*[@id="root"]/div[2]/div/div/div/button
${xpath_pnsSSOnew_password1}    xpath=//*[@id="form-4-pass-toggle-1"]
${xpath_pnsSSOnew_password2}    xpath=//*[@id="form-4-pass-toggle-2"]
${xpath_pnsSSOnew_password_sendbutton}    xpath=//*[@id="root"]/div[2]/div/div/div/button
${xpath_pnsSSO_verification_code_otp-0}    xpath=//*[@id="otp-0"]
${xpath_pnsSSOnew_binding2_username}    xpath=//*[@id="MerberInfo_MEMBER_NAME"]
${xpath_pnsSSOnew_binding2_phone_number}    xpath=//*[@id="MerberInfo_MEMBER_PHONE"]
${xpath_PnsSSOddlnew_binding2_address_CITY}   xpath=//*[@id="CITY"]
${xpath_PnsSSOddlnew_binding2_address_AREA}   xpath=//*[@id="AREA"]
${xpath_PnsSSOddlnew_binding2_address_ROAD}   xpath=//*[@id="RADDRoad"]
${xpath_PnsSSOddlnew_binding2_address_ROADNumber}    xpath=//*[@id="OTHER"]
${xpath_pnsSSOnew_binding2_RegBnt}   xpath=//*[@id="RegBnt"]
${xpath_pnsSSOnew_binding2_returnBnt}   xpath=//html/body/main/div[1]/div/div/div/div/div[2]/button[2]
${xpath_pnsSSOlogin_rightnow}     xpath=//html/body/div[3]/div/div/div/button[2]
${xpath_gview_jqgrid_table}       xpath=//*[@id="gview_jqgrid"]/div[2]/div/table



${xpath_591FrontEndContent1_title}    xpath=//*[@id="UpgradeConfirmBtn"]





*** keywords ***






post_postweb2_pnsBackEndlogin
        [Arguments]     ${url}
        [Documentation]    Do bmc web login
        ${Browser_Ids}=  Browser.Get Browser Ids
        ${Page_Ids}=     Browser.Get Page Ids
        IF  ${Browser_Ids} != []
            Browser.Go To    ${url}
        ELSE
#            New Browser  firefox  headless=false  args=['--allow-insecure-localhost']
            New Browser  chromium  headless=false  args=['--allow-insecure-localhost']
            New Context  ignoreHTTPSErrors=${True}  bypassCSP=${True}
            New Page    ${url}
        END
#        Open Browser  ${url}  firefox
#        Set Browser Timeout  60s
#        New Context    viewport={'width': 1920, 'height': 1080}


post_postweb2_ClickPnsBackEndLoginUsername
        [Arguments]     ${username}
        [Documentation]
        [Tags]
        Fill Text     ${xpath_pnsBackEnd_username}    ${username}

post_postweb2_ClickPnsBackEndLoginEnter
        [Documentation]
        Click    ${xpath_pnsBackEnd_enterbutton}
        Sleep  1s

post_postweb2_ClickPnsBackEndtvFunctionn0Nodes
        [Documentation]
        Select_Frame     ${xpath_pnsBackEndSelectFrame1}
        Click Element    ${xpath_pnsBackEndtvFunctionn0Nodes}
        Unselect_Frame
        Sleep  1s

post_postweb2_ClickPnsBackEndtvFunctiont1
        [Documentation]
#        Select_Frame     ${xpath_pnsBackEndSelectFrame1}
#        Click Element    ${xpath_pnsBackEndtvFunctiont1}
#        Unselect_Frame
        Click  ${xpath_pnsBackEndSelectFrame1} >>> ${xpath_pnsBackEndtvFunctiont1}
        Sleep  1s

post_postweb2_ClickPnsBackEndtvFunctiont1i
        [Documentation]
        Click Element    ${xpath_pnsBackEndtvFunctiont1i}
        Sleep  1s

post_postweb2_ClickPnsBackEndtvFunctiont2
        [Documentation]
#        Select_Frame     ${xpath_pnsBackEndSelectFrame1}
#        Click Element    ${xpath_pnsBackEndtvFunctiont2}
#        Unselect_Frame
        Click  ${xpath_pnsBackEndSelectFrame1} >>> ${xpath_pnsBackEndtvFunctiont2}
        Sleep  1s


post_postweb2_ClickPnsBackEndtvFunctionti  
        [Arguments]     ${program_no}
#        Select_Frame     ${xpath_pnsBackEndSelectFrame1}
#        Click Element    ${xpath_pnsBackEndtvFunctiont3}
#        Unselect_Frame
        FOR  ${i}  IN RANGE  1  100  1

            ${xpath_tvFunctiont}=  set variable   tvFunctiont${i} 
            Log  ${xpath_tvFunctiont}

            ${tvFunctiont_value}=    Get text     ${xpath_pnsBackEndSelectFrame1} >>> xpath=//*[@id="${xpath_tvFunctiont}"]
            Log  ${tvFunctiont_value}
#            ${tvFunctiont_value_split}=    Split String    ${tvFunctiont_value}    _
#            Log   ${tvFunctiont_value_split}[0]
            IF  '${program_no}' == '${tvFunctiont_value}'
                Exit For Loop
            END
        END
        Click  ${xpath_pnsBackEndSelectFrame1} >>> xpath=//*[@id="${xpath_tvFunctiont}"]
        Sleep  1s

post_postweb2_ClickPnsBackEndtvFunctiontj
        [Arguments]     ${program_no}
#        Select_Frame     ${xpath_pnsBackEndSelectFrame1}
#        Click Element    ${xpath_pnsBackEndtvFunctiont3}
#        Unselect_Frame
        FOR  ${i}  IN RANGE  1  100  1

            ${xpath_tvFunctiont}=  set variable   tvFunctiont${i} 
            Log  ${xpath_tvFunctiont}

            ${tvFunctiont_value}=    Get text     ${xpath_pnsBackEndSelectFrame1} >>> xpath=//*[@id="${xpath_tvFunctiont}"]
            Log  ${tvFunctiont_value}
            ${tvFunctiont_value_split}=    Split String    ${tvFunctiont_value}    _
            Log   ${tvFunctiont_value_split}[0]
            IF  '${program_no}' == '${tvFunctiont_value_split}[0]'
                Exit For Loop
            END
        END
        Click  ${xpath_pnsBackEndSelectFrame1} >>> xpath=//*[@id="${xpath_tvFunctiont}"]
        Sleep  1s

post_postweb2_ClickPnsBackEndtvFunctiont4
        [Documentation]
#        Select_Frame     ${xpath_pnsBackEndSelectFrame1}
#        Click Element    ${xpath_pnsBackEndtvFunctiont4}
#        Unselect_Frame
        Click  ${xpath_pnsBackEndSelectFrame1} >>> ${xpath_pnsBackEndtvFunctiont4}
        Sleep  1s

post_postweb2_ClickPnsBackEndtvFunctiont20
        [Documentation]
#        Select_Frame     ${xpath_pnsBackEndSelectFrame1}
#        Click Element    ${xpath_pnsBackEndtvFunctiont4}
#        Unselect_Frame
        Click  ${xpath_pnsBackEndSelectFrame1} >>> ${xpath_pnsBackEndtvFunctiont20}
        Sleep  1s

post_postweb2_ClickPnsBackEndtvFunctiont21
        [Documentation]
#        Select_Frame     ${xpath_pnsBackEndSelectFrame1}
#        Click Element    ${xpath_pnsBackEndtvFunctiont4}
#        Unselect_Frame
        Click  ${xpath_pnsBackEndSelectFrame1} >>> ${xpath_pnsBackEndtvFunctiont21}
        Sleep  1s

post_postweb2_ClickPnsBackEndtvFunctiont22
        [Documentation]
#        Select_Frame     ${xpath_pnsBackEndSelectFrame1}
#        Click Element    ${xpath_pnsBackEndtvFunctiont4}
#        Unselect_Frame
        Click  ${xpath_pnsBackEndSelectFrame1} >>> ${xpath_pnsBackEndtvFunctiont22}
        Sleep  1s

post_postweb2_ClickPnsBackEndtvFunctiont23
        [Documentation]
#        Select_Frame     ${xpath_pnsBackEndSelectFrame1}
#        Click Element    ${xpath_pnsBackEndtvFunctiont4}
#        Unselect_Frame
        Click  ${xpath_pnsBackEndSelectFrame1} >>> ${xpath_pnsBackEndtvFunctiont23}
        Sleep  1s

post_postweb2_ClickPnsBackEndtvFunctiont24
        [Documentation]
#        Select_Frame     ${xpath_pnsBackEndSelectFrame1}
#        Click Element    ${xpath_pnsBackEndtvFunctiont4}
#        Unselect_Frame
        Click  ${xpath_pnsBackEndSelectFrame1} >>> ${xpath_pnsBackEndtvFunctiont24}
        Sleep  1s

post_postweb2_ClickPnsBackEndtvFunctiont25
        [Documentation]
#        Select_Frame     ${xpath_pnsBackEndSelectFrame1}
#        Click Element    ${xpath_pnsBackEndtvFunctiont4}
#        Unselect_Frame
        Click  ${xpath_pnsBackEndSelectFrame1} >>> ${xpath_pnsBackEndtvFunctiont25}
        Sleep  1s

post_postweb2_ClickPnsBackEndtvFunctiont26
        [Documentation]
#        Select_Frame     ${xpath_pnsBackEndSelectFrame1}
#        Click Element    ${xpath_pnsBackEndtvFunctiont4}
#        Unselect_Frame
        Click  ${xpath_pnsBackEndSelectFrame1} >>> ${xpath_pnsBackEndtvFunctiont26}
        Sleep  1s

post_postweb2_ClickPnsBackEndtvFunctiont27
        [Documentation]
#        Select_Frame     ${xpath_pnsBackEndSelectFrame1}
#        Click Element    ${xpath_pnsBackEndtvFunctiont4}
#        Unselect_Frame
        Click  ${xpath_pnsBackEndSelectFrame1} >>> ${xpath_pnsBackEndtvFunctiont27}
        Sleep  1s

post_postweb2_ClickPnsBackEndtvFunctiont28
        [Documentation]
#        Select_Frame     ${xpath_pnsBackEndSelectFrame1}
#        Click Element    ${xpath_pnsBackEndtvFunctiont4}
#        Unselect_Frame
        Click  ${xpath_pnsBackEndSelectFrame1} >>> ${xpath_pnsBackEndtvFunctiont28}
        Sleep  1s

post_postweb2_ClickPnsBackEndtvFunctiont29
        [Documentation]
#        Select_Frame     ${xpath_pnsBackEndSelectFrame1}
#        Click Element    ${xpath_pnsBackEndtvFunctiont4}
#        Unselect_Frame
        Click  ${xpath_pnsBackEndSelectFrame1} >>> ${xpath_pnsBackEndtvFunctiont29}
        Sleep  1s










post_postweb2_ClickPnsBackEndContent1_btnQuery
        [Documentation]

#        Click  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndContent1_btnQuery}

        Click  ${xpath_pnsBackEndSelectFrame2} >>> xpath=//html/body/form/div[3]/table[2]/tbody/tr/td/div[2]/input[1]
        Sleep  1s
        Take Screenshot

post_postweb2_ClickPnsBackEndContent1_btnSend
        [Documentation]

        Click  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndContent1_btnSend}
        Sleep  1s
        Take Screenshot

post_postweb2_ClickPnsBackEndContent1_wucUpload
        [Documentation]

        Click  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndContent1_wucUpload}
        Sleep  1s
        Take Screenshot


post_postweb2_ClickPnsBackEndContent1_btnDownload
        [Documentation]

        Click  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndContent1_btnDownload}
        Sleep  1s
        Take Screenshot



post_postweb2_ClickPnsBackEndDateStart_Upload_CalTextBox
        [Arguments]     ${DateStart}
        [Documentation]
        [Tags]
        Fill Text      ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndDateStart_Upload_CalTextBox}  ${DateStart}
        Sleep  1s


post_postweb2_ClickPnsBackEndDateEnd_Upload_CalTextBox
        [Arguments]     ${DateEnd}
        [Documentation]
        [Tags]
        Fill Text  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndDateEnd_Upload_CalTextBox}  ${DateEnd}
        Sleep  1s


post_postweb2_ClickPnsBackEndDateStart_Send_CalTextBox
        [Arguments]     ${DateStart}
        [Documentation]
        [Tags]
        Fill Text      ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndDateStart_Send_CalTextBox}  ${DateStart}
        Sleep  1s


post_postweb2_ClickPnsBackEndDateEnd_Send_CalTextBox
        [Arguments]     ${DateEnd}
        [Documentation]
        [Tags]
        Fill Text  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndDateEnd_Send_CalTextBox}  ${DateEnd}
        Sleep  1s


post_postweb2_ClickPnsBackEndDateStart_CalTextBox
        [Arguments]     ${DateStart}
        [Documentation]
        [Tags]
        Fill Text      ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndDateStart_CalTextBox}  ${DateStart}
        Sleep  1s



post_postweb2_ClickPnsBackEndtxtDid
        [Arguments]     ${txtDid}
        [Documentation]
        [Tags]
        Fill Text  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndtxtDid}  ${txtDid}
        Sleep  1s


post_postweb2_ClickPnsBackEndtxtUploaderID
        [Arguments]     ${txtUploaderID}
        [Documentation]
        [Tags]
        Fill Text  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndtxtUploaderID}  ${txtUploaderID}
        Sleep  1s


post_postweb2_ClickPnsBackEndtxtFirstInspectorID
        [Arguments]     ${txtFirstInspectorID}
        [Documentation]
        [Tags]
        Fill Text  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndtxtFirstInspectorID}  ${txtFirstInspectorID}
        Sleep  1s


post_postweb2_ClickPnsBackEndtxtSecondInspectorID
        [Arguments]     ${txtSecondInspectorID}
        [Documentation]
        [Tags]
        Fill Text  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndtxtSecondInspectorID}  ${txtSecondInspectorID}
        Sleep  1s


post_postweb2_ClickPnsBackEndrblTyperbl1_0
        [Documentation]
#        Select_Frame     ${xpath_pnsBackEndSelectFrame2}
#        Click Element    ${xpath_pnsBackEndrblTyperbl1_0}
#        Unselect_Frame
        Click  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndrblTyperbl1_0}
        Sleep  1s


post_postweb2_ClickPnsBackEndrblTyperbl1_1
        [Documentation]
#        Select_Frame     ${xpath_pnsBackEndSelectFrame2}
#        Click Element    ${xpath_pnsBackEndrblTyperbl1_1}
#        Unselect_Frame
        Click  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndrblTyperbl1_1}
        Sleep  1s


post_postweb2_ClickPnsBackEndddlStatusddl1
        [Arguments]     ${select_value}
        [Documentation]
#         Select Options By   ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndContent1_ddlVerificationOffice_ddl1}  value   ${select_value}
        Select Options By     ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndddlStatusddl1}  value   ${select_value}
        Sleep  1s


post_postweb2_ClickPnsBackEndddlCommentTypeddl1
        [Arguments]     ${select_value}
        [Documentation]
#         Select Options By   ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndContent1_ddlVerificationOffice_ddl1}  value   ${select_value}
        Select Options By     ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndddlCommentTypeddl1}  value   ${select_value}
        Sleep  1s

post_postweb2_ClickPnsBackEndContent1_fvw_CommentType_ddl1
        [Arguments]     ${select_value}
        [Documentation]
        Select Options By     ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndContent1_fvw_ddlCommentType_ddl1}  value   ${select_value}
        Sleep  1s

post_postweb2_ClickPnsBackEndContent1_fvw_ddlStatus_ddl1
        [Arguments]     ${select_value}
        [Documentation]
        Select Options By     ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndContent1_fvw_ddlStatus_ddl1}  value   ${select_value}
        Sleep  1s


post_postweb2_ClickPnsBackEndContent1_fvw_ddlInspector_ddl1
        [Arguments]     ${select_value}
        [Documentation]
        ${str_select_value}=    Convert_To_String    ${select_value}
        Select Options By     ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndContent1_fvw_ddlInspector_ddl1}  value   ${str_select_value}
        Sleep  1s

post_postweb2_ClickPnsBackEndddlScheduleType_ddl1
        [Arguments]     ${select_value}
        [Documentation]
#         Select Options By   ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndContent1_ddlVerificationOffice_ddl1}  value   ${select_value}
        Select Options By     ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndddlScheduleType_ddl1}  value   ${select_value}
        Sleep  1s



post_postweb2_ClickPnsBackEndContent1_fvw_txtFirstInspectDesc
        [Arguments]     ${txtFirstInspectDesc}
        [Documentation]
        Fill Text  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndContent1_fvw_txtFirstInspectDesc}  ${txtFirstInspectDesc}
        Sleep  1s


post_postweb2_ClickPnsBackEndContent1_fvw_txtSecondInspectDesc
        [Arguments]     ${txtSecondInspectDesc}
        [Documentation]
        Fill Text  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndContent1_fvw_txtSecondInspectDesc}  ${txtSecondInspectDesc}
        Sleep  1s


post_postweb2_ClickPnsBackEndContent1_ddlVerificationOffice_ddl1
        [Arguments]     ${select_value}
        [Documentation]

#        Select Options By   ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndContent1_ddlVerificationOffice_ddl1}  value   ${select_value_TaipeiPostOffice}
         Select Options By   ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndContent1_ddlVerificationOffice_ddl1}  value   ${select_value}
        Sleep  1s

post_postweb2_ClickPnsBackEndContent1_gvList_LinkButton_0
        [Documentation]
#        Select_Frame     ${xpath_pnsBackEndSelectFrame2}
#        Click Element    ${xpath_pnsBackEndContent1_gvList_LinkButton_0}
#        Unselect_Frame
        Click  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndContent1_gvList_LinkButton_0}
        Sleep  1s

post_postweb2_CheckPnsBackEndContent1_gvList_LinkButton_0
        [Arguments]     ${CR_no}
        [Documentation]

        Take Screenshot
        ${LB0_no}=  Get_text  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndContent1_gvList_LinkButton_0}
        Run Keyword If    "${LB0_no}"!="${CR_no}"    FAIL    msg=${message}


post_postweb2_ClickPnsBackEndContent1_gvList_LinkButton
        [Arguments]     ${LinkButton_no}
        [Documentation]

        ${xpath_pnsBackEndContent1_gvList_LinkButton_no}=  set variable  xpath_pnsBackEndContent1_gvList_LinkButton_${LinkButton_no}

        Click  ${xpath_pnsBackEndSelectFrame2} >>> ${${xpath_pnsBackEndContent1_gvList_LinkButton_no}}
        Sleep  1s


post_postweb2_ClickPnsBackEndContent1_fvw_ddl1_ddl1
        [Arguments]     ${select_value}
        [Documentation]

#        Select Options By   ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndContent1_fvw_ddl1_ddl1}  value   ${select_value_TaipeiPostOffice}
        Select Options By   ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndContent1_fvw_ddl1_ddl1}  value   ${select_value}
        Sleep  2s

post_postweb2_ClickPnsBackEndContent1_fvw_ddl2_ddl1
        [Arguments]     ${select_value}
        [Documentation]

#        Select Options By   ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndContent1_fvw_ddl2_ddl1}  value   ${select_value_Zhongzheng_delivery}
        Select Options By   ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndContent1_fvw_ddl2_ddl1}  value   ${select_value}
        Sleep  1s



post_postweb2_ClickPnsBackEndContent1_fvw_btnSave
        [Documentation]
 
        Click  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndContent1_fvw_btnSave}
        Sleep  1s


post_postweb2_ClickPnsBackEndContent1_fvw1Print
        [Documentation]

        Handle Future Dialogs    action=accept
        Click  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndContent1_fvw1_btnFvwPrint_btnPrint}
        Take Screenshot

        Sleep  5s
        ${catalog}=   Get Browser Catalog
        Get Title

        log  ${catalog}[0]
        log  ${catalog}[0][contexts]
        log  ${catalog}[0][contexts][0][pages]
        log  ${catalog}[0][contexts][0][pages][0]
        log  ${catalog}[0][contexts][0][pages][0][id]
        log  ${catalog}[0][contexts][0][pages][1]
        log  ${catalog}[0][contexts][0][pages][1]
        log  ${catalog}[0][contexts][0][pages][1][id]


#        ${previous_page_id}=   Switch Page   ${catalog}[0][contexts][0][pages][0][id]
#        log   ${previous_page_id}
        Get Title

        Take Screenshot

        Sleep  1s

#        Close Page    CURRENT     CURRENT     CURRENT



#        ${previous_previous_page_id}=   Switch Page   ${previous_page_id}
#        log   ${previous_previous_page_id}

        Close Page    ${catalog}[0][contexts][0][pages][0][id]     CURRENT     CURRENT

        ${catalog}=   Get Browser Catalog
        Get Title

        Take Screenshot

        Sleep  1s


#        ${titles}  Get Window Titles
#        Log_To_Console  all_titles: ${titles}
#        ${titles1}      Get From List   ${titles}   0
#        Log_To_Console  titles_1: ${titles1}
#        ${titles2}      Get From List   ${titles}   1
#        Log_To_Console  titles_2: ${titles2}
#        Switch Window    title=${titles2}
#        Capture Page Screenshot
#        Close Window
#        Switch Window    title=${titles1}






post_postweb2_FetchPnsBackEndContent1_fvw1Print
        ${message}=  Element Should Be Visible    ${xpath_pnsBackEndContent1_fvw1_btnFvwPrint_btnPrint}
        [Return]  ${message}




post_postweb2_ClickPnsBackEndContent1_fvw1Change
        [Documentation]
#        Select_Frame     ${xpath_pnsBackEndSelectFrame2}
#        Click Element    ${xpath_pnsBackEndContent1_fvw1_btnFvwChange}

        Take Screenshot

        Click  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndContent1_fvw1_btnFvwChange}
#        Handle Alert
#        Click  id=alerts
#        Unselect_Frame


post_postweb2_FetchPnsBackEndContent1_fvw1_btnFvwChange
        [Documentation]

        ${fvw1_btnFvwChange_is_disabled}  ${message}=  Run_Keyword_And_Ignore_Error  Get Attribute    ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndContent1_fvw1_btnFvwChange}  disabled

       [Return]  ${fvw1_btnFvwChange_is_disabled}  ${message}



post_postweb2_FetchPnsBackEndContent1_fvw2_btnFvwChange
        [Documentation]

#        ${fvw2_btnFvwChange_is_disabled}  ${message}=  Run_Keyword_And_Ignore_Error  Get Attribute    ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndContent1_fvw2_btnFvwChange}  disabled


#        ${fvw2_btnFvwChange_is_visible}=  Run Keyword And Continue On Failure    Get Element States    ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndContent1_fvw2_btnFvwChange}  *=   visible   return_names=False

        ${fvw2_btnFvwChange_is_visible}=   Run Keyword And Continue On Failure    Get Element States    ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndContent1_fvw2_btnFvwChange}  then   bool(value & visible)   


       RETURN  ${fvw2_btnFvwChange_is_visible}  



post_postweb2_ClickPnsBackEndContent1_fvw2Change
        [Documentation]

        Take Screenshot
        Click  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndContent1_fvw2_btnFvwChange}



post_postweb2_ClickPnsBackEndContent1_fvw2Print
        [Documentation]

        Handle Future Dialogs    action=accept
        Take Screenshot
        Sleep  1s
        Click  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndContent1_fvw2_btnFvwPrint_btnPrint}
        Take Screenshot

        Sleep  5s
        ${catalog}=   Get Browser Catalog
        Get Title

        log  ${catalog}[0]
        log  ${catalog}[0][contexts]
        log  ${catalog}[0][contexts][0][pages]
        log  ${catalog}[0][contexts][0][pages][0]
        log  ${catalog}[0][contexts][0][pages][0][id]
        log  ${catalog}[0][contexts][0][pages][1]
        log  ${catalog}[0][contexts][0][pages][1]
        log  ${catalog}[0][contexts][0][pages][1][id]


#        ${previous_page_id}=   Switch Page   ${catalog}[0][contexts][0][pages][0][id]
#        log   ${previous_page_id}
        Get Title

        Take Screenshot

        Sleep  1s

#        Close Page    CURRENT     CURRENT     CURRENT



#        ${previous_previous_page_id}=   Switch Page   ${previous_page_id}
#        log   ${previous_previous_page_id}

        Close Page    ${catalog}[0][contexts][0][pages][0][id]     CURRENT     CURRENT

        ${catalog}=   Get Browser Catalog
        Get Title

        Take Screenshot

        Sleep  1s



post_postweb2_ClickPnsBackEndContent1_fvw3Change
        [Documentation]

        Take Screenshot
        Click  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndContent1_fvw3_btnFvwChange}



post_postweb2_FetchPnsBackEndContent1_HavePrint
#        Select_Frame     ${xpath_pnsBackEndSelectFrame2}
        ${HavePrint_match1}  ${message}=  Run_Keyword_And_Ignore_Error  Get Attribute    ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndContent1_fvw1_btnFvwPrint_btnPrint}  disabled
#        Unselect_Frame
        Log  ${HavePrint_match1}
        Log  ${message}
        [Return]  ${HavePrint_match1}  ${message}


post_postweb2_ClickPnsBackEndContent1_fvw1_ResultStateSuccess
        [Documentation]

#        Select Options By   ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndContent1_fvw1_ddlResult_ddl1}   value   ${select_value_30success}

        Select Options By   ${xpath_pnsBackEndSelectFrame2} >>> xpath=//html/body/form/div[3]/table[2]/tbody/tr/td/table/tbody/tr[2]/td/table/tbody/tr/td/table/tbody/tr[11]/td/select   value   ${select_value_30success}
                       
        Sleep  1s

post_postweb2_ClickPnsBackEndContent1_fvw1_ResultStateFail
        [Documentation]
        Select Options By   ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndContent1_fvw1_ddlResult_ddl1}  value   ${select_value_31fail}                     
        Sleep  1s

post_postweb2_ClickPnsBackEndContent1_fvw1_txtVerificationNote
        [Arguments]     ${VerificationNote}
        [Documentation]
        [Tags]
        Fill Text     ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndContent1_fvw1_txtVerificationNote}    ${VerificationNote}
        Sleep  1s


post_postweb2_ClickPnsBackEndContent1_fvw2_txtVerificationNote
        [Arguments]     ${VerificationNote}
        [Documentation]
        [Tags]
        Fill Text     ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndContent1_fvw2_txtVerificationNote}    ${VerificationNote}
        Sleep  1s


post_postweb2_ChoosefileUpload
        [Arguments]     ${source_excel_file}
        [Documentation]
        Log  ${source_excel_file}

        Upload File By Selector     ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEnduploadfile}    ${local_path}\\${Excel_folder_path}\\${source_excel_file}
        Sleep  5s
        Take Screenshot





post_postweb2_ChooseVerifyPicture
        [Documentation]
        Log  ${local_path}\\${Picture_folder_path}\\pnsBackEndVerify.jpeg
        Log  ${local_path}\${Picture_folder_path}\\pnsBackEndVerify.jpeg
        Log  ${local_path}\\${Picture_folder_path}\pnsBackEndVerify.jpeg
        Log  ${local_path}\${Picture_folder_path}\pnsBackEndVerify.jpeg
        Log  .\\${Picture_folder_path}\\pnsBackEndVerify.jpeg
        Log  .\${Picture_folder_path}\\pnsBackEndVerify.jpeg
        Log  .\\${Picture_folder_path}\pnsBackEndVerify.jpeg
        Log  .\${Picture_folder_path}\pnsBackEndVerify.jpeg
        Log  ${local_path}\\${Picture_folder_path}\\pnsBackEndVerify.jpeg
        Log  ${CURDIR}

#        Select_Frame     ${xpath_pnsBackEndSelectFrame2}
#        Choose File    ${xpath_pnsBackEnduploadVerifyPicture}    ${local_path}/${Picture_folder_path}/pnsBackEndVerify.jpeg
#        Choose File    ${xpath_pnsBackEnduploadVerifyPicture}    ${local_path}\\${Picture_folder_path}\\pnsBackEndVerify.jpeg



        Take Screenshot

        ${catalog}=   Get Browser Catalog
        Get Title

        log  ${catalog}[0]
        log  ${catalog}[0][contexts]
        log  ${catalog}[0][contexts][0][pages]
        log  ${catalog}[0][contexts][0][pages][0]
        log  ${catalog}[0][contexts][0][pages][0][id]
#        log  ${catalog}[0][contexts][0][pages][1]
#        log  ${catalog}[0][contexts][0][pages][1]
#        log  ${catalog}[0][contexts][0][pages][1][id]

        ${Get_Attribute_Names_pnsBackEnduploadVerifyPicture}  ${message}=  Run_Keyword_And_Ignore_Error  Get Attribute Names    ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEnduploadVerifyPicture}  

        ${Get_Element_pnsBackEnduploadVerifyPicture}  ${message}=  Run_Keyword_And_Ignore_Error  Get Element     ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEnduploadVerifyPicture}

        ${Get_Property_pnsBackEnduploadVerifyPicture}  ${message}=  Run_Keyword_And_Ignore_Error  Get Property     ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEnduploadVerifyPicture}  value



        Upload File By Selector     ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEnduploadVerifyPicture}    ${local_path}\\${Picture_folder_path}\\pnsBackEndVerify.jpg
#        Unselect_Frame
        Sleep  5s
        Take Screenshot



post_postweb2_fvw2_ChooseVerifyPicture
        [Documentation]


        Upload File By Selector     ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEnd_fvw2_uploadVerifyPicture}    ${local_path}\\${Picture_folder_path}\\pnsBackEndVerify.jpg

        Sleep  5s
        Take Screenshot



post_postweb2_ClickPnsBackEndContent1_fvw1_btnUpload
        [Documentation]

#        Handle Future Dialogs    action=accept

        Sleep  1s

        Click  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndContent1_fvw1_btnUpload}
        Take Screenshot
        Sleep  1s
        Take Screenshot

post_postweb2_ClickPnsBackEndContent1_fvw2_btnUpload
        [Documentation]

#        Handle Future Dialogs    action=accept

        Sleep  1s

        Click  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndContent1_fvw2_btnUpload}
        Take Screenshot
        Sleep  1s
        Take Screenshot

post_postweb2_FetchPnsBackEndContent1_fvw2_HavePrint


        ${HavePrint_match1}  ${message}=  Run_Keyword_And_Ignore_Error  Get Element States    ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndContent1_fvw2_btnFvwPrint_btnPrint}  *=  disable


        Log  ${HavePrint_match1}
        Log  ${message}
        [Return]  ${HavePrint_match1}  ${message}









post_postweb2_ClickPnsBackEndContent1_btnFvwSave
        [Documentation]
#        Select_Frame     ${xpath_pnsBackEndSelectFrame2}
#        Click Element    ${xpath_pnsBackEndContent1_btnFvwSave}
        Click  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndContent1_btnFvwSave}
#        Handle Alert
#        Click  id=alerts
#        Unselect_Frame
#        Capture Page Screenshot
        Take Screenshot
#        ${titles}=  Get Window Titles
        ${titles}=  Get Title
        Log_To_Console  ${titles}



post_postweb2_FetchPnsBackEndContent1_HaveUploadPicture

        ${HaveUploadPicture_match1}  ${message}=  Run Keyword And Continue On Failure    Get Element States         ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndContent1_fvw1_lbtnFile}  contains   visible

        [Return]  ${HaveUploadPicture_match1}  ${message}



post_postweb2_FetchPnsBackEndContent1_fvw2_HaveUploadPicture

        ${HaveUploadPicture_match1}  ${message}=  Run Keyword And Continue On Failure    Get Element States     ${xpath_pnsBackEndContent1_fvw2_lbtnFile}  contains   detached

        [Return]  ${HaveUploadPicture_match1}  ${message}

post_postweb2_ClickPnsBackEndContent1_fvw2_ResultStateSuccess
        [Documentation]
#        Select_Frame     ${xpath_pnsBackEndSelectFrame2}
#        Select From List By Value   ${xpath_pnsBackEndContent1_fvw2_ddlResult_ddl1}      ${select_value_30success}
        Select Options By   ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndContent1_fvw2_ddlResult_ddl1}  value   ${select_value_30success}
#        Unselect_Frame                       
        Sleep  1s

post_postweb2_ClickPnsBackEndContent1_fvw2_ResultStateFail
        [Documentation]
        Select Options By   ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndContent1_fvw2_ddlResult_ddl1}  value   ${select_value_31fail}                    
        Sleep  1s

post_postweb2_ClickPnsBackEndContent1_fvw3_ResultStateSuccess
        [Documentation]
#        Select_Frame     ${xpath_pnsBackEndSelectFrame2}
#        Select From List By Value   ${xpath_pnsBackEndContent1_fvw3_ddlResult_ddl1}      ${select_value_30success}
        Select Options By   ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndContent1_fvw3_ddlResult_ddl1}  value   ${select_value_30success}
#        Unselect_Frame                       
        Sleep  1s

post_postweb2_ClickPnsBackEndContent1_fvw3_ResultStateFail
        [Documentation]
        Select Options By   ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndContent1_fvw3_ddlResult_ddl1}  value   ${select_value_31fail}                    
        Sleep  1s

post_postweb2_ClickPnsBackEndContent1_fvw3_txtVerificationNote
        [Arguments]     ${VerificationNote}
        [Documentation]
        [Tags]
        Fill Text     ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndContent1_fvw3_txtVerificationNote}    ${VerificationNote}
        Sleep  1s




post_postweb2_ClickPnsBackEndContent1_btnFvw1Save
        [Documentation]

        Click  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndContent1_btnFvw1Save}

        Take Screenshot

        ${title}=  Get Title
        Log_To_Console  ${title}


post_postweb2_ClickPnsBackEndContent1_btnFvw2Save
        [Documentation]

        Click  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndContent1_btnFvw2Save}

        Take Screenshot

        ${title}=  Get Title
        Log_To_Console  ${title}


post_postweb2_ClickPnsBackEndddlNewCity_ddl1
        [Arguments]        ${City_name}   ${District_name}   ${Road_name}   ${NewNumber}    ${String}
    Log   City_name=${City_name} District_name=${District_name} Road_name=${Road_name} NewNumber=${NewNumber} String=${String}
    IF  '${String}' == 'post'
        Click   ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsrblNewPostType_Backend}
        Select Options By   ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsddlNewOrangePost1_Backend}  value   ${City_name}
        Sleep  1s
        Select Options By   ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsddlNewOrangePost2_Backend}  value   ${District_name}
        Sleep  1s
        Select Options By   ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsddlNewOrangePost3_Backend}  index   1
        Sleep  1s
        Fill Text  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnstxtNewPostNumber_Backend}  ${NewNumber}


    ELSE
        Select Options By   ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_PnsddlCity_ddl1}  value   ${City_name}
        Sleep  1s

        Select Options By   ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_PnsddlArea_ddl1}  value   ${District_name}
        Sleep  1s
        Log  ${String}
        IF  '${String}' == 'object'

            Select Options By   ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_PnsddlRoad_ddl1}  value   ${Road_name}
        ELSE IF  '${String}' == 'string'
            Click   ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_PnschkNewRoad_Backend}

            fill text   ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_PnstxtNewRoad_Backend}     ${Road_name}
        ELSE
            Fail
        END





        Fill Text  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_PnstxtLane}         1
        Fill Text  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_PnstxtAlley}        2
        Fill Text  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_PnstxtSubNumber}    3
        Fill Text  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_PnstxtFloor}        4
        Fill Text  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_PnstxtRoom}         808
        Fill Text  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_PnstxtSubFloor}     5

        Sleep  1s
        Click   ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_PnstxtRemark_Backend} 
        Fill Text  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_PnstxtRemark_Backend}  測試註記
       
        Sleep  1s
        Take Screenshot
        Fill Text  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_PnstxtNumber}  ${NewNumber}
        Take Screenshot
    END
    Click  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_PnstxtVerificationDate_Backend}
    Sleep  1s
    Fill Text  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_PnstxtVerificationDate_Backend}  113/6/1 
    Take Screenshot



post_postweb2_ClickPnsBackEndddlOldCity_ddl1
        [Arguments]        ${City_name}   ${District_name}   ${Road_name}   ${OldNumber}    ${String}
    Log   City_name=${City_name} District_name=${District_name} Road_name=${Road_name} OldNumber=${OldNumber} String=${String}
    IF  '${String}' == 'post'
        Click   ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsrblOldPostType_Backend}
        Select Options By   ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsddlOldOrangePost1_Backend}  value   ${City_name}
        Sleep  1s
        Select Options By   ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsddlOldOrangePost2_Backend}  value   ${District_name}
        Sleep  1s
        Select Options By   ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsddlOldOrangePost3_Backend}  index   1
        Sleep  1s
        Fill Text  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnstxtOldPostNumber_Backend}  ${OldNumber}


    ELSE
#        Select Options By   ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_PnsddlCity_old_ddl1}  value   ${select_value_TaipeiCity}
        Select Options By   ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_PnsddlCity_old_ddl1}  value   ${City_name}
        Sleep  1s
#        Select Options By   ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_PnsddlArea_old_ddl1}  value   ${select_value_ZhongzhengDistrict}
        Select Options By   ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_PnsddlArea_old_ddl1}  value   ${District_name}
        Sleep  1s  
        Log  ${String}
        IF  '${String}' == 'object'
#            Select Options By   ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_PnsddlRoad_old_ddl1}  value   ${select_value_SanyuanStreet}
            Select Options By   ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_PnsddlRoad_old_ddl1}  value   ${Road_name}
        ELSE IF  '${String}' == 'string'
            Click   ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_PnschkOldRoad_Backend}
#            fill text   ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_PnstxtOldRoad_Backend}     中山北路1段
            fill text   ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_PnstxtOldRoad_Backend}     ${Road_name}
        ELSE
            Fail
        END
        Fill Text  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_PnstxtLane_old}         1
        Fill Text  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_PnstxtAlley_old}        2
        Fill Text  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_PnstxtSubNumber_old}    3
        Fill Text  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_PnstxtFloor_old}        4
        Fill Text  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_PnstxtRoom_old}         808
        Fill Text  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_PnstxtSubFloor_old}     5
        Sleep  1s
        Fill Text  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_PnstxtNumber_old}  ${OldNumber}
        Take Screenshot
        Sleep  1s
        Take Screenshot
    END




post_postweb2_ClickPnsBackEndbtnSend
        Scroll To  vertical=bottom
        Sleep  1s
#        Scroll To Element     ${xpath_PnsbtnSend} 
        Click     ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_PnstxtUserName_Backend}
        Sleep  1s
        Fill Text  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_PnstxtUserName_Backend}  呂紹宏
        Click     ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_PnstxtCellPhone_Backend}
        Sleep  1s
        Fill Text  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_PnstxtCellPhone_Backend}  0963038476
#        Sleep  1s
        Fill Text  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_PnstxtTelePhone_Backend}  02-2375-3160
#        Sleep  1s

        Fill Text  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_PnstxtEmail}  tw.shaohung@gmail.com

        Debug

        Click     ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_PnsbtnSave} 
#        Sleep  10s
#        Handle Alert
#        Click  id=alerts
#        Sleep  1s
#        Capture Page Screenshot
        Take Screenshot
        Sleep  1s


post_postweb2_ClickPnsBackEndTextBox
        Fill Text  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_PnsTextBox1_Backend}    大寶
        Fill Text  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_PnsTextBox2_Backend}    二寶
        Fill Text  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_PnsTextBox3_Backend}    三寶
        Fill Text  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_PnsTextBox4_Backend}    四寶
        Fill Text  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_PnsTextBox5_Backend}    五寶

        Click      ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_PnsbtnP1} 

        Fill Text  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_PnsTextBox6_Backend}    六寶
        Fill Text  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_PnsTextBox7_Backend}    七寶
        Fill Text  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_PnsTextBox8_Backend}    八寶
        Fill Text  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_PnsTextBox9_Backend}    九寶
        Fill Text  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_PnsTextBox10_Backend}    十寶



post_postweb2_ClickPnsBackEndddlEffectiveDate
        [Arguments]     ${StartDate}  ${EndDate}
        Sleep  1s
        Click      ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_PnstxtEffectiveStartDate_Backend}
        Sleep  1s
        Fill Text  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_PnstxtEffectiveStartDate_Backend}    ${StartDate}
        Sleep  1s
        Click      ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_PnstxtEffectiveEndDate_Backend}
        Sleep  1s
        Fill Text  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_PnstxtEffectiveEndDate_Backend}    ${EndDate}

post_postweb2_ClickPnsBackEndbtnQuery
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}
        Click  ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndContent1_btnQuery}
        Sleep  1s

post_postweb2_FetchPnsBackEndLinkButton_0
        [Documentation]

#        ${result}  ${bEI0_content}=  Run_Keyword_And_Ignore_Error  Get text     ${xpath_PnsFrontEndbtnEditInfo_0}
#        Run Keyword If    "${bEI0_content}"!="修改"    FAIL    msg=${bEI0_content}

        ${CR_no}=  Get_text   ${xpath_pnsBackEndSelectFrame2} >>> ${xpath_pnsBackEndLinkButton_0}    
        [Return]  ${CR_no}
#        //*[@id="ContentPlaceHolder1_gvList_LinkButton_0"]








































post_postweb2_pnsFrontEndloginFirefox
    [Arguments]     ${url}
    [Documentation]    Do bmc web login
        ${Browser_Ids}=  Browser.Get Browser Ids
        ${Page_Ids}=     Browser.Get Page Ids
        IF  ${Browser_Ids} != []
            Browser.Go To    ${url}
        ELSE
            New Browser  firefox  headless=false  args=['--allow-insecure-localhost']
#            New Browser  chromium  headless=false  args=['--allow-insecure-localhost']
            New Context  ignoreHTTPSErrors=${True}  bypassCSP=${True}
            New Page    ${url}
        END
#        Open Browser  ${url}  firefox
#        Set Browser Timeout  60s
#        New Context    viewport={'width': 1920, 'height': 1080}



post_postweb2_pnsFrontEndloginChrome
    [Arguments]     ${url}
    [Documentation]    Do bmc web login
        ${Browser_Ids}=  Browser.Get Browser Ids
        ${Page_Ids}=     Browser.Get Page Ids
        IF  ${Browser_Ids} != []
            Browser.Go To    ${url}
        ELSE
#            New Browser  firefox  headless=false  args=['--allow-insecure-localhost']
            New Browser  chromium  headless=false  args=['--allow-insecure-localhost']
            New Context  ignoreHTTPSErrors=${True}  bypassCSP=${True}
            New Page    ${url}
        END
#        Open Browser  ${url}  firefox
#        Set Browser Timeout  60s
#        New Context    viewport={'width': 1920, 'height': 1080}




post_postweb2_pnsFrontEndloginbyExcel
    [Arguments]     ${excel_url}
    [Documentation]    Do bmc web login
        ${Browser_Ids}=  Browser.Get Browser Ids
        ${Page_Ids}=     Browser.Get Page Ids
        IF  ${Browser_Ids} != []
            Browser.Go To    https://pnstest.post.gov.tw/LI.Web/Quest.aspx?q_sid=${excel_url}
        ELSE
            New Browser  firefox  headless=false  args=['--allow-insecure-localhost']
            New Context  ignoreHTTPSErrors=${True}  bypassCSP=${True}
            New Page    https://pnstest.post.gov.tw/LI.Web/Quest.aspx?q_sid=${excel_url}
        END
#        Open Browser  ${url}  firefox
#        Set Browser Timeout  60s
#        New Context    viewport={'width': 1920, 'height': 1080}
        


post_postweb2_pnsSSOFrontEndloginbyExcel_1
    [Arguments]        ${url}  ${source_excel_file}
    [Documentation]    Do pns SSO frontEnd web login by Cascade excel source file
        ${Browser_Ids}=  Browser.Get Browser Ids
        ${Page_Ids}=     Browser.Get Page Ids
        IF  ${Browser_Ids} != []
            Browser.Go To    https://pnstest.post.gov.tw/LI.Web/
        ELSE
            New Browser  firefox  headless=false  args=['--allow-insecure-localhost']
            New Context  ignoreHTTPSErrors=${True}  bypassCSP=${True}
            New Page    https://pnstest.post.gov.tw/LI.Web/
        END

        ${excel_list_0}=  post_excel_getdata_for_state_machine_0  ${source_excel_file}  Sheet1


	    Log_To_Console	${excel_list_0}
	    Log	 ${excel_list_0}

	    Log_To_Console	${excel_list_0}[0]
	    Log	 ${excel_list_0}[0]

	    ${excel_file_data_0}=  get from list  ${excel_list_0}  0

	    Log_To_Console	${excel_file_data_0}
	    Log	 ${excel_file_data_0}

	    Log_To_Console	${excel_file_data_0}[0]
	    Log	 ${excel_file_data_0}[0]

      IF  '${excel_file_data_0}[0]' == 'login1'
        Click  ${xpath_pnsSSOlogin}


      ELSE IF  '${excel_file_data_0}[0]' == 'signup'
        Click  ${xpath_pnsSSOsignup_1}
	    Log_To_Console	${excel_file_data_0}[0]
	    Log	 ${excel_file_data_0}[0]
	    Take Screenshot
      ELSE
         Fail
      END

        ${excel_list}=  post_excel_getdata_for_state_machine    ${source_excel_file}  Sheet1  
    FOR  ${excel_file_data}  IN  @{excel_list}
      Take Screenshot
      IF  '${excel_file_data}[0]' == 'old_nexttime'
	    Click  ${xpath_pnsSSOold_nexttime}
      ELSE IF  '${excel_file_data}[0]' == 'new_nexttime'
         Click  ${xpath_pnsSSOnew_nexttime}
	    Log_To_Console	${excel_file_data}[0]
	    Log	 ${excel_file_data}[0]


      ELSE IF  '${excel_file_data}[0]' == 'upgrade'
         Click  ${xpath_pnsSSOUpgrade}  
	    Log_To_Console	${excel_file_data}[0]
	    Log	 ${excel_file_data}[0]
      ELSE IF  '${excel_file_data}[0]' == 'signup'
         Click  ${xpath_pnsSSOsignup_2}  
	    Log_To_Console	${excel_file_data}[0]
	    Log	 ${excel_file_data}[0]
      ELSE IF  '${excel_file_data}[0]' == 'register_phone'
	    post_postweb2_ClickPnsSSOFrontEndregister_phone  ${excel_file_data_0}[1]
	    Click  ${xpath_pnsSSOregister_phone}
      ELSE IF  '${excel_file_data}[0]' == 'verification_code'
	    Take Screenshot
	    
        Wait For Elements State    ${xpath_pnsSSO_verification_code_otp-0}    visible    timeout=5s 
	    Take Screenshot   
        Sleep  1s

	    Keyboard Input    insertText    111111
	    Take Screenshot
#	    Sleep  1s
#	    Keyboard Key    press    1
#	    Take Screenshot
#	    Keyboard Key    press    1
#	    Keyboard Key    press    1
#	    Keyboard Key    press    1
#	    Keyboard Key    press    1
#	    Keyboard Key    press    1

	    Click  ${xpath_pnsSSOverification_code}

      ELSE IF  '${excel_file_data}[0]' == 'information'
	    post_postweb2_ClickPnsSSOpassword_1  ${excel_file_data_0}[2]
	    post_postweb2_ClickPnsSSOpassword_2  ${excel_file_data_0}[2]
	    post_postweb2_ClickPnsSSObirthday  1990/08/08
	    Click  ${xpath_pnsSSOinformation_checkbox}
	    Sleep  1s 
        Take Screenshot
	    Sleep  1s
	    Scroll By    ${mask_below_3}   5000    0
	    Sleep  1s 
        Take Screenshot
	    Sleep  1s
	    Scroll By    ${mask_below_3}   5000    0
	    Sleep  1s 
        Take Screenshot
	    Click  ${xpath_pnsSSOinformation_mask_below_button}
	    Click  ${xpath_pnsSSOinformation_primary_button}
        Take Screenshot
        Debug
        Click  ${xpath_pnsSSOreturn_button}  
        Take Screenshot

      ELSE IF  '${excel_file_data}[0]' == 'forget'
        Take Screenshot
        Sleep  1s
        Click  ${xpath_pnsSSOforget}
        Take Screenshot
        Sleep  1s
        Take Screenshot
        post_postweb2_ClickPnsSSOFrontEndinput_phone  ${excel_file_data_0}[1]
        Take Screenshot
        Sleep  10s
        Take Screenshot
        Click  ${xpath_pnsSSOsend_forget_password_button}
        Take Screenshot
	    Log_To_Console	${excel_file_data}[0]
	    Log	 ${excel_file_data}[0]

      ELSE IF  '${excel_file_data}[0]' == 'login2'
        Take Screenshot
        post_postweb2_ClickPnsFrontEndLoginUsername  ${excel_file_data_0}[1]
        Take Screenshot
        post_postweb2_ClickPnsFrontEndLoginPassword  ${excel_file_data_0}[2]
        Sleep  10s
        Take Screenshot
        post_postweb2_ClickPnsFrontEndLoginEnter
        Take Screenshot
	    Log_To_Console	${excel_file_data}[0]
	    Log	 ${excel_file_data}[0]



      ELSE IF  '${excel_file_data}[0]' == 'sleep'
        Debug
	    Log_To_Console	${excel_file_data}[0]
	    Log	 ${excel_file_data}[0]

      ELSE IF  '${excel_file_data}[0]' == 'birthday'
        post_postweb2_ClickPnsSSOforget_birthday   ${excel_file_data}[3]
        Click     ${xpath_pnsSSOforget_birthday_sendbutton}
	    Log	 ${excel_file_data}[0]

      ELSE IF  '${excel_file_data}[0]' == 'new_password'
        Log	 ${excel_file_data_0}
        Log	 ${excel_file_data}
        Log	 ${excel_file_data}[2]
        post_postweb2_ClickPnsSSOnew_password   ${excel_file_data}[2]
        Take Screenshot 
        Debug
        Click     ${xpath_pnsSSOnew_password_sendbutton}
        Take Screenshot 
	    Log	 ${excel_file_data}[0]


      ELSE IF  '${excel_file_data}[0]' == 'login_rightnow'
        Sleep  1s
        Click     ${xpath_pnsSSOlogin_rightnow}
	    Log	 ${excel_file_data}[0]


      ELSE IF  '${excel_file_data}[0]' == 'new_binding1'
        Take Screenshot
        Click  ${xpath_pnsSSOnew_binding}  
        Take Screenshot
        Sleep  1s 
        Take Screenshot
	    Sleep  1s
	    Scroll By    ${termsContainer}   5000    0
	    Sleep  1s 
        Take Screenshot
	    Sleep  1s
	    Scroll By    ${termsContainer}   5000    0
	    Sleep  1s
        Take Screenshot
	    Click  ${xpath_pnsSSOnew_binding2_submitButton}
        Take Screenshot


      ELSE IF  '${excel_file_data}[0]' == 'new_binding2'
        post_postweb2_ClickPnsSSOnew_binding2_username  ${excel_file_data}[4]
        post_postweb2_ClickPnsSSOnew_binding2_phone  ${excel_file_data}[1]
        post_postweb2_ClickPnsSSOnew_binding2_address    ${excel_file_data}[8]
        Take Screenshot
        Click  ${xpath_pnsSSOnew_binding2_RegBnt}
        Take Screenshot
        Sleep  1s
        Take Screenshot
        Click  ${xpath_pnsSSOnew_binding2_returnBnt}
        Take Screenshot


      ELSE IF  '${excel_file_data}[0]' == '5'
	    Log_To_Console	${excel_file_data}[0]
	    Log	 ${excel_file_data}[0]

      ELSE
    	Log_To_Console	${excel_file_data}[0]
    	Log  ${excel_file_data}[0]
    	CONTINUE For Loop
      END
    END




post_postweb2_ClickPnsSSOnew_binding2_username
    [Arguments]     ${username}
        [Documentation]
        [Tags]

        Fill Text     ${xpath_pnsSSOnew_binding2_username}    ${username}

post_postweb2_ClickPnsSSOnew_binding2_phone
    [Arguments]     ${phone_number}
        [Documentation]
        [Tags]

        Fill Text     ${xpath_pnsSSOnew_binding2_phone_number}    ${phone_number}

post_postweb2_ClickPnsSSOnew_binding2_address
    [Arguments]     ${ROADNumber}
        [Documentation]
        [Tags]

       
        Select Options By   ${xpath_PnsSSOddlnew_binding2_address_CITY}  value   ${select_value_TaipeiCity}

        Select Options By   ${xpath_PnsSSOddlnew_binding2_address_AREA}  value   ${select_value_ZhongzhengDistrict}

        Fill Text   ${xpath_PnsSSOddlnew_binding2_address_ROAD}     三元街

        Fill Text     ${xpath_PnsSSOddlnew_binding2_address_ROADNumber}    ${ROADNumber}





post_postweb2_ClickPnsSSOforget_birthday
    [Arguments]     ${birthday}
        [Documentation]
        [Tags]

        Fill Text     ${xpath_pnsSSOforget_birthday}    ${birthday}
        
post_postweb2_ClickPnsSSOnew_password
    [Arguments]     ${password}
        [Documentation]
        [Tags]

        Fill Text     ${xpath_pnsSSOnew_password1}    ${password}
        Fill Text     ${xpath_pnsSSOnew_password2}    ${password}

post_postweb2_ClickPnsFrontEndLoginUsername
    [Arguments]     ${username}
        [Documentation]
        [Tags]
#        Fill Text     ${xpath_pnsFrontEnd_username}    ${username}
         Fill Text     ${xpath_pnsSSOFrontEnd_username}    ${username}


post_postweb2_ClickPnsFrontEndLoginPassword
    [Arguments]     ${password}
        [Documentation]
        [Tags]
#        Fill Text     ${xpath_pnsFrontEnd_password}    ${password}

        Fill Text     ${xpath_pnsSSOFrontEnd_password}    ${password}

#        Input Password    ${xpath_pnsFrontEnd_password}    ${password}
#        Input Text    ${xpath_pnsFrontEnd_password}    ${password}

post_postweb2_ClickPnsSSOpassword_1
    [Arguments]     ${password}
        [Documentation]
        [Tags]

        Fill Text     ${xpath_pnsSSOpassword_1}    ${password}

post_postweb2_ClickPnsSSOpassword_2
    [Arguments]     ${password}
        [Documentation]
        [Tags]

        Fill Text     ${xpath_pnsSSOpassword_2}    ${password}


post_postweb2_ClickPnsSSObirthday
    [Arguments]     ${birthday}
        [Documentation]
        [Tags]

        Fill Text     ${xpath_pnsSSObirthday}    ${birthday}

post_postweb2_ClickPnsSSOFrontEndregister_phone
    [Arguments]     ${phone_number}
        [Documentation]
        [Tags]

        Fill Text     ${xpath_pnsSSOFrontEndregister_phone}    ${phone_number}




post_postweb2_ClickPnsSSOFrontEndinput_phone
    [Arguments]     ${phone_number}
        [Documentation]
        [Tags]

        Fill Text     ${xpath_pnsSSOFrontEndinput_phone}    ${phone_number}


post_postweb2_ClickPnsFrontEndLoginEnter
        [Documentation]
#        Click     ${xpath_pnsFrontEnd_enterbutton}
        Click     ${xpath_pnsSSOFrontEnd_enterbutton}

post_postweb2_ClickPnsFrontEndMenuList2
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndMenu_List2}
        Click     ${xpath_PnsFrontEndMenu_List2}
        Sleep  1s
#        Handle Alert


post_postweb2_ClickPnsFrontEndMenuList2Button1
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndMenu_List2Button1}
        Click     ${xpath_PnsFrontEndMenu_List2Button1}
        Sleep  1s
#        Handle Alert

post_postweb2_ClickPnsFrontEndbtnQuery
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnQuery}
        Click    ${xpath_PnsFrontEndbtnQuery}
        Sleep  1s

post_postweb2_ClickPnsFrontEndlbtnReqNo_0
        [Documentation]
#        Element Should Be Enabled    ${xpath_PnsFrontEndlbtnReqNo_0}
        Click    ${xpath_PnsFrontEndlbtnReqNo_0}    
        Sleep  1s

post_postweb2_FetchPnsFrontEndlbtnReqNo_0
        [Documentation]

        ${result}  ${bEI0_content}=  Run_Keyword_And_Ignore_Error  Get text     ${xpath_PnsFrontEndbtnEditInfo_0}
        Run Keyword If    "${bEI0_content}"!="修改"    FAIL    msg=${bEI0_content}

        ${CR_no}=  Get_text  ${xpath_PnsFrontEndlbtnReqNo_0}    
        [Return]  ${CR_no}


post_postweb2_FetchPnsFrontEndlbtnReqNo_0_1
        [Documentation]

#        ${result}  ${bEI0_content}=  Run_Keyword_And_Ignore_Error  Get text     ${xpath_PnsFrontEndbtnEditInfo_0}
#        Run Keyword If    "${bEI0_content}"=="修改"    FAIL    msg=${bEI0_content}

        ${CR_no}=  Get_text  ${xpath_PnsFrontEndlbtnReqNo_0}    
        [Return]  ${CR_no}

post_postweb2_ClickPnsFrontEndCancelbtnSave
        [Documentation]
#        Element Should Be Enabled    ${xpath_PnsFrontEndCancelbtnSave}
        Sleep  1s
        Take Screenshot
        Debug
        Click    ${xpath_PnsFrontEndCancelbtnSave}    
        Sleep  1s
        Take Screenshot
        Sleep  1s
        Handle Alert
#        Click  id=alerts




post_postweb2_ClickPnsFrontEndMenuList1
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndMenu_List1}
        Click    ${xpath_PnsFrontEndMenu_List1}
        Sleep  1s
#        Handle Alert


post_postweb2_ClickPnsFrontEndMenuList1Button1
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndMenu_List1Button1}
        Click    ${xpath_PnsFrontEndMenu_List1Button1}
#        Handle Alert
#        Click  id=alerts

post_postweb2_ClickPnsFrontEndMenuList1Button2
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndMenu_List1Button2}
        Click    ${xpath_PnsFrontEndMenu_List1Button2}
#        Handle Alert
#        Click  id=alerts

post_postweb2_ClickPnsFrontEndMenuList1Button3
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndMenu_List1Button3}
        Click    ${xpath_PnsFrontEndMenu_List1Button3}
#        Handle Alert
#        Click  id=alerts

post_postweb2_ClickPnsFrontEndMenuList1Button4
        [Documentation]
        [Tags]
#        Element Should Be Enabled    ${xpath_PnsFrontEndMenu_List1Button4}
        Click    ${xpath_PnsFrontEndMenu_List1Button4}
#        Handle Alert
#        Click  id=alerts

post_postweb2_ClickPnsFrontEndcbConfirm
        [Documentation]
        [Tags]
        Sleep  1s
#        Element Should Be Enabled    ${xpath_PnsFrontEndcbConfirm}
        Click    ${xpath_PnsFrontEndcbConfirm}
        Sleep  1s
#        Element Should Be Enabled    ${xpath_PnsFrontEndbtnConfirm}
        Click    ${xpath_PnsFrontEndbtnConfirm} 
        Sleep  1s



post_postweb2_ClickPnsFrontEndddlNewCity_ddl1
        [Arguments]        ${City_name}   ${District_name}   ${Road_name}   ${NewNumber}    ${String}
    Log   City_name=${City_name} District_name=${District_name} Road_name=${Road_name} NewNumber=${NewNumber} String=${String}
    IF  '${String}' == 'post'
        Click   ${xpath_pnsrblNewPostType}
        Select Options By    ${xpath_pnsddlNewOrangePost1}  value   ${City_name}
        Sleep  1s
        Select Options By    ${xpath_pnsddlNewOrangePost2}  value   ${District_name}
        Sleep  1s
        Select Options By    ${xpath_pnsddlNewOrangePost3}  index   1
        Sleep  1s
        Fill Text   ${xpath_pnstxtNewPostNumber}  ${NewNumber}


    ELSE        
#        Select Options By   ${xpath_PnsddlNewCity_ddl1}  value   ${select_value_TaipeiCity}
        Select Options By   ${xpath_PnsddlNewCity_ddl1}  value   ${City_name}
        Sleep  1s
#        Select Options By   ${xpath_PnsddlNewArea_ddl1}  value   ${select_value_ZhongzhengDistrict}
        Select Options By   ${xpath_PnsddlNewArea_ddl1}  value   ${District_name}
        Sleep  1s
        Log  ${String}
        IF  '${String}' == 'object'
#            Select Options By   ${xpath_PnsddlNewRoad_ddl1}  value   ${select_value_SectionOneOfBadeRoad}
            Select Options By   ${xpath_PnsddlNewRoad_ddl1}  value   ${Road_name} 
        ELSE IF  '${String}' == 'string'
            Click   ${xpath_PnschkNewRoad}
#            fill text   ${xpath_PnstxtNewRoad}     大埔街
            fill text   ${xpath_PnstxtNewRoad}     ${Road_name}
        ELSE
            Fail
        END


        Fill Text  ${xpath_PnstxtNewLane}         1
        Fill Text  ${xpath_PnstxtNewAlley}        2
        Fill Text  ${xpath_PnstxtNewSubNumber}    3
        Fill Text  ${xpath_PnstxtNewFloor}        4
        Fill Text  ${xpath_PnstxtNewRoom}         808
        Fill Text  ${xpath_PnstxtNewSubFloor}     5

        Sleep  1s
        Click   ${xpath_PnstxtNewRemark} 
        Fill Text  ${xpath_PnstxtNewRemark}  測試註記
        
        Sleep  1s
        Click   ${xpath_PnstxtNewNumber} 
        Fill Text  ${xpath_PnstxtNewNumber}  ${NewNumber}
        Take Screenshot
    END
    Click  ${xpath_PnstxtVerificationDate}
    Sleep  1s
    Fill Text  ${xpath_PnstxtVerificationDate}  113/6/1 
    Take Screenshot



post_postweb2_ClickPnsFrontEndddlOldCity_ddl1
        [Arguments]   ${City_name}   ${District_name}   ${Road_name}   ${OldNumber}    ${String}

    Log   City_name=${City_name} District_name=${District_name} Road_name=${Road_name} OldNumber=${OldNumber} String=${String}
    Scroll To  vertical=bottom    
    IF  '${String}' == 'post'
        Click    ${xpath_pnsrblOldPostType}
        Select Options By    ${xpath_PnsddlOldOrangePost1}  value   ${City_name}
        Sleep  1s
        Select Options By    ${xpath_PnsddlOldOrangePost2}  value   ${District_name}
        Sleep  1s
        Select Options By    ${xpath_pnsddlOldOrangePost3}  index   1
        Sleep  1s
        Fill Text   ${xpath_pnstxtOldPostNumber}  ${OldNumber}


    ELSE        
#        Select Options By   ${xpath_PnsddlOldCity_ddl1}  value   ${select_value_TaipeiCity}
        Select Options By   ${xpath_PnsddlOldCity_ddl1}  value   ${City_name}
        Sleep  1s
#        Select Options By   ${xpath_PnsddlOldArea_ddl1}  value   ${select_value_ZhongzhengDistrict}
        Select Options By   ${xpath_PnsddlOldArea_ddl1}  value   ${District_name}
        Sleep  1s  
        Log  ${String}
        IF  '${String}' == 'object'
            Select Options By   ${xpath_PnsddlOldRoad_ddl1}  value   ${Road_name}
        ELSE IF  '${String}' == 'string'
            Click   ${xpath_PnschkOldRoad}
            fill text   ${xpath_PnstxtOldRoad}     ${Road_name}
        ELSE
            Fail
        END
        Fill Text  ${xpath_PnstxtOldLane}         1
        Fill Text  ${xpath_PnstxtOldAlley}        2
        Fill Text  ${xpath_PnstxtOldSubNumber}    3
        Fill Text  ${xpath_PnstxtOldFloor}        4
        Fill Text  ${xpath_PnstxtOldRoom}         808
        Fill Text  ${xpath_PnstxtOldSubFloor}     5
        Sleep  1s
        Fill Text  ${xpath_PnstxtOldNumber}  ${OldNumber}
        Take Screenshot
        Sleep  1s
        Take Screenshot
    END



post_postweb2_ClickPnsFrontEndbtnSend
        Scroll To  vertical=bottom
        Sleep  1s
#        Scroll To Element     ${xpath_PnsbtnSend} 
        Click     ${xpath_PnstxtCellPhone}
        Sleep  1s
        Fill Text  ${xpath_PnstxtCellPhone}  0963038476
#        Sleep  1s
        Fill Text  ${xpath_PnstxtTelePhone}  02-2375-3160
#        Sleep  1s



#        Click     ${xpath_PnsbtnP1}
#        Sleep  1s
#        Fill Text  ${xpath_PnsTextBox6}    六寶
#        Fill Text  ${xpath_PnsTextBox7}    七寶
#        Fill Text  ${xpath_PnsTextBox8}    八寶
#        Fill Text  ${xpath_PnsTextBox9}    九寶
#        Fill Text  ${xpath_PnsTextBox10}    十寶

        Debug

        Click     ${xpath_PnsbtnSend} 
#        Sleep  10s
#        Handle Alert
#        Click  id=alerts
#        Sleep  1s
#        Capture Page Screenshot
        Take Screenshot
        Sleep  1s


post_postweb2_ClickPnsFrontEndTextBox
        Fill Text  ${xpath_PnsTextBox1}    大寶
        Fill Text  ${xpath_PnsTextBox2}    二寶
        Fill Text  ${xpath_PnsTextBox3}    三寶
        Fill Text  ${xpath_PnsTextBox4}    四寶
        Fill Text  ${xpath_PnsTextBox5}    五寶
        Click      ${xpath_PnsbtnP1}
        Sleep  1s
        Fill Text   ${xpath_PnsTextBox6}    六寶
        Fill Text   ${xpath_PnsTextBox7}    七寶
        Fill Text   ${xpath_PnsTextBox8}    八寶
        Fill Text   ${xpath_PnsTextBox9}    九寶
        Fill Text   ${xpath_PnsTextBox10}    十寶

post_postweb2_ClickPnsFrontEndddlEffectiveDate
        [Arguments]     ${StartDate}  ${EndDate}
        Sleep  1s
        Click      ${xpath_PnstxtEffectiveStartDate}
        Sleep  1s
        Fill Text  ${xpath_PnstxtEffectiveStartDate}    ${StartDate}
        Sleep  1s
        Click      ${xpath_PnstxtEffectiveEndDate}
        Sleep  1s
        Fill Text  ${xpath_PnstxtEffectiveEndDate}    ${EndDate}



post_postweb2_ClickPnstestmailFrontEndLoginEnter
        [Documentation]
        Click    ${xpath_pnstestmailFrontEnd_enterbutton}


post_postweb2_ClickPnsFrontEndQ2_VerA
        [Documentation]
        [Tags]
        Click    ${xpath_pnstestmailFrontEnd_Q2_3_1_2_3}
        Click    ${xpath_pnstestmailFrontEnd_Q2_4_1_2_3_1}
#        Sleep  1s



post_postweb2_ClickPnsFrontEndQ3_VerA
        [Documentation]
        [Tags]
        Click    ${xpath_pnstestmailFrontEnd_Q3_11_1_3_1}
#        Sleep  1s

post_postweb2_ClickPnsFrontEndQ4_VerA
        [Documentation]
        [Tags]
        Fill Text    ${xpath_pnstestmailFrontEnd_Q4_12_0_4}    中華郵政
#        Sleep  1s

post_postweb2_ClickPnsFrontEndQ5_VerA
        [Documentation]
        [Tags]
        Fill Text    ${xpath_pnstestmailFrontEnd_Q5_13_0_5}    加油，辛苦了!
#        Sleep  1s

post_postweb2_ClickPnsFrontEndQ6_VerA
        [Documentation]
        [Tags]
        Click    ${xpath_pnstestmailFrontEnd_Q6_14_1_6_1}
#        Sleep  1s

post_postweb2_ClickPnsFrontEndQ7_VerA
        [Documentation]
        [Tags]
        Click    ${xpath_pnstestmailFrontEnd_Q7_15_1_7_1}
#        Sleep  1s

post_postweb2_ClickPnsFrontEndQ8_VerA
        [Documentation]
        [Tags]
        Click    ${xpath_pnstestmailFrontEnd_Q4_12_0_4}
#        Sleep  1s

post_postweb2_ClickPnsFrontEndQ8_1_VerA
        [Documentation]
        [Tags]
        Fill Text    ${xpath_pnstestmailFrontEnd_Q8_16_0_8_16}    賈先生
#        Sleep  1s

post_postweb2_ClickPnsFrontEndQ8_2_VerA
        [Documentation]
        [Tags]
        Fill Text    ${xpath_pnstestmailFrontEnd_Q8_17_0_8_16}    0912345678
#        Sleep  1s

post_postweb2_ClickPnsFrontEndQ8_3_VerA
        [Documentation]
        [Tags]
        Fill Text    ${xpath_pnstestmailFrontEnd_Q8_18_0_8_16}    台北市
#        Sleep  1s

post_postweb2_ClickPnsFrontEndQ9_VerA
        [Documentation]
        [Tags]
        Click    ${xpath_pnstestmailFrontEnd_Q9_20_1_9_1}    
#        Sleep  1s

post_postweb2_ClickPnsFrontEndQ2_VerB
        [Documentation]
        [Tags]
        Click    ${xpath_pnstestmailFrontEnd_Q2_B_30_1_2_9_3}
   
#        Sleep  1s

post_postweb2_ClickPnsFrontEndQ3_VerB
        [Documentation]
        [Tags]
        Click    ${xpath_pnstestmailFrontEnd_Q3_B_31_1_3__3}
  
#        Sleep  1s

post_postweb2_ClickPnsFrontEndQ4_VerB
        [Documentation]
        [Tags]
        Fill Text  ${xpath_pnstestmailFrontEnd_Q4_B_32_0_4_}  中華郵政
  
#        Sleep  1s

post_postweb2_ClickPnsFrontEndQ5_VerB
        [Arguments]     ${Q5_Note}
        [Documentation]
        [Tags]
#        Fill Text  ${xpath_pnstestmailFrontEnd_Q5_B_33_0_5_}  加油，辛苦了!
        Fill Text  ${xpath_pnstestmailFrontEnd_Q5_B_33_0_5_}  ${Q5_Note}

#        Sleep  1s

post_postweb2_ClickPnsFrontEndQ6_VerB
        [Documentation]
        [Tags]
        Click    ${xpath_pnstestmailFrontEnd_Q6_B_34_1_6__1}
    
#        Sleep  1s

post_postweb2_ClickPnsFrontEndQ7_VerB
        [Documentation]
        [Tags]
        Click    ${xpath_pnstestmailFrontEnd_Q7_B_35_1_7__1}
   
#        Sleep  1s

post_postweb2_ClickPnsFrontEndQ8_1_VerB
        [Documentation]
        [Tags]
        Fill Text   ${xpath_pnstestmailFrontEnd_Q8_B_36_0_8_16}  賈先生
  
#        Sleep  1s

post_postweb2_ClickPnsFrontEndQ8_2_VerB
        [Documentation]
        [Tags]
        Fill Text   ${xpath_pnstestmailFrontEnd_Q8_B_37_0_8_16}  0912345678
    
#        Sleep  1s

post_postweb2_ClickPnsFrontEndQ8_3_VerB
        [Documentation]
        [Tags]
        Fill Text   ${xpath_pnstestmailFrontEnd_Q8_B_38_0_8_16}  台北市
  
#        Sleep  1s




post_postweb2_ClickPnsFrontEnd_cbTreatyConfirm
        [Documentation]
        [Tags]
        Click    ${xpath_pnstestmailFrontEnd_cbTreatyConfirm}    
#        Sleep  1s

post_postweb2_ClickPnsFrontEnd_Submit
        [Documentation]
        [Tags]
        Click    ${xpath_pnstestmailFrontEnd_Submit}    
#        Sleep  1s




post_postweb2_591FrontEndlogin
        [Arguments]     ${url}
        [Documentation]
        [Tags]
        
        Set Browser Timeout  20s
        ${Browser_Ids}=  Browser.Get Browser Ids
        ${Page_Ids}=     Browser.Get Page Ids
        IF  ${Page_Ids} != []
            Browser.Go To    ${url}
        ELSE
            New Browser  chromium  headless=false  args=['--allow-insecure-localhost']

#            New Browser    headless=false  args=['--allow-insecure-localhost']

            New Context  ignoreHTTPSErrors=${True}  bypassCSP=${True}
            Set Browser Timeout  40s
            New Page    ${url}
        END
#        Open Browser  ${url}  firefox
#        Set Browser Timeout  60s
#        New Context    viewport={'width': 1920, 'height': 1080}





post_postweb2_Check591FrontEndContent1_title
        [Documentation]
        [Tags]

        ${str_title}=  Get_text  ${xpath_591FrontEndContent1_title}
        [return]  ${str_title}


post_postweb2_finmindFrontEndlogin
        [Arguments]     ${url}
        [Documentation]
        [Tags]
        
        Set Browser Timeout  20s
        ${Browser_Ids}=  Browser.Get Browser Ids
        ${Page_Ids}=     Browser.Get Page Ids
        IF  ${Page_Ids} != []
            Browser.Go To    ${url}
        ELSE
#            New Browser  chromium  headless=false  args=['--allow-insecure-localhost']  downloadsPath=C:/Users/shaohung/Downloads

             New Browser  chromium  headless=false  args=['--allow-insecure-localhost']  

#            New Browser  webkit  headless=false  args=['--allow-insecure-localhost']

#            New Browser    headless=false  args=['--allow-insecure-localhost']

            New Context  ignoreHTTPSErrors=${True}  bypassCSP=${True}  acceptDownloads=True    viewport={'width': 1920, 'height': 1080}
            Set Browser Timeout  40s
            New Page    ${url}
        END
#        Open Browser  ${url}  firefox
#        Set Browser Timeout  60s
#        New Context    viewport={'width': 1920, 'height': 1080}





post_postweb2_CheckfinmindFrontEndContent1_title
        [Documentation]
        [Tags]

        ${str_title}=  Get_text  ${xpath_finmindFrontEndContent1_title}
        [return]  ${str_title}






post_postweb2_mapcomFrontEndlogin
        [Arguments]     ${url}
        [Documentation]
        [Tags]
    

        Set Browser Timeout  20s
        ${Browser_Ids}=  Browser.Get Browser Ids
        ${Page_Ids}=     Browser.Get Page Ids
        IF  ${Page_Ids} != []
            Browser.Go To    ${url}
            Set Browser Timeout  20s
        ELSE
            New Browser  chromium  headless=false  args=['--allow-insecure-localhost']

#            New Browser    headless=false  args=['--allow-insecure-localhost']

            New Context  ignoreHTTPSErrors=${True}  bypassCSP=${True}
            Set Browser Timeout  120s
            New Page    ${url}
        END
#        Open Browser  ${url}  firefox
#        Set Browser Timeout  60s
#        New Context    viewport={'width': 1920, 'height': 1080}
#        Sleep  10s



bulk_postweb2_loginChrome
    [Arguments]     ${url}
    [Documentation]    Do bmc web login
        ${Browser_Ids}=  Browser.Get Browser Ids
        ${Page_Ids}=     Browser.Get Page Ids
        IF  ${Browser_Ids} != []
            Browser.Go To    ${url}
        ELSE
#            New Browser  firefox  headless=false  args=['--allow-insecure-localhost']
            New Browser  chromium  headless=false  args=['--allow-insecure-localhost']
            New Context  ignoreHTTPSErrors=${True}  bypassCSP=${True}
            New Page    ${url}
        END
#        Open Browser  ${url}  firefox
#        Set Browser Timeout  60s
#        New Context    viewport={'width': 1920, 'height': 1080}


bulk_postweb2_loginUsername
    [Arguments]     ${username}
        [Documentation]
        [Tags]
#        Fill Text     ${xpath_pnsFrontEnd_username}    ${username}
         Fill Text     ${xpath_bulkusername}    ${username}


bulk_postweb2_loginPassword
    [Arguments]     ${password}
        [Documentation]
        [Tags]
#        Fill Text     ${xpath_pnsFrontEnd_password}    ${password}

        Fill Text     ${xpath_bulkpassword}    ${password}



bulk_postweb2_loginEnter
        [Documentation]
#        Click     ${xpath_pnsFrontEnd_enterbutton}
        Click     ${xpath_bulkenterbutton}

bulk_postweb2_adminloginEnter
        [Documentation]
#        Click     ${xpath_pnsFrontEnd_enterbutton}
        Click     ${xpath_bulkadminenterbutton}

bulk_postweb2_ClickSY000
        [Documentation]
        [Tags]

        Click    ${xpath_bulkSY000}

bulk_postweb2_ClickSY000List3
        [Documentation]
        [Tags]

        Click    ${xpath_bulkSY000List3}

bulk_postweb2_ClickSY000List3bean_search
        [Documentation]
        [Tags]

        Click    ${xpath_bulkSY000List3bean_search}  


bulk_postweb2_ClickBU000
        [Documentation]
        [Tags]

        Click    ${xpath_bulkBU000}

bulk_postweb2_ClickBU000List2
        [Documentation]
        [Tags]

        Click    ${xpath_bulkBU000List2}

bulk_postweb2_ClickBU000List2bean_search
        [Documentation]
        [Tags]
        Click    ${xpath_bulkBU000List2bean_search}  
        Sleep  1s
	    Take Screenshot

bulk_postweb2_ClickBU000List2erste
        [Documentation]
        [Tags]
        Click    ${xpath_bulkBU000List2erste}  
        Take Screenshot

bulk_postweb2_ClickBU000List2ersteS1
        [Documentation]
        [Tags]
        Click    ${xpath_bulkBU000List2ersteS1}  
        Take Screenshot


bulk_postweb2_FetchBU000List2ersteS1log_name
        ${S1log_name}=  Get_text   ${xpath_bulkBU000List2ersteS1log_name}    
        [Return]  ${S1log_name}


bulk_postweb2_DownloadBU000List2ersteS1_log
    [Arguments]     ${dir_download}    ${time}
        [Documentation]
        [Tags]
        Promise To Wait For Download  saveAs=${dir_download}/${time}_S1.log
        Click  ${xpath_bulkBU000List2ersteS1_log}
        Sleep  1s
        Take Screenshot

bulk_postweb2_CheckBU000List2ersteS1_log
    [Arguments]     ${dir_download}  ${time}  ${In_or_Out}
        [Documentation]
        [Tags]
        ${S1_log_content}=    Get File    ${dir_download}/${time}_S1.log    encoding=UTF-8
        Log    ${S1_log_content}
        Log    _010006_${time}_0.TXT
        IF  '${In_or_Out}' == 'In'
            Should Contain    ${S1_log_content}      _010006_${time}_0.TXT 
        ELSE IF  '${In_or_Out}' == 'Out'
            Should Contain    ${S1_log_content}      -010006-${time}-  
        ELSE
            Fail
        END     

bulk_postweb2_ClickBU000List2ersteS2
        [Documentation]
        [Tags]
        Click    ${xpath_bulkBU000List2ersteS2}  
        Take Screenshot


bulk_postweb2_FetchBU000List2ersteS2log_name
        ${S2log_name}=  Get_text   ${xpath_bulkBU000List2ersteS2log_name}    
        [Return]  ${S2log_name}


bulk_postweb2_DownloadBU000List2ersteS2_log
    [Arguments]     ${dir_download}    ${time}
        [Documentation]
        [Tags]
        Promise To Wait For Download  saveAs=${dir_download}/${time}_S2.log
        Click  ${xpath_bulkBU000List2ersteS2_log}
        Sleep  1s
        Take Screenshot

bulk_postweb2_CheckBU000List2ersteS2_log
    [Arguments]     ${dir_download}  ${time}  ${In_or_Out}
        [Documentation]
        [Tags]
        ${S2_log_content}=    Get File    ${dir_download}/${time}_S2.log    encoding=UTF-8
        Log    ${S2_log_content}
        Log    _010006_${time}_0.TXT
        IF  '${In_or_Out}' == 'In'
            Should Contain    ${S2_log_content}      _010006_${time}_0.TXT 
        ELSE IF  '${In_or_Out}' == 'Out'
            Should Contain    ${S2_log_content}      -010006-${time}-  
        ELSE
            Fail
        END           

bulk_postweb2_ClickBU000List2ersteS3
        [Documentation]
        [Tags]
        Click    ${xpath_bulkBU000List2ersteS3}  
        Take Screenshot


bulk_postweb2_FetchBU000List2ersteS3log_name
        ${S1log_name}=  Get_text   ${xpath_bulkBU000List2ersteS3log_name}    
        [Return]  ${S1log_name}


bulk_postweb2_DownloadBU000List2ersteS3_log
    [Arguments]     ${dir_download}    ${time}
        [Documentation]
        [Tags]
        Promise To Wait For Download  saveAs=${dir_download}/${time}_S3.log
        Click  ${xpath_bulkBU000List2ersteS3_log}
        Sleep  1s
        Take Screenshot

bulk_postweb2_CheckBU000List2ersteS3_log
    [Arguments]     ${dir_download}  ${time}  ${In_or_Out}
        [Documentation]
        [Tags]
        ${S3_log_content}=    Get File    ${dir_download}/${time}_S3.log    encoding=UTF-8
        Log    ${S3_log_content}
        Log    _010006_${time}_0.TXT
        IF  '${In_or_Out}' == 'In'
            Should Contain    ${S3_log_content}      _010006_${time}_0.TXT 
        ELSE IF  '${In_or_Out}' == 'Out'
            Should Contain    ${S3_log_content}      -010006-${time}-  
        ELSE
            Fail
        END           




bulk_postweb2_Check_Status_And_Refresh_If_Needed
    [Arguments]     ${FDBK_process}

    ${new_status_xpath}  ${new_button_xpath}=  bulk_postweb2_FetchTableGridButton   jqgrid  	  ${FDBK_process}
    log  ${new_status_xpath}
    log  ${new_button_xpath}
    Take Screenshot
    ${current_status}=    Get_Text    ${new_status_xpath}    
    Take Screenshot
    Run Keyword If    '${current_status}' != 'Active'    bulk_postweb2_ClickSY000List3bean_search
    Take Screenshot       
    Should Contain    ${current_status}    Active




bulk_postweb2_FetchTableGridButton
    [Arguments]     ${table_name}  ${text_name}
        [Documentation]
        [Tags]

#    ${Count}=   Browser.Get Element Count    ${xpath_gview_jqgrid_table}


    
    # 先取得元素
    ${element}=    Browser.Get Element    text="${text_name}"
    
    # 使用 Evaluate JavaScript 將元素轉成 XPath
    ${original_xpath}=    Evaluate JavaScript    ${element}    
    ...    (element) => {
    ...        function getXPath(node) {
    ...            if (node.id) {
    ...                return '//*[@id="' + node.id + '"]';
    ...            }
    ...            if (node === document.body) {
    ...                return '/html/body';
    ...            }
    ...            let position = 0;
    ...            let siblings = node.parentNode.childNodes;
    ...            for (let i = 0; i < siblings.length; i++) {
    ...                let sibling = siblings[i];
    ...                if (sibling === node) {
    ...                    return getXPath(node.parentNode) + '/' + node.tagName.toLowerCase() + '[' + (position + 1) + ']';
    ...                }
    ...                if (sibling.nodeType === 1 && sibling.tagName === node.tagName) {
    ...                    position++;
    ...                }
    ...            }
    ...        }
    ...        return getXPath(element);
    ...    }
    
   
    Log    The XPath is: ${original_xpath}

    Take Screenshot
    Click   ${original_xpath}
    Take Screenshot

    ${origin_id_string_list}=    Get Regexp Matches    ${original_xpath}    \\[@id="(\\d+)"\\]
    ${origin_td_string_list}=    Get Regexp Matches    ${original_xpath}    td\\[(\\d+)\\]$
    
    ${origin_id_string_list1}=  Split String    ${origin_id_string_list}[0]    [@id="
    ${origin_id_list2}=      Split String    ${origin_id_string_list1}[1]    "]
    ${origin_id_num}=  set variable  ${origin_id_list2}[0]

    ${origin_td_string_list1}=  Split String    ${origin_td_string_list}[0]    td[
    ${origin_td_list2}=      Split String    ${origin_td_string_list1}[1]    ]
    ${origin_td_num}=  set variable  ${origin_td_list2}[0]

    ${new_id_num}=   set variable    ${origin_id_num}
    ${new_status_td_num}=   Evaluate    ${origin_td_num} + 3
    ${new_button_td_num}=   Evaluate    ${origin_td_num} + 7

    ${new_status_xpath}=    Set Variable    //*[@id="${new_id_num}"]/td[${new_status_td_num}]


    ${new_button_xpath}=    Set Variable    //*[@id="${new_id_num}"]/td[${new_button_td_num}]/input

#    Take Screenshot
#    Click   ${new_xpath}
#    Take Screenshot

    
    ${idx}=    Get Table Cell Index    ${element}    
    ${rdx}=    Get Table Row Index    ${element}    
	${e}=    Get Table Cell Element    xpath=//*[@id="${table_name}"]   4   7
	log  ${e}
	RETURN  ${new_status_xpath}  ${new_button_xpath}



bulk_postweb2_ClickTableGridButton
    [Arguments]  ${new_button_xpath}  ${table_name}   ${text_name}
        [Documentation]
        [Tags]

    ${rows}=    Browser.Get_Elements    xpath=//*[@id="${table_name}"]/tbody/tr
    ${length}  Get Length   ${rows}
    log   ${rows}

    ${full_table}=    Create List

    Take Screenshot 

    FOR  ${row}   IN  @{rows}
        ${cells}=    Browser.Get_Elements    ${row} >> css=td, th
        ${row_data}=    Create_List
        FOR    ${cell}    IN    @{cells}
            ${text}=    Get_Text    ${cell}
            Append_To_List    ${row_data}    ${text}
        END
        Append_To_List    ${full_table}    ${row_data}
    END

    Take Screenshot

    FOR  ${index_i}    ${i}    IN ENUMERATE   @{rows}
        log   ${index_i} ${i}
        FOR  ${index_j}    ${j}    IN ENUMERATE  @{full_table[${index_i}]}
            log   ${j}
            IF  '${j}' == '${text_name}'
                log  ${text_name}
                log  index_i= ${index_i}
                log  index_j= ${index_j}
                Take Screenshot
                ${promise} =         Promise To    Wait For Alert    action=accept    text=確定執行?

                Take Screenshot

                Click  ${new_button_xpath}
            
                Take Screenshot
#                Debug
                BREAK
            END
        END
    END

