*** Variables ***
#@{sensor_data}  @{EMPTY}
#@{assign_data}  @{EMPTY}
#@{result_data}  @{EMPTY}
#@{excel_list}  @{EMPTY}
#@{excel_list_0}  @{EMPTY}

*** Keywords ***

post_csv_getdata
    [Arguments] 	${csv_file_name}
    [Documentation]    Load sensor list file and prepare list
    Log_To_Console   csv_file_name : ${csv_file_name}
#    Log_To_Console   sheet_name : ${sheet_name}

#	${new_sheet_name} =	Replace String Using Regexp	${sheet_name}	( )	\\ \  	count=1
#	Log_To_Console  string ${new_sheet_name}

#	${output}=   OperatingSystem.Run   python3 ${local_path}/${Script_folder_path}/excel_remove_strike.py ${local_path}/${Excel_folder_path}/${excel_file_name} ${new_sheet_name}

#    Log_To_Console   excel_python_script_output : ${output}

#    Open Excel Document    filename=${local_path}/${591_csv_folder_path}/${excel_file_name}   doc_id=doc1


            ${old_csv_content}=    Get File    lvr_landcsv/${csv_file_name}    encoding=UTF-8-SIG    encoding_errors=strict

#    @{old_csv_content_list}=  Read Csv String To List  ${old_csv_content}

            @{list_csv_before_yesterday}=  Read Csv String To List  ${old_csv_content}

            ${list_csv_by_cnt}=    Get length    ${list_csv_before_yesterday}
            
            FOR  ${old_j}  IN RANGE  2  ${list_csv_by_cnt}  1

                ${s1_by_array}=  get_from_list  ${list_csv_before_yesterday}  ${old_j}
                Log  s1_by_array ${s1_by_array}

                Log  ${s1_by_array}[2]

            END



	[Return]  ${sensor_check_list}




post_csv_setdata
    [Arguments] 	${csv_file_path}  ${csv_header_string}  ${csv_string}
    [Documentation]    Load sensor list file and prepare list
    Log   csv_file_path : ${csv_file_path}


                ${file_exists}=  Run Keyword And Return Status  OperatingSystem.File_Should_Exist   ${csv_file_path}

                IF  '${file_exists}' == 'False'
                    Copy File  lvr_landcsv/a_lvr_land_a_header.csv  ${csv_file_path}
                    Append To File   ${csv_file_path}   ${csv_header_string}
                END

                Append To File   ${csv_file_path}   ${csv_string}



post_csv_get_strategy_data    
    [Arguments] 	${csv_file_path}
    [Documentation]    Load sensor list file and prepare list

#    ${file}=    Get File    stock_csv_new_macd_dif/1_strategy_2024.csv

#        ${old1_csv_content}=    Get File    stock_csv_new_macd_dif/1_strategy_2024.csv    encoding=UTF-8-SIG    encoding_errors=strict
        ${old1_csv_content}=    Get File    ${csv_file_path}    encoding=UTF-8-SIG    encoding_errors=strict
        @{list_1}=  Read Csv String To List  ${old1_csv_content}

#            ${length}=  Get length  ${list_1}
#            ${length+1}=  evaluate  ${length} + 1

        [Return]  @{list_1}



post_csv_append_cell_data
    [Arguments] 	${csv_file_path}  ${csv_cell_data}
    [Documentation]    Load sensor list file and prepare list
    Log   csv_file_path : ${csv_file_path}


                ${file_exists}=  Run Keyword And Return Status  OperatingSystem.File_Should_Exist   ${csv_file_path}

                IF  '${file_exists}' == 'False'
                    Fail
#                    Copy File  lvr_landcsv/a_lvr_land_a_header.csv  ${csv_file_path}
#                    Append To File   ${csv_file_path}   ${csv_header_string}
                END

                Append To File   ${csv_file_path}   ,${csv_cell_data}
#                Append To File   ${csv_file_path}   test_cell,

#                Fail


