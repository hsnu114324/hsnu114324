*** keywords ***
finmind_DynamicDateRange
    [Arguments]  ${start_date}  ${end_date}
    Log_To_Console  ${start_date}
    Log  ${start_date}
    Log_To_Console  ${end_date}
    Log  ${end_date}
    ${date_range}=   finmind_GetDateRange   ${start_date}   ${end_date}
    FOR  ${date}  IN  @{date_range}
        Log  ${date} ~ ${date}
        Log_To_Console  ${date} ~ ${date}
    END




finmind_GetDateRange
    [Arguments]  ${start_date}  ${end_date}

#    ${start_date}=    Set Variable    20230227
#    ${start_date}=    Convert To Integer    ${start_date1}
#    ${end_date}=    Set Variable    20230302
#    ${end_date}=    Convert To Integer    ${end_date1}

    Log_To_Console  ${start_date}
    Log  ${start_date}
    sleep  1s
    Log_To_Console  ${end_date}
    Log  ${end_date}
    sleep  1s

    ${start_date_obj}=  Convert_Date  ${start_date}	result_format=%Y-%m-%d    date_format=%Y%m%d
#    ${start_date_obj}=  Convert_Date  ${start_date}	result_format=%Y%m%d    date_format=%Y%m%d
	Log_To_Console  ${start_date_obj}
    ${end_date_obj}=    Convert_Date  ${end_date}	result_format=%Y-%m-%d    date_format=%Y%m%d
#    ${end_date_obj}=    Convert_Date  ${end_date}	result_format=%Y%m%d    date_format=%Y%m%d
	Log_To_Console  ${end_date_obj}
    ${date_obj_range}=      Create List  ${start_date_obj}
	Log_To_Console	date_obj_range ${date_obj_range}
    ${current_date}=    Set Variable  ${start_date}
	Log_To_Console	current_date ${current_date}
    WHILE  ${current_date} < ${end_date}  limit=NONE
        ${next_date}=  Add_Time_To_Date  ${current_date}  1days  %Y%m%d
        ${next_date_obj}=  Add_Time_To_Date  ${current_date}  1days  %Y-%m-%d
	Log_To_Console  next_date ${next_date}
	Log_To_Console  next_date_obj ${next_date_obj}
        Append_To_List  ${date_obj_range}  ${next_date_obj}
        ${current_date}=  Set Variable  ${next_date}
    END
    [Return]  ${date_obj_range}

