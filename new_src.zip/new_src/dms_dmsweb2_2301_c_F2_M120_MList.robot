*** Keywords ***
dms_dmsweb2_2301_c_F2_M120_MList
    [Arguments]  ${excel_file_data}

	[Documentation]
	[Tags]
#***

    Log  ${excel_file_data}

#***
	dms_postweb2_pnsFrontEndloginChrome  http://localhost:3000/



#    Debug

    dms_dmsweb2_ClickDmsFrontEnduserID_login

	dms_dmsweb2_ClickDmsFrontEndMenuButton
#***
	dms_dmsweb2_ClickDmsFrontEndMenu_ListOP1
#***
	dms_dmsweb2_ClickDmsFrontEndMenu_ListOP1_2301
#***
#	Sleep  1s
    Click    //*[@id="alert-container"]/div/div/div[3]/button
#***
	dms_dmsweb2_ClickDmsFrontEnd_2000ACC_DATE  ${excel_file_data}[1]
#***
	dms_dmsweb2_ClickDmsFrontEnd_2000TOUR_NO  ${excel_file_data}[2]
#***
#    dms_dmsweb2_ClickDmsFrontEnd_2000STAFF_NO
#	${MLIST_NO}  ${MLIST_STATE}=  dms_dmsweb2_ClickDmsFrontEnd_2000FetchButton
#    Log  ${MLIST_NO} ${MLIST_STATE}


	dms_dmsweb2_ClickDmsFrontEnd_2000FetchButton  




        ${match1}  ${match2}=    dms_dmsweb2_DmsFrontEnd_2301_stage1_1  ${excel_file_data}    M120  2301


        ${match2}  ${match3}=    dms_dmsweb2_DmsFrontEnd_2301_stage1_i  ${match2}  ${excel_file_data}    M120  2301


	IF	'${match2}' == 'False'
        
#	    dms_dmsweb2_DmsFrontEnd_2301_stage1_c

		Take Screenshot


	END


        ${match1}  ${match2}=    dms_dmsweb2_DmsFrontEnd_2301_stage2_1  ${excel_file_data}    




        ${match2}  ${match3}=    dms_dmsweb2_DmsFrontEnd_2301_stage2_i  ${match2}  ${excel_file_data}    





	IF	'${match2}' == 'False'
        
	    dms_dmsweb2_DmsFrontEnd_2301_stage2_c   ${excel_file_data}

		Take Screenshot


	END





	


	

 

#***
	dms_dmsweb2_ClickDmsFrontEnduserID_logout

    Sleep  3s

#	RETURN  ${CR_no}
