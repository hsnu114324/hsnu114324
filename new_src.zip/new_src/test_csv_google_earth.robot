*** Variables ***
@{az_list}=  a  b  c  d  e  f  g  h  i  j  k  m  n  o  p  q  t  u  v  w  x  z

*** Keywords ***
test_csv_google_earth
    [Arguments]     ${ii}  
    Log   ${ii}

    imagehorizonlibrary.set reference folder   ${CURDIR}

#    post_postweb2_591FrontEndlogin  https://earth.google.com/web

#    FOR  ${ii}  IN   @{az_list}
#        log  ${ii}

        ${file_exists}=  Run Keyword And Return Status  OperatingSystem.File_Should_Exist   lvr_landcsv/${ii}_lvr_land_a_gps.csv
 

        ${start_num}=  set variable  2

        IF  '${file_exists}' == 'True'

        
    
            ${old_csv_content}=    Get File    lvr_landcsv/${ii}_lvr_land_a_gps.csv    encoding=UTF-8-SIG    encoding_errors=strict

            @{old_csv_content_list}=  Read Csv String To List  ${old_csv_content}   
            ${old_csv_content_count}=    Get length    ${old_csv_content_list}

            ${old_csv_content_count_1}=  Evaluate  ${old_csv_content_count}-1

            ${old_csv_content_array}=  get_from_list  ${old_csv_content_list}  ${old_csv_content_count_1}

            log  ${old_csv_content_array}
            log  ${old_csv_content_array}[2]

            ${restart_csv_string}=  set variable  ${old_csv_content_array}[2]

            log  ${restart_csv_string}


            ${CsvFileContent}    Get File    lvr_landcsv/${ii}_lvr_land_a.csv    encoding=UTF-8-SIG    encoding_errors=strict


            @{list_csv_before_yesterday}=  Read Csv String To List  ${CsvFileContent}

            ${list_csv_by_cnt}=    Get length    ${list_csv_before_yesterday}
            
            FOR  ${old_j}  IN RANGE  2  ${list_csv_by_cnt}  1

                ${s1_by_array}=  get_from_list  ${list_csv_before_yesterday}  ${old_j}
                Log  s1_by_array ${s1_by_array}

                Log  ${s1_by_array}[2]

#                ${sensor_match}=   Get Regexp Matches  ${s1_by_array}[2]   ${restart_csv_string}

                log  ${restart_csv_string}

                IF  '${s1_by_array}[2]' == '${restart_csv_string}'

                    ${start_num}=  Evaluate  ${old_j}+1
                    log  ${old_j}
                    log  ${start_num}
                    Exit For Loop

                ELSE
                    CONTINUE For Loop
                END



            END

            
        END

        log  ${start_num}



#        ${CsvFileContent}    Get File    lvr_landcsv\\${ii}_lvr_land_a.csv    encoding=UTF-8-SIG    encoding_errors=strict
        ${CsvFileContent}    Get File    lvr_landcsv/${ii}_lvr_land_a.csv    encoding=UTF-8-SIG    encoding_errors=strict
#        ${CsvFileContent}    Get File    ${ii}_lvr_land_a.csv    encoding=UTF-8    encoding_errors=strict
#UTF-8-SIG

		@{list_csv_before_yesterday}=  Read Csv String To List  ${CsvFileContent}
#		@{list_csv_before_yesterday}=  read_csv_file_to_list  a_lvr_land_a.csv    
		${list_csv_by_cnt}=    Get length    ${list_csv_before_yesterday}










#            ${s1_by_array}=  get_from_list  ${list_csv_before_yesterday}  ${start_num}
#            ${s1_by_array}=  get_from_list  ${list_csv_before_yesterday}  ${old_j}
            Log  s1_by_array ${s1_by_array}

            Log  ${s1_by_array}[1]

        ${sensor_match}=   Get Regexp Matches  ${s1_by_array}[1]   房地
                Log  ${sensor_match}
                IF    "${sensor_match}" == "[]"
                    CONTINUE For Loop
                END
        Log  ${s1_by_array}[2]

            post_postweb2_591FrontEndlogin  https://earth.google.com/web


            ${s1_by_array_2_split}=    Split String    ${s1_by_array}[2]    號

            Log  ${s1_by_array_2_split}[0]
            Log  ${s1_by_array_2_split}[1]
            ${str_number}=  set variable  號

            ${s1_by_array_2_split_0}=  set variable  ${s1_by_array_2_split}[0]${str_number}

            Log  ${s1_by_array_2_split_0}

            Sleep  15s            

            ${point_2}=  Locate  chromium_logo2.png
            Log   ${point_2}
            @{coordinates}=  Convert To List  ${point_2}
            log  ${coordinates}
            log  ${coordinates}[0]
            log  ${coordinates}[1]

            ${point_3}=  Evaluate    (${coordinates}[0]+1250, ${coordinates}[1]+1225)

            Move to  ${point_3}
            Double Click     left

            Sleep  1s



            Click To The Right Of Image   submitbtn4.png  100

            Keyboard Key    press       Delete
            Keyboard Input  insertText  ${s1_by_array_2_split_0}


            Sleep  1s

            Sleep  1s
            Click Image   earth_title2.png



            Sleep  2s
            Click Image   earth_title3.png

            ${point_2}=  Locate  chromium_logo2.png
            Log   ${point_2}
            @{coordinates}=  Convert To List  ${point_2}
            log  ${coordinates}
            log  ${coordinates}[0]
            log  ${coordinates}[1]

            ${point_3}=  Evaluate    (${coordinates}[0]+1900, ${coordinates}[1]+800)

#            Move to  ${point_3}
#            Double Click     left


            Sleep  1s
            Click Image   earth_title4.png


            Sleep  1s
#            Sleep  10s

























		FOR  ${j}  IN RANGE  ${start_num}+1  ${list_csv_by_cnt}  1

			${s1_by_array}=  get_from_list  ${list_csv_before_yesterday}  ${j}
		    Log  s1_by_array ${s1_by_array}

        	Log  ${s1_by_array}[1]

		${sensor_match}=   Get Regexp Matches  ${s1_by_array}[1]   房地
                Log  ${sensor_match}
                IF    "${sensor_match}" == "[]"
                    CONTINUE For Loop
                END

#           Log_To_Console   2 ${i}
#            Should Be True    ${sensor_data}[1] > ${inlet_rotor_minimum}
#                Should Be True    ${sensor_data}[1] < ${inlet_rotor_maximum}
        

        	Log  ${s1_by_array}[2]

#	        post_postweb2_591FrontEndlogin  https://earth.google.com/web


            ${s1_by_array_2_split}=    Split String    ${s1_by_array}[2]    號

            Log  ${s1_by_array_2_split}[0]
            Log  ${s1_by_array_2_split}[1]
            ${str_number}=  set variable  號

            ${s1_by_array_2_split_0}=  set variable  ${s1_by_array_2_split}[0]${str_number}

            Log  ${s1_by_array_2_split_0}



#            Sleep  1s


#            ImageHorizonLibrary.Click_Image     1.png

#    	    Fill Text   xpath=/html/body/flutter-view/flt-text-editing-host/form/input[1]  ${s1_by_array_2_split_0}

#            Click To The Right Of Image   earth_title1.png  100

#            Sleep  10s

#            Click To The Right Of Image   submitbtn4.png  100
            Click To The Right Of Image   earth_title5.png  100

            log  ${s1_by_array_2_split_0}
            Sleep  50ms
            Keyboard Key    press       Delete
#            Sleep  5s
            Keyboard Input  insertText  ${s1_by_array_2_split_0}


#    	    Fill Text   xpath=//*[@id="searchboxinput"]   ${s1_by_array}[2]

#        	click  xpath=/html/body/flutter-view/flt-text-editing-host/form/input[2]

#            Sleep  1s

#            ${point_2}=  Locate  submitbtn5.png
#            Log   ${point_2}
#            Move to  ${point_2}
#            Double Click     left

            Sleep  500ms
            Click Image   earth_title2.png

#/html/body/flutter-view/flt-text-editing-host/form[10]/input[1]

            Sleep  1s
            Click Image   earth_title3.png

            ${point_2}=  Locate  chromium_logo2.png
            Log   ${point_2}
            @{coordinates}=  Convert To List  ${point_2}
            log  ${coordinates}
            log  ${coordinates}[0]
            log  ${coordinates}[1]

            ${point_3}=  Evaluate    (${coordinates}[0]+1900, ${coordinates}[1]+800)

            Move to  ${point_3}
#            Double Click     left


#            Sleep  1s
#            Click Image   earth_title4.png



#            Sleep  10s



		END

        


#    END



















