*** Keywords ***
test_stock_sql_delete
    [Documentation]
    [Tags]
#    Connect To Database
#    ...    pymssql
#    ...    dbName=DLIQSERV
#    ...    dbUsername=DLIQTASK
#    ...    dbPassword=DLIQTASK3817
#    ...    dbHost=10.201.52.130
#    ...    dbPort=1433



    




    Connect To Database Using Custom Params  sqlite3  database="./test.db"


    ${output}=   Execute Sql String     delete from strategy_in ;
    ${output}=   Execute Sql String     delete from evaluate_in ;
    ${output}=   Execute Sql String     delete from estimate_in ;
    ${output}=   Execute Sql String     delete from assets_in ;
    ${output}=   Execute Sql String     delete from strategy_out ;
    ${output}=   Execute Sql String     delete from evaluate_out ;
    ${output}=   Execute Sql String     delete from estimate_out ;
    ${output}=   Execute Sql String     delete from assets_out ;
    ${output}=   Execute Sql String     delete from assets ;
    ${output}=   Execute Sql String     delete from equity ;
    Log  ${output}


  Disconnect From Database
