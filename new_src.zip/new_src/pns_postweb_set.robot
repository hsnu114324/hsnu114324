*** Keywords ***
pns_postweb_set
	[Documentation]
	[Tags]
#***


#***
#	post_postweb_pnsFrontEndlogin  https://pnstest.post.gov.tw/LI.Web/LI0010.aspx
#***
#	post_postweb_ClickPnsFrontEndLoginUsername  0963038476
#***
#	post_postweb_ClickPnsFrontEndLoginPassword  Jy99jy88
#***
#	Sleep  10s
#	post_postweb_ClickPnsFrontEndLoginEnter
#	Sleep  5s
#***
#	post_postweb_ClickPnsFrontEndMenuList2
#***
#	post_postweb_ClickPnsFrontEndMenuList2Button1
#***  
#	post_postweb_ClickPnsFrontEndbtnQuery
#	post_postweb_ClickPnsFrontEndlbtnReqNo_0
##	post_postweb_ClickPnsFrontEndCancelbtnSave
#***
#	post_postweb_ClickPnsFrontEndMenuList1
#***
#	post_postweb_ClickPnsFrontEndMenuList1Button1
#***
#	post_postweb_ClickPnsFrontEndcbConfirm
#***
#	post_postweb_ClickPnsFrontEndddlNewCity_ddl1
#***
#	post_postweb_ClickPnsFrontEndddlOldCity_ddl1
#***
##	post_postweb_ClickPnsFrontEndbtnSend
#***

	post_postweb_pnsBackEndlogin  https://pnstest.post.gov.tw/LI.adm/Login.aspx
#***
	post_postweb_ClickPnsBackEndLoginUsername  174646
#	#165406
#***
	post_postweb_ClickPnsBackEndLoginEnter
	Sleep  1s  
#***
	post_postweb_ClickPnsBackEndtvFunctiont1
#***
	post_postweb_ClickPnsBackEndtvFunctiont3
#***
	post_postweb_ClickPnsBackEndContent1_btnQuery
#***
	post_postweb_ClickPnsBackEndContent1_gvList_LinkButton_0
#***
	post_postweb_ClickPnsBackEndContent1_fvw1Print
#***
        Sleep  10

        ${titles}  Get Window Titles
        Log_To_Console  all_titles: ${titles}
        ${titles2}      Get From List   ${titles}   1
        Log_To_Console  titles_2: ${titles2}
        ${titles1}      Get From List   ${titles}   0
        Log_To_Console  titles_1: ${titles1}
        Switch Window    title=${titles2}


#	pns_postweb_logout
#***
#	pns_postweb_logout
#***
#	pns_postweb_logout
#***
#	pns_postweb_logout
#***
#	pns_postweb_logout


