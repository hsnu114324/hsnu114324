*** Settings ***
Library  yaml
Library  OperatingSystem
Library  Collections

*** Test Cases ***

test_fundamental_genYaml

#    [Arguments] ${data_1} ${data_2} ${data_3} ${data_4} ${data_5} ${data_6} ${data_7} ${data_8} ${data_9}  
    
    ${data_1}=  Set_Variable  myChart1
#    ${data_2}=  Set_list  line
  ${data_2_list}=  Create List
  Append To List  ${data_2_list}  Jan  Feb  Mar


    ${data_3}=  Set_Variable  line
    ${data_4}=  Set_Variable  Exceptional
    ${data_5}=  Set_Variable  "#e8c3b9"
    ${data_6}=  Set_Variable  ${empty}
    ${data_7}=  Set_Variable  false
    ${data_8}=  Set_Variable  "y-axis-1"
    ${data_9}=  Set_Variable  true
    ${data_10_list}=  Create List
    Append To List  ${data_10_list}  1  2  3
    ${data_12}=  Set_Variable  0
    ${data_13}=  Set_Variable  100


    ${test2pyfile1_content}=  Set_Variable  import pulp as pl

    ${test2pyfile2_content}=  Set_Variable  \n\nmodel = pl.LpProblem(name="Model_3.1", sense=pl.LpMaximize)

    ${test2pyfile3_content}=  Set_Variable  \n\nx=pl.LpVariable(name='x')
    ${test2pyfile4_content}=  Set_Variable  \ny=pl.LpVariable(name='y')
    
    ${test2pyfile5_content}=  Set_Variable  \n\nmodel += (2*x+3*y-6>=0)
    ${test2pyfile6_content}=  Set_Variable  \nmodel += (x+y-3<=0)
    ${test2pyfile7_content}=  Set_Variable  \nmodel += (y-2<=0)
    
    ${test2pyfile8_content}=  Set_Variable  \n\nmodel += x+3*y
    
    ${test2pyfile9_content}=  Set_Variable  \n\nstatus = model.solve()
    
    ${test2pyfile10_content}=  Set_Variable  \n\nprint(f"status: {model.status}, {pl.LpStatus[model.status]}")
    ${test2pyfile11_content}=  Set_Variable  \nprint(f"objective: {model.objective.value()}")
    ${test2pyfile12_content}=  Set_Variable  \n\nfor var in model.variables():
    ${test2pyfile13_content}=  Set_Variable  \n\tprint(f"{var.name}: {var.value()}")
    ${test2pyfile14_content}=  Set_Variable  \n\nfor name, constraint in model.constraints.items():
    ${test2pyfile15_content}=  Set_Variable  \n\tprint(f"{name}: {constraint.value()}")



   
###########################################################

    Remove_File  test2.py


    append_to_file  test2.py  ${test2pyfile1_content}
    append_to_file  test2.py  ${test2pyfile2_content}
    append_to_file  test2.py  ${test2pyfile3_content}
    append_to_file  test2.py  ${test2pyfile4_content}
    append_to_file  test2.py  ${test2pyfile5_content}
    append_to_file  test2.py  ${test2pyfile6_content}
    append_to_file  test2.py  ${test2pyfile7_content}
    append_to_file  test2.py  ${test2pyfile8_content}
    append_to_file  test2.py  ${test2pyfile9_content}
    append_to_file  test2.py  ${test2pyfile10_content}
    append_to_file  test2.py  ${test2pyfile11_content}
    append_to_file  test2.py  ${test2pyfile12_content}
    append_to_file  test2.py  ${test2pyfile13_content}
    append_to_file  test2.py  ${test2pyfile14_content}
    append_to_file  test2.py  ${test2pyfile15_content}



