*** Keywords ***
test_stock_sql_insert_old_kd_value
#    [Arguments]    ${excel_file_data}
#    [Arguments]  ${start_date}  ${end_date}
    [Documentation]
    [Tags]
#    Connect To Database
#    ...    pymssql
#    ...    dbName=DLIQSERV
#    ...    dbUsername=DLIQTASK
#    ...    dbPassword=DLIQTASK3817
#    ...    dbHost=10.201.52.130
#    ...    dbPort=1433



    




    Connect To Database Using Custom Params  sqlite3  database="./test.db"




                ${table_name}=  set variable  old_kd_value
                ${name_1}=      set variable  old_kd_value
                ${type_1}=      set variable  INT
                ${name_2}=      set variable  date
                ${type_2}=      set variable  DATE
                ${name_3}=      set variable  strategy_id
                ${type_3}=      set variable  INT
                ${name_4}=      set variable  buyin_signal
                ${type_4}=      set variable  INT
                ${name_5}=      set variable  class
                ${type_5}=      set variable  varchar(100)
                ${name_6}=      set variable  stock_id
                ${type_6}=      set variable  varchar(100)
                ${name_7}=      set variable  strategy_in_or_out
                ${type_7}=      set variable  varchar(100)
                ${name_8}=      set variable  close
                ${type_8}=      set variable  INT

                ${name_9}=      set variable  number_of_share
                ${type_9}=      set variable  INT
                ${name_10}=      set variable  share_amount_price
                ${type_10}=      set variable  FLOAT

                ${name_11}=      set variable  evaluate_in_strategy_ror
                ${type_11}=      set variable  FLOAT
                ${name_12}=      set variable  estimate_in_stock_ror
                ${type_12}=      set variable  FLOAT
                ${name_13}=      set variable  evaluate_in_buyin_signal
                ${type_13}=      set variable  INT
                ${name_14}=      set variable  estimate_in_buyin_signal
                ${type_14}=      set variable  INT
                ${name_15}=      set variable  null_parent_id
                ${type_15}=      set variable  INT
                ${name_16}=      set variable  evaluate_out_children_id
                ${type_16}=      set variable  INT




  ${output}=  Execute Sql String  INSERT INTO ${table_name} VALUES ( -1 )
  Log  ${output}


#  ${output}=  Execute Sql String  INSERT INTO ${table_name} VALUES ( 0, 0, 0, 0, 0, 0, 0, 0 )
#  Log  ${output}


#  ${output}=  Execute Sql String  INSERT INTO ${table_name} VALUES ( 2, '2024-01-02', 2, 1,'tw_stock', '2454', 'in', 1000, 774, 774000, 0, 0, 0, 0, 0, 0 )
#  Log  ${output}

  Disconnect From Database


#    OperatingSystem.Run  echo 'primary_key|date|strategy_id|separate_buyin_signal|class|stock_id|strategy_in_or_out|close|number_of_share|share_amount_price|evaluate_in_strategy_ror|estimate_in_stock_ror|evaluate_in_priority_buyin_signal|estimate_in_buyin_signal|null_parent_id|evaluate_in_children_id' > strategy_in.txt                                     

#    OperatingSystem.Run  sqlite3 test.db 'select primary_key,date,strategy_id,separate_buyin_signal,class,stock_id,strategy_in_or_out,close,number_of_share,share_amount_price,evaluate_in_strategy_ror,estimate_in_stock_ror,evaluate_in_priority_buyin_signal,estimate_in_buyin_signal,null_parent_id,evaluate_in_children_id from strategy_in;' >> strategy_in.txt

#    OperatingSystem.Run  sqlite3 test.db 'select primary_key from primary_key;' >> primary_key.txt

