import pulp as pl

model = pl.LpProblem(name="Model_3.1", sense=pl.LpMaximize)

x=pl.LpVariable(name='x')
y=pl.LpVariable(name='y')

model += (2*x+3*y-6>=0)
model += (x+y-3<=0)
model += (y-2<=0)

model += x+3*y

status = model.solve()

print(f"status: {model.status}, {pl.LpStatus[model.status]}")
print(f"objective: {model.objective.value()}")

for var in model.variables():
	print(f"{var.name}: {var.value()}")

for name, constraint in model.constraints.items():
	print(f"{name}: {constraint.value()}")
