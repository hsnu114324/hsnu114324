*** Keywords ***
#*** Test Cases ***
test_stock4_evaluate_in_module
    [Arguments]     ${excel_file_data}  ${query_start_date}  ${query_end_date}  ${query_stock_id}  ${query_database}

    [Documentation]    Load sensor list file and prepare list
    Log    ${excel_file_data}



    Connect To Database Using Custom Params  sqlite3  database="./${query_database}"






#    ${output}=    query_output_from_database  '${query_start_date}'  '${query_end_date}'  '${query_stock_id}'
#    Log  ${output}


  ${estimate_child_id}=  set variable  1 
  ${evaluate_in_buyin_signal}=  set variable  0
  ${estimate_in_buyin_signal}=  set variable  0

########################################

  
#    ${query_old_data}=  Query  SELECT * from assets_in;
    ${query_old_data}=  Query  SELECT * from strategy_in;

    log  ${query_old_data}
    ${length_query_old_data}=  get length  ${query_old_data}
#    ${length_query_old_data}=  set variable  2

  FOR  ${i}  IN RANGE  0  ${length_query_old_data}  1
    Sleep  1ms
#    ${query_strategy_id}=  set variable  ${query_old_data}[${i}]
    ${query_strategy_id}=  set variable  1
#    ${query_stock_id}=  set variable  2330

    ${strategy_old1}=  Query  SELECT * from assets_in where strategy_id = ${query_strategy_id} order by date;

    ${strategy_old2}=  Query  SELECT * from assets_in where strategy_id = ${query_strategy_id} and stock_id = ${query_stock_id} order by date;

    ${strategy_old3}=  Query  SELECT * from assets_out where strategy_id = ${query_strategy_id} order by date;

    ${strategy_old4}=  Query  SELECT * from assets_out where strategy_id = ${query_strategy_id} and stock_id = ${query_stock_id} order by date;
    

    ${stock_old1}=  Query  SELECT * from assets_out where stock_id = ${query_stock_id} order by date;

    ${stock_old2}=  Query  SELECT * from assets_out where stock_id = ${query_stock_id} order by date;
    


  END

    ${flag_evaluate_old_buyin}=  set variable  1

    IF  ${flag_evaluate_old_buyin} == 1
        ${flag_send_buyin}=  set variable  1
    END

########################################

#    ${list_i}=    Query    SELECT primary_key,date,strategy_id,buyin_signal,class,stock_id,strategy_in_or_out,close,number_of_share,share_amount_price FROM strategy_in WHERE stock_id = '2330' AND DATE between '${query_start_date}' and '${query_end_date}' order by DATE ;
#    Log  ${list_i}

    ${list_i}=    Query_strategy_in_from_database  ${query_start_date}  ${query_end_date}

#            ${list_i}=    post_csv_get_strategy_data    stock_csv_new_macd_dif/1_strategy_2024.csv
            ${length}=  Get length  ${list_i}
            ${length+1}=  evaluate  ${length} + 1

   log  ${list_i}
   log  ${list_i}[0]
   log  ${list_i}[0][15]

   ${yesterday_first_primary_key}=  set variable  ${list_i}[0][15]  
   log  ${yesterday_first_primary_key}

  FOR  ${i}  IN RANGE  ${length}


#     ${primary_key}=           set variable  ${list_i}[${i}][0]  
     ${strategy_in_parent_id}=   set variable  ${list_i}[${i}][0]  
     ${date}=                    set variable  ${list_i}[${i}][1]   
     ${strategy_id}=             set variable  ${list_i}[${i}][2]      
     ${buyin_signal}=            set variable  ${list_i}[${i}][3]  
     ${class}=                   set variable  ${list_i}[${i}][4]       
     ${stock_id}=                set variable  ${list_i}[${i}][5]    
#     ${strategy_in_or_out}=      set variable  ${list_i}[${i}][6]  
     ${evaluate_in_or_out}=      set variable  ${list_i}[${i}][6]  
     ${close}=                   set variable  ${list_i}[${i}][7]  
     ${number_of_share}=         set variable  ${list_i}[${i}][8]  
     ${share_amount_price}=      set variable  ${list_i}[${i}][9]   



####################################################
    Fail

    ${query_evaluate_in_strategy_ror}=  Query  select evaluate_out_strategy_ror from assets_out where strategy_id = ${strategy_id} order by date desc limit 1;
    IF  ${query_evaluate_in_strategy_ror} == []
        ${evaluate_in_strategy_ror}=  set variable  0
    ELSE
        ${evaluate_in_strategy_ror}=  set variable  ${query_evaluate_in_strate_ror}[0][0]
    END

    ${query_estimate_in_stock_ror}=  Query  select evaluate_out_strategy_ror from assets_out where strategy_id = ${strategy_id} order by date desc limit 1;
    IF  ${query_estimate_in_stock_ror} == []
        ${estimate_in_stock_ror}=  set variable  0
    ELSE
        ${estimate_in_stock_ror}=  set variable  ${query_estimate_in_strate_ror}[0][0]
    END



#    ${estimate_in_children_id}=  set variable  0

####################################################

      

  ${flag_disable_old_buyin_signal}=  set variable  1
      IF  ${flag_disable_old_buyin_signal} == 1
           ${flag_send_buyin_signal}=  set variable  0
#          update_strategy_in_data_old_buyin_signal=0
#           ${output}=  Execute Sql String  Update 
      END


        ${table_name}=  set variable  evaluate_in
        ${primary_key}=  set variable  1

    IF  ${flag_send_buyin_signal} == 1

        insert_evaluate_data_to_database  ${table_name}  ${primary_key}  ${date}  ${strategy_id}  ${buyin_signal}  ${class}  ${stock_id}  ${evaluate_in_or_out}  ${close}  ${number_of_share}  ${share_amount_price}  ${evaluate_in_strategy_ror}  ${estimate_in_stock_ror}  ${evaluate_in_buyin_signal}  ${estimate_in_buyin_signal}  ${strategy_in_parent_id}  ${estimate_in_children_id}

    ELSE
        Continue For Loop
    END















#                ${csv_header_string}=  set variable  日期,策略代號,買入訊號,股票代碼,收盤價,成交量,成交金額,evaluate_strategy_ror,strategy_parent_id,estimate_child_id\n


#                ${csv_string}=  set variable  ${today_date}, ${strategy_id}, ${buyin_signal}, ${today_stock_id}, ${today_close}, ${buyin_signal_volume}, ${buyin_among_NTD},${strategy_parent_id},${estimate_child_id},${evaluate_strategy_ror},${strategy_parent_id},${estimate_child_id}\n
#                log  ${csv_string}

#                post_csv_setdata  stock_csv_new_macd_dif/${strategy_id}_evaluate_in_${today_date}[0:4].csv  ${csv_header_string}  ${csv_string}  





  END

























