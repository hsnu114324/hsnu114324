*** Keywords ***
test_stock_genExcel_for_linux


    [Arguments] 	${excel_file_name}  ${sheet_name}  ${start_date}  ${end_date}  ${stock_id_list}  ${database} 
    Log   ${excel_file_name}
    Log   ${sheet_name}
    Log   ${start_date}
    Log   ${end_date}
    Log   ${stock_id_list}
    Log   ${database}


    OperatingSystem.Copy File  Excel/state_machine_for_stock_template.xlsx  Excel/${excel_file_name}

    OperatingSystem.File Should Exist   Excel/${excel_file_name}


    ${date_range}=  finmind_GetDateRange     ${start_date}  ${end_date} 




    ${line_num}=  set variable  1 
    ${states}=    Create List  a  b  c  d  e  f  g  h   

    FOR  ${date}  IN  @{date_range}
        FOR  ${i}  IN  @{states}
            FOR  ${stock_id}  IN  @{stock_id_list}

#####################################################



                ${line_num}=  evaluate  ${line_num} + 1
                ${para0}=  Set Variable  ${i}
                ${para1}=  Set Variable  ${date}
                ${para2}=  Set Variable  ${date}
                ${para3}=  Set Variable  ${stock_id}[0]
                ${para4}=  Set Variable  ${database}
                ${para5}=  Set Variable  ${NULL}
                ${para6}=  Set Variable  ${NULL}
        
                Log  ${para0}
                Log  ${para1}
                Log  ${para2}
                Log  ${para3}
                Log  ${para4}
                Log  ${para5}
                Log  ${para6}
        
        
                post_excel_write_for_linux 	    Excel/${excel_file_name}  ${sheet_name}  ${line_num}  ${para0}  ${para1}  ${para2}  ${para3}  ${para4}  ${para5}  ${para6}

            END
        END
    END

#	[Return]  ${CR_no}
