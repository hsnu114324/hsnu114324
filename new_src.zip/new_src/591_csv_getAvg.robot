*** Keywords ***
591_csv_getAvg

    [Arguments]           ${path_csv}   
    Log_To_Console  path_csv : ${path_csv}



    FOR  ${month_i}  IN RANGE  11201  11212  1   

        ${month_i_count}=  set variable  0  
        ${month_i_sum}=    set variable  0
                      





        ${old_csv_content}=    Get File    lvr_landcsv/${path_csv}    encoding=UTF-8-SIG    encoding_errors=strict
        @{list_csv_before_yesterday}=  Read Csv String To List  ${old_csv_content}
        ${list_csv_by_cnt}=    Get length    ${list_csv_before_yesterday}
                
        FOR  ${old_j}  IN RANGE  0  ${list_csv_by_cnt}  1
    
            ${s1_by_array}=  get_from_list  ${list_csv_before_yesterday}  ${old_j}
    
            Log  s1_by_array ${s1_by_array}
            Log  ${s1_by_array}[2]
            Log  ${s1_by_array}[6]
            Log  ${s1_by_array}[7]
            Log  ${s1_by_array}[8]
            Log  ${s1_by_array}[36]
    
    
            ${s1_substring} =    Get Substring   ${s1_by_array}[33]   0   7
            log  ${s1_substring}
            ${s2_substring} =    Get Substring   ${s1_by_array}[33]   0   7
            log  ${s2_substring}
     
   
            log  ${s1_by_array}[7][0:5]
            IF  ${s1_by_array}[7][0:5] == ${month_i}
                ${month_i_count}=  evaluate  ${month_i_count} + 1
		${month_i_sum}=    evaluate  ${month_i_sum} + ${s1_by_array}[36]
            ELSE
                CONTINUE For Loop
	    END

        END
   

        IF  ${month_i_count} == 0
            CONTINUE For Loop
        END

    
        ${file_exists}=  Run Keyword And Return Status  OperatingSystem.File_Should_Exist   591_csv/avg.csv
     
        IF  '${file_exists}' == 'False'
                        Copy File  lvr_landcsv/a_lvr_land_a_header.csv  591_csv/avg.csv
        END
    
                
    
        ${csv_string}=  set variable  ${empty}
#        ${str_s1_by_array}=   Evaluate  ",".join(${s1_by_array})   
    
#        ${csv_string}=  set variable  ${str_s1_by_array}\n
        ${month_i_avg}=  set variable  ${empty}
        ${month_i_avg}=  evaluate      ${month_i_sum}/${month_i_count}
        ${csv_string}=  set variable  ${month_i},${month_i_avg}\n
        log  ${csv_string}
    
        Append To File   591_csv/avg.csv  ${csv_string}


    END







