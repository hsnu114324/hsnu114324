*** Keywords ***
pnstestmail_sql_setVerB2



#    [Arguments] 	${path_excel}  ${sheet_name}
#    Log_To_Console	path_excel : ${path_excel}
#    Log_To_Console	sheet_name : ${sheet_name}
    
    [Arguments] 	${excel_file_data}   ${is_force_update}
	[Documentation]
	[Tags]
#***

#    ${sensor_check_list}=  post_excel_getdata_for_ezpost    ${path_excel}  ${sheet_name} 

#    ${list_count} =    Get length    ${sensor_check_list}
#    Log_To_Console   list_count ${list_count}
#	Log_To_Console   ${sensor_check_list}

#    FOR  ${sensor_name}  IN  @{sensor_check_list}

#		Log   sensor_name: ${sensor_name}
#		Log   ${sensor_name}[0]

#    END




#  FOR  ${sensor_name}  IN  @{sensor_check_list}
#    IF  '${sensor_name}[0]' == 'sql'
#	    Log_To_Console	${sensor_name}[0]
#	    Log	 ${sensor_name}[0]
#    ELSE
#    	Log_To_Console	${sensor_name}[0]
#    	Log  ${sensor_name}[0]
#    	CONTINUE For Loop
#    END



    IF  '${excel_file_data}[1]' == 'sql'
        ${is_force_update}=  set variable  True
    END

    IF  '${is_force_update}' == 'True'

        Connect_To_pnstest_Databases



        ${Q_SID_num}=        set variable  ${excel_file_data}[2]
        ${CREATE_DATE_str}=  set variable  ${excel_file_data}[4]
        ${Q_VALUE_str}=      set variable  ${excel_file_data}[7]

        IF  '${CREATE_DATE_str}' == 'today'
            ${temp_date}=  Get Current Date  result_format=%Y-%m-%d 
            ${CREATE_DATE_str}=  set variable   ${temp_date}         
        END


#        update_data_from_pnstest_database	${sensor_name}[1]	${sensor_name}[3]	${sensor_name}[5]
         update_data_from_pnstest_database	${Q_SID_num}	  ${CREATE_DATE_str}	  ${Q_VALUE_str}

        ${output}=    Execute Sql String    UPDATE QuestMain SET INSPECTOR_SSO_ID = '714838' where Q_SID = '${Q_SID_num}'
        Log_To_Console  ${output}

        ${output}=    Execute Sql String    UPDATE QuestData SET Q_VALUE = '2024/04/09' where Q_SID = '${Q_SID_num}' and Q_SNO = '21'
        Log_To_Console  ${output}



    ELSE
        Sleep  1ms
    END



#  END

#	[Return]  ${CR_no}
