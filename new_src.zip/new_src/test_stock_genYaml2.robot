*** Keywords ***
test_stock_genYaml2

#    [Arguments] ${data_1} ${data_2} ${data_3} ${data_4} ${data_5} ${data_6} ${data_7} ${data_8} ${data_9}  
    
    ${data_1}=  Set_Variable  myChart1
#    ${data_2}=  Set_list  line
  ${data_2_list}=  Create List
  Append To List  ${data_2_list}  Jan  Feb  Mar


    ${data_3}=  Set_Variable  line
    ${data_4}=  Set_Variable  Exceptional
    ${data_5}=  Set_Variable  "#e8c3b9"
    ${data_6}=  Set_Variable  ${empty}
    ${data_7}=  Set_Variable  false
    ${data_8}=  Set_Variable  "y-axis-1"
    ${data_9}=  Set_Variable  true
    ${data_10_list}=  Create List
    Append To List  ${data_10_list}  1  2  3
    ${data_12}=  Set_Variable  0
    ${data_13}=  Set_Variable  100


    ${chart2yamlfile1_content}=  Set_Variable  \n-\n${SPACE}${SPACE}canvas_id:${SPACE}

    ${chart2yamlfile2_content}=  Set_Variable  \n${SPACE}${SPACE}labels:${SPACE}

    ${chart2yamlfile2_post_content}=  Set_Variable  \n${SPACE}${SPACE}datasets:

    ${chart2yamlfile3_content}=  Set_Variable  \n${SPACE}${SPACE}${SPACE}${SPACE}-\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}type:${SPACE}

    ${chart2yamlfile4_content}=  Set_Variable  \n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}label:${SPACE}

    ${chart2yamlfile5_content}=  Set_Variable  \n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}borderColor:${SPACE}

    ${chart2yamlfile6_content}=  Set_Variable  \n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}backgroundColor:${SPACE}

    ${chart2yamlfile7_content}=  Set_Variable  \n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}fill:${SPACE}

    ${chart2yamlfile8_content}=  Set_Variable  \n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}yAxisID:${SPACE}

    ${chart2yamlfile9_content}=  Set_Variable  \n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}spanGaps:${SPACE}

    ${chart2yamlfile10_content}=  Set_Variable  \n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}data:${SPACE}

    ${chart2yamlfile11_content}=  Set_Variable  \n${SPACE}${SPACE}options:\n${SPACE}${SPACE}${SPACE}${SPACE}scales:\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}xAxes:\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}yAxes:\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}-\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}type:${SPACE}"linear"\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}position:${SPACE}"left"\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}id:${SPACE}"y-axis-1"\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}-\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}type: "linear"\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}position: "right"\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}id: "y-axis-2"


    ${chart2yamlfile12_content}=  Set_Variable  \n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}ticks:\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}min:${SPACE}

    ${chart2yamlfile13_content}=  Set_Variable  \n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}max:${SPACE}












#    ${chart2yamlfile3_content}=  Get_file  chartjsfile3.txt
    ${chart2yamlfile1_content}=  Set_Variable  ${chart2yamlfile1_content}${data_1}
    Log  ${chart2yamlfile1_content}

###
    ${length}=  Get length  ${data_2_list}
    FOR  ${i}  IN RANGE  0  ${length}  1
        ${chart2yamlfile2_content}=  Set_Variable  ${chart2yamlfile2_content}\n${SPACE}${SPACE}${SPACE}${SPACE}-${SPACE}${data_2_list}[${i}]

    END
###

    Log  ${chart2yamlfile2_content}

    ${chart2yamlfile2_post_content}=  Set_Variable  ${chart2yamlfile2_post_content}
    Log  ${chart2yamlfile2_post_content}

    ${chart2yamlfile3_content}=  Set_Variable  ${chart2yamlfile3_content}${data_3}
    Log  ${chart2yamlfile3_content}


    ${chart2yamlfile4_content}=  Set_Variable  ${chart2yamlfile4_content}${data_4}
    Log  ${chart2yamlfile4_content}

    ${chart2yamlfile5_content}=  Set_Variable  ${chart2yamlfile5_content}${data_5}
    Log  ${chart2yamlfile5_content}

    ${chart2yamlfile6_content}=  Set_Variable  ${chart2yamlfile6_content}${data_6}
    Log  ${chart2yamlfile6_content}

    ${chart2yamlfile7_content}=  Set_Variable  ${chart2yamlfile7_content}${data_7}
    Log  ${chart2yamlfile7_content}

    ${chart2yamlfile8_content}=  Set_Variable  ${chart2yamlfile8_content}${data_8}
    Log  ${chart2yamlfile8_content}

    ${chart2yamlfile9_content}=  Set_Variable  ${chart2yamlfile9_content}${data_9}
    Log  ${chart2yamlfile9_content}

###
    ${length}=  Get length  ${data_10_list}
    FOR  ${i}  IN RANGE  0  ${length}  1
        ${chart2yamlfile10_content}=  Set_Variable  ${chart2yamlfile10_content}\n${SPACE}${SPACE}${SPACE}${SPACE}-${SPACE}${data_10_list}[${i}]

    END
    Log  ${chart2yamlfile10_content}
###

    ${chart2yamlfile11_content}=  Set_Variable  ${chart2yamlfile11_content}
    Log  ${chart2yamlfile11_content}

    ${chart2yamlfile12_content}=  Set_Variable  ${chart2yamlfile12_content}${data_12}
    Log  ${chart2yamlfile12_content}

    ${chart2yamlfile13_content}=  Set_Variable  ${chart2yamlfile13_content}${data_13}
    Log  ${chart2yamlfile13_content}




#    Log  ${chart2yamlfile4_content}

    Create_File  chart.html
    ${content}=  Get_File     chart.html
    Log  ${content}

#    Remove_File  chart2.yaml
    
    append_to_file  chart2.yaml  ${chart2yamlfile1_content}
    append_to_file  chart2.yaml  ${chart2yamlfile2_content}
    append_to_file  chart2.yaml  ${chart2yamlfile2_post_content}
#    append_to_file  chart2.yaml  ${chart2yamlfile3_content}
#    append_to_file  chart2.yaml  ${chart2yamlfile4_content}
#    append_to_file  chart2.yaml  ${chart2yamlfile5_content}
#    append_to_file  chart2.yaml  ${chart2yamlfile6_content}
#    append_to_file  chart2.yaml  ${chart2yamlfile7_content}
#    append_to_file  chart2.yaml  ${chart2yamlfile8_content}
#    append_to_file  chart2.yaml  ${chart2yamlfile9_content}
#    append_to_file  chart2.yaml  ${chart2yamlfile10_content}
#    append_to_file  chart2.yaml  ${chart2yamlfile11_content}
#    append_to_file  chart2.yaml  ${chart2yamlfile12_content}
#    append_to_file  chart2.yaml  ${chart2yamlfile13_content}
