*** Settings ***
Library       DatabaseLibrary
#Test Setup    Connect To My Oracle DB

*** Keywords ***
Connect To My Oracle DB
    Connect To Database
    ...    pymssql
    ...    dbName=DLIQSERV
    ...    dbUsername=DLIQTASK
    ...    dbPassword=DLIQTASK3817
    ...    dbHost=10.201.52.130
    ...    dbPort=1433

Connect To My sqlite3 DB
#    Connect To Database  sqlite3  test.db
     Connect To Database Using Custom Params  sqlite3  database="./test.db"




*** Test Cases ***
Test
#    Connect To My Oracle DB
    Connect To My sqlite3 DB

Person Table Contains Expected Records
#    ${output}=    Query    SELECT * FROM QuestData WHERE Q_SID = '08FE0PujSqB';
    ${output}=    Query    SELECT * FROM COMPANY;
    Log_To_Console  ${output}
    Log  ${output}
    ${output_length}=  get length  ${output}
    log  ${output}[0]
    log  ${output}[0][1]

    ${output}=    Execute SQL String    CREATE TABLE user (id integer unique, first_name varchar, last_name varchar);
    ${output}=    Execute Sql String   INSERT INTO DemoItems (ItemName, FirstName) VALUES ('New Item: ' + CAST(GetDate()
#    Length Should Be    ${output}    2
#    Should Be Equal    ${output}[0][0]    See
#    Should Be Equal    ${output}[1][0]    Schneider

#Person Table Contains No Joe
#    ${sql}=    Catenate    SELECT id FROM person
#    ...                    WHERE FIRST_NAME= 'Joe'    
#    Check If Not Exists In Database    ${sql}
