*** Keywords ***
pns_postweb_applyR
	[Documentation]
	[Tags]
#***


#***
	post_postweb_pnsFrontEndlogin  https://pnstest.post.gov.tw/LI.Web/LI0010.aspx
#***
	post_postweb_ClickPnsFrontEndLoginUsername  0963038476
#***
	post_postweb_ClickPnsFrontEndLoginPassword  Jy99jy88
#***
	Sleep  10s
	post_postweb_ClickPnsFrontEndLoginEnter
	Sleep  5s
#***
	post_postweb_ClickPnsFrontEndMenuList2
#***
	post_postweb_ClickPnsFrontEndMenuList2Button1
#***  
	post_postweb_ClickPnsFrontEndbtnQuery
	post_postweb_ClickPnsFrontEndlbtnReqNo_0
#	post_postweb_ClickPnsFrontEndCancelbtnSave
#***
	post_postweb_ClickPnsFrontEndMenuList1
#***
	post_postweb_ClickPnsFrontEndMenuList1Button1
#***
	post_postweb_ClickPnsFrontEndcbConfirm
#***
	post_postweb_ClickPnsFrontEndddlNewCity_ddl1  8
#***
	post_postweb_ClickPnsFrontEndddlOldCity_ddl1  2
#***
	post_postweb_ClickPnsFrontEndbtnSend
#***
