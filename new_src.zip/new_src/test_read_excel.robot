*** Settings ***
Library  OperatingSystem
Library  ExcelLibrary
Library  String
Library  Collections

*** Variables ***
${SOL_BIOS_OUTPUT}    ubuntu
${IPMI_SOL_LOG_FILE}    IPMI_SOL_LOG_FILE.txt
${local_path}           C:\Users\714838\Downloads\new_src
${Excel_folder_path}        Excel
${excel_file_name}          post_address.xlsx
${sheet_name}               Sheet2

#*** Keywords ***
*** Test Cases ***
test_excel_read
#    [Arguments]     ${excel_file_name}  ${sheet_name}
    [Documentation]    Load sensor list file and prepare list
    Log_To_Console   excel_file_name : ${excel_file_name}
    Log_To_Console   sheet_name : ${sheet_name}

 

#    Log_To_Console   filename=${local_path}\${Excel_folder_path}\${excel_file_name}
    Log_To_Console   filename=.\\${Excel_folder_path}\\${excel_file_name}

#    Open Excel Document    filename=${local_path}\${Excel_folder_path}\${excel_file_name}   doc_id=doc1
#    Open Excel Document    filename=${excel_file_name}   doc_id=doc1
    Open Excel Document    filename=.\\${Excel_folder_path}\\${excel_file_name}   doc_id=doc1
    Get Sheet   ${sheet_name}





















