*** Settings ***
Library  OperatingSystem
Library  ExcelLibrary
Library  String
Library  Collections
Library  CSVLibrary
Library  DateTime
Library  DatabaseLibrary
Library  yaml
Resource  Common/common_stock.robot
Resource  Common/common_finmind.robot
Resource  Common/common_chart.robot


*** Variables ***
@{stock_list}    @{EMPTY}


#*** Keywords ***
*** Test Cases ***
test_stock2_marketmakerplot_module2
    [Documentation]    Load sensor list file and prepare list



    Connect To Database Using Custom Params  sqlite3  database="./test.db"

    ${query_start_date}=  set variable  '2024-01-01'
    ${query_end_date}=    set variable  '2024-04-01'










#    ${files}    OperatingSystem.List_Files_In_Directory    stock_csv_new_macd_dif    *_assets_2024.csv
   
#    FOR    ${file}    IN    @{files}


#
#        ${file0_split}=    Split String    ${file}    .
#        Log_To_Console  ${file0_split}[0]
#        ${file1_split}=    Split String    ${file0_split}[0]    _
#        Log_To_Console  ${file1_split}[0]
#
#        ${old1_csv_content}=    Get File    stock_csv_new_macd_dif/${file1_split}[0]_assets_${file1_split}[2].csv    encoding=UTF-8-SIG    encoding_errors=strict
#        @{list_pre_1}=  Read Csv String To List  ${old1_csv_content}
#
#
#        ${old0_csv_content}=    Get File    stock_csv_new_macd_dif/${file1_split}[0]_equity_${file1_split}[2].csv    encoding=UTF-8-SIG    encoding_errors=strict
#        @{list_pre_0}=  Read Csv String To List  ${old0_csv_content}
#
#
#
#
#
#
#        @{list_1}=  Read Csv String To List  ${old1_csv_content} 
#
#        @{list_0}=  Read Csv String To List  ${old0_csv_content} 
##        ${list_0_j-1}=  set variable  ${list_0}[-1]
#
#
#
#
#        @{list_1}=  Read Csv String To List  ${old1_csv_content} 
#
#        @{list_0}=  Read Csv String To List  ${old0_csv_content} 
#
#            ${length}=  Get length  ${list_1}
#            ${length+1}=  evaluate  ${length} + 1
#
#
##            FOR  ${j}  IN RANGE  1  ${length+1}  1 
#
#    END
#






#    ${output}=    Query    SELECT DATE,stock_id,Trading_Volume,Trading_money,open,max,min,close,spread,Trading_turnover FROM daily_stock WHERE stock_id = '2330' AND DATE between ${query_start_date} and ${query_end_date} order by DATE ;
#    Log  ${output}



    ${output_k}=    Query  SELECT DISTINCT today_k,DATE FROM daily_stock_kdj WHERE stock_id = '2330' AND DATE between ${query_start_date} and ${query_end_date} order by DATE ;
    Log  ${output_k}

    ${output_stock_id}=    Query  SELECT DISTINCT stock_id FROM assets WHERE class = 'tw_stock' AND DATE between ${query_start_date} and ${query_end_date} order by DATE ;
    Log  ${output_stock_id}


    ${output_DATE}=    Query  SELECT DISTINCT DATE FROM daily_stock WHERE stock_id = '2330' AND DATE between ${query_start_date} and ${query_end_date} order by DATE ;
    Log  ${output_DATE}

  ${strategy_id}=  set variable  1 
#  ${buyin}=  set variable  0
  ${buyin_signal}=  set variable  0
  ${buyin_signal_volume}=  set variable  0
  ${buyin_among_NTD}=  set variable  0

    ${longterm_position}=  set variable  0
    ${longterm_position_list}=  Create List
    ${primary_key}=  set variable  0
    ${amount_price}=  set variable  0


  ${length}=  get length  ${output_stock_id}

  FOR  ${i}  IN RANGE  0  ${length}  1

#    ${today_date}=  set variable  ${list_1}[${i}][0]     






#    ${today_date}=  set variable  ${output_k}[${i}][1]     
#    ${today_stock_id}=  set variable  ${list_1}[${i}][5]     

#    ${today_stock_id}=  set variable  ${output}[${i}][1]     
#    ${today_trading_volume}=  set variable  ${output}[${i}][2]     
#    ${today_trading_money}=  set variable  ${output}[${i}][3]     
#    ${today_open}=  set variable  ${output}[${i}][4]     
#    ${today_high}=  set variable  ${output}[${i}][5]     
#    ${today_low}=  set variable  ${output}[${i}][6]     
#    ${today_close}=  set variable  ${output}[${i}][7]     
#    ${today_spread}=  set variable  ${output}[${i}][8]     
#    ${today_trading_turnover}=  set variable  ${output}[${i}][9]     
 

        log  ${output_stock_id}[${i}][0]


        ${output_strategy_id}=    Query  SELECT DISTINCT strategy_id FROM assets WHERE stock_id = '${output_stock_id}[${i}][0]' AND DATE between ${query_start_date} and ${query_end_date} order by DATE ;
        Log  ${output_strategy_id}


          ${length_strategy_id}=  get length  ${output_strategy_id}

          FOR  ${j}  IN RANGE  0  ${length_strategy_id}  1

            ${output}=    Query    SELECT DATE,stock_id,Trading_Volume,Trading_money,open,max,min,close,spread,Trading_turnover FROM daily_stock WHERE stock_id = ${output_stock_id}[${i}][0] AND DATE between ${query_start_date} and ${query_end_date} order by DATE ;
            Log  ${output}
            ${output_length}=  get length  ${output}


            ${output_volume}=    Query    SELECT number_of_share,date,unit_price,assets_in_or_out FROM assets WHERE strategy_id = ${output_strategy_id}[${j}][0] AND DATE between ${query_start_date} and ${query_end_date} order by DATE ;
            Log  ${output_volume}
	    
	    ${output_date_i}=  set variable  0
	    ${output_close_list_${j}}=  create list
	    ${output_trading_turnover_list}=  create list
	    ${sum_output_trading_turnover_list}=  create list
	    ${var}=  set variable  sum_output_trading_turnover_
            ${output_close_list_all}=  create list
	    ${output_trading_turnover_list_all}=  create list
	    
	    ${output_volume_length}=  get length  ${output_volume}
	    FOR  ${output_volume_i}  IN RANGE  ${output_volume_length}
                 log  ${output_volume_i}
                 log  ${output_volume}${output_volume_i}




#                 IF  ${output_volume_i} == 0
#		     ${sum_output_trading_turnover_${output_date_i}}=  Create List  0
#		     append_to_list  ${sum_output_trading_turnover_list}  ${sum_output_trading_turnover_${output_date_i}}
#                     log  ${sum_output_trading_turnover_list}
#		 END  
#                 log  ${sum_output_trading_turnover_list}




                 log  ${output_date_i}
                 log  ${output}[${output_date_i}][0]
		 IF  '${output_volume}[${output_volume_i}][1]' > '${output}[${output_date_i}][0]'
                     FOR  ${ii}  IN RANGE  0  ${output_length}  1
       		         ${output_date_i}=  evaluate  ${output_date_i} + 1
                         log  ${output_date_i}
		         IF  '${output_volume}[${output_volume_i}][1]' == '${output}[${output_date_i}][0]'
                             log  ${output_date_i}
                             log  ${output}[${output_date_i}][0]
                             BREAK 
                         END
                     END
                     log  ${output_date_i}

                     ${output_close_${j}_${output_date_i}}=  create list  0
                     append to list  ${output_close_list_${j}}  ${output_close_${j}_${output_date_i}}
		     log  ${output_close_list_${j}}

                     ${output_trading_turnover_${output_date_i}}=  create list  0
                     append to list  ${output_trading_turnover_list}  ${output_trading_turnover_${output_date_i}}
		     log  ${output_trading_turnover_list}

#                        IF  ${output_volume_i} == 0
                         ${sum_output_trading_turnover_0}=  Create List  0
                         ${variables}=    get variables
                         log  ${variables}
                         Should be true      "\@{sum_output_trading_turnover_0}" in $variables
                         ${test_i}=  set variable  0
                         Should be true      "\@{sum_output_trading_turnover_${test_i}}" in $variables
#                         Should be true      "\@{sum_output_trading_turnover_${output_date_i}}" in $variables

                         log  ${output_date_i}
                         ${status}=  Run Keyword And Return Status  Variable Should Exist  ${sum_output_trading_turnover_0}
                         ${status}=  Run Keyword And Return Status  Variable Should Exist  @{sum_output_trading_turnover_0}
                         ${status}=  Run Keyword And Return Status  Variable Should Exist  ${sum_output_trading_turnover_${output_date_i}}
                         ${status}=  Run Keyword And Return Status  Variable Should Exist  @{sum_output_trading_turnover_${output_date_i}}
                         log  ${status}
                         IF  ${status} == ${FALSE}
        		     ${sum_output_trading_turnover_${output_date_i}}=  Create List  0
        		     append_to_list  ${sum_output_trading_turnover_list}  ${sum_output_trading_turnover_${output_date_i}}
                             log  ${sum_output_trading_turnover_list}
        		 END  
                         log  ${sum_output_trading_turnover_list}
#                        END        

                         log  ${output_date_i}
		         ${sum_output_trading_turnover_${output_date_i}}[0]=  evaluate  ${sum_output_trading_turnover_${output_date_i}}[0] + 0  

		 ELSE IF  '${output_volume}[${output_volume_i}][1]' == '${output}[${output_date_i}][0]'



#		     ${output_close_i}=  create list
		     log  ${output_volume}[${output_volume_i}]
		     log  ${output_volume}[${output_volume_i}][2]

                     ${output_close_${j}_${output_date_i}}=  create list  ${output_volume}[${output_volume_i}][2]
                     append to list  ${output_close_list_${j}}  ${output_close_${j}_${output_date_i}}
		     log  ${output_close_list_${j}}

#		     ${output_trading_turnover_i}=  create list
		     log  ${output_volume}[${output_volume_i}][0]
		     ${output_trading_turnover_${output_date_i}}=  create list   ${output_volume}[${output_volume_i}][0]
		     append to list  ${output_trading_turnover_list}  ${output_trading_turnover_${output_date_i}}
		     log  ${output_trading_turnover_list}

                         IF  ${output_volume_i} == 0
        		     ${sum_output_trading_turnover_${output_date_i}}=  Create List  0
        		     append_to_list  ${sum_output_trading_turnover_list}  ${sum_output_trading_turnover_${output_date_i}}
                             log  ${sum_output_trading_turnover_list}
        		 END  
                         log  ${sum_output_trading_turnover_list}
        

		     log  ${output_volume}[${output_volume_i}][3]
                     IF  '${output_volume}[${output_volume_i}][3]' == 'in'
		         ${sum_output_trading_turnover_${output_date_i}}[0]=  evaluate  ${sum_output_trading_turnover_${output_date_i}}[0] + ${output_volume}[${output_date_i}][0]  
                     ELSE IF  '${output_volume}[${output_volume_i}][3]' == 'out'
		         ${sum_output_trading_turnover_${output_date_i}}[0]=  evaluate  ${sum_output_trading_turnover_${output_date_i}}[0] - ${output_volume}[${output_date_i}][0]  
                     ELSE
                         Fail
                     END
                     log  ${sum_output_trading_turnover_list}
		 ELSE
		     Fail
		 END

                 append_to_list  ${output_close_list_all}  ${output_close_list_${j}}
                 log  ${output_close_list_all}
	         append_to_list  ${output_trading_turnover_list_all}  ${output_trading_turnover_list}
	    

            END

#            ${length_output}=  get length  ${output}
#
#            FOR  ${k}  IN RANGE  0  ${length_output}  1
#	         
#                Log  ${k}
#		Log  ${output}[${k}]
#		
##		IF  ${output_volume}
#
#            END

          END






#                ${file_exists_1}=  Run Keyword And Return Status  OperatingSystem.File_Should_Exist   stock_csv_new_macd_dif/${strategy_id}_assets_${today_date}[0:4].csv
#
#                IF  '${file_exists_1}' == 'False'
#                    Copy File  lvr_landcsv/a_lvr_land_a_header.csv  stock_csv_new_macd_dif/${strategy_id}_assets_${today_date}[0:4].csv
#                    Append To File   stock_csv_new_macd_dif/${strategy_id}_assets_${today_date}[0:4].csv   primary_key,策略代號,日期,種類,股票代碼,買進或賣出,成交量,收盤價,成交金額\n
##                    Append To File   stock_csv_new_macd_dif/${strategy_id}_assets_${today_date}[0:4].csv   日期,策略代號,股票代碼,收盤價,成交量,成交金額,開盤價,最高價,最低價,收盤價,漲跌幅,交易筆數,today_ema12,today_ema26,dif,today_macd\n
#                END
#
#
#
#                ${csv_string_1}=  set variable  ${primary_key}, ${strategy_id}, ${today_date}, ${class}, ${today_stock_id}, ${in_or_out}, ${volume}, ${unit_price}, ${amount_price}\n 
#
##                ${csv_string}=  set variable  ${today_date}, ${strategy_id}, ${buyin_signal}, ${today_stock_id}, ${today_close}, ${buyin_signal_volume}, ${buyin_among_NTD}\n
#                log  ${csv_string_1}
#
#                Append To File   stock_csv_new_macd_dif/${strategy_id}_assets_${today_date}[0:4].csv   ${csv_string_1}
#
#
#
#
#
#
#
#
#                ${file_exists_2}=  Run Keyword And Return Status  OperatingSystem.File_Should_Exist   stock_csv_new_macd_dif/${strategy_id}_equity_${today_date}[0:4].csv
#
#                IF  '${file_exists_2}' == 'False'
#                    Copy File  lvr_landcsv/a_lvr_land_a_header.csv  stock_csv_new_macd_dif/${strategy_id}_equity_${today_date}[0:4].csv
#                    Append To File   stock_csv_new_macd_dif/${strategy_id}_equity_${today_date}[0:4].csv   primary_key,策略代號,日期,種類,買入或賣出,通貨,匯率,總新台幣金額\n
##                    Append To File   stock_csv_new_macd_dif/${strategy_id}_buyin_${today_date}[0:4].csv   日期,策略代號,股票代碼,收盤價,成交量,成交金額,開盤價,最高價,最低價,收盤價,漲跌幅,交易筆數,today_ema12,today_ema26,dif,today_macd\n
#                END
#
#
#
#
#
#
#
#
#                ${csv_string_2}=  set variable  ${primary_key}, ${strategy_id}, ${today_date}, ${class}, ${in_or_out}, ${currency}, ${exchange_rate}, ${amount_NTD}\n
#
#
##                ${csv_string}=  set variable  ${today_date}, ${strategy_id}, ${buyin_signal}, ${today_stock_id}, ${today_close}, ${buyin_signal_volume}, ${buyin_among_NTD}\n
#                log  ${csv_string_2}
#
#                Append To File   stock_csv_new_macd_dif/${strategy_id}_equity_${today_date}[0:4].csv   ${csv_string_2}
#


  END













            post_chart_genYamlStart   chart4.yaml 


            post_chart_genYaml2       chart4.yaml  mychart4  ${output_DATE}

            ${length_output_close_list_all}=  get length  ${output_close_list_all}
            FOR  ${y}  IN RANGE  0  ${length_output_close_list_all}  1
	        log  ${output_k}
	        log  ${output_close_list_all}
	        log  ${output_close_list_all}[${y}]
                post_chart_genYaml3       chart4.yaml   line  today_close  '#e8c3b9'  ${empty}  false  'y-axis-1'  true  ${output_close_list_all}[${y}]
            END

            ${length_output_trading_turnover_list}=  get length  ${output_trading_turnover_list}
            FOR  ${z}  IN RANGE  0  ${length_output_trading_turnover_list}  1
	        log  ${output_k}
	        log  ${output_close_list}
                post_chart_genYaml3       chart4.yaml   bar  bar_test  ${empty}  '#ff6384'  false  'y-axis-2'  true  ${output_trading_turnover_list}${z}
            END



            post_chart_genYaml3       chart4.yaml   bar  bar_test  ${empty}  '#ff6384'  false  'y-axis-2'  true  ${sum_output_trading_turnover_list}

            post_chart_genYaml4       chart4.yaml   0  100000




            post_chart_genYaml2       chart4.yaml  mychart5  ${output_DATE}


            post_chart_genYaml3       chart4.yaml   line  today_rsv  '#36a2eb'  ${empty}  false  'y-axis-1'  true  ${output_rsv}

            post_chart_genYaml3       chart4.yaml   line  today_k    '#ff6384'  ${empty}  false  'y-axis-1'  true  ${output_k}

            post_chart_genYaml3       chart4.yaml   line  today_d    '#e8c3b9'  ${empty}  false  'y-axis-1'  true  ${output_d}

            post_chart_genYaml3       chart4.yaml   line  today_3d-2k    '#0f0f0f'  ${empty}  false  'y-axis-1'  true  ${output_3d-2k}

            post_chart_genYaml3       chart4.yaml   line  today_3k-2d    '#9f9f9f'  ${empty}  false  'y-axis-1'  true  ${output_3k-2d}

            post_chart_genYaml3       chart4.yaml   bar  bar_test  ${empty}  '#cc65fe'  false  'y-axis-2'  true  ${output_Trading_turnover}

            post_chart_genYaml4       chart4.yaml   0  100000


            post_chart_genChart2      chart4.yaml  chart4.html
















