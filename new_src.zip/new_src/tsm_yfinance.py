import yfinance as yf
import pandas as pd

# 取得TSM公司的財務數據
msft = yf.Ticker("TSM")

# 取得季度資產負債表數據
balance_sheet_quarterly = msft.quarterly_balance_sheet

# 轉換為DataFrame格式 
balance_sheet_quarterly_df = balance_sheet_quarterly.transpose()

# 儲存為CSV文件
balance_sheet_quarterly_df.to_csv("tsm_quarterly_balance_sheet.csv", header=True, index=True)


income_stmt_quarterly = msft.quarterly_income_stmt
income_stmt_quarterly_df = income_stmt_quarterly.transpose()
income_stmt_quarterly_df.to_csv("tsm_quarterly_income_stmt.csv", header=True, index=True)


cashflow_quarterly = msft.quarterly_cashflow
cashflow_quarterly_df = cashflow_quarterly.transpose()
balance_sheet_quarterly_df.to_csv("tsm_quarterly_cashflow.csv", header=True, index=True)


