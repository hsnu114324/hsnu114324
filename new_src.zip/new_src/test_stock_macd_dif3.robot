*** Settings ***
Library  OperatingSystem
Library  ExcelLibrary
Library  String
Library  Collections
Library  CSVLibrary
Library  DateTime
Library  DatabaseLibrary
Resource  Common/common_stock.robot
Resource  Common/common_finmind.robot


*** Variables ***
@{stock_list}    @{EMPTY}


#*** Keywords ***
*** Test Cases ***
test_stock_macd_dif3
#    [Arguments]     ${excel_file_name}  ${sheet_name}
    [Documentation]    Load sensor list file and prepare list
#    Log_To_Console   excel_file_name : ${excel_file_name}
#    Log_To_Console   sheet_name : ${sheet_name}



    Connect To Database Using Custom Params  sqlite3  database="./test.db"


    ${str_start_date}=  set_variable   2023-01-01
    ${str_end_date}=    set_variable   2024-03-31



            ${yesterday_macd}=  set variable  0
            ${yesterday_ema12}=  set variable  0
            ${yesterday_ema26}=  set variable  0
            ${today_macd}=  set variable  0
            ${today_ema12}=  set variable  0
            ${today_ema16}=  set variable  0






#    ${date_range}=  finmind_GetDateRange  ${start_date}  ${end_date}



#    ${output_date}=    Query    SELECT DATE FROM daily_stock WHERE DATE = '${date}' AND stock_id = '2330';
#    Log  ${output_date}
#
#    IF  ${output_date} == []
#       CONTINUE FOR LOOP
#    END

#    ${output_stock_id}=    Query    SELECT stock_id,DATE FROM daily_stock WHERE DATE = '${date}' AND stock_id = '2330';
#    Log  ${output_stock_id}
#
#    ${output_open}=    Query    SELECT open,DATE FROM daily_stock WHERE DATE = '${date}' AND stock_id = '2330';
#    Log  ${output_open}
#
#    ${output_close}=    Query    SELECT close,DATE FROM daily_stock WHERE DATE = '${date}' AND stock_id = '2330';
#    Log  ${output_close}
#
#    ${output_high}=    Query    SELECT max,DATE FROM daily_stock WHERE DATE = '${date}' AND stock_id = '2330';
#    Log  ${output_high}
#
#    ${output_low}=    Query    SELECT min,DATE FROM daily_stock WHERE DATE = '${date}' AND stock_id = '2330';
#    Log  ${output_low}



    ${output}=    Query    SELECT DATE,stock_id,Trading_Volume,Trading_money,open,max,min,close,spread,Trading_turnover FROM daily_stock WHERE stock_id = '2330' AND DATE between '${str_start_date}' and '${str_end_date}' order by DATE ;
    Log  ${output}



  ${date_length}=  get length  ${output}

  FOR  ${i}  IN RANGE  ${date_length}


    ${today_date}=  set variable  ${output}[${i}][0]     
    ${today_stock_id}=  set variable  ${output}[${i}][1]     
    ${today_trading_volume}=  set variable  ${output}[${i}][2]     
    ${today_trading_money}=  set variable  ${output}[${i}][3]     
    ${today_open}=  set variable  ${output}[${i}][4]     
    ${today_high}=  set variable  ${output}[${i}][5]     
    ${today_low}=  set variable  ${output}[${i}][6]     
    ${today_close}=  set variable  ${output}[${i}][7]     
    ${today_spread}=  set variable  ${output}[${i}][8]     
    ${today_trading_turnover}=  set variable  ${output}[${i}][9]     
 

                    log  ( ${today_close}*2 + ${yesterday_ema12}*(12-1) )/(12+1)
                    ${today_ema12}=  evaluate  ( ${today_close}*2 + ${yesterday_ema12}*(12-1) )/(12+1)

                    log  ( ${today_close}*2 + ${yesterday_ema26}*(26-1) )/(26+1)
                    ${today_ema26}=  evaluate  ( ${today_close}*2 + ${yesterday_ema26}*(26-1) )/(26+1)


                    log  ${today_ema12}-${today_ema26}
                    
		    ${dif}=  evaluate  ${today_ema12}-${today_ema26}

                    log  ( ${dif}*2 + ${yesterday_macd}*(9-1) )/(9+1)

                    ${today_macd}=  evaluate  ( ${dif}*2 + ${yesterday_macd}*(9-1) )/(9+1)








#                ${list_i_j-1_0}=  set variable  ${list_1_j-1}[0]
#                ${list_i_j-1_1}=  set variable  ${list_1_j-1}[1]
#                ${list_i_j-1_2}=  set variable  ${list_1_j-1}[2]
#                ${list_i_j-1_3}=  set variable  ${list_1_j-1}[3]
#                ${list_i_j-1_4}=  set variable  ${list_1_j-1}[4]
#                ${list_i_j-1_5}=  set variable  ${list_1_j-1}[5]
#                ${list_i_j-1_6}=  set variable  ${list_1_j-1}[6]
#                ${list_i_j-1_7}=  set variable  ${list_1_j-1}[7]
#                ${list_i_j-1_8}=  set variable  ${list_1_j-1}[8]
#                ${list_i_j-1_9}=  set variable  ${list_1_j-1}[9]









                ${file_exists}=  Run Keyword And Return Status  OperatingSystem.File_Should_Exist   stock_csv_new_macd_dif/${today_stock_id}_dif_${today_date}[0:4].csv

                IF  '${file_exists}' == 'False'
                    Copy File  lvr_landcsv/a_lvr_land_a_header.csv  stock_csv_new_macd_dif/${today_stock_id}_dif_${today_date}[0:4].csv
                    Append To File   stock_csv_new_macd_dif/${today_stock_id}_dif_${today_date}[0:4].csv   日期,股票代碼,成交量,成交金額,開盤價,最高價,最低價,收盤價,漲跌幅,交易筆數,today_ema12,today_ema26,dif,today_macd\n
                END




#                ${macd_dif_value}=   set variable  ${list_i_j-1_0},${list_i_j-1_1},${list_i_j-1_2},${list_i_j-1_3},${list_i_j-1_4},${list_i_j-1_5},${list_i_j-1_6},${list_i_j-1_7},${list_i_j-1_8},${list_i_j-1_9},${today_ema12}],${today_ema26},${dif},${today_macd}
                ${macd_dif_value}=   set variable  ${today_date},${today_stock_id},${today_trading_volume},${today_trading_money},${today_open},${today_high},${today_low},${today_close},${today_spread},${today_trading_turnover},${today_ema12},${today_ema26},${dif},${today_macd}
                log  ${macd_dif_value}

                ${macd_dif_by_array}=  set variable  ${macd_dif_value}

                log  ${macd_dif_by_array}


                ${csv_string}=  set variable  ${macd_dif_by_array}\n
                log  ${csv_string}

                Append To File   stock_csv_new_macd_dif/${today_stock_id}_dif_${today_date}[0:4].csv   ${csv_string}

#                ${yesterday_k}=  set variable  ${today_k}
#                ${yesterday_d}=  set variable  ${today_d}
                ${yesterday_macd}=  set variable  ${today_macd}
                ${yesterday_ema12}=  set variable  ${today_ema12}
                ${yesterday_ema26}=  set variable  ${today_ema26}


  END

























