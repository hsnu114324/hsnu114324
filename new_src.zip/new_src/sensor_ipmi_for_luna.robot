*** Keywords ***
sensor_ipmi_for_luna
    [Documentation]    Verify Sensors Displayed On ipmitool
    [Tags]    Verify Sensors Displayed On Ipmitool
    [Arguments] 	${path_excel}  ${sheet_name}
    Log_To_Console	path_excel : ${path_excel}
    Log_To_Console	sheet_name : ${sheet_name}


    ${sensor_check_list}=  wistron_excel_getdata    ${path_excel}  ${sheet_name} 

	Log_To_Console   ${sensor_check_list}

	wistron_ipmi_CheckSensor  @{sensor_check_list}
	


