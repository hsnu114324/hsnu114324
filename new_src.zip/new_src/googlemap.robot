*** Keywords ***
googlemap



    post_postweb2_591FrontEndlogin  https://www.google.com.tw/maps/

    Fill Text   xpath=//*[@id="searchboxinput"]   新北市溪尾街27巷30-1號

    click  //*[@id="searchbox-searchbutton"]/span

    ${URL1}=  Get_URL
    Log  ${URL1}

    Sleep  1000ms

    ${URL2}=  Get_URL
    Log  ${URL2}




    Fill Text   xpath=//*[@id="searchboxinput"]   臺中市北區館前路一號

    click  //*[@id="searchbox-searchbutton"]/span

    ${URL1}=  Get_URL
    Log  ${URL1}

    Sleep  1000ms

    ${URL2}=  Get_URL
    Log  ${URL2}

    Fill Text   xpath=//*[@id="searchboxinput"]   新北市溪尾街27巷30-1號

    click  //*[@id="searchbox-searchbutton"]/span

    ${URL1}=  Get_URL
    Log  ${URL1}

    Sleep  1000ms

    ${URL2}=  Get_URL
    Log  ${URL2}






