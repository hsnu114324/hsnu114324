*** Keywords ***
pnstestmail_postweb2_LI7030

#***

#    [Arguments] 	${path_excel}  ${sheet_name}
#    Log_To_Console	path_excel : ${path_excel}
#    Log_To_Console	sheet_name : ${sheet_name}
    
    [Arguments] 	${excel_file_data}
	[Documentation]
	[Tags]
#***

#    ${sensor_check_list}=  post_excel_getdata_for_ezpost    ${path_excel}  ${sheet_name} 

#    ${list_count} =    Get length    ${sensor_check_list}
#    Log_To_Console   list_count ${list_count}
#	Log_To_Console   ${sensor_check_list}

#    FOR  ${sensor_name}  IN  @{sensor_check_list}

#		Log   sensor_name: ${sensor_name}
#		Log   ${sensor_name}[0]

#    END



#    ${quest_conditions}=  set variable  @{excel_file_data}[0]
#	Log   ${quest_conditions}

    ${quest_conditions}=  set variable  ${excel_file_data}
	Log   ${quest_conditions}

    ${quest_conditions_0}=  set variable  ${excel_file_data}[0]
	Log   ${quest_conditions_0}


#    IF  '${quest_conditions}[4]' == 'today'
    IF  '${quest_conditions}[29]' == 'today'
                ${temp_date}=  Get Current Date  result_format=%Y-%m-%d
                ${temp2_date}=  Subtract Time From Date  ${temp_date}  697979d  
                ${temp3_date}=  Subtract Time From Date  ${temp_date}  697978d
                ${para2_date}=  Convert Date  ${temp2_date}  result_format=%Y/%m/%d
                Should Match Regexp  ${para2_date}  ^0\\d{3}/\\d{2}/\\d{2}$
                ${para3_date}=  Convert Date  ${temp3_date}  result_format=%Y/%m/%d
                Should Match Regexp  ${para3_date}  ^0\\d{3}/\\d{2}/\\d{2}$
                ${para2}=  Replace String Using Regexp  ${para2_date}    ^0    \     count=1
                ${para3}=  Replace String Using Regexp  ${para3_date}    ^0    \     count=1
        IF  '${quest_conditions}[29]' == 'today'
            ${quest_conditions}[29]=  set variable  ${para2}
        END 
        IF  '${quest_conditions}[30]' == 'today'
            ${quest_conditions}[30]=  set variable  ${para3}
        END        
    END



#  FOR  ${sensor_name}  IN  @{sensor_check_list}
#    IF  '${sensor_name}[0]' == 'web'
#	    Log_To_Console	${sensor_name}[0]
#	    Log	 ${sensor_name}[0]
#    ELSE
#    	Log_To_Console	${sensor_name}[0]
#    	Log  ${sensor_name}[0]
#    	CONTINUE For Loop
#    END
#
#  END




	post_postweb2_pnsBackEndlogin  https://pnstest.post.gov.tw/LI.adm/Login.aspx
#***
#	post_postweb2_ClickPnsBackEndLoginUsername    ${user_no}
#	post_postweb2_ClickPnsBackEndLoginUsername    714838
#	post_postweb2_ClickPnsBackEndLoginUsername    ${quest_conditions}[3]
	post_postweb2_ClickPnsBackEndLoginUsername    ${quest_conditions}[28]

#	174646
#	#165406
#***
	post_postweb2_ClickPnsBackEndLoginEnter
#	Sleep  10s  
#***
#	post_postweb2_ClickPnsBackEndtvFunctiont20
	post_postweb2_ClickPnsBackEndtvFunctiont22
#***
#	post_postweb2_ClickPnsBackEndtvFunctiont24
	post_postweb2_ClickPnsBackEndtvFunctiont26

#	post_postweb2_ClickPnsBackEndDateStart_Send_CalTextBox    ${quest_conditions}[4]
    Log  ${quest_conditions}[29]
	post_postweb2_ClickPnsBackEndDateStart_Send_CalTextBox    ${quest_conditions}[29]

#	post_postweb2_ClickPnsBackEndDateEnd_Send_CalTextBox    ${quest_conditions}[5]
    Log  ${quest_conditions}[30]
	post_postweb2_ClickPnsBackEndDateEnd_Send_CalTextBox    ${quest_conditions}[30]



#	post_postweb2_ClickPnsBackEndtxtSecondInspectorID    ${EMPTY}  
	post_postweb2_ClickPnsBackEndtxtSecondInspectorID    ${quest_conditions}[39]  


#	post_postweb2_ClickPnsBackEndrblTyperbl1_0

#	post_postweb2_ClickPnsBackEndrblTyperbl1_1

#	post_postweb2_ClickPnsBackEndddlCommentTypeddl1    ${quest_conditions}[9]
	post_postweb2_ClickPnsBackEndddlCommentTypeddl1    ${quest_conditions}[34]

#***
	post_postweb2_ClickPnsBackEndContent1_btnQuery

	Take Screenshot
#***
#	post_postweb2_CheckPnsBackEndContent1_gvList_LinkButton_0   ${CR_no}
#	post_postweb2_ClickPnsBackEndContent1_gvList_LinkButton_0
#***
#        post_postweb2_ClickPnsBackEndContent1_fvw3_ResultStateSuccess
#***
#        post_postweb2_ClickPnsBackEndContent1_btnFvw2Save
#***

        ${row_line}=      set variable  2
        ${total_column}=  set variable  3
	FOR  ${i}  IN RANGE  2  11  1


        ${match1}  ${testmail_no_fromBackEnd}=  Run Keyword And Warn On Failure    Browser.Get Text        xpath=//*[@id="frameName"]/frame[2] >>> xpath=/html/body/form/div[3]/table[2]/tbody/tr/td/div[3]/div/table/tbody/tr[${i}]/td[${row_line}]

	    Log  ${match1}
	    Log  ${testmail_no_fromBackEnd}

	    IF	'${match1}' == 'FAIL'
#		    ${result_data}=  set variable  FAIL
		    Exit For Loop
	    END
#			FOR  ${sensor_name}  IN  @{sensor_check_list}
				${testmail_no}=  set variable  ${quest_conditions}[6]
	    	    IF	'${testmail_no_fromBackEnd}' == '${testmail_no}'
	    		    ${result_data}=  set variable  PASS
	    		    ${total_column}=  evaluate  ${i} + 1
	    		    Exit For Loop
	    	    ELSE IF	'${testmail_no_fromBackEnd}' != '${testmail_no}'
	    		    ${result_data}=  set variable  FAIL
	    	    END
#			END
#		Run Keyword If    '${result_data}'=='FAIL'    Exit For Loop
		${total_column}=  set variable  ${i}
		Take Screenshot
	END

#	Run Keyword If    '${result_data}'=='FAIL'    FAIL

#	FOR  ${sensor_name}  IN  @{sensor_check_list}
#		${testmail_no}=  set variable  ${sensor_name}[0]

#	    Log  ${sensor_name}
#	    Log  ${testmail_no}

	        FOR  ${i}  IN RANGE  2  ${total_column}  1
                ${match1}  ${testmail_no_fromBackEnd}=  Run Keyword And Warn On Failure    Browser.Get Text        xpath=//*[@id="frameName"]/frame[2] >>> xpath=/html/body/form/div[3]/table[2]/tbody/tr/td/div[3]/div/table/tbody/tr[${i}]/td[${row_line}]

	            Log  ${match1}
	            Log  ${testmail_no_fromBackEnd}

	    	    IF	'${testmail_no_fromBackEnd}' == '${testmail_no}'
	    		    ${result_data}=  set variable  PASS
	    		    Exit For Loop
	    	    ELSE IF	'${testmail_no_fromBackEnd}' != '${testmail_no}'
#	    		    ${result_data}=  set variable  FAIL
	    		    ${result_data}=  set variable  PASS
	    	    END   
	        END
		Log  ${result_data}
		Run Keyword If    '${result_data}'=='FAIL'    Exit For Loop
		Log  ${result_data}
		Take Screenshot
#	END








        ${total_column-3}=  evaluate  ${total_column} - 3
	post_postweb2_ClickPnsBackEndContent1_gvList_LinkButton   ${total_column-3}
	
#	post_postweb2_ClickPnsBackEndContent1_fvw_ddlInspector_ddl1    ${quest_conditions}[13]
#	post_postweb2_ClickPnsBackEndContent1_fvw_ddlStatus_ddl1    ${quest_conditions}[8]
    Log  ${quest_conditions}[33]
	post_postweb2_ClickPnsBackEndContent1_fvw_ddlStatus_ddl1    ${quest_conditions}[33]
#	post_postweb2_ClickPnsBackEndContent1_fvw_txtSecondInspectDesc    ${quest_conditions}[16]
    Log  ${quest_conditions}[41]
	post_postweb2_ClickPnsBackEndContent1_fvw_txtSecondInspectDesc    ${quest_conditions}[41]
	Take Screenshot
	post_postweb2_ClickPnsBackEndContent1_btnSend

	Run Keyword If    '${result_data}'=='FAIL'    FAIL

	[Return]  ${result_data}
	        






