*** Keywords ***
test_stock_sql_create_old_kd_value_table
#    [Arguments]  ${start_date}  ${end_date}
    [Documentation]
    [Tags]


    Connect To Database Using Custom Params  sqlite3  database="./test.db"


                ${table_name}=  set variable  old_kd_value
                ${name_1}=      set variable  stock_id
                ${type_1}=      set variable  varchar(100)
                ${name_2}=      set variable  old_kd_value
                ${type_2}=      set variable  INT
#                ${name_2}=      set variable  evaluate_in
#                ${type_2}=      set variable  INT
#                ${name_3}=      set variable  estimate_in
#                ${type_3}=      set variable  INT
#                ${name_4}=      set variable  assets_in
#                ${type_4}=      set variable  INT
#                ${name_5}=      set variable  strategy_out
#                ${type_5}=      set variable  INT
#                ${name_6}=      set variable  evaluate_out
#                ${type_6}=      set variable  INT
#                ${name_7}=      set variable  estimate_out
#                ${type_7}=      set variable  INT
#                ${name_8}=      set variable  assets_out
#                ${type_8}=      set variable  INT


#    ${output}=   Execute Sql String     CREATE TABLE ${table_name} ( ${name_1} ${type_1}, ${name_2} ${type_2}, ${name_3} ${type_3}, ${name_4} ${type_4}, ${name_5} ${type_5}, ${name_6} ${type_6}, ${name_7} ${type_7}, ${name_8} ${type_8} ) ;

    ${output}=   Execute Sql String     CREATE TABLE ${table_name} ( ${name_1} ${type_1}, ${name_2} ${type_2} ) ;

    Log  ${output}









