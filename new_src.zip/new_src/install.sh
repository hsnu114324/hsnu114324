chmod +x geckodriver
mv geckodriver /usr/local/bin/
apt-get install ipmitool
pip3 install -r requirements.txt
apt install curl gnupg
curl -s https://deb.nodesource.com/setup_18.x | sudo bash
apt autoremove
apt purge libc-ares2 libnode72 nodejs
apt install nodejs -y
node -v
python -m Browser.entry init
