*** Variables ***


${FIRMEWARE_RETRY_TIMEOUT}    10s
${FIRMEWARE_TIMEOUT}    20min
${LAN_FIRMEWARE_TIMEOUT}    40min


# OS related parameters.
${OS_WAIT_TIMEOUT}    15min
${OS_WAIT_RETRY_TIMEOUT}    30s

${SSH_CONNECTION_TIMEOUT}    30s


#An indicator flag to connect to IMAP host securely or not.
${IMAP_IS_SECURE}    False


# GUI Loading Timeout Setting
${BROWSER_CONNECTION_TIMEOUT}    30s
${BROWSER_CONNECTION_RETRY_TIMEOUT}    1s
${BROWSER_PROCESSING_TIMEOUT}    3min
${BROWSER_PROCESSING_RETRY_TIMEOUT}    5s
${BROWSER_UPDATING_TIMEOUT}    7min

# PowerStatus Loading Timeout Setting
${POWERSTATUS_CHECK_TIMEOUT}    3min
${POWERSTATUS_CHECK_RETRY_TIMEOUT}    5s

# FAN PWM checking Timeout Setting
${FAN_CHECK_TIMEOUT}    3min
${FAN_CHECK_RETRY_TIMEOUT}    1s

${kvm_timeout_value}    300
