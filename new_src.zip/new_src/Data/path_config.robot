*** Variables ***
#${local_path}			/builds/robotframework_testautomation/testcase/src
#${local_path}			/home/parallels/Desktop/robot_local_test/src
#${local_path}			/media/psf/Home/Downloads/new_src
${local_path}			C:\\Users\\714838\\Downloads\\new_src


${Image_folder_path}		Image
${Script_folder_path}		Script
${Utility_folder_path}		Utility
${Excel_folder_path}		Excel
${Picture_folder_path}		Picture
${591_csv_folder_path}		csv

