*** Variables ***
#BMC setting
#${PORT}          ${EMPTY}

${BMC_IP}         pns.post.gov.tw
#${BMC_IP}         10.32.25.107
#${BMC_IP}         10.32.50.23
#${BMC_IP}         10.32.50.12
#${BMC_IP}         10.32.45.52
${BMC_USERNAME}    admin
${BMC_PASSWORD}    admin
#${BMC_PASSWORD}    dgxluna.admin

# Default GUI browser and mode is set to "Firefox" and "headless"
#${GUI_BROWSER}    ff
${GUI_BROWSER}    chrome
#${GUI_MODE}       headless
${GUI_MODE}       header

# IPMITOOL LAN SETTING
${IPMI_USERNAME}    admin
${IPMI_PASSWORD}    admin

# OS related parameters.
${OS_HOST}        10.36.26.20
${OS_USERNAME}    root
${OS_PASSWORD}    root
#${OS_PASSWORD}    Pass2008

${new_dms_account}    DS000013
${new_dms_password}   C11011101.