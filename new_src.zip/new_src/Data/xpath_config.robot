*** Variables ***


#${xpath_refresh_button}    xpath=//*[@id="main"]/div/header/nav/div/ul/li[4]#${xpath_refresh_button}    xpath=//*[@id="refreshPage"]

${xpath_processing_image}    xpath=//*[@id="processing_layout"]/div
${xpath_kvm_processing_image}    xpath=//*[@id="processing_content"]
${xpath_H5View_button}  xpath=//*[@id="download"]
${xpath_kvm_power}              xpath=//*[@id="button_power_menu"]
${xpath_Immediate_shutdown}     xpath=//*[@id="power_off_immediate"]
${xpath_Power_On_Server}        xpath=//*[@id="power_on"]
${xpath_kvm_edit}       xpath=//*[@id="main"]/div/div/aside[2]/div/section[2]/div[4]/div/div/div/div/div/table/tbody/tr[2]/td[9]/a[5]/i
${xpath_input_kvm_timeout_value}        xpath=//*[@id="idtime_out"]
${xpath_button_kvm_setting_saving}      xpath=//*[@id="save"]
${xpath_kvm_timeout_string}             xpath=//*[@id="status_body"]

${xpath_led_status}    xpath=//*[@id="chassis_led_status"]/i
${xpath_power_control_button}    xpath=//*[@id="main"]/div/div/aside[1]/div/section/ul/li[11]
${xpath_save_button}    xpath=//*[@id="save"]
${xpath_event_filters_data}    xpath=//*[@id="main"]/div/div/aside[2]/div/section[2]/div[4]/div
${xpath_event_count}    xpath=//*[@id="timeline"]/table/tbody/tr/td[1]
${xpath_start_bmc_firmware_update_button}    xpath=//*[@id="start"]
${xpath_start_bios_firmware_update_button}    xpath=//*[@id="proceed"]
${xpath_IPMI_Event_Log_path}    xpath=//*[@id="main"]/div/div/aside[1]/div/section/ul/li[6]/ul/li[1]
${xpath_IPMI_Event_Log_table_row}    xpath=//*[@id='timeline']/table/tbody/tr
${xpath_firmware_checks_button}    xpath=//*[@id="btnFirmwareChecks"]
${xpath_preserve_all_configuration_checkbox}    xpath=//*[@id="idpreserveAll"]
${xpath_upload_firmware_image}    xpath=//*[@id="mainfirmware_image"]
${xpath_clear_user}    xpath=//*[@id="main"]/div/div/aside[2]/div/section[2]/div[2]/div
${xpath_eventlength}    xpath=//*[@id="eventlength"]
${xpath_power_off_radio}    xpath=//*[@id="main"]/div/div/aside[2]/div/section[2]/div/div/div[2]/form/div[1]/label/div
${xpath_power_on_radio}    xpath=//*[@id="main"]/div/div/aside[2]/div/section[2]/div/div/div[2]/form/div[2]/label/div
${xpath_power_cycle_radio}    xpath=//*[@id="main"]/div/div/aside[2]/div/section[2]/div/div/div[2]/form/div[3]/label/div
${xpath_power_hard_reset_radio}    xpath=//*[@id="main"]/div/div/aside[2]/div/section[2]/div/div/div[2]/form/div[4]/label/div
${xpath_power_ACPI_shutdown_radio}    xpath=//*[@id="main"]/div/div/aside[2]/div/section[2]/div/div/div[2]/form/div[5]/label/div
