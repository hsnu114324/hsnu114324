*** Variables ***

${url_sensors}    https://${BMC_IP}/#sensors
${url_event_log_ipmi}    https://${BMC_IP}/#logs/event-log
${url_FW_upgrade}    https://${BMC_IP}/#maintenance/firmware_update_wizard
${url_event_filters}    https://${BMC_IP}/#settings/pef/event_filters
${url_users}    https://${BMC_IP}/#settings/users
${url_power_control}    https://${BMC_IP}/#power-control
${url_remote_control}   https://${BMC_IP}/#remote_control
${url_services}         https://${BMC_IP}/#settings/services
