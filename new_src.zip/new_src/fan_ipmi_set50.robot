*** Variables ***
${fan_target_pwm_50}	  0x32
${inlet_rotor_minimum_50}    7016
${inlet_rotor_maximum_50}    8575
${outlet_rotor_minimum_50}   6524
${outlet_rotor_maximum_50}	  7973


*** Keywords ***
fan_ipmi_set50
	wistron_ipmi_FanSetManual
	wistron_ipmi_FanSet	${fan_target_pwm_50}
	wistron_ipmi_FanGetDuty  ${inlet_rotor_minimum_50}    ${inlet_rotor_maximum_50}    ${outlet_rotor_minimum_50}    ${outlet_rotor_maximum_50}
	wistron_ipmi_FanSetAuto


