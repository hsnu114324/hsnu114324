*** Keywords ***
test_stock_genChart2

 
   

    ${YAML}=  Get File  ${CURDIR}${/}chart2.yaml
    ${LOADED}=  yaml.Safe Load  ${YAML}

    Remove_File  chart3.html


    ${chartjs3file1_content}=  Get_file  chartjs3file1.txt
    append_to_file  chart3.html  ${chartjs3file1_content}

 



    ${chartjs_item_list}=  Get slice From List   ${LOADED}[chartjs] 
    log  ${chartjs_item_list}

    ${chartjs_item_length}=  get length  ${chartjs_item_list}


    FOR  ${i}  IN RANGE  0  ${chartjs_item_length}  1





        ${chartjs3file2pre_content}=  Set_Variable  \n${SPACE}${SPACE}${SPACE}${SPACE}<div style="height:50%;width:50%;">\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}<canvas id="

        
        ${chartjs3file2_variable}=  Get From Dictionary  ${LOADED}[chartjs][${i}]  canvas_id 

        ${chartjs3file2pre_content}=  Set_Variable  ${chartjs3file2pre_content}${chartjs3file2_variable}
        Log  ${chartjs3file2pre_content}

        append_to_file  chart3.html  ${chartjs3file2pre_content}



        ${chartjs3file2middle_content}=  Set_Variable  "${SPACE}></canvas>\n${SPACE}${SPACE}${SPACE}${SPACE}</div>\n${SPACE}${SPACE}${SPACE}<script>\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}var${SPACE}ctx

        ${chartjs3file2middle_content}=  Set_Variable  ${chartjs3file2middle_content}${chartjs3file2_variable}
        Log  ${chartjs3file2middle_content}

        append_to_file  chart3.html  ${chartjs3file2middle_content}


        ${chartjs3file2post_content}=  Set_Variable  ${SPACE}=${SPACE}document.getElementById('

        ${chartjs3file2post_content}=  Set_Variable  ${chartjs3file2post_content}${chartjs3file2_variable}
        Log  ${chartjs3file2post_content}

        append_to_file  chart3.html  ${chartjs3file2post_content}





        ${chartjs3file3_content}=  Set_Variable  ').getContext('2d');\n\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}let${SPACE}obj

        ${chartjs3file3_content}=  Set_Variable  ${chartjs3file3_content}${chartjs3file2_variable}
        Log  ${chartjs3file3_content}

        append_to_file  chart3.html  ${chartjs3file3_content}






        ${chartjs3file4_content}=  Set_Variable  ${SPACE}=${SPACE}{\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}labels:${SPACE}\["
        
        ${chartjs_labels_item_list}=  Get slice From List   ${LOADED}[chartjs][${i}][labels]
        log  ${chartjs_labels_item_list}
        ${chartjs_labels_item_length}=  get length  ${chartjs_labels_item_list}

#        FOR  ${j}  IN RANGE  0  ${chartjs_labels_item_length}  1

            ${chartjs3file4_variable}=  Evaluate  '","'.join(${chartjs_labels_item_list})

#        END
        Log  ${chartjs3file4_variable}

        ${chartjs3file4_content}=  Set_Variable  ${chartjs3file4_content}${chartjs3file4_variable}
        Log  ${chartjs3file4_content}

        append_to_file  chart3.html  ${chartjs3file4_content}




        ${chartjs3file4post_content}=  Set_Variable  "],\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}datasets:${SPACE}\[\n

        append_to_file  chart3.html  ${chartjs3file4post_content}


        ${chartjs_datasets_item_list}=  Get slice From List   ${LOADED}[chartjs][${i}][datasets]
        log  ${chartjs_datasets_item_list}
        ${chartjs_datasets_item_length}=  get length  ${chartjs_datasets_item_list}

        FOR  ${i_j}  IN RANGE  0  ${chartjs_datasets_item_length}  1



            ${chartjs3file5_content}=  Set_Variable  \n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}{\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}type:${SPACE}'
 
            
            ${chartjs3file5_variable}=  Get From Dictionary  ${LOADED}[chartjs][${i}][datasets][${i_j}]    type
    
            ${chartjs3file5_content}=  Set_Variable  ${chartjs3file5_content}${chartjs3file5_variable}
            Log  ${chartjs3file5_content}
    
            append_to_file  chart3.html  ${chartjs3file5_content}
    
 
            ${chartjs3file6_content}=  Set_Variable  ',\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}label:${SPACE}'
 
            
            ${chartjs3file6_variable}=  Get From Dictionary  ${LOADED}[chartjs][${i}][datasets][${i_j}]    label
    
            ${chartjs3file6_content}=  Set_Variable  ${chartjs3file6_content}${chartjs3file6_variable}
            Log  ${chartjs3file6_content}
    
            append_to_file  chart3.html  ${chartjs3file6_content}


 
            ${chartjs3file7_content}=  Set_Variable  ',\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}borderColor:${SPACE}'
             
            ${chartjs3file7_variable}=  Get From Dictionary  ${LOADED}[chartjs][${i}][datasets][${i_j}]    borderColor
    
            ${chartjs3file7_content}=  Set_Variable  ${chartjs3file7_content}${chartjs3file7_variable}
            Log  ${chartjs3file7_content}
    
            append_to_file  chart3.html  ${chartjs3file7_content}

     
            ${chartjs3file8_content}=  Set_Variable  ',\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}backgroundColor:${SPACE}'
             
            ${chartjs3file8_variable}=  Get From Dictionary  ${LOADED}[chartjs][${i}][datasets][${i_j}]    backgroundColor
    
            ${chartjs3file8_content}=  Set_Variable  ${chartjs3file8_content}${chartjs3file8_variable}
            Log  ${chartjs3file8_content}
    
            append_to_file  chart3.html  ${chartjs3file8_content}
    

      
            ${chartjs3file9_content}=  Set_Variable  ',\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}fill:${SPACE}
             
            ${chartjs3file9_variable}=  Get From Dictionary  ${LOADED}[chartjs][${i}][datasets][${i_j}]    fill
   

            IF  ${chartjs3file9_variable} == False
                ${chartjs3file9_content}=  Set_Variable  ${chartjs3file9_content} false
            ELSE 
                ${chartjs3file9_content}=  Set_Variable  ${chartjs3file9_content}${chartjs3file9_variable}
            END
            Log  ${chartjs3file9_content}
    
            append_to_file  chart3.html  ${chartjs3file9_content}
   
   
       
            ${chartjs3file10_content}=  Set_Variable  ,\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}yAxisID:${SPACE}"
             
            ${chartjs3file10_variable}=  Get From Dictionary  ${LOADED}[chartjs][${i}][datasets][${i_j}]    yAxisID
    
            ${chartjs3file10_content}=  Set_Variable  ${chartjs3file10_content}${chartjs3file10_variable}
            Log  ${chartjs3file10_content}
    
            append_to_file  chart3.html  ${chartjs3file10_content}
   

     
            ${chartjs3file11_content}=  Set_Variable  ",\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}spanGaps:${SPACE}
             
            ${chartjs3file11_variable}=  Get From Dictionary  ${LOADED}[chartjs][${i}][datasets][${i_j}]    spanGaps

    
            IF  ${chartjs3file11_variable} == True
                ${chartjs3file11_content}=  Set_Variable  ${chartjs3file11_content} true
            ELSE
                ${chartjs3file11_content}=  Set_Variable  ${chartjs3file11_content}${chartjs3file11_variable}
            END

            Log  ${chartjs3file11_content}
    
            append_to_file  chart3.html  ${chartjs3file11_content}
 

     
            ${chartjs3file12_content}=  Set_Variable  ,\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}data:${SPACE}\[
         
            ${chartjs_data_item_list}=  Get slice From List   ${LOADED}[chartjs][${i}][datasets][${i_j}][data]
            log  ${chartjs_data_item_list}
            ${chartjs_data_item_length}=  get length  ${chartjs_data_item_list}

            ${chartjs3file12_variable}=  Evaluate  ",".join(str(x) for x in ${chartjs_data_item_list})

            Log  ${chartjs3file12_variable}
    
            ${chartjs3file12_content}=  Set_Variable  ${chartjs3file12_content}${chartjs3file12_variable}
            Log  ${chartjs3file12_content}
    
            append_to_file  chart3.html  ${chartjs3file12_content}
   


            ${chartjs3file12post_content}=  Set_Variable  \],\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}},
    
            Log  ${chartjs3file12post_content}
    
            append_to_file  chart3.html  ${chartjs3file12post_content}
 







        END


        ${chartjs3file14pre_content}=  Set_Variable     ]\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}};\n\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}var${SPACE}

        
        ${chartjs3file14_variable}=  Get From Dictionary  ${LOADED}[chartjs][${i}]  canvas_id 

        ${chartjs3file14pre_content}=  Set_Variable  ${chartjs3file14pre_content}${chartjs3file2_variable}
        Log  ${chartjs3file14pre_content}

        append_to_file  chart3.html  ${chartjs3file14pre_content}



        ${chartjs3file14middle_content}=  Set_Variable  ${SPACE}=${SPACE}new${SPACE}Chart(ctx

        ${chartjs3file14middle_content}=  Set_Variable  ${chartjs3file14middle_content}${chartjs3file14_variable}
        Log  ${chartjs3file14middle_content}

        append_to_file  chart3.html  ${chartjs3file14middle_content}


        ${chartjs3file14post_content}=  Set_Variable  ,${SPACE}{\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}type:${SPACE}'line',\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}data:${SPACE}obj

        ${chartjs3file14post_content}=  Set_Variable  ${chartjs3file14post_content}${chartjs3file14_variable}
        Log  ${chartjs3file14post_content}

        append_to_file  chart3.html  ${chartjs3file14post_content}


        ${chartjs3file15_content}=  Set_Variable     ,\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}options:${SPACE}{\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}scales:${SPACE}{\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}xAxes:${SPACE}\[{\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}offset:${SPACE}true,\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}gridLines:${SPACE}{\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}display:${space}true\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}},\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}}],\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}yAxes:${SPACE}\[{
        

        ${chartjs3file15_content}=  Set_Variable  ${chartjs3file15_content}
        Log  ${chartjs3file15_content}

        append_to_file  chart3.html  ${chartjs3file15_content}



        ${chartjs3file16_content}=  Set_Variable  \n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}type:${SPACE}"linear",\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}display:${SPACE}true,\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}position:${SPACE}"left",\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}id:${SPACE}"y-axis-1",\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}gridLines:${SPACE}{\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}drawOnChartArea:${SPACE}false,\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}},\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}},

        ${chartjs3file16_content}=  Set_Variable  ${chartjs3file16_content}
        Log  ${chartjs3file16_content}

        append_to_file  chart3.html  ${chartjs3file16_content}



        ${chartjs3file17_content}=  Set_Variable  \n{\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}type:${SPACE}"linear",\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}display:${SPACE}true,\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}position:${SPACE}"right",\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}id:${SPACE}"y-axis-2",\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}gridLines:${SPACE}{\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}drawOnChartArea:${SPACE}false,\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}},

        ${chartjs3file17_content}=  Set_Variable  ${chartjs3file17_content}
        Log  ${chartjs3file17_content}

        append_to_file  chart3.html  ${chartjs3file17_content}



        ${chartjs3file18pre_content}=  Set_Variable     \n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}ticks:{\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}min:${SPACE}
        
        ${chartjs3file18min_variable}=  Get From Dictionary  ${LOADED}[chartjs][${i}][options][scales][yAxes][1][ticks]  min

        ${chartjs3file18pre_content}=  Set_Variable  ${chartjs3file18pre_content}${chartjs3file18min_variable}
        Log  ${chartjs3file18pre_content}

        append_to_file  chart3.html  ${chartjs3file18pre_content}



        ${chartjs3file18middle_content}=  Set_Variable     ,\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}max:${SPACE}
        
        ${chartjs3file18max_variable}=  Get From Dictionary  ${LOADED}[chartjs][${i}][options][scales][yAxes][1][ticks]  max

        ${chartjs3file18middle_content}=  Set_Variable  ${chartjs3file18middle_content}${chartjs3file18max_variable}
        Log  ${chartjs3file18middle_content}

        append_to_file  chart3.html  ${chartjs3file18middle_content}






        ${chartjs3file19_content}=  Set_Variable  ,\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}}\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}}],\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}}\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}}\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}});\n${SPACE}${SPACE}${SPACE}${SPACE}${SPACE}\n${SPACE}${SPACE}${SPACE}${SPACE}</script>


        ${chartjs3file19_content}=  Set_Variable  ${chartjs3file19_content}
        Log  ${chartjs3file19_content}

        append_to_file  chart3.html  ${chartjs3file19_content}







    END



    ${chartjs3file21_content}=  Set_Variable  \n</body>\n</html>

    ${chartjs3file21_content}=  Set_Variable  ${chartjs3file21_content}
    Log  ${chartjs3file21_content}

    append_to_file  chart3.html  ${chartjs3file21_content}




