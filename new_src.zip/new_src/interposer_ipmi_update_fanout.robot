*** Variables ***
${board_type_fanout}  fanout
${Re-timer_number}    0

*** Keywords ***

interposer_ipmi_update_fanout


	wistron_ipmi_updateinterposer  ${board_Type_fanout}   ${Re-timer_number}  UT20_G4_RETIMER_011501_enc.hpm 
	wistron_ipmi_ExpectInterposerVersion  ${board_Type_fanout}   ${Re-timer_number}  0f
	wistron_ipmi_updateinterposer  ${board_Type_fanout}  ${Re-timer_number}  UT20_G4_RETIMER_012200_enc.hpm 
	wistron_ipmi_ExpectInterposerVersion  ${board_Type_fanout}   ${Re-timer_number}  16
