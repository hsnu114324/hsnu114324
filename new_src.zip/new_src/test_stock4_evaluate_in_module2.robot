*** Keywords ***
#*** Test Cases ***
test_stock4_evaluate_in_module2
    [Arguments]     ${excel_file_data}  ${query_start_date}  ${query_end_date}  ${query_stock_id}  ${query_database}

    [Documentation]    Load sensor list file and prepare list
    Log    ${excel_file_data}


    ${query_start_date}=  set variable  ${excel_file_data}[1]
    Log   ${query_start_date}
    ${query_end_date}=  set variable  ${excel_file_data}[2]
    Log   ${query_end_date}
    ${query_stock_id}=  set variable  ${excel_file_data}[3]
    Log   ${query_stock_id}
    ${query_database}=  set variable  ${excel_file_data}[4]
    Log   ${query_database}


    Connect To Database Using Custom Params  sqlite3  database="./${query_database}"

    ${query_primary_key}=  Query  select primary_key from primary_key limit 1 ;
    IF  ${query_primary_key}== []
        ${primay_key}=  set variable  1
    ELSE
        ${primary_key}=  set variable  ${query_primary_key}[0][0]
    END 



     ${table_name}=              set variable  evaluate_in


    ${yesterday}=  Query  select date from evaluate_in order by date desc limit 1 ;
    IF  ${yesterday} == []
#        Fail
         Sleep  1ms
#         Continue For Loop
    ELSE
        ${list_i}=  Query  select * from strategy_in where date = '${yesterday}[0][0]' AND stock_id = ${query_stock_id} ;
 

        ${length_list_i}=  get length  ${list_i}
       FOR  ${i}  IN RANGE  0  ${length_list_i}  1
     
#         ${primary_key}=             set variable  ${list_i}[${i}][0]  
         ${strategy_in_parent_id}=   set variable  ${list_i}[${i}][0]  
         ${date}=                    set variable  ${list_i}[${i}][1]   
         ${strategy_id}=             set variable  ${list_i}[${i}][2]      
         ${separate_buyin_signal}=            set variable  ${list_i}[${i}][3]  
         ${class}=                   set variable  ${list_i}[${i}][4]       
         ${stock_id}=                set variable  ${list_i}[${i}][5]    
    #     ${strategy_in_or_out}=      set variable  ${list_i}[${i}][6]  
         ${evaluate_in_or_out}=      set variable  ${list_i}[${i}][6]  
         ${close}=                   set variable  ${list_i}[${i}][7]  
         ${number_of_share}=         set variable  ${list_i}[${i}][8]  
         ${share_amount_price}=      set variable  ${list_i}[${i}][9]
         ${evaluate_in_strategy_ror}=      set variable  ${list_i}[${i}][9]
         ${estimate_in_stock_ror}=      set variable  ${list_i}[${i}][9]
         ${evaluate_in_priority_buyin_signal}=      set variable  0
         ${estimate_in_buyin_signal}=      set variable  0
         ${strategy_in_parent_id}=      set variable  0
         ${estimate_in_children_id}=      set variable  0

 
    
            IF  ${separate_buyin_signal} >= 1
               ${separate_buyin_signal}=  evaluate  ${separate_buyin_signal} - 1
    #          update_strategy_in_data_old_buyin_signal=0
    #           ${output}=  Execute Sql String  Update 
            END
    
    
            ${flag_send_buyin_signal}=  set variable  1
            IF  ${flag_send_buyin_signal} == 1

                ${primary_key}=  evaluate  ${primary_key} + 1
    
#              ${output}=  Execute sql string  update strategy_in set evaluate_in_children_id=${primary_key};

#                insert_evaluate_data_to_database  ${table_name}  ${primary_key}  ${date}  ${strategy_id}  ${separate_buyin_signal}  ${class}  ${stock_id}  ${evaluate_in_or_out}  ${close}  ${number_of_share}  ${share_amount_price}  ${evaluate_in_strategy_ror}  ${estimate_in_stock_ror}  ${evaluate_in_priority_buyin_signal}  ${estimate_in_buyin_signal}  ${strategy_in_parent_id}  ${estimate_in_children_id}

#                ${output}=  Execute sql string  update primary_key set primary_key=${primary_key};     

            ELSE
                Continue For Loop
            END
        END

    END



    ${list_j}=    query_strategy_in_from_database  ${query_start_date}  ${query_end_date}  ${query_stock_id} 
   



    ${flag_evaluate_old_buyin}=  set variable  1
    ${length_list_j}=  get length  ${list_j}
    FOR  ${j}  IN RANGE  0  ${length_list_j}  1
 
#     ${primary_key}=             set variable  ${list_j}[${j}][0]  
#     ${primary_key}=             set variable  1  
     ${strategy_in_parent_id}=   set variable  ${list_j}[${j}][0]  
     ${date}=                    set variable  ${list_j}[${j}][1]   
     ${strategy_id}=             set variable  ${list_j}[${j}][2]      
     ${separate_buyin_signal}=            set variable  ${list_j}[${j}][3]  
     ${class}=                   set variable  ${list_j}[${j}][4]       
     ${stock_id}=                set variable  ${list_j}[${j}][5]    
#     ${strategy_in_or_out}=      set variable  ${list_j}[${j}][6]  
     ${evaluate_in_or_out}=      set variable  ${list_j}[${j}][6]  
     ${close}=                   set variable  ${list_j}[${j}][7]  
     ${number_of_share}=         set variable  ${list_j}[${j}][8]  
     ${share_amount_price}=      set variable  ${list_j}[${j}][9]
     ${evaluate_in_strategy_ror}=      set variable  ${list_j}[${j}][10]
     ${estimate_in_stock_ror}=      set variable  0
     ${evaluate_in_priority_buyin_signal}=      set variable  0
     ${estimate_in_buyin_signal}=      set variable  0
     ${strategy_in_parent_id}=      set variable  ${list_j}[${j}][0]
     ${estimate_in_children_id}=      set variable  0


####################################################

    ${query_evaluate_in_strategy_ror}=  Query  select evaluate_out_strategy_ror from assets_out where strategy_id = ${strategy_id} order by date desc limit 1;

    IF  '${query_evaluate_in_strategy_ror}' == 'None'
        ${evaluate_in_strategy_ror}=  set variable  0
    ELSE IF  ${query_evaluate_in_strategy_ror} == []
        ${evaluate_in_strategy_ror}=  set variable  0
    ELSE
        ${evaluate_in_strategy_ror}=  set variable  ${query_evaluate_in_strategy_ror}[0][0]
    END    




#################################################### 


       IF  ${flag_evaluate_old_buyin} == 1
            ${flag_send_buyin_signal}=  set variable  1
        END
 
        IF  ${flag_send_buyin_signal} == 1

                ${primary_key}=  evaluate  ${primary_key} + 1
    
            ${output}=  Execute sql string  update strategy_in set evaluate_in_children_id=${primary_key} where primary_key=${strategy_in_parent_id};

            insert_evaluate_data_to_database  ${table_name}  ${primary_key}  ${date}  ${strategy_id}  ${separate_buyin_signal}  ${class}  ${stock_id}  ${evaluate_in_or_out}  ${close}  ${number_of_share}  ${share_amount_price}  ${evaluate_in_strategy_ror}  ${estimate_in_stock_ror}  ${evaluate_in_priority_buyin_signal}  ${estimate_in_buyin_signal}  ${strategy_in_parent_id}  ${estimate_in_children_id}

                ${output}=  Execute sql string  update primary_key set primary_key=${primary_key};     
            

        ELSE
            Continue For Loop
        END
        
    END

    Disconnect From Database

#    Sleep  1s

    ${output}=  OperatingSystem.Run  echo "primary_key|date|strategy_id|separate_buyin_signal|class|stock_id|evaluate_in_or_out|close|number_of_share|share_amount_price|evaluate_in_strategy_ror|estimate_in_stock_ror|evaluate_in_priority_buyin_signal|estimate_in_buyin_signal|strategy_in_parent_id|estimate_in_children_id" > evaluate_in.txt 

    log  ${output}


    ${output}=  OperatingSystem.Run  sqlite3 test.db "select primary_key,date,strategy_id,separate_buyin_signal,class,stock_id,evaluate_in_or_out,close,number_of_share,share_amount_price,evaluate_in_strategy_ror,estimate_in_stock_ror,evaluate_in_priority_buyin_signal,estimate_in_buyin_signal,strategy_in_parent_id,estimate_in_children_id from evaluate_in;" >> evaluate_in.txt 

    log  ${output}


#    OperatingSystem.Run  sqlite3 test.db 'select * from evaluate_in;' > test.txt 

