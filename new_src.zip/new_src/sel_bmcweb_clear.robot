*** Variables ***
${xpath_clear_log_button}   xpath=//*[@id='idcl_log']
${xpath_IPMI_Event_Log_table_row}    xpath=//*[@id='timeline']/table/tbody/tr
${xpath_IPMI_Event_Log_1}   xpath=//*[@id="event-content"]/li[2]/div/h3 

*** Keywords ***
sel_bmcweb_clear
	[Documentation]
	[Tags]
	wistron_bmcweb_login
###
        wistron_bmcweb_GoToPage  ${url_event_log_ipmi}
###
	wistron_bmcweb_ClickClearLogButton
###
	wistron_bmcweb_ExpectClearLog



     wistron_bmcweb_logout



