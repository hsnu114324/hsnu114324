*** Keywords ***
#*** Test Cases ***
test_stock4_strategy_in_module
#    [Arguments]     ${excel_file_data}  
#    [Arguments]     ${query_start_date}  ${query_end_date}  ${query_stock_id}  ${query_database}
    [Arguments]     ${excel_file_data}  ${query_start_date}  ${query_end_date}  ${query_stock_id}  ${query_database}

    [Documentation]    Load sensor list file and prepare list
    Log    ${excel_file_data}

    ${query_start_date}=  set variable  ${excel_file_data}[1]
    Log   ${query_start_date}
    ${query_end_date}=  set variable  ${excel_file_data}[2]
    Log   ${query_end_date}
    ${query_stock_id}=  set variable  ${excel_file_data}[3]
    Log   ${query_stock_id}
    ${query_database}=  set variable  ${excel_file_data}[4]
    Log   ${query_database}


#    Connect To Database Using Custom Params  sqlite3  database="./test.db"
    Connect To Database Using Custom Params  sqlite3  database="./${query_database}"


    ${query_primary_key}=  Query  select primary_key from primary_key limit 1 ;
    IF  ${query_primary_key}== []
        ${primay_key}=  set variable  1
    ELSE
        ${primary_key}=  set variable  ${query_primary_key}[0][0]
    END 

    ${query_old_kd_value}=  Query  select old_kd_value from old_kd_value where stock_id = '${query_stock_id}' limit 1 ;
    IF  ${query_old_kd_value}== []
        ${output}=  Execute Sql String  INSERT INTO old_kd_value VALUES ( ${query_stock_id}, -1 ) ;
        ${old_kd_value}=  set variable  -1
    ELSE
        ${old_kd_value}=  set variable  ${query_old_kd_value}[0][0]
    END 

#    ${str_start_date}=  set_variable   2023-01-01
#    ${str_end_date}=    set_variable   2024-03-31



    ${output}=    query_output_from_database  '${query_start_date}'  '${query_end_date}'  '${query_stock_id}'
    Log  ${output}

    ${output_k}=    query_output_k_from_database  '${query_start_date}'  '${query_end_date}'  '${query_stock_id}'
    Log  ${output_k}

    ${output_d}=    query_output_d_from_database  '${query_start_date}'  '${query_end_date}'  '${query_stock_id}'
    Log  ${output_d}







  ${strategy_id}=  set variable  1 
#  ${buyin_signal}=  set variable  0
#  ${buyin_signal_volume}=  set variable  0
#  ${buyin_among_NTD}=  set variable  0
  ${class}=  set variable  tw_stock
  ${strategy_in_or_out}=  set variable  in
  ${number_of_share}=  set variable  1000
  ${evaluate_in_strategy_ror}=  set variable  0
  ${estimate_in_stock_ror}=  set variable  0
  ${evaluate_in_buyin_signal}=  set variable  0
  ${estimate_in_buyin_signal}=  set variable  0
  ${null_parent_id}=  set variable  0
  ${evaluate_in_children_id}=  set variable  0

  ${date_length}=  get length  ${output_k}

  FOR  ${i}  IN RANGE  ${date_length}

        log  ${output_k}[${i}]
        log  ${output_d}[${i}]

        log  ${output_k}[${i}][0]
        log  ${output_d}[${i}][0]

    ${date}=  set variable  ${output}[${i}][0]
    ${stock_id}=  set variable  ${output}[${i}][1]
    ${close}=  set variable  ${output}[${i}][7]     
    

        IF  ${output_k}[${i}][0] > ${output_d}[${i}][0]
            IF  ${old_kd_value} <= 0
                ${old_kd_value}=  set variable  1
                ${output}=  Execute sql string  update old_kd_value set old_kd_value=${old_kd_value} where stock_id=${stock_id};  		     
                ${flag_sned_buyin_signal}=  set variable  1 
		


		OperatingSystem.Run  echo "${date} | ${output_k}[${i}][0] > ${output_d}[${i}][0]" >> kd.txt
            ELSE
	        Continue For Loop
            END
	ELSE

            Continue For Loop
        END

     ${old_output_buyin}=  set variable  1
        IF  ${old_output_buyin} == 1
           ${flag_sned_buyin_signal}=  set variable  1   
        END

        IF  ${flag_sned_buyin_signal} == 1
                ${flag_send_buyin_signal}=  set variable  0
                ${buyin_signal}=  set variable  1
                ${buyin_signal_volume}=  set variable  1000
                ${share_amount_price}=  evaluate  ${buyin_signal} * ${close} * ${buyin_signal_volume} 
        END


        ${table_name}=  set variable  strategy_in
                ${primary_key}=  evaluate  ${primary_key} + 1
	

        insert_strategy_data_to_database  ${table_name}  ${primary_key}  ${date}  ${strategy_id}  ${buyin_signal}  ${class}  ${stock_id}  ${strategy_in_or_out}  ${close}  ${number_of_share}  ${share_amount_price}  ${evaluate_in_buyin_signal}  ${estimate_in_buyin_signal}  ${evaluate_in_strategy_ror}  ${estimate_in_stock_ror}  ${null_parent_id}  ${evaluate_in_children_id}  









                ${output}=  Execute sql string  update primary_key set primary_key=${primary_key};     
            










                ${csv_header_string}=  set variable  日期,策略代號,買入訊號,股票代碼,收盤價,成交量,成交金額\n


                ${csv_string}=  set variable  ${date}, ${strategy_id}, ${buyin_signal}, ${stock_id}, ${close}, ${buyin_signal_volume}, ${share_amount_price}\n
                log  ${csv_string}

                post_csv_setdata  stock_csv_new_macd_dif/${strategy_id}_strategy_${date}[0:4].csv  ${csv_header_string}  ${csv_string}  





  END

    Disconnect From Database

    OperatingSystem.Run  echo "primary_key|date|strategy_id|separate_buyin_signal|class|stock_id|strategy_in_or_out|close|number_of_share|share_amount_price|evaluate_in_strategy_ror|estimate_in_stock_ror|evaluate_in_priority_buyin_signal|estimate_in_buyin_signal|null_parent_id|evaluate_in_children_id" > strategy_in.txt                                     

    OperatingSystem.Run  sqlite3 test.db "select primary_key,date,strategy_id,separate_buyin_signal,class,stock_id,strategy_in_or_out,close,number_of_share,share_amount_price,evaluate_in_strategy_ror,estimate_in_stock_ror,evaluate_in_priority_buyin_signal,estimate_in_buyin_signal,null_parent_id,evaluate_in_children_id from strategy_in;" >> strategy_in.txt






















