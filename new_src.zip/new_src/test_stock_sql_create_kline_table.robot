*** Keywords ***
test_stock_sql_create_kline_table
#    [Arguments]  ${start_date}  ${end_date}
    [Documentation]
    [Tags]


    Connect To Database Using Custom Params  sqlite3  database="./test2.db"


                ${table_name}=  set variable  kline
                ${name_1}=      set variable  stock_id
                ${type_1}=      set variable  varchar(1000)
                ${name_2}=      set variable  init_date
                ${type_2}=      set variable  DATE
                ${name_3}=      set variable  history_kline
                ${type_3}=      set variable  varchar(1000000000)




    ${output}=   Execute Sql String     CREATE TABLE ${table_name} ( ${name_1} ${type_1}, ${name_2} ${type_2}, ${name_3} ${type_3} ) ;
    Log  ${output}









