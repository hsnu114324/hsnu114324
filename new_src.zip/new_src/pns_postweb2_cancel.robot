*** Keywords ***
pns_postweb2_cancel
    [Arguments] 	${excel_file_data}  ${CR_no}
	[Documentation]
	[Tags]
#***

    Log  ${excel_file_data}
#***
#	post_postweb2_pnsFrontEndloginChrome  https://pns.post.gov.tw/
	post_postweb2_pnsFrontEndloginChrome  https://pnstest.post.gov.tw/LI.Web/LI0010.aspx
#	post_postweb2_pnsFrontEndloginFirefox  https://pnstest.post.gov.tw/LI.Web/LI0010.aspx


    Debug

#***
	post_postweb2_ClickPnsFrontEndLoginUsername  0963038476
#***
	post_postweb2_ClickPnsFrontEndLoginPassword  Jy99jy88
#***
	Sleep  10s
	post_postweb2_ClickPnsFrontEndLoginEnter
	Sleep  1s
#***

#	post_postweb2_ClickPnsFrontEndMenuList1
#***
#	post_postweb2_ClickPnsFrontEndMenuList1Button2
#***
#	post_postweb2_ClickPnsFrontEndcbConfirm
#***
#	post_postweb2_ClickPnsFrontEndddlNewCity_ddl1  ${excel_file_data}[4]  string
#***
#	post_postweb2_ClickPnsFrontEndddlOldCity_ddl1  ${excel_file_data}[8]  string
#***
#	post_postweb2_ClickPnsFrontEndbtnSend
#***


	post_postweb2_ClickPnsFrontEndMenuList2
#***
	post_postweb2_ClickPnsFrontEndMenuList2Button1
#***  
	post_postweb2_ClickPnsFrontEndbtnQuery

    ${new_CR_no}=  post_postweb2_FetchPnsFrontEndlbtnReqNo_0_1

    IF  '${new_CR_no}' == '${CR_no}'
		post_postweb2_ClickPnsFrontEndlbtnReqNo_0
		post_postweb2_ClickPnsFrontEndCancelbtnSave
	ELSE
		Fail
	END
#***

	[Return]  ${CR_no}