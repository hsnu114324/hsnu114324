*** Keywords ***
#*** Test Cases ***
test_stock3_evaluate_in_module2
#    [Arguments]     ${excel_file_data}  
#    [Arguments]     ${query_start_date}  ${query_end_date}  ${query_stock_id}  ${query_database}
    [Arguments]     ${excel_file_data}  ${query_start_date}  ${query_end_date}  ${query_stock_id}  ${query_database}

    [Documentation]    Load sensor list file and prepare list
    Log    ${excel_file_data}



#    Connect To Database Using Custom Params  sqlite3  database="./test.db"
    Connect To Database Using Custom Params  sqlite3  database="./${query_database}"


#    ${query_start_date}=  set variable  '2024-01-01'
#    ${query_end_date}=    set variable  '2024-04-01'
#    ${query_stock_id}=    set variable  '2330'

#    ${str_start_date}=  set_variable   2023-01-01
#    ${str_end_date}=    set_variable   2024-03-31



    ${output}=    query_output_from_database  '${query_start_date}'  '${query_end_date}'  '${query_stock_id}'
    Log  ${output}

    ${output_k}=    query_output_k_from_database  '${query_start_date}'  '${query_end_date}'  '${query_stock_id}'
    Log  ${output_k}

    ${output_d}=    query_output_d_from_database  '${query_start_date}'  '${query_end_date}'  '${query_stock_id}'
    Log  ${output_d}







  ${strategy_id}=  set variable  1 
#  ${buyin_signal}=  set variable  0
#  ${buyin_signal_volume}=  set variable  0
#  ${buyin_among_NTD}=  set variable  0

  ${estimate_child_id}=  set variable  1 


  ${date_length}=  get length  ${output_k}


            ${list_1}=    post_csv_get_strategy_data    stock_csv_new_macd_dif/1_strategy_2024.csv
            ${length}=  Get length  ${list_1}
            ${length+1}=  evaluate  ${length} + 1


  FOR  ${i}  IN RANGE  ${date_length}

#        log  ${output_k}[${i}]
#        log  ${output_d}[${i}]
#
#        log  ${output_k}[${i}][0]
#        log  ${output_d}[${i}][0]
#
#    ${today_close}=  set variable  ${output}[${i}][7]     
#
#        IF  ${output_k}[${i}][0] > ${output_d}[${i}][0]
#            ${buyin_signal}=  set variable  1
#            ${buyin_signal_volume}=  set variable  1000
#            ${buyin_among_NTD}=  evaluate  ${buyin_signal} * ${today_close} * ${buyin_signal_volume} 
#	ELSE
#            ${buyin_signal}=  set variable  0
#            ${buyin_signal_volume}=  set variable  0
#            ${buyin_among_NTD}=  evaluate  ${buyin_signal} * ${today_close} * ${buyin_signal_volume} 
#        END



    ${today_date}=  set variable  ${output_k}[${i}][1]     
    ${today_stock_id}=  set variable  2330     


####################################################

    ${past_close}=  set variable  0

    ${today_close}=  set variable  1

    ${period_spread}=  set variable  ${today_close} - ${past_close}

    ${evaluate_strategy_ror}=  evaluate  ${period_spread} / ${today_close}

    ${strategy_parent_id}=  set variable  ${list_1}[1][1]
    log  ${strategy_parent_id}

    ${children_id}=  set variable  1
#    set_strategy_table_childrend_id  ${i}  ${children_id}
     post_csv_append_cell_data  stock_csv_new_macd_dif/${strategy_id}_strategy_${today_date}[0:4].csv  test_cell 

####################################################


        ${table_name}=  set variable evaluate_in

        insert_evaluate_in_data_to_database  ${table_name}  ${primary_key}  ${primary_key}  ${date}  ${strategy_id}  ${buyin_signal}  ${stock_id}  ${close}  ${number_of_share}  ${share_amount_price}  ${evaluate_strategy_ror}  ${strategy_in_parent_id}  ${estinate_in_children_id}

















#                ${csv_header_string}=  set variable  日期,策略代號,買入訊號,股票代碼,收盤價,成交量,成交金額,evaluate_strategy_ror,strategy_parent_id,estimate_child_id\n


#                ${csv_string}=  set variable  ${today_date}, ${strategy_id}, ${buyin_signal}, ${today_stock_id}, ${today_close}, ${buyin_signal_volume}, ${buyin_among_NTD},${strategy_parent_id},${estimate_child_id},${evaluate_strategy_ror},${strategy_parent_id},${estimate_child_id}\n
#                log  ${csv_string}

#                post_csv_setdata  stock_csv_new_macd_dif/${strategy_id}_evaluate_in_${today_date}[0:4].csv  ${csv_header_string}  ${csv_string}  





  END

























