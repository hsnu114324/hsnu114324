*** Keywords ***
pnsschedule_sql_create_table
#    [Arguments]  ${start_date}  ${end_date}
    [Documentation]
    [Tags]


    Connect To Database Using Custom Params  sqlite3  database="./test.db"

#	[FILE_BATCH_NO] [varchar](15) NOT NULL,
#	[FILE_ROWID] [char](10) NOT NULL,
#	[BOFF_NO] [char](6) NOT NULL,
#	[ZIP3] [char](3) NOT NULL,
#	[SCHEDULE_TYPE] [char](2) NOT NULL,
#	[TOUR_NO] [char](1) NOT NULL,
#	[TIME_DLV_STA] [char](4) NULL,
#	[TIME_DLV_END] [char](4) NULL,
#	[START_DATE] [date] NULL,
#	[STATUS] [char](3) NULL,
#	[SCHEDULE_STATUS] [char](3) NULL,


                ${table_name}=  set variable  schedule
                ${name_1}=      set variable  FILE_ROWID
                ${type_1}=      set variable  varchar(10)
                ${name_2}=      set variable  BOFF_NO
                ${type_2}=      set variable  varchar(6)
                ${name_3}=      set variable  ZIP3
                ${type_3}=      set variable  varchar(3)
                ${name_4}=      set variable  TIME_DLV_STA_1
                ${type_4}=      set variable  varchar(4)
                ${name_5}=      set variable  TIME_DLV_END_1
                ${type_5}=      set variable  varchar(4)
                ${name_6}=      set variable  TIME_DLV_STA_2
                ${type_6}=      set variable  varchar(4)
                ${name_7}=      set variable  TIME_DLV_END_2
                ${type_7}=      set variable  varchar(4)
                ${name_8}=      set variable  TIME_DLV_STA_3
                ${type_8}=      set variable  varchar(4)
                ${name_9}=      set variable  TIME_DLV_END_3
                ${type_9}=      set variable  varchar(4)
                ${name_10}=     set variable  TIME_DLV_STA_4
                ${type_10}=     set variable  varchar(4)
                ${name_11}=     set variable  TIME_DLV_END_4
                ${type_11}=     set variable  varchar(4)
                ${name_12}=     set variable  SCHEDULE_TYPE
                ${type_12}=     set variable  varchar(2)


    ${output}=   Execute Sql String     CREATE TABLE ${table_name} ( ${name_1} ${type_1}, ${name_2} ${type_2}, ${name_3} ${type_3}, ${name_4} ${type_4}, ${name_5} ${type_5}, ${name_6} ${type_6}, ${name_7} ${type_7}, ${name_8} ${type_8}, ${name_9} ${type_9}, ${name_10} ${type_10}, ${name_11} ${type_11}, ${name_12} ${type_12} ) ;

    Log  ${output}









