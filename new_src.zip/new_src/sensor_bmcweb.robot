*** Keywords ***
sensor_bmcweb
    [Documentation]    Verify Sensors Displayed On bmcweb
    [Tags]    Verify Sensors Displayed On bmcweb
    [Arguments] 	${path_excel}  ${sheet_name}
    Log_To_Console	path_excel : ${path_excel}
    Log_To_Console	sheet_name : ${sheet_name}


    ${sensor_check_list}=  wistron_excel_getdata    ${path_excel}  ${sheet_name} 

	Log_To_Console   ${sensor_check_list}

	wistron_bmcweb_CheckSensor  @{sensor_check_list}
	




