*** Keywords ***
test_stock_sql_create_equity_table
#    [Arguments]  ${start_date}  ${end_date}
    [Documentation]
    [Tags]


    Connect To Database Using Custom Params  sqlite3  database="./test.db"


                ${table_name}=  set variable  equity
                ${name_1}=      set variable  primary_key
                ${type_1}=      set variable  INT
                ${name_2}=      set variable  date
                ${type_2}=      set variable  DATE
                ${name_3}=      set variable  strategy_id
                ${type_3}=      set variable  INT
                ${name_4}=      set variable  buyin_signal
                ${type_4}=      set variable  INT
                ${name_5}=      set variable  class
                ${type_5}=      set variable  varchar(100)
                ${name_6}=      set variable  stock_id
                ${type_6}=      set variable  varchar(100)
                ${name_7}=      set variable  assets_in_or_out
                ${type_7}=      set variable  varchar(100)
                ${name_8}=      set variable  currency
                ${type_8}=      set variable  INT

                ${name_9}=      set variable  exchange_rate
                ${type_9}=      set variable  INT
                ${name_10}=      set variable  currency_amount_NTD
                ${type_10}=      set variable  FLOAT

                ${name_11}=      set variable  evaluate_strategy_ror
                ${type_11}=      set variable  FLOAT
                ${name_12}=      set variable  estimate_stock_ror
                ${type_12}=      set variable  FLOAT
                ${name_13}=      set variable  evaluate_signal
                ${type_13}=      set variable  INT
                ${name_14}=      set variable  estimate_signal
                ${type_14}=      set variable  INT
                ${name_15}=      set variable  estimate_parent_id
                ${type_15}=      set variable  INT
                ${name_16}=      set variable  strategy_out_children_id
                ${type_16}=      set variable  INT

    ${output}=   Execute Sql String     CREATE TABLE ${table_name} ( ${name_1} ${type_1}, ${name_2} ${type_2}, ${name_3} ${type_3}, ${name_4} ${type_4}, ${name_5} ${type_5}, ${name_6} ${type_6}, ${name_7} ${type_7}, ${name_8} ${type_8}, ${name_9} ${type_9}, ${name_10} ${type_10}, ${name_11} ${type_11}, ${name_12} ${type_12}, ${name_13} ${type_13}, ${name_14} ${type_14}, ${name_15} ${type_15}, ${name_16} ${type_16} ) ;

    Log  ${output}









