*** Keywords ***
pnstestmail_sql_remove2
#    [Arguments]    ${excel_file_data}
    [Documentation]
    [Tags]
    Connect To Database
    ...    pymssql
    ...    dbName=DLIQSERV
    ...    dbUsername=DLIQTASK
    ...    dbPassword=DLIQTASK3817
    ...    dbHost=10.201.52.130
    ...    dbPort=1433


    ${Q_SID_value}=  set variable  '08FBANRss8S'
    ${testmail_no}=  set variable  '111611121200000004'

    ${output}=    Query    SELECT * FROM QuestData WHERE Q_SID = ${Q_SID_value};
    Log_To_Console  ${output}

    IF  ${output} != []

        ${output}=    Execute Sql String    delete　from QuestData where Q_SID = ${Q_SID_value};
        Log_To_Console  ${output}
        ${output}=    Execute Sql String    delete from QuestMain where Q_SID = ${Q_SID_value};
        Log_To_Console  ${output}
        ${output}=    Execute Sql String    delete from T_QUESTREPORT where DID = ${testmail_no};
        Log_To_Console  ${output}
        ${output}=    Execute Sql String    DELETE　from T_QUESTREPORT_LOG where DID = ${testmail_no};
        Log_To_Console  ${output}

    ELSE
        Sleep  1ms
    END
