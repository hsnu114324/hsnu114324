*** Settings ***
Library  OperatingSystem
Library  ExcelLibrary
Library  String
Library  Collections
Library  CSVLibrary
Library  DateTime
Library  DatabaseLibrary
Resource  Common/common_stock.robot
Resource  Common/common_finmind.robot


*** Variables ***
@{stock_list}    @{EMPTY}


#*** Keywords ***
*** Test Cases ***
test_stock_standardRSIgenChart3





    Connect To Database Using Custom Params  sqlite3  database="./test.db"


    ${str_start_date}=  set_variable   2023-01-01
    ${str_end_date}=    set_variable   2024-03-31








 
    Remove_File  chart5.html
   



    ${chartjs5file1_content}=  Get_file  chartjs5file1_RSI.txt

    append_to_file  chart5.html  ${chartjs5file1_content}







#    ${date_range}=  finmind_GetDateRange  ${start_date}  ${end_date}



#    FOR  ${date}  IN  @{date_range}


#        ${output_date}=    Query    SELECT DATE FROM daily_stock WHERE stock_id = '2330' AND date between '${str_start_date}' and '${str_end_date}';
#        Log  ${output_date}

#        IF  ${output_date} == []
#           CONTINUE FOR LOOP
#        END


        ${output_content}=    Query    SELECT DATE,stock_id,open,max,min,close,Trading_turnover FROM daily_stock WHERE stock_id = '2330' and DATE between '${str_start_date}' and '${str_end_date}' order by date ;
        Log  ${output_content}


        ${output_length}=  get length  ${output_content}


#        append_to_file  chart5.html  ['${list_1_j}[0]', '${list_1_j}[1]', ${list_1_j}[4], ${list_1_j}[5], ${list_1_j}[6], ${list_1_j}[7], ${list_1_j}[9]],\n

    FOR  ${i}  IN RANGE  0  ${output_length}

        append_to_file  chart5.html  ['${output_content}[${i}][0]', '${output_content}[${i}][1]', ${output_content}[${i}][2], ${output_content}[${i}][3], ${output_content}[${i}][4], ${output_content}[${i}][5], ${output_content}[${i}][6]],\n



    END


    ${chartjs5file3_content}=  Get_file  chartjs5file3.txt

    append_to_file  chart5.html  ${chartjs5file3_content}

    append_to_file  chart5.html  '${output_content}[0][1]'

    ${chartjs5file5_content}=  Get_file  chartjs5file5_RSI.txt

    append_to_file  chart5.html  ${chartjs5file5_content}



