*** Keywords ***
pns_postweb2_LI4020_applyR
    [Arguments] 	${excel_file_data}
	[Documentation]
	[Tags]
#***

    Log  ${excel_file_data}

	post_postweb2_pnsBackEndlogin  https://pnstest.post.gov.tw/LI.adm/Login.aspx
#***
#	post_postweb2_ClickPnsBackEndLoginUsername   ${user_no}
	post_postweb2_ClickPnsBackEndLoginUsername   714838

	post_postweb2_ClickPnsBackEndLoginEnter
	Sleep  1s  
#***
	post_postweb2_ClickPnsBackEndtvFunctionti  代申請作業

#***
	post_postweb2_ClickPnsBackEndtvFunctiontj  LI4020
#***
#	post_postweb2_ClickPnsBackEndTextBox


	post_postweb2_ClickPnsBackEndddlNewCity_ddl1  ${excel_file_data}[1]  ${excel_file_data}[2]  ${excel_file_data}[3]  ${excel_file_data}[4]  post
#   string or object or post


	post_postweb2_ClickPnsBackEndddlOldCity_ddl1  ${excel_file_data}[5]  ${excel_file_data}[6]  ${excel_file_data}[7]  ${excel_file_data}[8]  post
#   string or object


#	post_postweb2_ClickPnsBackEndddlEffectiveDate  ${excel_file_data}[16]  ${excel_file_data}[17]


#***
#	post_postweb2_ClickPnsFrontEndddlOldCity_ddl1  ${excel_file_data}[8]
#***




#    Debug


	post_postweb2_ClickPnsBackEndbtnSend
#***


	post_postweb2_ClickPnsBackEndtvFunctionti  查詢列印作業

#***
	post_postweb2_ClickPnsBackEndtvFunctiontj  LI5010
#***  
	post_postweb2_ClickPnsBackEndbtnQuery
#	//*[@id="ContentPlaceHolder1_btnQuery"]

    ${CR_no}=  post_postweb2_FetchPnsBackEndLinkButton_0
#    ${CR_no}=  post_postweb2_FetchPnsFrontEndlbtnReqNo_0

#	post_postweb2_ClickPnsFrontEndlbtnReqNo_0
#	post_postweb2_ClickPnsFrontEndCancelbtnSave
#***

	[Return]  ${CR_no}