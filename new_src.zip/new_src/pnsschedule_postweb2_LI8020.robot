#*** Settings ***
#
#Library  RequestsLibrary
#Library  Collections
#Library  SeleniumLibrary
#Library  String
##Library  SoapLibrary
#Library  OperatingSystem
#Library  XML
#Library  json
#Library  ExcelLibrary
#Library  DateTime
#Library  Browser
#Resource  Common/common_excel.robot
#Resource  Common/common_request.robot
#Resource  Common/common_postweb2.robot








#*** Test Cases ***
*** Keywords ***

pnsschedule_postweb2_LI8020

    [Arguments]  ${user_id}  ${date}  ${schedule_type}  ${dir_download}  ${source_excel_file}  ${source_excel_sheetname}  
#    [Arguments]  ${user_id}  ${date}  ${schedule_type}  ${dir_download}  ${source_excel_file}  ${source_excel_sheetname}  ${download_excel_file}  ${download_excel_sheetname}


#    post_postweb2_pnsBackEndlogin    https://pnstest.post.gov.tw/LI.adm/Login.aspx
#
##    post_postweb2_ClickPnsBackEndLoginUsername    714838
#    post_postweb2_ClickPnsBackEndLoginUsername    ${user_id}
#    post_postweb2_ClickPnsBackEndLoginEnter
#
#        post_postweb2_ClickPnsBackEndtvFunctiont27
##***
#        post_postweb2_ClickPnsBackEndtvFunctiont28
#
##	post_postweb2_ClickPnsBackEndDateStart_CalTextBox    113/05/31
#	post_postweb2_ClickPnsBackEndDateStart_CalTextBox    ${date}
#
##        post_postweb2_ClickPnsBackEndddlScheduleType_ddl1    WD 
#        post_postweb2_ClickPnsBackEndddlScheduleType_ddl1    ${schedule_type} 
#
#########################
#
##    ${dir_download}=  set variable     C:/Users/714838/Downloads/new_src/Excel
##    Remove Files  ${dir_download}${/}LI8010_download.xlsx
#    Remove Files  ${dir_download}${/}${download_excel_file}
##    Promise To Wait For Download  saveAs=${dir_download}/LI8010_download.xlsx 
#    Promise To Wait For Download  saveAs=${dir_download}/${download_excel_file} 
#########################
#    post_postweb2_ClickPnsBackEndContent1_btnDownload
#    Sleep  1s
#
##    post_excel_compareexcel  LI8010.xlsx  投遞班次時刻表
##    post_excel_compareexcel_old  ${source_excel_file}  ${source_excel_sheetname}  ${download_excel_file}  ${download_excel_sheetname} 
#    post_excel_compareexcel  ${source_excel_file}  ${source_excel_sheetname}  ${download_excel_file}  ${download_excel_sheetname} 

#    post_excel_comparejson  LI8010.xlsx  投遞班次時刻表
#    post_excel_comparejson_old  ${schedule_type}  ${source_Excel_file}  ${source_excel_sheetname}   
    post_excel_comparejson  ${schedule_type}  ${source_Excel_file}  ${source_excel_sheetname}   


