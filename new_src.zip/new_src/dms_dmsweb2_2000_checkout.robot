*** Keywords ***
dms_dmsweb2_2000_checkout
    [Arguments]  ${excel_file_data}
#    [Arguments] 	${ACC_DATE}  ${TOUR_NO}  ${CAR_NO}  ${RCV_STAFF_ID}  ${RCV_KIND}  ${CUS_PH_NO}  ${SND_TEL}  ${BNS_TYPE}  ${ZIP_CODE}  ${SPL_OFFICE}  ${MAIL_NO}  ${MAIL_LENGTH}  ${MAIL_WIDTH}  ${MAIL_HEIGHT}  ${MAIL_WEIGHT}  ${DST_NT_CODE}  ${MAIL_TYPE}  ${DSN_TYPE}  ${MAIL_TYPE1}  ${ISR_CHARGE}  ${PAY_CASH_AMT}  ${PAY_POSTAL_AMT}  ${PAY_STMP_AMT}  ${MON_PAY}  ${CustomsFlag}  ${RCV_TEL}  ${TOL_POSTAL}  
#  ${MON_PAY}
	[Documentation]
	[Tags]
#***

    Log  ${excel_file_data}
#    Log  ${ACC_DATE} ${TOUR_NO} ${CAR_NO} ${RCV_STAFF_ID} ${RCV_KIND} ${CUS_PH_NO} ${SND_TEL} ${BNS_TYPE} ${ZIP_CODE} ${SPL_OFFICE} ${MAIL_NO} ${MAIL_LENGTH} ${MAIL_WIDTH} ${MAIL_HEIGHT} ${MAIL_WEIGHT} ${DST_NT_CODE} ${MAIL_TYPE} ${DSN_TYPE} ${MAIL_TYPE1} ${ISR_CHARGE} ${PAY_CASH_AMT} ${PAY_POSTAL_AMT} ${PAY_STMP_AMT} ${CustomsFlag} ${RCV_TEL} ${TOL_POSTAL}
#***
	dms_postweb2_pnsFrontEndloginChrome  http://localhost:3000/
#	post_postweb2_pnsFrontEndloginFirefox  https://pnstest.post.gov.tw/LI.Web/LI0010.aspx


#    Debug

    dms_dmsweb2_ClickDmsFrontEnduserID_login

	dms_dmsweb2_ClickDmsFrontEndMenuButton
#***
	dms_dmsweb2_ClickDmsFrontEndMenu_ListOP1
#***
	dms_dmsweb2_ClickDmsFrontEndMenu_ListOP1_2000
#***

    Take Screenshot

	dms_dmsweb2_ClickDmsFrontEnd_2000ACC_DATE  ${excel_file_data}[1]
#***
	dms_dmsweb2_ClickDmsFrontEnd_2000TOUR_NO  ${excel_file_data}[2]
#***
    dms_dmsweb2_ClickDmsFrontEnd_2000STAFF_NO
#	${MLIST_NO}  ${MLIST_STATE}=  dms_dmsweb2_ClickDmsFrontEnd_2000FetchButton
#    Log  ${MLIST_NO} ${MLIST_STATE}


	dms_dmsweb2_ClickDmsFrontEnd_2000FetchButton  

#    Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[1]






    Take Screenshot
    
    ${match1}  ${match2}=    dms_dmsweb2_DmsFrontEnd_2000_stage1_1  ${excel_file_data}    checkout    2000

    Log  ${match1}
    Log  ${match2}

    ${match2}  ${match3}=    dms_dmsweb2_DmsFrontEnd_2000_stage1_i  ${match2}  ${excel_file_data}    checkout  2900

    Log  ${match2}
    Log  ${match3}





#***
#    Debug
#***


	

 

    dms_dmsweb2_ClickDmsFrontEnduserID_logout 

    Sleep  3s

#	RETURN  ${CR_no}
