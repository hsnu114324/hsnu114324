*** Settings ***

Library  RequestsLibrary
Library  Collections
Library  SeleniumLibrary
Library  String
#Library  SoapLibrary
Library  OperatingSystem
Library  XML








*** Test Cases ***

pnstestmail_revoke_api


    ${base_url}=  set variable   http://10.201.52.149
#    ${base_url}=  set variable   https://ctewsp.post.gov.tw/
#    ${base_url}=  set variable   https://172.17.2.58
#    ${base_url}=  set variable   http://172.17.2.58
#    ${base_url}=  set variable   https://10.201.51.65

    ${channel_url}=  set variable  /QuestWebApi4Dms/QuestGetSID/GetSID
#    ${channel_url}=  set variable  /PSTPT.WebService/PSTPT_WebService.asmx
#    ${channel_url}=  set variable  /PSTPT/PSTPT_WebService.asmx

    create session  deleteemail    ${base_url}     

    #Create a dynamic messageId
    ${rand_MessageID}=  generate random string  5  [NUMBERS]

    #Set a request variable
     ${SOAP_XML}=   set variable  {"QUEST_SID":[{"Q_SID":"08FBAXbGiyX"},{"Q_SID":"08FBAXbGiyY"},{"Q_SID":"08FMWPmJXkj"},{"Q_SID":"08FMWPmJXkk"}]}
#    ${SOAP_XML}=   set variable  <?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body> <TransferForAddress33Object xmlns="http://tempuri.org/"> <City>臺北市</City> <Area>士林區</Area> <Road>長安東路二段</Road> <Lane></Lane> <Alley></Alley> <No>225</No> </TransferForAddress33Object> </soap:Body> </soap:Envelope>



    log  ${SOAP_XML}

    ${SOAP_XML_UTF8}=  evaluate   '${SOAP_XML}'.encode("utf-8")

    log  ${SOAP_XML_UTF8}

    #Create Request Headers
    ${request_header}=    create dictionary    Content-Type=application/json; charset=utf-8   
#    ${request_header}=    create dictionary    Content-Type=text/xml; charset=utf-8   User-Agent=Apache-HttpClient/4.1.1

    #Send the XML request body
    ${SAVE_Response}=    Post Request    deleteemail    ${channel_url}    headers=${request_header}    data=${SOAP_XML_UTF8}

    #Log Response and Status Code Details
    log to console    ${SAVE_Response.status_code}
    log    ${SAVE_Response.headers}
    log    ${SAVE_Response.content}
    log    ${SOAP_XML}


#    ${XML}=  parse xml  ${SAVE_Response.content}
    ${XML}=  parse xml   	<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema"><soap:Body><TransferForAddress33StringResponse xmlns="http://tempuri.org/"><TransferForAddress33StringResult>No. 216, Aiguo E. Rd., Da\xe2\x80\x99an Dist., Taipei City 106201, Taiwan (R.O.C.)</TransferForAddress33StringResult></TransferForAddress33StringResponse></soap:Body></soap:Envelope>
    Save Xml   ${XML}   1.xml
#    ${XML1}=    Get Element  ${XML}  TransferForAddress33StringResponse
    ${children} =	Get Child Elements	${XML}	
    ${children_length}=  get length  ${children}
    FOR  ${i}  IN RANGE  0  ${children_length}  1
         ${children_val}=  set variable  ${children}[0]
    END
#   ${child1} =	        Get Element	${XML}	Body
    ${child1} =	        Get Element	${XML}	${children}[0]
    ${child2} =	Get Child Elements	${child1}	
    ${child3} =	Get Child Elements	${child2}	
    ${child4} =	Get Child Elements	${child3}	
    ${child5} =	Get Child Elements	${child4}	


