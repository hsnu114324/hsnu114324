*** Keywords ***
pns_postweb2_LI3010_assign
    [Arguments] 	${assigner_no}  ${path_excel}  ${sheet_name}  ${CR_no}
	[Documentation]
	[Tags]
#***

    Log 	assigner_no : ${assigner_no}
    Log 	path_excel : ${path_excel}
    Log 	sheet_name : ${sheet_name}

    ${sensor_check_list}=  post_excel_getdata_for_assign   ${assigner_no}  ${path_excel}  ${sheet_name} 

    ${list_count} =    Get length    ${sensor_check_list}
    Log_To_Console   list_count ${list_count}
	Log_To_Console   ${sensor_check_list}

    FOR  ${sensor_name}  IN  @{sensor_check_list}

		Log   sensor_name: ${sensor_name}
		Log   ${sensor_name}[0]

    END

#***

	post_postweb2_pnsBackEndlogin  https://pnstest.post.gov.tw/LI.adm/Login.aspx
#***
	post_postweb2_ClickPnsBackEndLoginUsername  ${sensor_name}[0]
#	post_postweb2_ClickPnsBackEndLoginUsername  174646
#	#165406
#***
	post_postweb2_ClickPnsBackEndLoginEnter
	Sleep  1s  
#***
	post_postweb2_ClickPnsBackEndtvFunctionti  查證作業
#***
	post_postweb2_ClickPnsBackEndtvFunctiontj  LI3010
#***
	post_postweb2_ClickPnsBackEndContent1_ddlVerificationOffice_ddl1  ${sensor_name}[2]
#***
	post_postweb2_ClickPnsBackEndContent1_btnQuery
#***
	post_postweb2_CheckPnsBackEndContent1_gvList_LinkButton_0   ${CR_no}
	post_postweb2_ClickPnsBackEndContent1_gvList_LinkButton_0
#***
    post_postweb2_ClickPnsBackEndContent1_fvw_ddl1_ddl1  ${sensor_name}[2]
#***
    post_postweb2_ClickPnsBackEndContent1_fvw_ddl2_ddl1  ${sensor_name}[4]

#***
    post_postweb2_ClickPnsBackEndContent1_fvw_btnSave
#***
#	post_postweb2_ClickPnsBackEndContent1_fvw1_btnFvwPrint_btnPrint
#***
#        Sleep  10

#        ${titles}  Get Window Titles
#        Log_To_Console  all_titles: ${titles}
#        ${titles2}      Get From List   ${titles}   1
#        Log_To_Console  titles_2: ${titles2}
#        ${titles1}      Get From List   ${titles}   0
#        Log_To_Console  titles_1: ${titles1}
#        Switch Window    title=${titles2}


#	pns_postweb_logout
#***
#	pns_postweb_logout
#***
#	pns_postweb_logout
#***
#	pns_postweb_logout
#***
#	pns_postweb_logout


