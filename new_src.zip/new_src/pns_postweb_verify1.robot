*** Keywords ***
pns_postweb_verify1
	[Documentation]
	[Tags]
#***




	post_postweb_pnsBackEndlogin  https://pnstest.post.gov.tw/LI.adm/Login.aspx
#***
	post_postweb_ClickPnsBackEndLoginUsername  174646
#	#165406
#***
	post_postweb_ClickPnsBackEndLoginEnter
	Sleep  1s  
#***
	post_postweb_ClickPnsBackEndtvFunctiont1
#***
	post_postweb_ClickPnsBackEndtvFunctiont3
#***
	post_postweb_ClickPnsBackEndContent1_btnQuery
#***
	post_postweb_ClickPnsBackEndContent1_gvList_LinkButton_0
#***	
        Select_Frame     ${xpath_pnsBackEndSelectFrame2}
        ${test1_message}  ${message}=  Run_Keyword_And_Ignore_Error  Element_Should_Be_Enabled    ${xpath_pnsBackEndContent1_fvw1_btnFvwChange}
        Unselect_Frame
        Log  ${test1_message}
        Log  ${message}

        ${HavePrint_match}  ${message}=  Run_Keyword_And_Ignore_Error  post_postweb_CheckPnsBackEndContent1_HavePrint
        Log  ${HavePrint_match}
        Log  ${message}

	IF	'${HavePrint_match}' == 'PASS'
	    Sleep  1
	ELSE IF	 '${HavePrint_match}' == 'FAIL'
            post_postweb_ClickPnsBackEndContent1_fvw1Print
	END

#***
        post_postweb_ClickPnsBackEndContent1_fvw1_ResultStateSuccess
#***
 
        ${HaveUploadPicture_match}  ${message}=  Run Keyword And Ignore Error  post_postweb_CheckPnsBackEndContent1_HaveUploadPicture

        Log  ${HaveUploadPicture_match}
        Log  ${message}

	IF	'${HaveUploadPicture_match}' == 'PASS'

            Sleep  10

	ELSE IF	 '${HaveUploadPicture_match}' == 'FAIL'

            Log_To_Console  ChooseVerifyPicture start
            Sleep  10
            post_postweb_ChooseVerifyPicture
            Log_To_Console  ChooseVerifyPicture end

            Log_To_Console  fvw1_btnUpload start
            Sleep  10
            post_postweb_ClickPnsBackEndContent1_fvw1_btnUpload
            Log_To_Console  fvw1_btnUpload end

	END



#***

#***
        Log_To_Console  btnFvwSave start
        Sleep  10
	post_postweb_ClickPnsBackEndContent1_btnFvwSave
        Log_To_Console  btnFvwSave end
#***
        Sleep  10

#        ${titles}  Get Window Titles
#        Log_To_Console  all_titles: ${titles}
#        ${titles2}      Get From List   ${titles}   1
#        Log_To_Console  titles_2: ${titles2}
#        ${titles1}      Get From List   ${titles}   0
#        Log_To_Console  titles_1: ${titles1}
#        Switch Window    title=${titles2}





