*** Variables ***

*** Keywords ***
fin_csv_backtesting2




    [Arguments]     ${old_stock_price_csv_filepath}  ${date} ${stock_no} ${stock_price}  ${stock_lot}
    Log   ${old_stock_price_csv_filepath} 
    Log   ${date}
    Log   ${stock_no}
    Log   ${stock_price}
    Log   ${stock_lot}


        ${total_buy_money}=  set variable  0  
        ${total_buy_money}=  evaluate  ${stock_price}*${stock_lot}  

        ${cash_total}=  set variable  10000

        IF  ${total_buy_money} > ${cash_total}
        Fail
    END

            ${old_csv_content}=    Get File    ${old_stock_price_csv_filepath}    encoding=UTF-8-SIG    encoding_errors=strict

            @{old_csv_content_list}=  Read Csv String To List  ${old_csv_content}
            ${old_csv_content_count}=    Get length    ${old_csv_content_list}

            ${old_csv_content_count_1}=  Evaluate  ${old_csv_content_count}-1

            ${old_csv_content_array}=  get_from_list  ${old_csv_content_list}  ${old_csv_content_count_1}

            log  ${old_csv_content_array}
            log  ${old_csv_content_array}[2]

            IF  '${stock_price}' < '${old_csv_content_array}[2]'
            Fail
        END





                        ${file_exists}=  Run Keyword And Return Status  OperatingSystem.File_Should_Exist   stock_lot.csv

                IF  '${file_exists}' == 'False'
                    Copy File  lvr_landcsv/a_lvr_land_a_header.csv  591_csv/${ii}_lvr_land_a_gps_${s1_substring}[3:6]_${s2_substring}[4:7].csv
                END



            ${csv_string}=  set variable  ${empty}
            ${str_s1_by_array}=   Evaluate  ",".join(${s1_by_array})

            ${csv_string}=  set variable  ${str_s1_by_array}\n
            log  ${csv_string}

            Append To File   stock_lot.csv  ${csv_string}



















