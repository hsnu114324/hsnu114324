*** Keywords ***
dms_dmsweb2_2300_c
    [Arguments]  ${excel_file_data}

	[Documentation]
	[Tags]
#***

    Log  ${excel_file_data}

#***
	dms_postweb2_pnsFrontEndloginChrome  http://localhost:3000/
#	post_postweb2_pnsFrontEndloginFirefox  https://pnstest.post.gov.tw/LI.Web/LI0010.aspx


#    Debug

    dms_dmsweb2_ClickDmsFrontEnduserID_login

	dms_dmsweb2_ClickDmsFrontEndMenuButton
#***
	dms_dmsweb2_ClickDmsFrontEndMenu_ListOP1
#***
	dms_dmsweb2_ClickDmsFrontEndMenu_ListOP1_2300
#***
	dms_dmsweb2_ClickDmsFrontEnd_2000ACC_DATE  ${excel_file_data}[1]
#***
	dms_dmsweb2_ClickDmsFrontEnd_2000TOUR_NO  ${excel_file_data}[2]
#***
    dms_dmsweb2_ClickDmsFrontEnd_2000STAFF_NO
#	${MLIST_NO}  ${MLIST_STATE}=  dms_dmsweb2_ClickDmsFrontEnd_2000FetchButton
#    Log  ${MLIST_NO} ${MLIST_STATE}


	dms_dmsweb2_ClickDmsFrontEnd_2000FetchButton  

#    Click    xpath=//*[@id="__nuxt"]/div/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/div[2]/div[2]/table/tbody/tr[1]











        ${match1}  ${match2}=    dms_dmsweb2_DmsFrontEnd_2300_stage1_1  ${excel_file_data}  

        ${match2}  ${match3}=    dms_dmsweb2_DmsFrontEnd_2300_stage1_i  ${match2}  ${excel_file_data}    
	    



	IF	'${match2}' == 'False'

	    dms_dmsweb2_DmsFrontEnd_2300_stage1_c       ${excel_file_data}

		Take Screenshot


	END

	

 

    dms_dmsweb2_ClickDmsFrontEnduserID_logout 

    Sleep  3s

#	Return  ${CR_no}
