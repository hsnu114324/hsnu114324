*** Variables ***
${EventLength_TargetVal}   3000
${xpath_event_count}    xpath=//*[@id="timeline"]/table/tbody/tr/td[1]

*** Keywords ***

sel_full_for_luna
	[Documentation]
	[Tags]

###
#	wistron_ipmi_fullsel

###
	wistron_bmcweb_login
	wistron_bmcweb_GoAndCheckSELEventPage

###

	Wait Until Page Contains Element  ${xpath_event_count}
	${event_count}=    Get Text    ${xpath_event_count}
        Log_To_Console    event_count ${event_count}
	${EventLength_Val}=  Set Variable  ${event_count}
	Should Be True    ${EventLength_Val} > ${EventLength_TargetVal}


	wistron_bmcweb_logout
