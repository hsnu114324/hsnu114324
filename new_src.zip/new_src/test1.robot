*** Variables ***
${SOL_BIOS_OUTPUT}    ubuntu
${IPMI_SOL_LOG_FILE}    IPMI_SOL_LOG_FILE.txt

*** Keywords ***
test1
    [Arguments]     ${param1}


    ${status1}=  Run Keyword And Return Status    Compare Images   ${local_path}/${Picture_folder_path}/nvidia.png    test_sol_01.png
    Log To Console	status1 ${status1}

    ${status2}=  Run Keyword And Return Status    Compare Images   ${local_path}/${Picture_folder_path}/sol_01.png    test_sol_01.png
    Log To Console	status2 ${status2}

    ${status3}=  Run Keyword And Return Status    Compare Images   ${local_path}/${Picture_folder_path}/sol_01.png    ${local_path}/${Picture_folder_path}/sol_01.png 
    Log To Console	status3 ${status3}



    RETURN  hello




















