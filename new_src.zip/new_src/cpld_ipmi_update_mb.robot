*** Keywords ***
cpld_ipmi_update_mb

	wistron_bmcweb_logout
###
  FOR  ${i}  IN RANGE  2

	${CpldVersion}=   wistron_ipmi_GetMBCpldVersion
        Log_To_Console  CpldVerion ${CpldVersion}

	${CpldVersion_match}=	Get Regexp Matches	${CpldVersion}		40
	IF	${CpldVersion_match}
		${CpldVersion_major}	Set Variable	${EMPTY}
		${CpldVersion_major}	Set Variable	60
		Log_To_Console  CpldVersion_major ${CpldVersion_major}
		Log_To_Console  ${CpldVersion}
		Log_To_Console  Update UT20_MB_CPLD_v006_enc.hpm
		wistron_ipmi_updatecpld_mb  UT20_MB_CPLD_v006_enc.hpm 
	ELSE
		${CpldVersion_major}	Set Variable	${EMPTY}
		${CpldVersion_major}	Set Variable	40
		Log_To_Console  CpldVersion_major ${CpldVersion_major}
		Log_To_Console  ${CpldVersion}
		Log_To_Console  Update UT20_MB_CPLD_v004_enc.hpm
		wistron_ipmi_updatecpld_mb  UT20_MB_CPLD_v004_enc.hpm 
	END


###

	${target_CpldVersion}=   wistron_ipmi_GetMBCpldVersion
    	Should Be Equal    ${target_CpldVersion}    ${CpldVersion_Major}

  END



